# ISKRA Export v1 — Spec
Structure: archive/entries.md, archive/weave.json, archive/shadow_agg.json, meta/export_meta.json.
Shadow texts are never exported — aggregates only.
