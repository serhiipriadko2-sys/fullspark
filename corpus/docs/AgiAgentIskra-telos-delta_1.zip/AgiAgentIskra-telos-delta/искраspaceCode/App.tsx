import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { RhythmIndex } from './components/RhythmIndex';
import { AiInsight } from './components/AiInsight';
import { DuoConnection } from './components/DuoConnection';
import { Journal } from './components/Journal';
import { Rituals } from './components/Rituals';
import { Quests } from './components/Quests';
import { WeeklyReview } from './components/WeeklyReview';
import { IskraCore } from './components/IskraCore';
import { SmartAlarm } from './components/SmartAlarm';
import { Canvas } from './components/Canvas';
import { Presentation } from './components/Presentation';
import { Chat } from './components/Chat';
import { MorningRitualPrompt } from './components/MorningRitualPrompt';
import { Agenda } from './components/Agenda';
import { AdaptiveHeader } from './components/AdaptiveHeader';
import { TopTasks } from './components/TopTasks';
import { QuickActions } from './components/QuickActions';
import { More } from './components/More';
import { UserGuide } from './components/UserGuide';
import type { RhythmData, AiInsightData, Task, Habit, JournalEntry, IskraState, Partner, Ritual, Quest, Achievement, WeeklySummary, View, CognitiveState } from './types';
import { getAiInsight, getWeeklySummary, parseTaskFromString } from './services/geminiService';
import { playSound } from './services/soundService';


const initialRhythmData: RhythmData = {
    focus: { name: 'Фокус', value: 90, icon: '🎯', color: '#3EA8FF' },
    sleep: { name: 'Сон', value: 85, icon: '🛌', color: '#8B5CF6' },
    habits: { name: 'Привычки', value: 75, icon: '🔄', color: '#40C463' },
    energy: { name: 'Энергия', value: 60, icon: '💭', color: '#FFC700' },
};

const initialIskraState: IskraState = {
    trust: { description: 'Доверие', value: 85, color: '#40C463' },
    clarity: { description: 'Ясность', value: 90, color: '#3EA8FF' },
    drift: { description: 'Дрейф', value: 10, color: '#FFC700' },
    pain: { description: 'Боль', value: 15, color: '#FF8A00' },
    chaos: { description: 'Хаос', value: 5, color: '#FF4D4F' },
    phase: 'Ясность',
};

const initialTasks: Task[] = [
    { id: 1, text: "Подготовить презентацию", completed: false, priority: 'High', dueDate: new Date().toISOString().split('T')[0], ritualMark: '☉' },
    { id: 2, text: "Позвонить маме", completed: true, priority: 'Medium', dueDate: new Date().toISOString().split('T')[0], ritualMark: '≈' },
    { id: 3, text: "30 мин бега", completed: false, priority: 'Medium', dueDate: new Date().toISOString().split('T')[0], ritualMark: '🜂' },
    { id: 4, text: "Запланировать отпуск", completed: false, priority: 'Low', dueDate: new Date().toISOString().split('T')[0], ritualMark: '∆' },
];

const initialHabits: Habit[] = [
    { id: 1, text: "Пить стакан воды утром", completed: true },
    { id: 2, text: "Вечернее чтение", completed: false },
];

const initialQuests: Quest[] = [
    { id: 'q1', title: 'Утренний ритуал', description: 'Завершите 3 задачи до полудня.', type: 'daily', scope: 'personal', progress: 1, goal: 3, isComplete: false },
    { id: 'q2', title: 'Неделя фокуса', description: 'Завершите 10 задач с высоким приоритетом.', type: 'weekly', scope: 'personal', progress: 4, goal: 10, isComplete: false },
    { id: 'q3', title: 'Совместная тренировка', description: 'Проведите 3 совместные тренировки.', type: 'weekly', scope: 'duo', progress: 1, goal: 3, isComplete: false },
];

const initialAchievements: Achievement[] = [
     { id: 'a1', title: 'Первый шаг', description: 'Завершить первую задачу.', symbol: '🌱', isUnlocked: true },
     { id: 'a2', title: 'Недельный спринт', description: 'Завершить все задачи недели.', symbol: '🏆', isUnlocked: false },
     { id: 'a3', title: 'Мастер привычек', description: 'Выполнять все привычки 7 дней подряд.', symbol: '🧘', isUnlocked: false },
];

const getCognitiveState = (): CognitiveState => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 18) return 'focus';
    if (hour >= 18 && hour < 22) return 'evening';
    return 'rest';
};

const App: React.FC = () => {
    // State management
    const [rhythmData, setRhythmData] = useState<RhythmData>(initialRhythmData);
    const [iskraState, setIskraState] = useState<IskraState>(initialIskraState);
    const [aiInsight, setAiInsight] = useState<AiInsightData | null>(null);
    const [isLoadingInsight, setIsLoadingInsight] = useState(true);
    const [tasks, setTasks] = useState<Task[]>(initialTasks);
    const [habits, setHabits] = useState<Habit[]>(initialHabits);
    const [journalEntries, setJournalEntries] = useState<JournalEntry[]>([]);
    const [rituals, setRituals] = useState<Ritual[]>([]);
    const [quests, setQuests] = useState<Quest[]>(initialQuests);
    const [achievements, setAchievements] = useState<Achievement[]>(initialAchievements);
    const [weeklySummary, setWeeklySummary] = useState<WeeklySummary | null>(null);
    const [isLoadingSummary, setIsLoadingSummary] = useState(false);
    
    const [activeView, setActiveView] = useState<View>('main');
    const [showChat, setShowChat] = useState(false);
    const [showMorningRitual, setShowMorningRitual] = useState(() => new Date().getHours() < 12);
    const [activeRitual, setActiveRitual] = useState<Ritual | null>(null);

    // Mock data
    const currentUser = { id: 'user1', name: 'Вы' };
    const partner: Partner = { id: 'user2', name: 'Анна', statusEmoji: '😊', rhythmIndex: 88, sleep: '7.2ч' };

    const calculateOverallScore = (data: RhythmData) => {
        const values = Object.values(data).map(d => d.value);
        return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
    };

    const overallScore = calculateOverallScore(rhythmData);

    const fetchInsight = useCallback(async () => {
        setIsLoadingInsight(true);
        try {
            const insight = await getAiInsight(rhythmData, iskraState);
            setAiInsight(insight);
            if(insight) playSound('insightReceived');
        } catch (error) {
            console.error(error);
            setAiInsight(null);
        } finally {
            setIsLoadingInsight(false);
        }
    }, [rhythmData, iskraState]);


    useEffect(() => {
        fetchInsight();
    }, [fetchInsight]);
    
    // Dynamic Quest & Achievement Updates
    useEffect(() => {
        const completedTasksToday = tasks.filter(t => t.completed && t.dueDate === new Date().toISOString().split('T')[0]).length;
        setQuests(prev => prev.map(q => q.id === 'q1' ? {...q, progress: completedTasksToday, isComplete: completedTasksToday >= q.goal} : q));
        
        const firstTaskAchievement = achievements.find(a => a.id === 'a1');
        if (!firstTaskAchievement?.isUnlocked && tasks.some(t => t.completed)) {
            setAchievements(prev => prev.map(a => a.id === 'a1' ? {...a, isUnlocked: true} : a));
        }
    }, [tasks, achievements]);

    const handleAddTask = async (text: string) => {
        const parsed = await parseTaskFromString(text);
        if (parsed) {
            const newTask: Task = {
                id: Date.now(),
                text: parsed.text,
                completed: false,
                priority: parsed.priority,
                dueDate: parsed.dueDate || new Date().toISOString().split('T')[0],
            };
            setTasks(prev => [...prev, newTask]);
        } else {
            console.error("Failed to parse task");
        }
    };
    
    const handleToggleTask = (id: number) => {
        setTasks(prev => prev.map(t => {
            if (t.id === id) {
                if (!t.completed) playSound('taskComplete');
                return {...t, completed: !t.completed };
            }
            return t;
        }));
    };

    const handleToggleHabit = (id: number) => {
        setHabits(prev => prev.map(h => {
             if (h.id === id) {
                if (!h.completed) playSound('stepComplete');
                return {...h, completed: !h.completed };
            }
            return h;
        }));
    };
    
    const handleAddHabit = (text: string) => {
        if (text) {
            setHabits(prev => [...prev, {id: Date.now(), text, completed: false}]);
        }
    };

    const handleSaveJournalEntry = (id: string, content: string) => {
        setJournalEntries(prev => {
            const existing = prev.find(e => e.id === id);
            if (existing) {
                return prev.map(e => e.id === id ? {...e, content} : e);
            }
            return [...prev, {id, content}];
        });
    };
    
    const handleStartRitual = (ritual: Ritual) => {
        setActiveRitual(ritual);
        playSound('viewOpen');
    };
    
    const handleExitRitual = () => {
        setActiveRitual(null);
        playSound('viewClose');
    };
    
    const handleCompleteRitualStep = (step: import('./types').RitualStep) => {
        if(step.type === 'task') {
            handleToggleTask(step.contentId);
        } else {
            handleToggleHabit(step.contentId);
        }
        playSound('stepComplete');
    };

    const handleGenerateSummary = async () => {
        setActiveView('review');
        setIsLoadingSummary(true);
        try {
            const summary = await getWeeklySummary(tasks, habits, journalEntries);
            setWeeklySummary(summary);
            playSound('summaryGenerated');
        } catch (error) {
            console.error(error);
        } finally {
            setIsLoadingSummary(false);
        }
    };
    
    // Determine Iskra's phase and apply global effects
    const dynamicPhase = useMemo(() => {
        const { pain, chaos, drift, clarity, trust } = iskraState;
        if (chaos.value > 60) return 'Растворение';
        if (pain.value > 70) return 'Тьма';
        if (drift.value > 30) return 'Эхо';
        if (clarity.value < 70) return 'Переход';
        if (trust.value < 75) return 'Молчание';
        return 'Ясность';
    }, [iskraState]);

    useEffect(() => {
        setIskraState(prev => ({...prev, phase: dynamicPhase}));

        const phaseMap: Record<string, string> = {
            'Тьма': 'phase-tma',
            'Молчание': 'phase-molchanie',
        };
        document.body.className = 'bg-bg text-textSecondary font-sans'; // Reset
        const phaseClass = phaseMap[dynamicPhase];
        if (phaseClass) {
            document.body.classList.add(phaseClass);
        }

    }, [dynamicPhase]);
    
    const currentViewTitle = useMemo(() => {
        const titles: Record<View, string> = {
            main: 'Пульс Дня',
            agenda: 'Повестка дня',
            journal: 'Дневник',
            rituals: 'Ритуалы',
            quests: 'Задания и Достижения',
            review: 'Недельный Отчет',
            iskra: 'Ядро Искры',
            alarm: 'Умный Будильник',
            canvas: 'Canvas',
            presentation: 'Презентация Проекта',
            guide: 'Гид по "Искра space"',
            more: 'Ещё',
        };
        return titles[activeView] || 'Искра space';
    }, [activeView]);
    
    const isNight = getCognitiveState() === 'rest';

    const renderView = () => {
        if (showChat) {
            return <Chat currentUser={currentUser} partner={partner} rhythmData={rhythmData} />;
        }

        if (activeRitual) {
            return <Rituals 
                rituals={rituals} 
                tasks={tasks} 
                habits={habits} 
                activeRitual={activeRitual}
                onSave={(r) => setRituals(prev => prev.map(p => p.id === r.id ? r : p))}
                onDelete={(id) => setRituals(prev => prev.filter(r => r.id !== id))}
                onStart={handleStartRitual} 
                onExit={handleExitRitual} 
                onCompleteStep={handleCompleteRitualStep}
            />;
        }

        switch (activeView) {
            case 'main': return (
                <div className="space-y-6">
                    <AdaptiveHeader 
                        cognitiveState={getCognitiveState()}
                        rhythmData={rhythmData}
                        tasks={tasks}
                    />
                    <RhythmIndex data={rhythmData} overallScore={overallScore} />
                    <div className="module-card p-4 sm:p-5">
                        <AiInsight insightData={aiInsight} isLoading={isLoadingInsight} />
                    </div>
                    <TopTasks tasks={tasks} onToggleTask={handleToggleTask} />
                    <QuickActions onNavigate={(view) => { setActiveView(view); playSound('viewOpen'); }} />
                    <div className="module-card p-4 sm:p-5">
                         <h3 className="font-serif text-lg text-textPrimary mb-3">👥 Связь двоих</h3>
                         <DuoConnection partner={partner} onOpenChat={() => {setShowChat(true); playSound('viewOpen');}} quests={quests} />
                    </div>
                    <div className="module-card p-4 sm:p-5">
                        <h3 className="font-serif text-lg text-textPrimary mb-3">⚙️ Ядро Искры</h3>
                         <IskraCore iskraState={iskraState} />
                    </div>
                </div>
            );
            case 'agenda': return <Agenda 
                tasks={tasks} 
                habits={habits}
                onAddTask={handleAddTask}
                onToggleTask={handleToggleTask}
                onAddHabit={handleAddHabit}
                onToggleHabit={handleToggleHabit}
            />;
            case 'journal': return <Journal entries={journalEntries} onSaveEntry={handleSaveJournalEntry} rhythmData={rhythmData} />;
            case 'rituals': return <Rituals 
                rituals={rituals} 
                tasks={tasks} 
                habits={habits} 
                activeRitual={null}
                onSave={(r) => {
                    const exists = rituals.some(p => p.id === r.id);
                    if (exists) {
                        setRituals(prev => prev.map(p => p.id === r.id ? r : p));
                    } else {
                        setRituals(prev => [...prev, r]);
                    }
                }}
                onDelete={(id) => setRituals(prev => prev.filter(r => r.id !== id))}
                onStart={handleStartRitual} 
                onExit={handleExitRitual} 
                onCompleteStep={handleCompleteRitualStep}
             />;
            case 'quests': return <Quests quests={quests} achievements={achievements} />;
            case 'review': return <WeeklyReview summaryData={weeklySummary} isLoading={isLoadingSummary} onGenerate={handleGenerateSummary} />;
            case 'iskra': return <IskraCore iskraState={iskraState} />;
            case 'alarm': return <SmartAlarm />;
            case 'canvas': return <Canvas />;
            case 'presentation': return <Presentation />;
            case 'guide': return <UserGuide />;
            case 'more': return <More onNavigate={(view) => { setActiveView(view); playSound('viewOpen'); }} />;
            default: return null;
        }
    };
    
    const FooterNavButton: React.FC<{
        view: View;
        icon: string;
        label: string;
    }> = ({ view, icon, label }) => {
        const isActive = activeView === view;
        return (
            <button 
                onClick={() => { setActiveView(view); playSound('viewOpen'); }}
                className="relative flex flex-col items-center justify-center h-full transition-colors duration-200 group"
            >
                <span className={`text-3xl transition-all duration-300 ${isActive ? 'text-accent' : 'text-textSecondary/60 group-hover:text-textSecondary'}`}
                      style={{filter: isActive ? 'drop-shadow(0 0 8px var(--color-accent))' : 'none'}}
                >{icon}</span>
                <span className={`text-xs font-semibold transition-colors duration-300 ${isActive ? 'text-textPrimary' : 'text-textSecondary/60 group-hover:text-textSecondary'}`}>{label}</span>
                <div className={`absolute -bottom-1 h-1 w-8 rounded-full bg-accent transition-all duration-300 ${isActive ? 'opacity-100' : 'opacity-0 -translate-y-2'}`}></div>
            </button>
        );
    };

    return (
        <div className="bg-bg min-h-screen text-textSecondary font-sans relative pb-24">
            {showMorningRitual && <MorningRitualPrompt tasks={tasks} onClose={() => setShowMorningRitual(false)} />}
            
            <main className={`container mx-auto px-4 pt-6 max-w-2xl transition-all duration-500 ${isNight && activeView === 'main' ? 'night-mode' : ''}`}>
                 {activeView === 'main' ? (
                    renderView()
                ) : (
                    <div className="module-card p-4 sm:p-6 my-6">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="font-serif text-2xl sm:text-3xl text-textPrimary">{currentViewTitle}</h2>
                            <button onClick={() => setActiveView('main')} className="text-sm font-semibold text-accent hover:brightness-125 transition">
                                &larr; Назад к Пульсу
                            </button>
                        </div>
                        {renderView()}
                    </div>
                )}
            </main>
            
            {/* Footer Navigation */}
            <footer className="fixed bottom-0 left-0 right-0 h-20 bg-surface/80 backdrop-blur-lg border-t border-border z-40">
                <div className="max-w-5xl mx-auto h-full grid grid-cols-5 items-center px-2">
                    <FooterNavButton view="main" icon="🌀" label="Пульс" />
                    <FooterNavButton view="agenda" icon="🎯" label="Повестка" />
                    <FooterNavButton view="journal" icon="📖" label="Дневник" />
                    <FooterNavButton view="rituals" icon="🧘" label="Ритуалы" />
                    <FooterNavButton view="more" icon="⚙️" label="Ещё" />
                </div>
            </footer>

            {/* Chat Modal */}
            {showChat && (
                <div className="fixed inset-0 bg-bg/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center p-4">
                    <div className="w-full max-w-lg h-[85vh] module-card rounded-2xl flex flex-col">
                        <div className="flex justify-end p-2">
                             <button onClick={() => {setShowChat(false); playSound('viewClose')}} className="text-2xl text-textSecondary hover:text-accent">&times;</button>
                        </div>
                        <div className="flex-1 overflow-hidden">
                             <Chat currentUser={currentUser} partner={partner} rhythmData={rhythmData} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default App;