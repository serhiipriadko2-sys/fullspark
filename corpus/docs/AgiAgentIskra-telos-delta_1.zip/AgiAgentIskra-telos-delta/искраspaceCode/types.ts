// Fix: Removed circular import of View and CanvasNode from this file.

export type Priority = 'High' | 'Medium' | 'Low';
export type CognitiveState = 'morning' | 'focus' | 'evening' | 'rest';
export type Voice = 'Искра' | 'Кайн' | 'Сэм' | 'Пино' | 'Маки' | 'Хуньдун' | 'Анхантра' | 'Искрив';
export type RitualMark = '🜂' | '⟡' | '☉' | '≈' | '∆';

export type View = 'main' | 'journal' | 'rituals' | 'quests' | 'review' | 'iskra' | 'alarm' | 'canvas' | 'presentation' | 'agenda' | 'guide' | 'more';

export interface RhythmComponent {
    name: string;
    value: number;
    icon: string;
    color: string;
}

export interface RhythmData {
    focus: RhythmComponent;
    sleep: RhythmComponent;
    habits: RhythmComponent;
    energy: RhythmComponent;
}

export interface AiInsightData {
    text: string;
    voice: Voice;
}

export interface Task {
    id: number;
    text: string;
    completed: boolean;
    priority: Priority;
    dueDate: string;
    ritualMark?: RitualMark;
}

export interface Partner {
    id: string;
    name: string;
    statusEmoji: string;
    rhythmIndex: number;
    sleep: string;
}

export interface Habit {
    id: number;
    text: string;
    completed: boolean;
}

export interface JournalEntry {
    id: string; // ISO Date string
    content: string;
}

export interface WeeklySummary {
    tasksCompleted: number;
    habitCompletionRate: number;
    summary: string;

    nextWeekFocus: string;
}

export interface IskraMetric {
    description: string;
    value: number;
    color: string;
}

export interface IskraState {
    trust: IskraMetric;
    clarity: IskraMetric;
    drift: IskraMetric;
    pain: IskraMetric;
    chaos: IskraMetric;
    phase: string;
}

export interface StoredKeys {
    publicKey: JsonWebKey;
    privateKey: JsonWebKey;
}

export interface ChatMessage {
    id: string;
    senderId: string;
    receiverId: string;
    ciphertext: string;
    iv: string;
    timestamp: number;
}

export interface Quest {
    id: string;
    title: string;
    description: string;
    type: 'daily' | 'weekly';
    scope: 'personal' | 'duo';
    progress: number;
    goal: number;
    isComplete: boolean;
}

export interface Achievement {
    id: string;
    title: string;
    description: string;
    symbol: string;
    isUnlocked: boolean;
}

export interface RitualStep {
    type: 'task' | 'habit';
    contentId: number;
}

export interface Ritual {
    id: string;
    name: string;
    icon: string;
    steps: RitualStep[];
}

export interface CanvasNode {
    id: string;
    x: number;
    y: number;
    text: string;
}