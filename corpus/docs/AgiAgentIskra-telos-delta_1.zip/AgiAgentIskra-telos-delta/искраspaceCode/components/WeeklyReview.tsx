import React from 'react';
// Fix: Corrected import path for type definitions.
import type { WeeklySummary } from '../types';

interface WeeklyReviewProps {
    summaryData: WeeklySummary | null;
    isLoading: boolean;
    onGenerate: () => void;
}

const Spinner: React.FC = () => (
    <div className="flex justify-center items-center p-8">
        <svg className="animate-spin h-10 w-10 text-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </div>
);

export const WeeklyReview: React.FC<WeeklyReviewProps> = ({ summaryData, isLoading, onGenerate }) => {
    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center h-full">
                <Spinner />
                <p className="mt-4 text-textSecondary">Анализируем твою неделю...</p>
            </div>
        );
    }

    if (!summaryData) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
                <span className="text-6xl mb-4">📜</span>
                <h3 className="font-serif text-2xl text-textPrimary">Твоя недельная сводка</h3>
                <p className="text-textSecondary mt-2 mb-6">Получи персональный анализ своей активности и фокус на следующую неделю.</p>
                <button onClick={onGenerate} className="bg-accent text-bg font-bold py-3 px-6 rounded-lg transition-transform duration-200 hover:scale-105 shadow-[0_0_20px_-5px_var(--tw-color-accent)]">
                    ✨ Сгенерировать отчет
                </button>
            </div>
        );
    }
    
    return (
        <div className="space-y-6 context-message">
            <div>
                <h3 className="font-serif text-xl text-textSecondary mb-3">Твоя неделя в цифрах</h3>
                <div className="grid grid-cols-2 gap-4">
                    <div className="bg-bg/30 p-4 rounded-lg text-center">
                        <p className="text-3xl font-bold text-accent">{summaryData.tasksCompleted}</p>
                        <p className="text-sm text-textSecondary mt-1">задач завершено</p>
                    </div>
                     <div className="bg-bg/30 p-4 rounded-lg text-center">
                        <p className="text-3xl font-bold text-accent">{summaryData.habitCompletionRate}%</p>
                        <p className="text-sm text-textSecondary mt-1">привычек выполнено</p>
                    </div>
                </div>
            </div>

            <div>
                 <h3 className="font-serif text-xl text-textSecondary mb-3">Искра говорит:</h3>
                 <p className="text-textSecondary leading-relaxed bg-bg/30 p-4 rounded-lg">
                    {summaryData.summary}
                 </p>
            </div>

            <div>
                 <h3 className="font-serif text-xl text-textSecondary mb-3">Фокус на следующую неделю</h3>
                 <div className="bg-border/30 border-l-4 border-accent rounded-r-lg p-4 flex items-start">
                     <span className="text-2xl mr-4 mt-1">✨</span>
                     <p className="text-textPrimary italic">
                        {summaryData.nextWeekFocus}
                     </p>
                 </div>
            </div>
        </div>
    );
};