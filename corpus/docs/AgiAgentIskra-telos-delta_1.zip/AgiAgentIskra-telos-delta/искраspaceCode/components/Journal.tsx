import React, { useState, useMemo } from 'react';
import type { JournalEntry, RhythmData } from '../types';
import { getReflectionPrompt } from '../services/geminiService';

interface JournalProps {
    entries: JournalEntry[];
    onSaveEntry: (date: string, content: string) => void;
    rhythmData: RhythmData; // Pass rhythmData for AI prompt context
}

const todayISO = new Date().toISOString().split('T')[0];

const Spinner: React.FC = () => (
    <svg className="animate-spin h-5 w-5 text-accent" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

export const Journal: React.FC<JournalProps> = ({ entries, onSaveEntry, rhythmData }) => {
    const todaysEntry = entries.find(e => e.id === todayISO) || { id: todayISO, content: '' };
    const [currentContent, setCurrentContent] = useState(todaysEntry.content);
    const [aiPrompt, setAiPrompt] = useState<string | null>(null);
    const [isLoadingPrompt, setIsLoadingPrompt] = useState(false);
    const [viewingEntry, setViewingEntry] = useState<JournalEntry | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const handleSave = () => {
        onSaveEntry(todayISO, currentContent);
    };

    const handleGeneratePrompt = async () => {
        setIsLoadingPrompt(true);
        setAiPrompt(null);
        try {
            const prompt = await getReflectionPrompt(rhythmData);
            setAiPrompt(prompt);
        } catch (error) {
            console.error(error);
            setAiPrompt("Не удалось получить вопрос. Попробуйте снова.");
        } finally {
            setIsLoadingPrompt(false);
        }
    };

    const pastEntries = useMemo(() => {
        return entries
            .filter(e => e.id !== todayISO)
            .sort((a, b) => b.id.localeCompare(a.id));
    }, [entries]);
    
    const filteredEntries = useMemo(() => {
        if (!searchTerm) return pastEntries;
        return pastEntries.filter(entry => 
            entry.content.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [pastEntries, searchTerm]);

    if (viewingEntry) {
        return (
            <div>
                <button onClick={() => setViewingEntry(null)} className="text-sm font-semibold text-accent mb-4 hover:brightness-125">
                    &larr; Назад к дневнику
                </button>
                <h3 className="font-serif text-xl text-textPrimary mb-2">
                    Запись от {new Date(viewingEntry.id).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })}
                </h3>
                <div className="bg-bg/30 p-4 rounded-lg text-textSecondary whitespace-pre-wrap">
                    {viewingEntry.content}
                </div>
            </div>
        )
    }

    return (
        <div className="space-y-6">
            <div>
                <h3 className="font-serif text-lg text-textPrimary mb-3">Запись на сегодня</h3>
                {aiPrompt && (
                    <div className="mb-4 p-3 bg-border/30 border-l-4 border-accent rounded-r-lg italic text-textSecondary context-message">
                        {aiPrompt}
                    </div>
                )}
                <textarea
                    value={currentContent}
                    onChange={(e) => setCurrentContent(e.target.value)}
                    onBlur={handleSave}
                    placeholder="Что у тебя на уме? Какие выводы ты сделал(а) сегодня?"
                    rows={6}
                    className="w-full bg-bg/50 border-2 border-border rounded-lg p-3 text-textSecondary placeholder-slate-400 focus:ring-2 focus:ring-accent focus:border-accent transition-all duration-200"
                />
                <div className="flex justify-end mt-2">
                    <button 
                        onClick={handleGeneratePrompt}
                        disabled={isLoadingPrompt}
                        className="flex items-center gap-2 text-sm font-semibold bg-border/50 hover:bg-border text-textSecondary py-2 px-4 rounded-lg transition-colors disabled:opacity-50">
                        {isLoadingPrompt && <Spinner />}
                        {isLoadingPrompt ? 'Думаем...' : '⟡ Спросить Искру'}
                    </button>
                </div>
            </div>
            
            {pastEntries.length > 0 && (
                <div>
                    <h3 className="font-serif text-lg text-textPrimary mb-3">Архив записей</h3>
                    <div className="relative mb-3">
                        <input
                          type="text"
                          placeholder="🔍 Поиск по записям..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="w-full bg-bg/50 border-2 border-border rounded-lg py-2 pl-10 pr-4 text-textSecondary placeholder-slate-400 focus:ring-2 focus:ring-accent focus:border-accent transition-all duration-200"
                        />
                         <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <span className="text-slate-400">🔍</span>
                        </div>
                    </div>
                    
                    {filteredEntries.length > 0 ? (
                        <ul className="space-y-2 max-h-60 overflow-y-auto no-scrollbar pr-2">
                            {filteredEntries.map(entry => (
                                <li key={entry.id}>
                                    <button 
                                        onClick={() => setViewingEntry(entry)}
                                        className="w-full text-left p-3 bg-bg/30 hover:bg-border/50 rounded-lg transition-colors">
                                        <span className="font-semibold text-textPrimary">
                                            {new Date(entry.id).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}
                                        </span>
                                        <p className="text-sm text-textSecondary truncate mt-1">
                                            {entry.content || "Пустая запись"}
                                        </p>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-center text-sm text-slate-400 p-4 bg-bg/30 rounded-lg">
                            {searchTerm ? "Ничего не найдено." : "Нет прошлых записей."}
                        </p>
                    )}
                </div>
            )}
        </div>
    );
};