import React from 'react';
import type { View } from '../types';

interface MoreProps {
    onNavigate: (view: View) => void;
}

const NavItem: React.FC<{ icon: string; title: string; description: string; onClick: () => void; }> = ({ icon, title, description, onClick }) => (
    <button
        onClick={onClick}
        className="w-full flex items-center p-4 bg-bg/30 hover:bg-border/50 rounded-lg transition-colors text-left"
    >
        <div className="text-3xl mr-4">{icon}</div>
        <div>
            <h4 className="font-bold text-textPrimary">{title}</h4>
            <p className="text-sm text-textSecondary/80">{description}</p>
        </div>
        <div className="ml-auto text-accent">&rarr;</div>
    </button>
);

export const More: React.FC<MoreProps> = ({ onNavigate }) => {
    return (
        <div className="space-y-4">
            <NavItem 
                icon="🏆"
                title="Задания и Достижения"
                description="Отслеживайте свой прогресс и открывайте новые вехи."
                onClick={() => onNavigate('quests')}
            />
            <NavItem 
                icon="🧭"
                title="Гид по 'Искра space'"
                description="Узнайте о философии и возможностях приложения."
                onClick={() => onNavigate('guide')}
            />
            <NavItem 
                icon="💡"
                title="Презентация Проекта"
                description="Познакомьтесь с видением и дорожной картой 'Искры'."
                onClick={() => onNavigate('presentation')}
            />
            <NavItem 
                icon="⏰"
                title="Умный Будильник"
                description="Настройте мягкое пробуждение в своем ритме."
                onClick={() => onNavigate('alarm')}
            />
             <NavItem 
                icon="🎨"
                title="Canvas"
                description="Бесконечный холст для ваших идей и планов."
                onClick={() => onNavigate('canvas')}
            />
        </div>
    );
};