import React from 'react';
import type { View } from '../types';

interface QuickActionsProps {
    onNavigate: (view: View) => void;
}

export const QuickActions: React.FC<QuickActionsProps> = ({ onNavigate }) => {
    return (
        <div className="grid grid-cols-2 gap-4">
            <button
                onClick={() => alert('Фокус-сессия скоро будет доступна!')}
                className="module-card flex flex-col items-center justify-center p-4 text-center hover:border-accent/50"
            >
                <span className="text-3xl mb-2">⏱️</span>
                <span className="font-semibold text-textPrimary">Начать фокус</span>
                <span className="text-xs text-textSecondary/70">Микро-практика</span>
            </button>
             <button
                onClick={() => onNavigate('journal')}
                className="module-card flex flex-col items-center justify-center p-4 text-center hover:border-accent/50"
            >
                <span className="text-3xl mb-2">📝</span>
                <span className="font-semibold text-textPrimary">Быстрая запись</span>
                 <span className="text-xs text-textSecondary/70">Дневник</span>
            </button>
        </div>
    );
};
