import React, { useState, useMemo } from 'react';
// Fix: Corrected import path for type definitions.
import type { Ritual, RitualStep, Task, Habit } from '../types';
import { playSound } from '../services/soundService';

// --- PROPS ---
interface RitualsProps {
    rituals: Ritual[];
    tasks: Task[];
    habits: Habit[];
    activeRitual: Ritual | null;
    onSave: (ritual: Ritual) => void;
    onDelete: (ritualId: string) => void;
    onStart: (ritual: Ritual) => void;
    onExit: () => void;
    onCompleteStep: (step: RitualStep) => void;
}

// --- SUB-COMPONENT: Ritual Runner ---
const RitualRunner: React.FC<{
    ritual: Ritual;
    tasks: Task[];
    habits: Habit[];
    onExit: () => void;
    onCompleteStep: (step: RitualStep) => void;
}> = ({ ritual, tasks, habits, onExit, onCompleteStep }) => {
    const [currentStepIndex, setCurrentStepIndex] = useState(0);

    const stepsWithDetails = useMemo(() => ritual.steps.map(step => {
        if (step.type === 'task') {
            const task = tasks.find(t => t.id === step.contentId);
            return { ...step, text: task?.text || 'Задача не найдена', completed: task?.completed || false };
        }
        const habit = habits.find(h => h.id === step.contentId);
        return { ...step, text: habit?.text || 'Привычка не найдена', completed: habit?.completed || false };
    }), [ritual.steps, tasks, habits]);

    const currentStep = stepsWithDetails[currentStepIndex];
    const isCompleted = currentStepIndex >= ritual.steps.length;

    const handleComplete = () => {
        if (!currentStep.completed) {
            onCompleteStep(currentStep);
        }
        if (currentStepIndex === ritual.steps.length - 1) {
             playSound('ritualComplete');
        } else {
             playSound('stepComplete');
        }
        setCurrentStepIndex(prev => prev + 1);
    };

    if (isCompleted) {
        return (
            <div className="text-center py-8 flex flex-col items-center justify-center">
                <span className="text-6xl mb-4">🎉</span>
                <h3 className="font-serif text-2xl text-textPrimary">Ритуал «{ritual.name}» завершён!</h3>
                <p className="text-textSecondary mt-2">Отличная работа! Ты сделал важный шаг к своему ритму.</p>
                <button onClick={onExit} className="mt-6 bg-accent text-bg font-bold py-2 px-6 rounded-lg transition-transform duration-200 hover:scale-105">
                    Завершить
                </button>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full p-4">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                    <span className="text-2xl mr-3">{ritual.icon}</span>
                    <h3 className="font-serif text-xl text-textPrimary">{ritual.name}</h3>
                </div>
                <button onClick={onExit} className="text-sm font-semibold text-accent hover:brightness-125">&times; Выйти</button>
            </div>
            <div className="text-center my-auto flex-grow flex flex-col items-center justify-center p-4 bg-bg/30 rounded-lg">
                <p className="text-sm text-textSecondary/80 mb-2">Шаг {currentStepIndex + 1} из {ritual.steps.length}</p>
                <p className="text-xl text-textPrimary font-semibold">
                    {currentStep.text}
                </p>
            </div>
            <div className="mt-6">
                <div className="progress-bar w-full h-2.5 mb-4">
                    <div className="progress-bar-fill" style={{ width: `${((currentStepIndex) / ritual.steps.length) * 100}%` }}></div>
                </div>
                <button
                    onClick={handleComplete}
                    disabled={currentStep.completed}
                    className="w-full bg-accent text-bg font-bold py-3 px-6 rounded-lg transition-transform duration-200 hover:scale-105 disabled:bg-green-500 disabled:opacity-70 disabled:cursor-not-allowed"
                >
                    {currentStep.completed ? 'Выполнено ✓' : 'Завершить шаг'}
                </button>
            </div>
        </div>
    );
};

// --- SUB-COMPONENT: Ritual Builder ---
const RitualBuilder: React.FC<{
    ritualToEdit: Ritual | null;
    tasks: Task[];
    habits: Habit[];
    onSave: (ritual: Ritual) => void;
    onCancel: () => void;
}> = ({ ritualToEdit, tasks, habits, onSave, onCancel }) => {
    const [name, setName] = useState(ritualToEdit?.name || '');
    const [icon, setIcon] = useState(ritualToEdit?.icon || '⚙️');
    const [steps, setSteps] = useState<RitualStep[]>(ritualToEdit?.steps || []);
    
    const availableSteps = useMemo(() => {
        const currentStepIds = new Set(steps.map(s => `${s.type}-${s.contentId}`));
        const availableTasks = tasks.map(t => ({...t, type: 'task' as const}));
        const availableHabits = habits.map(h => ({...h, type: 'habit' as const}));
        return [...availableTasks, ...availableHabits].filter(item => !currentStepIds.has(`${item.type}-${item.id}`));
    }, [tasks, habits, steps]);

    const addStep = (type: 'task' | 'habit', contentId: number) => setSteps([...steps, { type, contentId }]);
    const removeStep = (index: number) => setSteps(steps.filter((_, i) => i !== index));

    const handleSave = () => {
        if (!name.trim()) {
            alert("Пожалуйста, введите название ритуала.");
            return;
        }
        onSave({
            id: ritualToEdit?.id || `ritual-${Date.now()}`,
            name: name.trim(),
            icon,
            steps
        });
    };
    
    const getStepText = (step: RitualStep) => {
        if (step.type === 'task') return tasks.find(t => t.id === step.contentId)?.text;
        return habits.find(h => h.id === step.contentId)?.text;
    }
    
    const icons = ['☀️', '🌙', '💪', '🧘', '🚀', '🎯', '❤️', '🧠', '⚙️'];

    return (
        <div className="space-y-4">
            <div className="flex items-center space-x-2">
                <div className="relative w-16">
                     <button className="text-3xl bg-bg/50 border-2 border-border rounded-lg p-2 w-16 h-16 flex items-center justify-center">
                        {icon}
                    </button>
                </div>
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Название ритуала (напр. Утро)"
                    className="flex-1 bg-bg/50 border-2 border-border rounded-lg py-3 px-4 text-xl font-serif text-textSecondary placeholder-slate-500 focus:ring-2 focus:ring-accent focus:border-accent"
                />
            </div>
             <div className="flex flex-wrap gap-2 bg-bg/30 p-2 rounded-lg">
                {icons.map(ic => (
                    <button key={ic} onClick={() => setIcon(ic)} className={`text-2xl p-2 rounded-md transition-colors ${icon === ic ? 'bg-accent/30' : 'hover:bg-border/50'}`}>{ic}</button>
                ))}
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                    <h4 className="font-semibold text-textSecondary">Доступные шаги</h4>
                    <div className="bg-bg/30 p-2 rounded-lg h-48 overflow-y-auto no-scrollbar space-y-1">
                       {availableSteps.map(item => (
                           <button key={`${item.type}-${item.id}`} onClick={() => addStep(item.type, item.id)} className="w-full text-left p-2 bg-border/50 hover:bg-border rounded-md transition-colors text-sm flex items-center">
                               <span className="text-lg mr-2">{item.type === 'task' ? '🎯' : '🔄'}</span>
                               <span className="flex-1">{item.text}</span>
                               <span className="text-2xl ml-2 text-accent">+</span>
                           </button>
                       ))}
                    </div>
                </div>
                 <div className="space-y-2">
                    <h4 className="font-semibold text-textSecondary">Шаги ритуала</h4>
                     <div className="bg-bg/30 p-2 rounded-lg h-48 overflow-y-auto no-scrollbar space-y-1">
                        {steps.map((step, index) => (
                           <div key={index} className="w-full p-2 bg-border/50 rounded-md text-sm flex items-center">
                                <span className="text-lg mr-2">{step.type === 'task' ? '🎯' : '🔄'}</span>
                               <span className="flex-1">{getStepText(step)}</span>
                                <button onClick={() => removeStep(index)} className="text-lg ml-2 text-rose-400 hover:text-rose-600 transition-colors">&times;</button>
                           </div>
                        ))}
                     </div>
                </div>
            </div>

            <div className="flex justify-end gap-3 mt-4">
                <button onClick={onCancel} className="bg-border/50 hover:bg-border text-textSecondary font-bold py-2 px-6 rounded-lg transition-colors">Отмена</button>
                <button onClick={handleSave} className="bg-accent text-bg font-bold py-2 px-6 rounded-lg transition-transform duration-200 hover:scale-105">Сохранить</button>
            </div>
        </div>
    );
};

// --- SUB-COMPONENT: Rituals List ---
const RitualsList: React.FC<{
    rituals: Ritual[];
    tasks: Task[];
    habits: Habit[];
    onStart: (ritual: Ritual) => void;
    onEdit: (ritual: Ritual) => void;
    onDelete: (ritualId: string) => void;
    onCreate: () => void;
}> = ({ rituals, tasks, habits, onStart, onEdit, onDelete, onCreate }) => {
    return (
        <div className="space-y-4">
            {rituals.map(ritual => {
                const totalSteps = ritual.steps.length;
                const completedSteps = ritual.steps.reduce((count, step) => {
                    if (step.type === 'task') {
                        const task = tasks.find(t => t.id === step.contentId);
                        if (task?.completed) return count + 1;
                    } else if (step.type === 'habit') {
                        const habit = habits.find(h => h.id === step.contentId);
                        if (habit?.completed) return count + 1;
                    }
                    return count;
                }, 0);

                const progressPercentage = totalSteps > 0 ? (completedSteps / totalSteps) * 100 : 0;
                
                return (
                    <div key={ritual.id} className="bg-bg/30 p-3 rounded-lg flex items-center">
                        <span className="text-3xl mr-4">{ritual.icon}</span>
                        <div className="flex-1">
                            <h4 className="font-bold text-textPrimary">{ritual.name}</h4>
                            
                            {totalSteps > 0 ? (
                                <div className="mt-1.5">
                                    <div className="flex justify-between items-center text-xs text-textSecondary mb-1">
                                        <span>Прогресс</span>
                                        <span>{completedSteps} / {totalSteps}</span>
                                    </div>
                                    <div className="progress-bar w-full h-1.5">
                                        <div className="progress-bar-fill" style={{ width: `${progressPercentage}%` }}></div>
                                    </div>
                                </div>
                            ) : (
                                <p className="text-xs text-textSecondary mt-1">Нет шагов</p>
                            )}

                        </div>
                        <div className="flex items-center gap-2 ml-4">
                            <button onClick={(e) => { e.stopPropagation(); onEdit(ritual); }} className="p-2 rounded-md hover:bg-border transition-colors text-lg" aria-label={`Edit ${ritual.name}`}>✏️</button>
                            <button onClick={(e) => { e.stopPropagation(); onDelete(ritual.id); }} className="p-2 rounded-md hover:bg-border transition-colors text-lg" aria-label={`Delete ${ritual.name}`}>🗑️</button>
                            <button onClick={() => onStart(ritual)} className="bg-accent text-bg font-bold py-2 px-4 rounded-lg transition-transform duration-200 hover:scale-105 text-sm">Начать</button>
                        </div>
                    </div>
                );
            })}
            <button onClick={onCreate} className="w-full mt-4 bg-bg/50 border-2 border-dashed border-border rounded-lg py-3 text-textSecondary hover:bg-border/50 hover:border-accent hover:text-accent transition-all duration-200 font-semibold">
                + Создать новый ритуал
            </button>
        </div>
    );
};


// --- MAIN COMPONENT ---
export const Rituals: React.FC<RitualsProps> = (props) => {
    const [mode, setMode] = useState<'list' | 'builder'>('list');
    const [ritualToEdit, setRitualToEdit] = useState<Ritual | null>(null);

    const handleCreate = () => {
        setRitualToEdit(null);
        setMode('builder');
    };

    const handleEdit = (ritual: Ritual) => {
        setRitualToEdit(ritual);
        setMode('builder');
    };

    const handleSave = (ritual: Ritual) => {
        props.onSave(ritual);
        setMode('list');
        setRitualToEdit(null);
    };

    const handleCancel = () => {
        setMode('list');
        setRitualToEdit(null);
    };

    if (props.activeRitual) {
        return <RitualRunner {...props} ritual={props.activeRitual} />;
    }
    
    if (mode === 'builder') {
        return <RitualBuilder ritualToEdit={ritualToEdit} tasks={props.tasks} habits={props.habits} onSave={handleSave} onCancel={handleCancel} />;
    }

    return <RitualsList 
        rituals={props.rituals} 
        tasks={props.tasks}
        habits={props.habits}
        onStart={props.onStart} 
        onEdit={handleEdit} 
        onDelete={props.onDelete} 
        onCreate={handleCreate} 
    />;
};