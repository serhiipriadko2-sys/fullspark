import React from 'react';

const IskraLogo: React.FC = () => (
    <svg width="32" height="32" viewBox="0 0 100 100" className="mr-2 filter drop-shadow-[0_0_8px_theme(colors.space-accent)]">
        <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="var(--tw-color-space-accent)" />
                <stop offset="100%" stopColor="#FFAA44" />
            </linearGradient>
        </defs>
        <path d="M50 10 L90 80 L10 80 Z" fill="none" stroke="url(#logoGradient)" strokeWidth="8" />
        <path d="M50 45 C 58 45, 58 55, 50 55 C 42 55, 42 65, 50 65" fill="none" stroke="currentColor" strokeWidth="6" strokeLinecap="round" className="text-space-bright" />
    </svg>
);


export const Header: React.FC = () => {
    return (
        <header className="absolute top-0 left-1/2 -translate-x-1/2 pt-6 pb-4 flex items-center z-30">
            <IskraLogo />
            <h1 className="font-serif text-4xl font-bold text-space-accent glow-text-accent">
                Искра
            </h1>
            <span className="ml-2 font-sans text-lg font-medium text-space-light tracking-widest">
                space
            </span>
        </header>
    );
};