import React from 'react';
// Fix: Corrected import path for type definitions.
import type { RhythmComponent, RhythmData } from '../types';

interface RhythmIndexProps {
    data: RhythmData;
    overallScore: number;
}

const getScoreStyle = (score: number): { className: string; glowColor: string } => {
    if (score >= 90) return { className: 'text-[#4CAF50]', glowColor: '#4CAF50'};
    if (score >= 70) return { className: 'text-[#2196F3]', glowColor: '#2196F3' };
    if (score >= 50) return { className: 'text-[#FF9800]', glowColor: '#FF9800' };
    return { className: 'text-[#F44336]', glowColor: '#F44336' };
};

const RadialMetric: React.FC<{ metric: RhythmComponent }> = ({ metric }) => {
    const radius = 32;
    const circumference = 2 * Math.PI * radius;
    const offset = circumference - (metric.value / 100) * circumference;

    return (
        <div className="flex flex-col items-center justify-center text-center">
            <div className="relative w-20 h-20">
                <svg width="80" height="80" viewBox="0 0 80 80" className="-rotate-90">
                    <circle
                        cx="40"
                        cy="40"
                        r={radius}
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="6"
                        className="text-border/50"
                    />
                    <circle
                        cx="40"
                        cy="40"
                        r={radius}
                        fill="none"
                        stroke={metric.color}
                        strokeWidth="6"
                        strokeLinecap="round"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        className="transition-all duration-500 ease-out"
                        style={{ filter: `drop-shadow(0 0 4px ${metric.color})` }}
                    />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-2xl">
                    {metric.icon}
                </div>
            </div>
            <p className="mt-2 text-sm font-semibold text-textSecondary">{metric.name}</p>
            <p className="text-xs font-bold" style={{ color: metric.color }}>{metric.value}%</p>
        </div>
    );
};


export const RhythmIndex: React.FC<RhythmIndexProps> = ({ data, overallScore }) => {
    const { className: scoreClass, glowColor } = getScoreStyle(overallScore);

    return (
        <div className="module-card p-4 sm:p-5 text-center relative overflow-hidden">
            <div className="aurora-container">
                <div className="aurora-1"></div>
                <div className="aurora-2"></div>
                <div className="aurora-3"></div>
            </div>
            <div className="relative z-10">
                <div className="mb-6 text-center">
                    <h3 className="font-serif text-2xl text-textPrimary">🌀 Индекс Ритма</h3>
                     <p className={`text-6xl font-bold my-1 ${scoreClass}`} style={{ textShadow: `0 0 12px ${glowColor}` }}>
                        {overallScore}<span className="text-3xl opacity-80">%</span>
                    </p>
                    <p className="text-sm text-textSecondary/70">(Твой баланс сегодня)</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {(Object.keys(data) as Array<keyof RhythmData>).map((key) => {
                        const component = data[key];
                        return <RadialMetric key={key} metric={component} />;
                    })}
                </div>
            </div>
        </div>
    );
};