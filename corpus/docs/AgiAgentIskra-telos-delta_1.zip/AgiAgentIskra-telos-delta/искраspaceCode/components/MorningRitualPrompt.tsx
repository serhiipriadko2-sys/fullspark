import React, { useState, useEffect } from 'react';
import type { Task } from '../types';
import { playSound } from '../services/soundService';

interface MorningRitualPromptProps {
    tasks: Task[];
    onClose: () => void;
}

const steps = [
    "Доброе утро! Готов(а) начать день осознанно?",
    "Твои 3 главные задачи на сегодня:",
    "Теперь, давай настроимся. 1 минута на дыхание.",
    "Отличного дня! Твой ритм — твоя сила."
];

export const MorningRitualPrompt: React.FC<MorningRitualPromptProps> = ({ tasks, onClose }) => {
    const [currentStep, setCurrentStep] = useState(0);
    const [isVisible, setIsVisible] = useState(false);
    const [timer, setTimer] = useState(60);

    useEffect(() => {
        setIsVisible(true);
        playSound('viewOpen');
    }, []);

    useEffect(() => {
        // Fix: Changed NodeJS.Timeout to ReturnType<typeof setInterval> for browser compatibility.
        let interval: ReturnType<typeof setInterval> | null = null;
        if (currentStep === 2 && timer > 0) {
            interval = setInterval(() => {
                setTimer(prev => prev - 1);
            }, 1000);
        } else if (timer === 0 && currentStep === 2) {
             playSound('ritualComplete');
             handleNextStep();
        }
        return () => {
            if (interval) clearInterval(interval);
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentStep, timer]);

    const handleNextStep = () => {
        if (currentStep < steps.length - 1) {
            setCurrentStep(prev => prev + 1);
            playSound('stepComplete');
        } else {
            playSound('viewClose');
            setIsVisible(false);
            setTimeout(onClose, 500); // Wait for animation
        }
    };
    
    const topTasks = tasks.filter(t => !t.completed).sort((a, b) => {
        if (a.priority === 'High' && b.priority !== 'High') return -1;
        if (a.priority !== 'High' && b.priority === 'High') return 1;
        return 0;
    }).slice(0, 3);

    const renderContent = () => {
        switch (currentStep) {
            case 0:
                return <p className="text-2xl text-center text-textSecondary">{steps[0]}</p>;
            case 1:
                return (
                    <div>
                        <p className="text-xl text-center text-textSecondary mb-4">{steps[1]}</p>
                        <ul className="space-y-2 text-left">
                            {topTasks.length > 0 ? topTasks.map(task => (
                                <li key={task.id} className="p-3 bg-bg/50 rounded-lg text-textPrimary">
                                    🎯 {task.text}
                                </li>
                            )) : <p className="text-center text-sm text-slate-400 p-2">Задач на сегодня нет.</p>}
                        </ul>
                    </div>
                );
            case 2:
                return (
                    <div className="text-center">
                        <p className="text-xl text-textSecondary mb-4">{steps[2]}</p>
                        <div className="text-6xl font-mono font-bold text-accent">{timer}</div>
                        <p className="text-sm text-textSecondary/70">Вдох... Выдох...</p>
                    </div>
                );
            case 3:
                 return <p className="text-2xl text-center text-textPrimary">{steps[3]}</p>;
            default:
                return null;
        }
    }

    return (
        <div className={`fixed inset-0 bg-bg/90 backdrop-blur-md z-50 flex items-center justify-center transition-opacity duration-500 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
            <div className="max-w-md w-full p-8 bg-surface rounded-2xl shadow-2xl shadow-accent/10 border border-border/50 animate-fade-in-up">
                <div className="min-h-[200px] flex items-center justify-center">
                    {renderContent()}
                </div>
                {currentStep !== 2 && (
                     <button
                        onClick={handleNextStep}
                        className="w-full mt-6 bg-accent text-bg font-bold py-3 px-6 rounded-lg transition-transform duration-200 hover:scale-105"
                    >
                        {currentStep === steps.length - 1 ? "Начать день ✨" : "Далее"}
                    </button>
                )}
            </div>
        </div>
    );
};