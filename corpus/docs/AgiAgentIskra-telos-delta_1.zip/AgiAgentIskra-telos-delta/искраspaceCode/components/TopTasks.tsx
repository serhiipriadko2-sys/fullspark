import React from 'react';
import type { Task } from '../types';

interface TopTasksProps {
    tasks: Task[];
    onToggleTask: (id: number) => void;
}

export const TopTasks: React.FC<TopTasksProps> = ({ tasks, onToggleTask }) => {
    const topTasks = tasks
        .filter(t => !t.completed)
        .sort((a, b) => {
            const priorityMap = { 'High': 1, 'Medium': 2, 'Low': 3 };
            return priorityMap[a.priority] - priorityMap[b.priority];
        })
        .slice(0, 3);

    return (
        <div className="module-card p-4 sm:p-5">
            <h3 className="font-serif text-lg text-textPrimary mb-4">🎯 Твои 3 на сегодня:</h3>
            {topTasks.length > 0 ? (
                <ul className="space-y-3">
                    {topTasks.map((task) => (
                        <li key={task.id} className="flex items-center group">
                             <input
                                type="checkbox"
                                id={`top-task-${task.id}`}
                                checked={task.completed}
                                onChange={() => onToggleTask(task.id)}
                                className={`h-5 w-5 rounded-md appearance-none bg-border/60 border-2 border-border text-accent focus:ring-accent focus:ring-offset-surface focus:ring-2 cursor-pointer transition-all duration-300 mr-4 checked:bg-accent checked:border-transparent checked:shadow-[0_0_12px_var(--tw-color-accent)]`}
                                aria-labelledby={`top-task-label-${task.id}`}
                            />
                            <label
                                htmlFor={`top-task-${task.id}`}
                                id={`top-task-label-${task.id}`}
                                className="w-full cursor-pointer transition-colors duration-300 text-base text-textSecondary"
                            >
                                {task.text}
                            </label>
                            {task.ritualMark && <span className="text-lg ml-2">{task.ritualMark}</span>}
                        </li>
                    ))}
                </ul>
            ) : (
                <div className="text-center py-4 text-slate-400">
                    <p>Все важные дела на сегодня сделаны. Отличная работа! ✨</p>
                </div>
            )}
        </div>
    );
};
