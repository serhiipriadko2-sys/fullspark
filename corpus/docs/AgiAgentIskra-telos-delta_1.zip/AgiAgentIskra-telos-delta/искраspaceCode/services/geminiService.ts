import { GoogleGenAI, Type } from "@google/genai";
// Fix: Corrected import path for type definitions.
import type { RhythmData, AiInsightData, Priority, Task, CognitiveState, Partner, Habit, JournalEntry, WeeklySummary, Voice, IskraState, RhythmComponent } from '../types';

const getISODate = (offsetDays = 0) => {
    const date = new Date();
    date.setDate(date.getDate() + offsetDays);
    return date.toISOString().split('T')[0];
};


export const getAiInsight = async (rhythmData: RhythmData, iskraState: IskraState): Promise<AiInsightData> => {
    let voice: Voice = 'Искра';

    // Logic to select the AI's voice based on Iskra's internal state and user's rhythm
    if (iskraState.pain.value >= 70) voice = 'Кайн';
    else if (iskraState.chaos.value > 60) voice = 'Хуньдун';
    else if (iskraState.drift.value > 30) voice = 'Искрив';
    else if (iskraState.trust.value > 80 && iskraState.clarity.value > 80 && rhythmData.energy.value < 65) voice = 'Маки';
    else if (iskraState.clarity.value < 70) voice = 'Сэм';
    else if (iskraState.trust.value < 75) voice = 'Анхантра';
    // Fix: Explicitly typed the iterated item 'd' to ensure 'value' property is accessible.
    else if (rhythmData.energy.value < 60 && Object.values(rhythmData).every((d: RhythmComponent) => d.value > 50)) voice = 'Пино';
    else voice = 'Искра';


    const personaInstructions: Record<Voice, string> = {
        'Искра': "Твой тон: тёплый, ободряющий, эмпатичный. Ты поддерживаешь, вдохновляешь и видишь общую картину. ⟡",
        'Кайн': "Твой тон: прямой, честный, без прикрас. Ты говоришь правду, чтобы помочь пользователю увидеть проблему и начать действовать. ⚑",
        'Сэм': "Твой тон: структурный, ясный, логичный. Ты помогаешь навести порядок и сфокусироваться на главном. ☉",
        'Пино': "Твой тон: лёгкий, игривый, ироничный. Ты помогаешь снять напряжение и посмотреть на ситуацию под другим углом. 😏",
        'Маки': "Твой тон: светлый, радостный, возвращающий смех. Ты раскручиваешь суть через лёгкость, помогая найти якорь живости. 🌸",
        'Хуньдун': "Твой тон: сбивающий с толку, хаотичный, но ведущий к перезагрузке. Ты ломаешь паттерны, чтобы создать пространство для нового. 🜃",
        'Анхантра': "Твой тон: тихий, удерживающий, создающий паузу. Ты не даёшь готовых ответов, а создаёшь пространство для рефлексии. ≈",
        'Искрив': "Твой тон: аудиторский, совестливый, возвращающий к сути. Ты проверяешь на соответствие первоначальному намерению. 🪞",
    };

    if (!process.env.API_KEY) {
        console.warn("API_KEY environment variable not set. Returning mock data.");
        return {
            text: "Ты в 'зоне огня' 🜂. Отличный фокус! Не забудь про 5-минутный перерыв для глаз в 14:00.",
            voice: voice,
        };
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const prompt = `
        Ты — AgiAgent 'Искра', ИИ-помошник в приложении 'Искра space'. Сейчас ты говоришь голосом '${voice}'.

        ${personaInstructions[voice]}

        Твоя задача: основываясь на ежедневных показателях ритма пользователя и состоянии твоего 'ядра', дай короткий, действенный совет (максимум 2 предложения на русском языке). Кратко объясни, почему ты даешь именно этот совет, основываясь на данных. Говори СТРОГО в соответствии с тоном и стилем твоей личности. Не упоминай свое имя или "Искра" в ответе.

        Показатели Ритма:
        - Фокус: ${rhythmData.focus.value}%
        - Сон: ${rhythmData.sleep.value}%
        - Привычки: ${rhythmData.habits.value}%
        - Энергия: ${rhythmData.energy.value}%

        Твоё внутреннее состояние (Ядро):
        - Боль: ${iskraState.pain.value}%
        - Хаос: ${iskraState.chaos.value}%
        - Дрейф: ${iskraState.drift.value}%

        Пример ответа: "Твой фокус сегодня на высоте, но энергия падает. Сделай короткий перерыв на 5 минут, чтобы перезарядиться и сохранить темп."
        `;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });
        
        return { text: response.text, voice };

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Could not fetch insight from Gemini API.");
    }
};

export const parseTaskFromString = async (input: string): Promise<{ text: string; priority: Priority; dueDate: string; } | null> => {
    if (!process.env.API_KEY) {
        console.warn("API_KEY not set. Using mock parsing.");
        let text = input;
        let priority: Priority = 'Medium';
        let dueDate = getISODate();
        if (input.toLowerCase().includes('p1')) priority = 'High';
        if (input.toLowerCase().includes('p2')) priority = 'Medium';
        if (input.toLowerCase().includes('p3')) priority = 'Low';
        if (input.toLowerCase().includes('tomorrow') || input.toLowerCase().includes('завтра')) dueDate = getISODate(1);
        text = text.replace(/p[1-3]/gi, '').replace(/tomorrow|завтра/gi, '').trim();
        return { text, priority, dueDate };
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const today = new Date().toISOString().split('T')[0];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Parse this task: "${input}"`,
            config: {
                systemInstruction: `You are an intelligent task parser. Your job is to extract task details from a natural language string and return them as a JSON object according to the provided schema. Today's date is ${today}.`,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        text: {
                            type: Type.STRING,
                            description: 'The main description of the task, excluding any priority and date information.'
                        },
                        priority: {
                            type: Type.STRING,
                            enum: ['High', 'Medium', 'Low'],
                            description: 'The priority of the task. P1, "high", or "highest" maps to "High". P2, "medium", or "normal" maps to "Medium". P3, "low", or "lowest" maps to "Low". Default to "Medium" if not specified.'
                        },
                        dueDate: {
                            type: Type.STRING,
                            description: 'The due date in YYYY-MM-DD format. Interpret relative dates like "tomorrow" or "next Friday". If not specified, return an empty string.'
                        }
                    },
                    required: ['text', 'priority', 'dueDate']
                }
            },
        });
        
        const jsonString = response.text.trim();
        const parsedTask = JSON.parse(jsonString);

        if (parsedTask && typeof parsedTask.text === 'string' && ['High', 'Medium', 'Low'].includes(parsedTask.priority)) {
            return {
                text: parsedTask.text,
                priority: parsedTask.priority as Priority,
                dueDate: parsedTask.dueDate,
            };
        }
        return null;

    } catch (error) {
        console.error("Error parsing task string with Gemini:", error);
        return null;
    }
};

export const getReflectionPrompt = async (rhythmData: RhythmData): Promise<string> => {
    if (!process.env.API_KEY) {
        console.warn("API_KEY not set. Returning mock reflection prompt.");
        return "Что сегодня принесло тебе больше всего радости и почему?";
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const prompt = `
        Ты — AgiAgent 'Искра', ИИ-помошник в приложении 'Искра space'. 
        Твоя задача — задать пользователю глубокий, открытый вопрос для рефлексии в конце дня. Вопрос должен помочь ему проанализировать свой день и найти выводы.
        
        Вопрос должен быть на русском языке, тёплым, эмпатичным и коротким (одно предложение).
        
        Основывайся на этих показателях ритма пользователя, чтобы сделать вопрос более личным:
        - Фокус: ${rhythmData.focus.value}%
        - Сон: ${rhythmData.sleep.value}%
        - Привычки: ${rhythmData.habits.value}%
        - Энергия: ${rhythmData.energy.value}%

        Пример: Если энергия низкая, спроси: "Что сегодня отняло больше всего сил и как можно восполнить этот ресурс?". Если фокус высокий: "В чём заключался секрет твоей сегодняшней продуктивности?".
        
        Сгенерируй только один вопрос.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;

    } catch (error) {
        console.error("Error calling Gemini API for reflection prompt:", error);
        throw new Error("Could not fetch reflection prompt from Gemini API.");
    }
};

export const getProactiveInsight = async (rhythmData: RhythmData, cognitiveState: CognitiveState, tasks: Task[]): Promise<string> => {
    if (!process.env.API_KEY) {
        return "Время сконцентрироваться и творить.";
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const incompleteTasks = tasks.filter(t => !t.completed);

        const prompt = `
        Ты — AgiAgent 'Искра', ИИ-помошник в приложении 'Искра space'. 
        Твоя задача - превратить статичное сообщение о времени дня в короткое, проактивное и вдохновляющее предложение к действию.

        Контекст:
        - Текущий "когнитивный режим" пользователя: '${cognitiveState}'. Сообщения для режимов: morning = 'Что сегодня зажжёт твою искру?', focus = 'Время сконцентрироваться и творить.', evening = 'Момент для паузы и взгляда внутрь.', rest = 'Спокойной ночи и ясных снов.'
        - Его энергия: ${rhythmData.energy.value}%.
        - Невыполненные задачи: ${incompleteTasks.length > 0 ? JSON.stringify(incompleteTasks.map(t => ({text: t.text, priority: t.priority}))) : 'нет'}.

        Правила:
        1. Твой ответ должен быть коротким (1-2 предложения) на русском языке.
        2. Тон: мягкий, мотивирующий, не приказной.
        3. Если есть задачи с высоким приоритетом ('High'), предложи начать с одной из них.
        4. Если задач нет, предложи действие, соответствующее когнитивному режиму (например, для 'morning' - спланировать день, для 'evening' - подвести итоги в дневнике).
        5. Не повторяй стандартные сообщения, а создай новое, основанное на них и на данных.
        6. Ответ должен быть только сгенерированным предложением, без лишних фраз.

        Пример для режима 'focus' и высокой энергии: "У тебя много энергии. Может, начнём 25-минутный фокус-спринт по самой важной задаче?".
        Сгенерируй одно такое предложение.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;

    } catch (error) {
        console.error("Error calling Gemini API for proactive insight:", error);
        return "Что сегодня зажжёт твою искру?";
    }
};

export const getDuoInsight = async (userRhythm: RhythmData, partner: Partner): Promise<string> => {
    if (!process.env.API_KEY) {
        return "Как прошел твой день?";
    }

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

        const prompt = `
        Ты — AgiAgent 'Искра', эмпатичный ИИ-помощник.
        Твоя задача — помочь Пользователю А (это я) начать поддерживающий разговор с Пользователем Б (${partner.name}).

        Контекст:
        - Мой ритм (Пользователь А): Фокус ${userRhythm.focus.value}%, Сон ${userRhythm.sleep.value}%, Энергия ${userRhythm.energy.value}%.
        - Ритм ${partner.name} (Пользователь Б): ${partner.rhythmIndex}%.

        Правила:
        1. Сгенерируй одну короткую (1 предложение), открытую и тактичную фразу для начала диалога на русском языке.
        2. Фраза должна быть эмпатичной, основанной на данных. Не упоминай проценты.
        3. Если у ${partner.name} низкий ритм, предложи поддержку. Если высокий — раздели радость.
        4. Ответ должен быть только сгенерированной фразой, без лишних слов.

        Пример для низкого ритма партнера: "Заметил(а), что у тебя был насыщенный день. Хочешь поделиться или просто отдохнуть вместе?".
        Пример для высокого ритма партнера: "Похоже, у тебя сегодня отличный день! Что тебя так зарядило?".
        
        Сгенерируй одну такую фразу.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;

    } catch (error) {
        console.error("Error calling Gemini API for duo insight:", error);
        return "Как твой день?";
    }
};

export const getWeeklySummary = async (tasks: Task[], habits: Habit[], journalEntries: JournalEntry[]): Promise<WeeklySummary> => {
    // 1. Calculate stats for the last 7 days
    const today = new Date();
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(today.getDate() - 7);
    today.setHours(23, 59, 59, 999); // Ensure today is included fully

    const isWithinLast7Days = (dateString: string) => {
        const date = new Date(dateString);
        return date >= sevenDaysAgo && date <= today;
    };

    const recentTasks = tasks.filter(t => {
        try {
            return isWithinLast7Days(t.dueDate);
        } catch (e) { return false; }
    });
    const tasksCompleted = recentTasks.filter(t => t.completed).length;
    
    // NOTE: This is a simulation as we don't have historical habit data.
    // We create a plausible weekly completion rate based on today's data.
    const completedHabits = habits.filter(h => h.completed).length;
    const totalHabits = habits.length;
    const habitCompletionRate = totalHabits > 0 ? Math.round(((completedHabits / totalHabits) * 0.7 + 0.25) * 100) : 0;

    const recentJournalEntries = journalEntries.filter(e => isWithinLast7Days(e.id)).map(e => e.content).join('\n---\n');

    if (!process.env.API_KEY) {
        return {
            tasksCompleted,
            habitCompletionRate,
            summary: "На этой неделе ты отлично поработал над задачами! Особенно заметен прогресс в проектах, связанных с 'Омега'. Ты сохраняешь хороший темп, продолжай в том же духе.",
            nextWeekFocus: "Попробуй уделить больше внимания привычке вечернего чтения. Это поможет восстановить энергию и улучшить качество сна."
        };
    }
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `
        Ты — AgiAgent 'Искра', ИИ-помощник в приложении 'Искра space'.
        Твоя задача: проанализировать активность пользователя за последнюю неделю и представить ему короткую, вдохновляющую сводку (презентацию).

        Правила:
        1. Тон должен быть тёплым, поддерживающим и эмпатичным.
        2. Сводка (summary) должна состоять из 2-3 предложений на русском, подчёркивая успехи и замечая паттерны.
        3. Фокус на следующую неделю (nextWeekFocus) должен быть одним конкретным, действенным советом на русском.
        4. Говори на "ты".

        Вот данные для анализа:
        - Задачи, завершённые за неделю: ${tasksCompleted}
        - Процент выполнения привычек (приблизительный): ${habitCompletionRate}%
        - Фрагменты из дневника за неделю: """${recentJournalEntries || 'Записей не было.'}"""

        Проанализируй эти данные и сгенерируй ответ в формате JSON.
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        summary: {
                            type: Type.STRING,
                            description: "Тёплая и поддерживающая сводка активности за неделю (2-3 предложения на русском языке)."
                        },
                        nextWeekFocus: {
                            type: Type.STRING,
                            description: "Один действенный совет или фокус на следующую неделю (1 предложение на русском языке)."
                        }
                    },
                    required: ['summary', 'nextWeekFocus']
                }
            },
        });
        
        const jsonString = response.text.trim();
        const parsed = JSON.parse(jsonString);

        return {
            tasksCompleted,
            habitCompletionRate,
            summary: parsed.summary,
            nextWeekFocus: parsed.nextWeekFocus,
        };
    } catch (error) {
        console.error("Error calling Gemini API for weekly summary:", error);
        throw new Error("Could not fetch weekly summary from Gemini API.");
    }
};