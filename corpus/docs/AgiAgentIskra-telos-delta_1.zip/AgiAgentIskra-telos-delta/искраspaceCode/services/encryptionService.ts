// Fix: Corrected import path for type definitions.
import type { StoredKeys } from '../types';

const KEY_STORAGE_PREFIX = 'iskra-chat-keys-';

// Helper function to convert ArrayBuffer to Base64
const bufferToBase64 = (buffer: ArrayBuffer): string => {
    return btoa(String.fromCharCode(...new Uint8Array(buffer)));
};

// Helper function to convert Base64 to ArrayBuffer
const base64ToBuffer = (base64: string): ArrayBuffer => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
};

// Generate a new ECDH key pair for encryption
export const generateKeys = async (): Promise<CryptoKeyPair> => {
    return await window.crypto.subtle.generateKey(
        { name: 'ECDH', namedCurve: 'P-256' },
        true,
        ['deriveKey']
    );
};

// Export keys to a storable format (JWK)
export const exportKeys = async (keys: CryptoKeyPair): Promise<StoredKeys> => {
    const [publicKey, privateKey] = await Promise.all([
        window.crypto.subtle.exportKey('jwk', keys.publicKey),
        window.crypto.subtle.exportKey('jwk', keys.privateKey),
    ]);
    return { publicKey, privateKey };
};

// Import keys from storage
export const importKeys = async (storedKeys: StoredKeys): Promise<CryptoKeyPair> => {
    const [publicKey, privateKey] = await Promise.all([
        window.crypto.subtle.importKey(
            'jwk',
            storedKeys.publicKey,
            { name: 'ECDH', namedCurve: 'P-256' },
            true,
            []
        ),
        window.crypto.subtle.importKey(
            'jwk',
            storedKeys.privateKey,
            { name: 'ECDH', namedCurve: 'P-256' },
            true,
            ['deriveKey']
        ),
    ]);
    return { publicKey, privateKey };
};

// Store keys in localStorage
export const storeKeysForUser = async (userId: string, keys: CryptoKeyPair): Promise<void> => {
    const exportableKeys = await exportKeys(keys);
    localStorage.setItem(KEY_STORAGE_PREFIX + userId, JSON.stringify(exportableKeys));
};

// Retrieve and import keys from localStorage
export const getKeysForUser = async (userId: string): Promise<CryptoKeyPair | null> => {
    const stored = localStorage.getItem(KEY_STORAGE_PREFIX + userId);
    if (!stored) return null;
    try {
        const storedKeys: StoredKeys = JSON.parse(stored);
        return await importKeys(storedKeys);
    } catch (e) {
        console.error("Failed to parse or import keys:", e);
        return null;
    }
};

// Derive a shared secret key for AES-GCM encryption
export const deriveSharedSecret = async (privateKey: CryptoKey, publicKeyJwk: JsonWebKey): Promise<CryptoKey> => {
    const publicKey = await window.crypto.subtle.importKey(
        'jwk',
        publicKeyJwk,
        // FIX: Corrected typo from P-25S to P-256 for the elliptic curve name.
        { name: 'ECDH', namedCurve: 'P-256' },
        true,
        []
    );

    return await window.crypto.subtle.deriveKey(
        { name: 'ECDH', public: publicKey },
        privateKey,
        { name: 'AES-GCM', length: 256 },
        true,
        ['encrypt', 'decrypt']
    );
};

// Encrypt a message
export const encryptMessage = async (text: string, sharedSecret: CryptoKey): Promise<{ ciphertext: string, iv: string }> => {
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 96-bit IV
    const encodedText = new TextEncoder().encode(text);

    const ciphertext = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        sharedSecret,
        encodedText
    );

    return {
        ciphertext: bufferToBase64(ciphertext),
        iv: bufferToBase64(iv.buffer),
    };
};

// Decrypt a message
export const decryptMessage = async (ciphertext: string, iv: string, sharedSecret: CryptoKey): Promise<string> => {
    try {
        const decrypted = await window.crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: base64ToBuffer(iv) },
            sharedSecret,
            base64ToBuffer(ciphertext)
        );
        return new TextDecoder().decode(decrypted);
    } catch (e) {
        console.error("Decryption failed:", e);
        return "🔒 Не удалось расшифровать сообщение.";
    }
};