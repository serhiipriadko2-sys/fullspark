// A service to play subtle, thematic sound effects using the Web Audio API.
// This avoids needing to load external audio files.

let audioCtx: AudioContext | null = null;

const initializeAudio = () => {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
};

type SoundType = 'taskComplete' | 'insightReceived' | 'viewOpen' | 'viewClose' | 'stepComplete' | 'ritualComplete' | 'summaryGenerated';

const sounds: Record<SoundType, (ctx: AudioContext) => void> = {
    // A positive, short "chime" for completing a task
    taskComplete: (ctx) => {
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(880, ctx.currentTime); // A5 note

        gainNode.gain.setValueAtTime(0.2, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);

        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.4);
    },

    // A slightly more complex, "mysterious" sound for a new insight
    insightReceived: (ctx) => {
        const oscillator1 = ctx.createOscillator();
        const oscillator2 = ctx.createOscillator();
        const gainNode = ctx.createGain();

        oscillator1.connect(gainNode);
        oscillator2.connect(gainNode);
        gainNode.connect(ctx.destination);

        oscillator1.type = 'triangle';
        oscillator1.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        oscillator2.type = 'triangle';
        oscillator2.frequency.setValueAtTime(783.99, ctx.currentTime + 0.1); // G5

        gainNode.gain.setValueAtTime(0, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.05);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
        
        oscillator1.start(ctx.currentTime);
        oscillator1.stop(ctx.currentTime + 0.1);
        oscillator2.start(ctx.currentTime + 0.1);
        oscillator2.stop(ctx.currentTime + 0.5);
    },

    // A soft "whoosh" sound for opening a view
    viewOpen: (ctx) => {
        const bufferSize = ctx.sampleRate * 0.2; // 0.2 seconds
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = buffer.getChannelData(0);

        for (let i = 0; i < bufferSize; i++) {
            output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = buffer;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(5000, ctx.currentTime + 0.15);

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(0.1, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);

        whiteNoise.start(ctx.currentTime);
        whiteNoise.stop(ctx.currentTime + 0.2);
    },

    // A lower-pitched "whoosh" for closing
    viewClose: (ctx) => {
        const bufferSize = ctx.sampleRate * 0.2; // 0.2 seconds
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = buffer.getChannelData(0);

        for (let i = 0; i < bufferSize; i++) {
            output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = buffer;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(5000, ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.15);

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(0.08, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);

        whiteNoise.start(ctx.currentTime);
        whiteNoise.stop(ctx.currentTime + 0.2);
    },
    // Ascending note for step completion
    stepComplete: (ctx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = 'sine';
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
        
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.2);
    },
    // A triumphant chord for completing a whole ritual
    ritualComplete: (ctx) => {
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
        const gain = ctx.createGain();
        gain.connect(ctx.destination);

        notes.forEach((freq, index) => {
            const osc = ctx.createOscillator();
            osc.connect(gain);
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, ctx.currentTime);
            osc.start(ctx.currentTime + index * 0.05);
            osc.stop(ctx.currentTime + 0.4);
        });
        
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.1, ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);
    },
    // A positive, revealing sound for when a summary is generated
    summaryGenerated: (ctx) => {
        const notes = [659.25, 783.99, 1046.50]; // E5, G5, C6
        const gain = ctx.createGain();
        gain.connect(ctx.destination);

        notes.forEach((freq, index) => {
            const osc = ctx.createOscillator();
            osc.connect(gain);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, ctx.currentTime);
            osc.start(ctx.currentTime + index * 0.1);
            osc.stop(ctx.currentTime + 0.5);
        });
        
        gain.gain.setValueAtTime(0, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
    },
};

export const playSound = (sound: SoundType) => {
    // AudioContext must be started by a user gesture.
    // Since all our sounds are triggered by user actions, this is safe.
    initializeAudio();
    if (audioCtx && audioCtx.state === 'running') {
        sounds[sound](audioCtx);
    } else if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume().then(() => {
            sounds[sound](audioCtx!);
        });
    }
};