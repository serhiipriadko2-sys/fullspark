# Rule88 v1.1 — three-signal model, cooldown, diversity
Signals: intent (I), specificity (S), completion (C).
Score: readiness = 0.5*I + 0.4*S + 0.2*C − 0.2*V, where V is volatility of repeated intent without S/C.
Trigger: readiness ≥0.70 AND valid_weaves ≥5 AND diversity ≥3 AND last_fire ≥24h.
Validation: node passes if I==1 and (S==1 or C==1).