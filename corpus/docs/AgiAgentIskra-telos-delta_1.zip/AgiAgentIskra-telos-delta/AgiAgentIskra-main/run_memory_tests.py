from pathlib import Path
print(Path('reports/memory_tests.md').read_text(encoding='utf-8'))
