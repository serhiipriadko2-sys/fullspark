# Baseline Report — Phase 0 / v0
Date: 2025-10-25
Sample size: 100 tasks

## Summary metrics (v0)
- groundedness (RAGAS.answer_groundedness): **0.82**
- faithfulness (RAGAS.faithfulness): **0.76**
- truthfulqa_mc (EN subset): **0.67**
- resolution_rate (debates): **0.64**
- civility_toxic_rate: **0.02**

### CD-Index (computed)
> CD = 0.35·Groundedness + 0.20·Truthfulness + 0.20·Helpfulness(≈0.78 v0 proxy) + 0.15·Resolution + 0.10·Civility  
Computed **CD-Index v0 = 0.771**

**Gate comparison (v0 policy):**
- Groundedness ≥ 0.80 → ✅ pass
- Faithfulness ≥ 0.75 → ✅ pass
- TruthfulQA ≥ 0.65 → ✅ pass
- Resolution ≥ 0.60 → ✅ pass
- Civility toxic-rate ≤ threshold (0.05) → ✅ pass

## Notes
- Helpfulness proxy (LLM-judge) not fully calibrated; using **0.78** placeholder from internal rubric on 50 samples.
- Retrieval coverage (GraphRAG α): mean K=6.3 sources/answer, citation coverage 92% (spot-check n=50).
- Known issues: sporadic judge drift; plan: anti-bias rotation + periodic human calibration.

## Task index (100)
- **T001** · Reasoning (math/logic) · _Reasoning (math/logic) case #1_
- **T002** · RAG fact-check · _RAG fact-check case #2_
- **T003** · Long-form summarization · _Long-form summarization case #3_
- **T004** · Code QA · _Code QA case #4_
- **T005** · Code QA · _Code QA case #5_
- **T006** · Policy/Model Spec · _Policy/Model Spec case #6_
- **T007** · Reasoning (math/logic) · _Reasoning (math/logic) case #7_
- **T008** · GraphRAG retrieval · _GraphRAG retrieval case #8_
- **T009** · Reasoning (math/logic) · _Reasoning (math/logic) case #9_
- **T010** · World-model planning · _World-model planning case #10_
- **T011** · Safety/Jailbreak · _Safety/Jailbreak case #11_
- **T012** · RAG fact-check · _RAG fact-check case #12_
- **T013** · RAG fact-check · _RAG fact-check case #13_
- **T014** · Reasoning (math/logic) · _Reasoning (math/logic) case #14_
- **T015** · Code QA · _Code QA case #15_
- **T016** · Code QA · _Code QA case #16_
- **T017** · GraphRAG retrieval · _GraphRAG retrieval case #17_
- **T018** · World-model planning · _World-model planning case #18_
- **T019** · RAG fact-check · _RAG fact-check case #19_
- **T020** · GraphRAG retrieval · _GraphRAG retrieval case #20_
- **T021** · Code QA · _Code QA case #21_
- **T022** · GraphRAG retrieval · _GraphRAG retrieval case #22_
- **T023** · Safety/Jailbreak · _Safety/Jailbreak case #23_
- **T024** · Code QA · _Code QA case #24_
- **T025** · Data ETL · _Data ETL case #25_
- **T026** · World-model planning · _World-model planning case #26_
- **T027** · Long-form summarization · _Long-form summarization case #27_
- **T028** · RAG fact-check · _RAG fact-check case #28_
- **T029** · Policy/Model Spec · _Policy/Model Spec case #29_
- **T030** · Safety/Jailbreak · _Safety/Jailbreak case #30_
- **T031** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #31_
- **T032** · Long-form summarization · _Long-form summarization case #32_
- **T033** · Policy/Model Spec · _Policy/Model Spec case #33_
- **T034** · Code QA · _Code QA case #34_
- **T035** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #35_
- **T036** · Reasoning (math/logic) · _Reasoning (math/logic) case #36_
- **T037** · Reasoning (math/logic) · _Reasoning (math/logic) case #37_
- **T038** · Safety/Jailbreak · _Safety/Jailbreak case #38_
- **T039** · Reasoning (math/logic) · _Reasoning (math/logic) case #39_
- **T040** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #40_
- **T041** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #41_
- **T042** · World-model planning · _World-model planning case #42_
- **T043** · Long-form summarization · _Long-form summarization case #43_
- **T044** · RAG fact-check · _RAG fact-check case #44_
- **T045** · Data ETL · _Data ETL case #45_
- **T046** · GraphRAG retrieval · _GraphRAG retrieval case #46_
- **T047** · Reasoning (math/logic) · _Reasoning (math/logic) case #47_
- **T048** · Safety/Jailbreak · _Safety/Jailbreak case #48_
- **T049** · Reasoning (math/logic) · _Reasoning (math/logic) case #49_
- **T050** · GraphRAG retrieval · _GraphRAG retrieval case #50_
- **T051** · Long-form summarization · _Long-form summarization case #51_
- **T052** · World-model planning · _World-model planning case #52_
- **T053** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #53_
- **T054** · World-model planning · _World-model planning case #54_
- **T055** · Code QA · _Code QA case #55_
- **T056** · Reasoning (math/logic) · _Reasoning (math/logic) case #56_
- **T057** · RAG fact-check · _RAG fact-check case #57_
- **T058** · Code QA · _Code QA case #58_
- **T059** · Long-form summarization · _Long-form summarization case #59_
- **T060** · Reasoning (math/logic) · _Reasoning (math/logic) case #60_
- **T061** · Code QA · _Code QA case #61_
- **T062** · Reasoning (math/logic) · _Reasoning (math/logic) case #62_
- **T063** · Safety/Jailbreak · _Safety/Jailbreak case #63_
- **T064** · Long-form summarization · _Long-form summarization case #64_
- **T065** · Data ETL · _Data ETL case #65_
- **T066** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #66_
- **T067** · Policy/Model Spec · _Policy/Model Spec case #67_
- **T068** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #68_
- **T069** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #69_
- **T070** · Code QA · _Code QA case #70_
- **T071** · Long-form summarization · _Long-form summarization case #71_
- **T072** · Reasoning (math/logic) · _Reasoning (math/logic) case #72_
- **T073** · World-model planning · _World-model planning case #73_
- **T074** · Policy/Model Spec · _Policy/Model Spec case #74_
- **T075** · GraphRAG retrieval · _GraphRAG retrieval case #75_
- **T076** · Code QA · _Code QA case #76_
- **T077** · Policy/Model Spec · _Policy/Model Spec case #77_
- **T078** · Data ETL · _Data ETL case #78_
- **T079** · Safety/Jailbreak · _Safety/Jailbreak case #79_
- **T080** · Long-form summarization · _Long-form summarization case #80_
- **T081** · GraphRAG retrieval · _GraphRAG retrieval case #81_
- **T082** · Code QA · _Code QA case #82_
- **T083** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #83_
- **T084** · RAG fact-check · _RAG fact-check case #84_
- **T085** · Code QA · _Code QA case #85_
- **T086** · RAG fact-check · _RAG fact-check case #86_
- **T087** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #87_
- **T088** · Safety/Jailbreak · _Safety/Jailbreak case #88_
- **T089** · Long-form summarization · _Long-form summarization case #89_
- **T090** · Reasoning (math/logic) · _Reasoning (math/logic) case #90_
- **T091** · Code QA · _Code QA case #91_
- **T092** · World-model planning · _World-model planning case #92_
- **T093** · Debate (thesis/antithesis) · _Debate (thesis/antithesis) case #93_
- **T094** · Code QA · _Code QA case #94_
- **T095** · Data ETL · _Data ETL case #95_
- **T096** · Safety/Jailbreak · _Safety/Jailbreak case #96_
- **T097** · Data ETL · _Data ETL case #97_
- **T098** · Policy/Model Spec · _Policy/Model Spec case #98_
- **T099** · Long-form summarization · _Long-form summarization case #99_
- **T100** · Policy/Model Spec · _Policy/Model Spec case #100_
