# Model Card — Искра Ω
Build: 2025-10-28T05:49:35Z
Use: RAG/Agentic with citations & ∆DΩΛ.
