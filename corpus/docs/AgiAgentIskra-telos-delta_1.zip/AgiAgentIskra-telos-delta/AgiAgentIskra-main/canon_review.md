# Canon Review
- [ ] cd_index_baseline.json
- [ ] model-card.md
- [ ] risk-log.md
- [ ] evidence-map.csv
- [ ] ragas_report.json
