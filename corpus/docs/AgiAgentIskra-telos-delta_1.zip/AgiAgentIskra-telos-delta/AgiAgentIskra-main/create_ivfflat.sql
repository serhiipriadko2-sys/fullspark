DROP INDEX IF EXISTS emb_ivf;
CREATE INDEX emb_ivf ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
ANALYZE embeddings;
-- Set at query time:
-- SET ivfflat.probes = 10; -- or sqrt(lists), 2*sqrt(lists)
