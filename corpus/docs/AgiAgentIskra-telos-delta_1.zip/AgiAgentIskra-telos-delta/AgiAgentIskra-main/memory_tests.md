# MemoryManager Smoke Report

- ERROR executing memory_manager.py: Shadow entry requires non-empty 'pattern'
