
## 2025-10-25 — Baseline Report v0 + Canon Review Gate
**Δ:** Сформирован baseline_report.md на 100 задач; пройден canon_review_test; настроен gate (collect/decide/enforce)
**D:** Метрики v0; CI-стабы; соответствие порогам (Groundedness≥0.80; Faithfulness≥0.75; TruthfulQA≥0.65; Resolution≥0.60)
**Ω:** Высокая — все гейты v0 пройдены (KEEP)
**Λ:** Перейти к Неделе 2 (GraphRAG ETL), подготовить cd-index_v0.json для следующего ревью
traceability_link: sandbox:/mnt/data/reports/baseline_report.md
