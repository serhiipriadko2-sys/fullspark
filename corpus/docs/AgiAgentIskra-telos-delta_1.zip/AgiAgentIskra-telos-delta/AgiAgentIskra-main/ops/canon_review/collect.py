import json, sys
from pathlib import Path

ARTIFACTS = {
    "baseline_report": "baseline_report.md",
    "cd_index": "cd-index_v1.json",
    "risk_log": "risk-log.md"
}

missing = [k for k, p in ARTIFACTS.items() if not Path(p).exists()]
if missing:
    print("Missing artifacts:", missing)
    # Не валим сборку: даём шанс PR-обсуждению
    sys.exit(0)

data = {
    "baseline_report": Path(ARTIFACTS["baseline_report"]).read_text(encoding="utf-8"),
    "cd_index": json.loads(Path(ARTIFACTS["cd_index"]).read_text(encoding="utf-8")),
    "risk_log": Path(ARTIFACTS["risk_log"]).read_text(encoding="utf-8")
}
Path("canon").mkdir(exist_ok=True)
Path("canon/canon_review_input.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
print("Collected → canon/canon_review_input.json")
