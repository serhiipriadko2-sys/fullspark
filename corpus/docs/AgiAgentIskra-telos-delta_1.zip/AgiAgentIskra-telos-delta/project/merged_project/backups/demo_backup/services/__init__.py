"""
Сервисный слой интегрированной архитектуры.

Содержит:
- Dependency Injection контейнер
- Сервисы бизнес-логики
- Утилиты для управления зависимостями
"""

from .dependency_injection import (
    Container,
    ServiceRegistry,
    get_container,
    get_service_registry,
    singleton,
    injectable,
    legacy_service,
    v2_service
)

__all__ = [
    "Container",
    "ServiceRegistry", 
    "get_container",
    "get_service_registry",
    "singleton",
    "injectable",
    "legacy_service",
    "v2_service"
]