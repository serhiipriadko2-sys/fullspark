# Интегрированная система памяти

## Обзор

Интегрированная система памяти объединяет простую синхронную память Version 1 с продвинутой асинхронной памятью Version 2, обеспечивая плавную миграцию и гибкую работу в различных режимах.

## Основные возможности

### Поддерживаемые режимы

1. **Legacy Mode (Version 1)** - Простая синхронная память
   - Полная совместимость с Version 1
   - Синхронные операции
   - Минимальные накладные расходы
   - Идеально для простых сценариев

2. **Modern Mode (Version 2)** - Продвинутая асинхронная память
   - Асинхронные I/O операции
   - Batch обработка для производительности
   - Сжатие данных
   - Автоматический фоновый сброс
   - Оптимизировано для высокой нагрузки

3. **Hybrid Mode** - Дублирование в обе системы
   - Сохранение данных в Legacy и Modern одновременно
   - Максимальная надежность
   - Гибкость при выборе системы для чтения

4. **Migration Mode** - Постепенная миграция
   - Автоматическая синхронизация данных
   - Прозрачная миграция без простоев
   - Мониторинг прогресса
   - Возможность отката

### Ключевые особенности

- **Совместимость данных**: Обеспечивает совместимость между Version 1 и Version 2
- **Постепенная миграция**: Позволяет переходить от простой к продвинутой системе без остановки
- **Производительность**: Оптимизирована для различных сценариев использования
- **Мониторинг**: Встроенная статистика и мониторинг производительности
- **Масштабируемость**: Поддержка batch операций и асинхронной обработки

## Быстрый старт

### Базовое использование

```python
from memory.integrated_memory import IntegratedMemoryManager, MemoryMode, MemoryConfig

# Создание конфигурации
config = MemoryConfig(
    mode=MemoryMode.HYBRID,  # Дублирование в обе системы
    root_path="./memory",
    modern_batch_size=50,
    modern_compress=True
)

# Использование с контекстным менеджером
with IntegratedMemoryManager(config) as memory:
    # Сохранение данных
    event = memory.put(
        kind="archive",
        key="my_key",
        value={"data": "my_value"}
    )
    
    # Получение данных
    events = memory.get(kind="archive", key="my_key")
    print(f"Найдено событий: {len(events)}")
```

### Legacy Mode (Version 1)

```python
from memory.integrated_memory import MemoryMode, MemoryConfig

config = MemoryConfig(mode=MemoryMode.LEGACY)
with IntegratedMemoryManager(config) as memory:
    # Синхронные операции
    event = memory.put("archive", "key", {"data": "value"})
    events = memory.get("archive", "key")
```

### Modern Mode (Version 2)

```python
import asyncio
from memory.integrated_memory import MemoryMode, MemoryConfig

async def modern_example():
    config = MemoryConfig(
        mode=MemoryMode.MODERN,
        modern_batch_size=20,
        modern_compress=True
    )
    
    with IntegratedMemoryManager(config) as memory:
        # Асинхронные операции
        event = await memory.put_async("archive", "key", {"data": "value"})
        events = await memory.get_async("archive", "key")
        print(f"Найдено событий: {len(events)}")

asyncio.run(modern_example())
```

### Migration Mode

```python
import asyncio
from memory.integrated_memory import MemoryMode, MemoryConfig
from memory.migration_tools import run_comprehensive_migration

async def migration_example():
    config = MemoryConfig(
        mode=MemoryMode.MIGRATION,
        migration_auto_sync=True
    )
    
    with IntegratedMemoryManager(config) as memory:
        # Сохранение в Legacy (автоматически синхронизируется с Modern)
        event = await memory.put_async("archive", "key", {"data": "value"})
        
        # Выполнение полной миграции
        stats = await run_comprehensive_migration(
            memory,
            direction="legacy_to_modern",
            kinds=["archive"]
        )
        print(f"Мигрировано событий: {stats.migrated_events}")

asyncio.run(migration_example())
```

## Архитектура

### Компоненты системы

```
integrated_memory.py     - Основной интегрированный менеджер
legacy_memory.py         - Совместимость с Version 1
modern_memory.py         - Улучшенная память Version 2
migration_tools.py       - Инструменты миграции и синхронизации
```

### Схема взаимодействия

```
┌─────────────────┐    ┌─────────────────┐
│   Integrated    │    │   Integration   │
│   Memory        │◄──►│     Layer       │
│   Manager       │    │                 │
└─────────────────┘    └─────────────────┘
         │                       │
         ▼                       ▼
┌─────────────────┐    ┌─────────────────┐
│   Legacy        │    │     Modern      │
│   Memory V1     │    │   Memory V2     │
│  (Synchronous)  │    │  (Asynchronous) │
└─────────────────┘    └─────────────────┘
         │                       │
         ▼                       ▼
┌─────────────────┐    ┌─────────────────┐
│   Simple        │    │   Advanced      │
│   File I/O      │    │  Async I/O      │
└─────────────────┘    └─────────────────┘
```

## Конфигурация

### Основные параметры MemoryConfig

```python
config = MemoryConfig(
    # Режим работы
    mode=MemoryMode.HYBRID,
    
    # Пути
    root_path="./memory",
    
    # Legacy настройки
    legacy_enabled=True,
    legacy_auto_flush=True,
    
    # Modern настройки
    modern_enabled=True,
    modern_batch_size=50,
    modern_flush_interval=5.0,
    modern_compress=False,
    max_workers=4,
    
    # Миграция
    migration_auto_sync=True,
    migration_sync_interval=60.0,
    migration_batch_size=100,
    enable_real_time_sync=False,
    
    # Мониторинг
    enable_stats=True,
    stats_update_interval=30.0,
    enable_performance_monitoring=True
)
```

### Производительность и оптимизация

#### Batch Size (Размер батча)
- **Legacy**: 20-50 событий
- **Modern**: 50-100 событий
- Оптимальный размер зависит от размера событий и нагрузки

#### Compression (Сжатие)
- Уменьшает размер файлов на 50-80%
- Подходит для больших объемов данных
- Добавляет небольшие накладные расходы на CPU

#### Async Workers (Асинхронные воркеры)
- **Рекомендуется**: 2-8 потоков
- Больше потоков = больше параллелизма
- Зависит от возможностей системы

## Миграция данных

### Автоматическая миграция

```python
# В Migration режиме данные автоматически синхронизируются
config = MemoryConfig(
    mode=MemoryMode.MIGRATION,
    migration_auto_sync=True
)

memory = IntegratedMemoryManager(config)
```

### Ручная миграция

```python
from memory.migration_tools import MigrationManager

migration_manager = MigrationManager(memory)

# Запуск миграции
stats = await migration_manager.start_migration(
    direction="legacy_to_modern",
    kinds=["archive", "shadow"],
    since=timestamp  # Опциональная фильтрация по времени
)

print(f"Мигрировано: {stats.migrated_events}/{stats.total_events}")
```

### Верификация миграции

```python
# Проверка корректности миграции
verification = await migration_manager.verify_migration()
print(f"Совпадений: {verification['match_percentage']:.1f}%")
```

### Контрольные точки

```python
# Создание контрольной точки
checkpoint = await migration_manager.create_checkpoint("migration_progress")

# Восстановление из контрольной точки
success = await migration_manager.restore_checkpoint("migration_progress")
```

## Мониторинг и статистика

### Получение статистики

```python
memory = IntegratedMemoryManager(config)

# Общая статистика
stats = memory.get_stats()
print(f"Операций: {stats['total_operations']}")
print(f"Ошибок: {stats['error_count']}")

# Статистика компонентов
component_stats = stats['components']
if 'legacy' in component_stats:
    print(f"Legacy: {component_stats['legacy']}")
if 'modern' in component_stats:
    print(f"Modern: {component_stats['modern']}")
```

### Мониторинг в реальном времени

```python
config = MemoryConfig(
    enable_stats=True,
    stats_update_interval=30.0,  # Обновление каждые 30 секунд
    enable_performance_monitoring=True
)
```

## Обработка ошибок

### Восстановление после ошибок

```python
try:
    event = memory.put("archive", "key", {"data": "value"})
except Exception as e:
    print(f"Ошибка записи: {e}")
    # Автоматический fallback или повторная попытка
```

### Валидация данных

```python
# Проверка целостности данных между системами
from memory.migration_tools import DataIntegrityChecker

checker = DataIntegrityChecker(legacy_memory, modern_memory)
comparison = await checker.compare_systems()
```

## Тестирование

### Запуск тестов

```bash
# Запуск всех тестов
python -m memory.tests.test_integration

# Запуск конкретного тестового класса
python -m unittest memory.tests.test_integration.TestLegacyMemory

# Запуск с подробным выводом
python -m memory.tests.test_integration -v
```

### Демонстрация

```bash
# Запуск демонстрации всех возможностей
python memory/demo.py
```

## Примеры использования

### Веб-приложение с кешированием

```python
from memory.integrated_memory import IntegratedMemoryManager, MemoryMode, MemoryConfig

# Настройка для веб-приложения
config = MemoryConfig(
    mode=MemoryMode.HYBRID,
    root_path="./web_cache",
    modern_batch_size=100,
    modern_compress=True
)

class WebCache:
    def __init__(self):
        self.memory = IntegratedMemoryManager(config)
    
    async def cache_response(self, url, response):
        await self.memory.put_async(
            kind="cache",
            key=f"response:{url}",
            value=response,
            meta={"cached_at": time.time()}
        )
    
    async def get_cached_response(self, url):
        events = await self.memory.get_async(kind="cache", key=f"response:{url}")
        return events[0].value if events else None
```

### Система логирования

```python
# Высокопроизводительное логирование
config = MemoryConfig(
    mode=MemoryMode.MODERN,
    root_path="./logs",
    modern_batch_size=200,
    modern_compress=True,
    max_workers=8
)

class AsyncLogger:
    def __init__(self):
        self.memory = IntegratedMemoryManager(config)
    
    async def log(self, level, message, **kwargs):
        await self.memory.put_async(
            kind="log",
            key=f"{level}:{int(time.time())}",
            value={
                "level": level,
                "message": message,
                "timestamp": time.time(),
                **kwargs
            }
        )
```

### Постепенная миграция системы

```python
async def migrate_existing_system():
    # 1. Запуск в Migration режиме
    config = MemoryConfig(
        mode=MemoryMode.MIGRATION,
        migration_auto_sync=True
    )
    
    memory = IntegratedMemoryManager(config)
    
    # 2. Создание данных в старом формате
    # (система автоматически синхронизирует их)
    
    # 3. Выполнение полной миграции
    stats = await run_comprehensive_migration(
        memory,
        direction="legacy_to_modern"
    )
    
    # 4. Переключение на Modern режим
    modern_config = MemoryConfig(mode=MemoryMode.MODERN)
    modern_memory = IntegratedMemoryManager(modern_config)
    
    return modern_memory
```

## Производительность

### Сравнение режимов

| Режим | Производительность | Задержка | Надежность | Совместимость |
|-------|-------------------|----------|------------|---------------|
| Legacy | Высокая | Низкая | Базовая | 100% V1 |
| Modern | Очень высокая | Очень низкая | Высокая | Новый API |
| Hybrid | Средняя | Низкая | Максимальная | Ограниченная |
| Migration | Зависит от этапа | Низкая | Высокая | Полная |

### Рекомендации по выбору режима

#### Legacy Mode
- Простые приложения
- Низкая нагрузка
- Полная совместимость с Version 1
- Минимальные требования к ресурсам

#### Modern Mode
- Высоконагруженные приложения
- Большие объемы данных
- Требования к производительности
- Современная архитектура

#### Hybrid Mode
- Критические данные
- Максимальная надежность
- Переходный период
- Репликация данных

#### Migration Mode
- Постепенная миграция
- Минимизация простоев
- Обратная совместимость
- Откат при необходимости

## Устранение неполадок

### Частые проблемы

#### Медленная производительность
- Увеличьте `modern_batch_size`
- Включите `modern_compress`
- Добавьте `max_workers`
- Проверьте настройки диска

#### Ошибки миграции
- Проверьте права доступа к файлам
- Убедитесь в достаточном дисковом пространстве
- Используйте контрольные точки
- Выполните верификацию данных

#### Потеря данных
- Включите Hybrid режим для критичных данных
- Регулярно создавайте резервные копии
- Мониторьте синхронизацию
- Используйте верификацию

### Логирование

```python
import logging

# Включение подробного логирования
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('memory')
```

## API Reference

### IntegratedMemoryManager

#### Основные методы

- `put(kind, key, value, meta=None)` - Сохранение события (синхронный)
- `put_async(kind, key, value, meta=None)` - Сохранение события (асинхронный)
- `get(kind, key, since=None)` - Получение событий (синхронный)
- `get_async(kind, key, since=None)` - Получение событий (асинхронный)
- `flush_all()` - Принудительный сброс всех буферов
- `close()` - Закрытие системы
- `get_stats()` - Получение статистики

### MemoryEvent

#### Свойства

- `t` - Время создания события
- `kind` - Тип события ("archive" или "shadow")
- `key` - Ключ события
- `value` - Данные события
- `meta` - Метаданные (опционально)

### MigrationManager

#### Методы миграции

- `start_migration(direction, kinds, since)` - Запуск миграции
- `verify_migration(direction)` - Верификация результатов
- `create_checkpoint(name)` - Создание контрольной точки
- `restore_checkpoint(name)` - Восстановление из контрольной точки
- `get_migration_status()` - Получение статуса миграции

## Лицензия

Система разработана для интеграции с проектом Iskra и распространяется на условиях соответствующей лицензии.

## Поддержка

Для получения поддержки и сообщения об ошибках обращайтесь к документации проекта Iskra.