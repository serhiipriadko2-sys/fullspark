"""Тесты интегрированной системы памяти.

Проверяет:
- Совместимость с Version 1 (Legacy)
- Функциональность Version 2 (Modern)
- Интеграционные режимы (Hybrid, Migration)
- Миграцию данных
- Производительность различных режимов
"""

import unittest
import asyncio
import os
import tempfile
import shutil
import time
import json
from typing import List, Dict, Any

# Импорт модулей системы памяти
from ..memory.integrated_memory import (
    IntegratedMemoryManager, MemoryMode, MemoryConfig, MemoryEvent
)
from ..memory.legacy_memory import LegacyMemoryManager
from ..memory.modern_memory import ModernMemoryManager
from ..memory.migration_tools import MigrationManager, DataSynchronizer, DataIntegrityChecker


class TestLegacyMemory(unittest.TestCase):
    """Тесты Legacy Memory Manager (Version 1)."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
        self.legacy_memory = LegacyMemoryManager(root=self.test_dir)
    
    def tearDown(self):
        """Очистка после тестов."""
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    def test_put_and_get(self):
        """Тест базового сохранения и получения данных."""
        # Сохранение события
        event = self.legacy_memory.put(
            kind="archive",
            key="test_key",
            value={"data": "test_value"}
        )
        
        # Проверка события
        self.assertIsInstance(event, MemoryEvent)
        self.assertEqual(event.kind, "archive")
        self.assertEqual(event.key, "test_key")
        self.assertEqual(event.value["data"], "test_value")
        
        # Получение события
        events = self.legacy_memory.get(kind="archive", key="test_key")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].key, "test_key")
    
    def test_multiple_events(self):
        """Тест работы с несколькими событиями."""
        # Сохранение нескольких событий
        for i in range(5):
            self.legacy_memory.put(
                kind="archive",
                key=f"key_{i}",
                value={"index": i}
            )
        
        # Получение всех событий
        events = self.legacy_memory.get(kind="archive")
        self.assertEqual(len(events), 5)
        
        # Проверка фильтрации по ключу
        specific_events = self.legacy_memory.get(kind="archive", key="key_2")
        self.assertEqual(len(specific_events), 1)
        self.assertEqual(specific_events[0].value["index"], 2)
    
    def test_archive_and_shadow_separation(self):
        """Тест разделения archive и shadow событий."""
        # Сохранение в archive
        archive_event = self.legacy_memory.put(
            kind="archive",
            key="archive_key",
            value={"type": "archive"}
        )
        
        # Сохранение в shadow
        shadow_event = self.legacy_memory.put(
            kind="shadow",
            key="shadow_key",
            value={"type": "shadow"}
        )
        
        # Проверка разделения
        archive_events = self.legacy_memory.get(kind="archive")
        shadow_events = self.legacy_memory.get(kind="shadow")
        
        self.assertEqual(len(archive_events), 1)
        self.assertEqual(len(shadow_events), 1)
        self.assertEqual(archive_events[0].key, "archive_key")
        self.assertEqual(shadow_events[0].key, "shadow_key")
    
    def test_time_filtering(self):
        """Тест фильтрации по времени."""
        current_time = time.time()
        
        # Сохранение старого события
        old_event = self.legacy_memory.put(
            kind="archive",
            key="old_key",
            value={"time": "old"}
        )
        
        time.sleep(0.1)  # Небольшая задержка
        
        # Сохранение нового события
        new_event = self.legacy_memory.put(
            kind="archive",
            key="new_key",
            value={"time": "new"}
        )
        
        # Получение событий после определенного времени
        events = self.legacy_memory.get(
            kind="archive",
            since=current_time + 0.05
        )
        
        # Должно быть только новое событие
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].key, "new_key")


class TestModernMemory(unittest.TestCase):
    """Тесты Modern Memory Manager (Version 2)."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
        self.modern_memory = ModernMemoryManager(
            root=self.test_dir,
            batch_size=5,
            flush_interval=1.0
        )
    
    def tearDown(self):
        """Очистка после тестов."""
        asyncio.run(self.modern_memory.close())
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    async def test_async_put_and_get(self):
        """Тест асинхронного сохранения и получения данных."""
        # Сохранение события
        event = await self.modern_memory.put_async(
            kind="archive",
            key="test_key",
            value={"data": "test_value"}
        )
        
        # Проверка события
        self.assertIsInstance(event, MemoryEvent)
        self.assertEqual(event.kind, "archive")
        self.assertEqual(event.key, "test_key")
        
        # Получение события
        events = await self.modern_memory.get_async(kind="archive", key="test_key")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].key, "test_key")
    
    async def test_batch_operations(self):
        """Тест пакетных операций."""
        # Сохранение нескольких событий
        for i in range(10):
            await self.modern_memory.put_async(
                kind="archive",
                key=f"key_{i}",
                value={"index": i}
            )
        
        # Ожидание сброса буфера
        await asyncio.sleep(0.1)
        
        # Получение всех событий
        events = await self.modern_memory.get_async(kind="archive")
        self.assertEqual(len(events), 10)
    
    async def test_compression(self):
        """Тест сжатия данных."""
        # Создание менеджера с сжатием
        compressed_memory = ModernMemoryManager(
            root=self.test_dir + "_compressed",
            compress=True,
            batch_size=3
        )
        
        # Сохранение больших данных
        large_data = {"data": "x" * 1000}  # 1KB данных
        
        for i in range(5):
            await compressed_memory.put_async(
                kind="archive",
                key=f"large_key_{i}",
                value=large_data
            )
        
        # Ожидание сброса буфера
        await asyncio.sleep(0.1)
        
        # Проверка статистики сжатия
        stats = compressed_memory.get_stats()
        self.assertTrue(stats["archive_buffer"]["compression_enabled"])
        
        await compressed_memory.close()
    
    def test_sync_interface(self):
        """Тест синхронного интерфейса."""
        # Использование синхронного интерфейса
        event = self.modern_memory.put_sync(
            kind="archive",
            key="sync_key",
            value={"sync": True}
        )
        
        self.assertIsInstance(event, MemoryEvent)
        self.assertEqual(event.key, "sync_key")
        
        # Получение синхронно
        events = self.modern_memory.get_sync(kind="archive", key="sync_key")
        self.assertEqual(len(events), 1)


class TestIntegratedMemory(unittest.TestCase):
    """Тесты интегрированной системы памяти."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Очистка после тестов."""
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    def test_legacy_mode(self):
        """Тест Legacy режима."""
        config = MemoryConfig(
            mode=MemoryMode.LEGACY,
            root_path=self.test_dir
        )
        
        with IntegratedMemoryManager(config) as memory:
            # Сохранение события
            event = memory.put(
                kind="archive",
                key="legacy_key",
                value={"mode": "legacy"}
            )
            
            self.assertEqual(event.key, "legacy_key")
            
            # Получение события
            events = memory.get(kind="archive", key="legacy_key")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].key, "legacy_key")
    
    async def test_modern_mode(self):
        """Тест Modern режима."""
        config = MemoryConfig(
            mode=MemoryMode.MODERN,
            root_path=self.test_dir,
            modern_batch_size=3
        )
        
        with IntegratedMemoryManager(config) as memory:
            # Сохранение события
            event = await memory.put_async(
                kind="archive",
                key="modern_key",
                value={"mode": "modern"}
            )
            
            self.assertEqual(event.key, "modern_key")
            
            # Получение события
            events = await memory.get_async(kind="archive", key="modern_key")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].key, "modern_key")
    
    def test_hybrid_mode(self):
        """Тест Hybrid режима."""
        config = MemoryConfig(
            mode=MemoryMode.HYBRID,
            root_path=self.test_dir
        )
        
        with IntegratedMemoryManager(config) as memory:
            # Сохранение события в обе системы
            results = memory.put(
                kind="archive",
                key="hybrid_key",
                value={"mode": "hybrid"}
            )
            
            # Результат должен быть кортежем
            self.assertIsInstance(results, tuple)
            self.assertEqual(len(results), 2)
            
            legacy_event, modern_event = results
            self.assertEqual(legacy_event.key, "hybrid_key")
            self.assertEqual(modern_event.key, "hybrid_key")
    
    async def test_migration_mode(self):
        """Тест Migration режима."""
        config = MemoryConfig(
            mode=MemoryMode.MIGRATION,
            root_path=self.test_dir,
            migration_auto_sync=True
        )
        
        with IntegratedMemoryManager(config) as memory:
            # Сохранение события
            event = await memory.put_async(
                kind="archive",
                key="migration_key",
                value={"mode": "migration"}
            )
            
            self.assertEqual(event.key, "migration_key")
            
            # Ожидание синхронизации
            await asyncio.sleep(0.2)
            
            # Проверка что событие доступно в обеих системах
            legacy_events = memory.legacy_memory.get(kind="archive", key="migration_key")
            modern_events = await memory.modern_memory.get_async(kind="archive", key="migration_key")
            
            self.assertEqual(len(legacy_events), 1)
            self.assertEqual(len(modern_events), 1)
    
    def test_statistics(self):
        """Тест статистики системы."""
        config = MemoryConfig(
            mode=MemoryMode.LEGACY,
            root_path=self.test_dir,
            enable_stats=True
        )
        
        memory = IntegratedMemoryManager(config)
        
        # Выполнение нескольких операций
        memory.put(kind="archive", key="stat_key", value={"test": "data"})
        memory.put(kind="shadow", key="stat_key", value={"test": "data"})
        
        # Получение статистики
        stats = memory.get_stats()
        
        self.assertIn("total_operations", stats)
        self.assertIn("legacy_operations", stats)
        self.assertIn("components", stats)
        
        memory.close()


class TestMigrationTools(unittest.TestCase):
    """Тесты инструментов миграции."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
        
        # Создание интегрированной системы в Migration режиме
        config = MemoryConfig(
            mode=MemoryMode.MIGRATION,
            root_path=self.test_dir,
            migration_batch_size=5
        )
        
        self.integrated_memory = IntegratedMemoryManager(config)
    
    def tearDown(self):
        """Очистка после тестов."""
        asyncio.run(self.integrated_memory.close())
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    async def test_data_synchronization(self):
        """Тест синхронизации данных."""
        synchronizer = DataSynchronizer(self.integrated_memory)
        
        # Создание события
        event = MemoryEvent(
            t=time.time(),
            kind="archive",
            key="sync_test",
            value={"sync": True}
        )
        
        # Синхронизация события
        await synchronizer.sync_event_async(event)
        
        # Проверка статистики
        sync_stats = synchronizer.get_stats()
        self.assertGreaterEqual(sync_stats["pending_count"], 0)
        
        await synchronizer.close()
    
    async def test_migration_execution(self):
        """Тест выполнения миграции."""
        migration_manager = MigrationManager(self.integrated_memory)
        
        # Создание тестовых данных в Legacy
        for i in range(10):
            self.integrated_memory.legacy_memory.put(
                kind="archive",
                key=f"migration_key_{i}",
                value={"index": i}
            )
        
        # Запуск миграции
        stats = await migration_manager.start_migration(
            direction="legacy_to_modern",
            kinds=["archive"]
        )
        
        # Проверка результатов миграции
        self.assertGreaterEqual(stats.total_events, 0)
        
        # Верификация миграции
        verification = await migration_manager.verify_migration(
            direction="legacy_to_modern"
        )
        
        self.assertIn("total_events_migrated", verification)
        
        await migration_manager.close()
    
    async def test_data_integrity_check(self):
        """Тест проверки целостности данных."""
        checker = DataIntegrityChecker(
            self.integrated_memory.legacy_memory,
            self.integrated_memory.modern_memory
        )
        
        # Создание тестовых данных
        self.integrated_memory.legacy_memory.put(
            kind="archive",
            key="integrity_key",
            value={"test": "data"}
        )
        
        # Выполнение миграции
        migration_manager = MigrationManager(self.integrated_memory)
        await migration_manager.start_migration(direction="legacy_to_modern", kinds=["archive"])
        
        # Проверка целостности
        comparison = await checker.compare_systems(kinds=["archive"])
        
        self.assertIn("archive", comparison)
        
        await migration_manager.close()


class TestPerformance(unittest.TestCase):
    """Тесты производительности различных режимов."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Очистка после тестов."""
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    def test_legacy_performance(self):
        """Тест производительности Legacy режима."""
        config = MemoryConfig(
            mode=MemoryMode.LEGACY,
            root_path=self.test_dir
        )
        
        memory = IntegratedMemoryManager(config)
        
        # Тест скорости записи
        start_time = time.time()
        
        for i in range(100):
            memory.put(
                kind="archive",
                key=f"perf_key_{i}",
                value={"index": i, "data": "x" * 100}
            )
        
        write_time = time.time() - start_time
        print(f"Legacy write time for 100 events: {write_time:.3f}s")
        
        # Тест скорости чтения
        start_time = time.time()
        
        for i in range(100):
            memory.get(kind="archive", key=f"perf_key_{i}")
        
        read_time = time.time() - start_time
        print(f"Legacy read time for 100 events: {read_time:.3f}s")
        
        memory.close()
        
        # Проверка разумности времени выполнения
        self.assertLess(write_time, 5.0)  # Не более 5 секунд для 100 операций
        self.assertLess(read_time, 5.0)
    
    async def test_modern_performance(self):
        """Тест производительности Modern режима."""
        config = MemoryConfig(
            mode=MemoryMode.MODERN,
            root_path=self.test_dir,
            modern_batch_size=20
        )
        
        memory = IntegratedMemoryManager(config)
        
        # Тест асинхронной записи
        start_time = time.time()
        
        tasks = []
        for i in range(100):
            task = memory.put_async(
                kind="archive",
                key=f"perf_key_{i}",
                value={"index": i, "data": "x" * 100}
            )
            tasks.append(task)
        
        await asyncio.gather(*tasks)
        
        write_time = time.time() - start_time
        print(f"Modern async write time for 100 events: {write_time:.3f}s")
        
        # Ожидание сброса буфера
        await asyncio.sleep(0.1)
        
        # Тест асинхронного чтения
        start_time = time.time()
        
        read_tasks = []
        for i in range(100):
            task = memory.get_async(kind="archive", key=f"perf_key_{i}")
            read_tasks.append(task)
        
        await asyncio.gather(*read_tasks)
        
        read_time = time.time() - start_time
        print(f"Modern async read time for 100 events: {read_time:.3f}s")
        
        await memory.close()
        
        # Проверка разумности времени выполнения
        self.assertLess(write_time, 5.0)
        self.assertLess(read_time, 5.0)


class TestErrorHandling(unittest.TestCase):
    """Тесты обработки ошибок."""
    
    def setUp(self):
        """Настройка тестового окружения."""
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Очистка после тестов."""
        shutil.rmtree(self.test_dir, ignore_errors=True)
    
    def test_invalid_configurations(self):
        """Тест обработки невалидных конфигураций."""
        # Попытка создать Legacy менеджер без Legacy памяти
        config = MemoryConfig(
            mode=MemoryMode.LEGACY,
            legacy_enabled=False
        )
        
        with self.assertRaises(ValueError):
            IntegratedMemoryManager(config)
    
    def test_file_system_errors(self):
        """Тест ошибок файловой системы."""
        # Создание директории без прав записи
        readonly_dir = "/root/readonly_test"  # Обычно недоступная директория
        
        try:
            config = MemoryConfig(
                mode=MemoryMode.LEGACY,
                root_path=readonly_dir
            )
            
            memory = IntegratedMemoryManager(config)
            
            # Попытка записи должна вызвать исключение
            with self.assertRaises((PermissionError, OSError)):
                memory.put(
                    kind="archive",
                    key="test_key",
                    value={"test": "data"}
                )
            
            memory.close()
            
        except (PermissionError, OSError):
            # Ожидаемое поведение - нет прав доступа
            pass
    
    def test_corrupted_data_handling(self):
        """Тест обработки поврежденных данных."""
        config = MemoryConfig(
            mode=MemoryMode.LEGACY,
            root_path=self.test_dir
        )
        
        memory = IntegratedMemoryManager(config)
        
        # Создание файла с поврежденными данными
        archive_path = os.path.join(self.test_dir, "main_archive.jsonl")
        with open(archive_path, 'w', encoding='utf-8') as f:
            f.write('{"invalid": "json"}\n')
            f.write('{"t": 123.456, "kind": "archive", "key": "valid_key", "value": {"valid": true}}\n')
            f.write('another_invalid_line\n')
        
        # Чтение должно игнорировать поврежденные данные
        events = memory.get(kind="archive")
        
        # Должно быть найдено только валидное событие
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].key, "valid_key")
        
        memory.close()


def run_integration_tests():
    """Запуск интеграционных тестов."""
    print("=== Запуск интеграционных тестов системы памяти ===")
    
    # Создание тестового набора
    test_loader = unittest.TestLoader()
    test_suite = unittest.TestSuite()
    
    # Добавление тестовых классов
    test_classes = [
        TestLegacyMemory,
        TestModernMemory,
        TestIntegratedMemory,
        TestMigrationTools,
        TestPerformance,
        TestErrorHandling
    ]
    
    for test_class in test_classes:
        tests = test_loader.loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # Запуск тестов
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # Вывод результатов
    print(f"\n=== Результаты тестирования ===")
    print(f"Выполнено тестов: {result.testsRun}")
    print(f"Успешных: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Неудачных: {len(result.failures)}")
    print(f"Ошибок: {len(result.errors)}")
    
    if result.failures:
        print("\nНеудачные тесты:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print("\nТесты с ошибками:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
    
    return result.wasSuccessful()


if __name__ == "__main__":
    # Запуск тестов при прямом вызове модуля
    run_integration_tests()