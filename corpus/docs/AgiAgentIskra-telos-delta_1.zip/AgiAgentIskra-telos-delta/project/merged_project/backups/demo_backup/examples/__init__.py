"""
Примеры использования DI системы проекта "Искра"
"""

from .di_examples import (
    demo_backward_compatibility,
    demo_hybrid_mode,
    demo_gradual_migration,
    demo_configuration,
    demo_monitoring,
    demo_error_handling,
    main
)

__all__ = [
    'demo_backward_compatibility',
    'demo_hybrid_mode', 
    'demo_gradual_migration',
    'demo_configuration',
    'demo_monitoring',
    'demo_error_handling',
    'main'
]