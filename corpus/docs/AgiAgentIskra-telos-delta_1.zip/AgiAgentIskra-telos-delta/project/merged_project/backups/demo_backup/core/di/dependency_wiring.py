"""
Подключение зависимостей и автоматический wiring компонентов

Обеспечивает автоматическое подключение компонентов Version 1 и Version 2
с поддержкой backward compatibility и постепенной миграции.
"""

import logging
import inspect
import importlib
import traceback
from typing import Any, Dict, List, Optional, Type, Union, Set, Tuple
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
import threading

from .di_container import DIContainer, ServiceLifetime, VersionCompatibility, ServiceDescriptor
from .service_registry import ServiceRegistry, ServiceCategory
from .config_dependencies import DependencyConfig, ServiceCategory as ConfigCategory

class WireMode(Enum):
    """Режимы подключения зависимостей"""
    AUTO = "auto"                    # Автоматическое подключение
    MANUAL = "manual"               # Ручное подключение
    HYBRID = "hybrid"               # Гибридный режим
    BACKWARD_COMPATIBLE = "backward_compatible"  # Обратная совместимость

class ComponentStatus(Enum):
    """Статусы компонентов"""
    UNKNOWN = "unknown"
    WIRED = "wired"
    WIRED_LEGACY = "wired_legacy"   # Подключен как legacy
    WIRED_MODERN = "wired_modern"   # Подключен как modern
    FAILED = "failed"
    MISSING_DEPENDENCIES = "missing_dependencies"

class WireResult:
    """Результат подключения компонента"""
    
    def __init__(
        self,
        component_name: str,
        status: ComponentStatus,
        service_type: Optional[Type] = None,
        implementation: Optional[Type] = None,
        dependencies_resolved: Optional[List[str]] = None,
        error: Optional[Exception] = None,
        warnings: Optional[List[str]] = None
    ):
        self.component_name = component_name
        self.status = status
        self.service_type = service_type
        self.implementation = implementation
        self.dependencies_resolved = dependencies_resolved or []
        self.error = error
        self.warnings = warnings or []
    
    def is_success(self) -> bool:
        """Проверка успешности подключения"""
        return self.status in [ComponentStatus.WIRED, ComponentStatus.WIRED_LEGACY, ComponentStatus.WIRED_MODERN]
    
    def is_legacy(self) -> bool:
        """Проверка использования legacy компонента"""
        return self.status == ComponentStatus.WIRED_LEGACY
    
    def is_modern(self) -> bool:
        """Проверка использования modern компонента"""
        return self.status == ComponentStatus.WIRED_MODERN

class DependencyWiring:
    """
    Основной класс для автоматического подключения зависимостей
    
    Особенности:
    - Автоматическое обнаружение и подключение компонентов
    - Backward compatibility с Version 1
    - Graceful degradation при отсутствии зависимостей
    - Cycle detection и prevention
    - Metrics и мониторинг подключений
    """
    
    def __init__(self, container: DIContainer, registry: ServiceRegistry):
        self.container = container
        self.registry = registry
        self.config = DependencyConfig()
        
        self.logger = logging.getLogger(__name__)
        self._wire_results: Dict[str, WireResult] = {}
        self._component_status: Dict[str, ComponentStatus] = {}
        self._dependency_graph: Dict[str, Set[str]] = {}
        self._wire_lock = threading.RLock()
        
        # Известные legacy компоненты Version 1
        self._legacy_mappings = {
            'MemoryManager': ('legacy_memory', 'optimized.memory.MemoryManager'),
            'VectorSearch': ('legacy_search', 'optimized.vector_search.VectorSearch'),
            'APIHandler': ('legacy_api', 'architecture.api.Handler'),
            'AuthService': ('legacy_auth', 'architecture.security.AuthService')
        }
        
        self.logger.info("DependencyWiring initialized")
    
    def auto_wire_all(self, wire_mode: WireMode = WireMode.AUTO) -> Dict[str, WireResult]:
        """
        Автоматическое подключение всех компонентов
        
        Args:
            wire_mode: Режим подключения
            
        Returns:
            Результаты подключения всех компонентов
        """
        self.logger.info(f"Starting auto-wiring with mode: {wire_mode.value}")
        
        with self._wire_lock:
            self._wire_results.clear()
            self._component_status.clear()
            
            # Регистрация всех сервисов в реестре
            if not self.registry._services:
                self.registry.register_all_services()
            
            # Автообнаружение сервисов
            if self.config.config.auto_discover:
                self.registry.auto_discover_services()
            
            # Подключение по категориям
            categories = [ServiceCategory.MEMORY, ServiceCategory.SEARCH, ServiceCategory.API, ServiceCategory.SECURITY]
            
            for category in categories:
                self._wire_category(category, wire_mode)
            
            # Финальная проверка подключений
            self._validate_wiring_results()
            
            self.logger.info(f"Auto-wiring completed. {len([r for r in self._wire_results.values() if r.is_success()])}/{len(self._wire_results)} components wired successfully")
            
            return self._wire_results.copy()
    
    def _wire_category(self, category: ServiceCategory, wire_mode: WireMode):
        """Подключение компонентов по категориям"""
        
        services = self.registry.get_services_by_category(category)
        
        for service_info in services:
            try:
                result = self._wire_service(service_info, wire_mode)
                self._wire_results[service_info.name] = result
                
                if result.is_success():
                    self._component_status[service_info.name] = result.status
                
                self.logger.debug(f"Wired {service_info.name}: {result.status.value}")
                
            except Exception as e:
                error_result = WireResult(
                    component_name=service_info.name,
                    status=ComponentStatus.FAILED,
                    error=e
                )
                self._wire_results[service_info.name] = error_result
                self.logger.error(f"Failed to wire {service_info.name}: {e}")
    
    def _wire_service(self, service_info, wire_mode: WireMode) -> WireResult:
        """Подключение отдельного сервиса"""
        
        try:
            # Определение реализации для текущего режима
            implementation = self._resolve_implementation(service_info, wire_mode)
            
            if implementation is None:
                return WireResult(
                    component_name=service_info.name,
                    status=ComponentStatus.MISSING_DEPENDENCIES,
                    warnings=[f"No compatible implementation found for {wire_mode.value} mode"]
                )
            
            # Создание сервиса через контейнер
            service_descriptor = ServiceDescriptor(
                service_type=service_info.service_type,
                implementation=implementation,
                lifetime=self.config.get_dicomponent_lifetime(service_info.name),
                config=self.config.get_component_config(service_info.name, service_info.category),
                dependencies=self._resolve_dependencies(service_info.dependencies)
            )
            
            # Регистрация в контейнере
            service_key = service_info.service_type
            self.container._services[service_key] = service_descriptor
            
            # Определение статуса
            if self._is_legacy_implementation(implementation):
                status = ComponentStatus.WIRED_LEGACY
            elif self._is_modern_implementation(implementation):
                status = ComponentStatus.WIRED_MODERN
            else:
                status = ComponentStatus.WIRED
            
            return WireResult(
                component_name=service_info.name,
                status=status,
                service_type=service_info.service_type,
                implementation=implementation,
                dependencies_resolved=[dep.__name__ for dep in service_descriptor.dependencies]
            )
            
        except Exception as e:
            return WireResult(
                component_name=service_info.name,
                status=ComponentStatus.FAILED,
                error=e
            )
    
    def _resolve_implementation(self, service_info, wire_mode: WireMode) -> Optional[Union[Type, str]]:
        """Разрешение реализации сервиса"""
        
        # В гибридном режиме пытаемся найти подходящую реализацию
        if wire_mode == WireMode.HYBRID:
            # Пытаемся использовать modern версию
            modern_impl = self._get_modern_implementation(service_info.name)
            if modern_impl and self._test_implementation(modern_impl):
                return modern_impl
            
            # Fallback на legacy
            legacy_impl = self._get_legacy_implementation(service_info.name)
            if legacy_impl and self._test_implementation(legacy_impl):
                return legacy_impl
        
        elif wire_mode == WireMode.BACKWARD_COMPATIBLE:
            # Только legacy реализации
            legacy_impl = self._get_legacy_implementation(service_info.name)
            if legacy_impl and self._test_implementation(legacy_impl):
                return legacy_impl
        
        elif wire_mode == WireMode.AUTO:
            # Автоматический выбор на основе конфигурации
            if service_info.version_compatibility == VersionCompatibility.HYBRID:
                # Для гибридных сервисов пробуем современные версии
                impl = self._resolve_implementation(service_info, WireMode.HYBRID)
                if impl:
                    return impl
        
        # Прямое использование указанной реализации
        if service_info.implementation and self._test_implementation(service_info.implementation):
            return service_info.implementation
        
        return None
    
    def _get_modern_implementation(self, service_name: str) -> Optional[str]:
        """Получение современной реализации сервиса"""
        
        modern_mappings = {
            'memory': 'optimized.memory.OptimizedMemoryManager',
            'search': 'optimized.vector_search.OptimizedVectorSearch',
            'auth': 'architecture.security.ModernAuthService',
            'api': 'architecture.api.ModernApiRouter'
        }
        
        for key, impl in modern_mappings.items():
            if key in service_name.lower():
                return impl
        
        return None
    
    def _get_legacy_implementation(self, service_name: str) -> Optional[str]:
        """Получение legacy реализации сервиса"""
        
        legacy_mappings = {
            'memory': 'lib.memory.MemoryManager',
            'search': 'lib.vector_search.VectorSearch',
            'auth': 'lib.auth.LegacyAuthService',
            'api': 'lib.api.LegacyApiHandler'
        }
        
        for key, impl in legacy_mappings.items():
            if key in service_name.lower():
                return impl
        
        return None
    
    def _test_implementation(self, implementation: Union[Type, str]) -> bool:
        """Тестирование доступности реализации"""
        
        try:
            if isinstance(implementation, str):
                # Динамический импорт модуля
                module_path, class_name = implementation.rsplit('.', 1)
                module = importlib.import_module(module_path)
                cls = getattr(module, class_name)
                return inspect.isclass(cls)
            else:
                # Прямая ссылка на класс
                return inspect.isclass(implementation)
                
        except (ImportError, AttributeError, TypeError) as e:
            self.logger.debug(f"Implementation test failed for {implementation}: {e}")
            return False
    
    def _resolve_dependencies(self, dependencies: List[Type]) -> List[Type]:
        """Разрешение зависимостей сервиса"""
        
        resolved = []
        for dep_type in dependencies:
            if self.container.is_registered(dep_type):
                resolved.append(dep_type)
            else:
                self.logger.warning(f"Dependency {dep_type.__name__} not registered")
        
        return resolved
    
    def _is_legacy_implementation(self, implementation: Union[Type, str]) -> bool:
        """Проверка legacy реализации"""
        
        if isinstance(implementation, str):
            return any(legacy in implementation.lower() for legacy in ['lib.', 'legacy', 'v1'])
        else:
            return hasattr(implementation, '_is_legacy') and getattr(implementation, '_is_legacy')
    
    def _is_modern_implementation(self, implementation: Union[Type, str]) -> bool:
        """Проверка modern реализации"""
        
        if isinstance(implementation, str):
            return any(modern in implementation.lower() for modern in ['optimized.', 'architecture.', 'modern', 'v2'])
        else:
            return hasattr(implementation, '_is_modern') and getattr(implementation, '_is_modern')
    
    def _validate_wiring_results(self):
        """Валидация результатов подключения"""
        
        failed_components = [name for name, result in self._wire_results.items() if not result.is_success()]
        
        if failed_components:
            self.logger.warning(f"Failed to wire components: {failed_components}")
            
            # Попытка восстановления через fallback механизм
            for component_name in failed_components:
                self._attempt_fallback_wiring(component_name)
    
    def _attempt_fallback_wiring(self, component_name: str):
        """Попытка подключения через fallback механизм"""
        
        service_info = self.registry.get_service(component_name)
        if not service_info:
            return
        
        # Попытка найти любую доступную реализацию
        for impl_path in self._get_fallback_implementations(component_name):
            try:
                if self._test_implementation(impl_path):
                    result = WireResult(
                        component_name=component_name,
                        status=ComponentStatus.WIRED,
                        implementation=impl_path,
                        warnings=["Fallback implementation used"]
                    )
                    self._wire_results[component_name] = result
                    self.logger.info(f"Fallback wiring successful for {component_name}")
                    break
            except Exception as e:
                self.logger.debug(f"Fallback failed for {component_name}: {e}")
    
    def _get_fallback_implementations(self, component_name: str) -> List[str]:
        """Получение fallback реализаций"""
        
        fallbacks = []
        
        # Общие fallback реализации
        common_fallbacks = [
            f"core.{component_name}.Base{component_name.title()}",
            f"shared.{component_name}.Generic{component_name.title()}",
            f"utils.{component_name}.Simple{component_name.title()}"
        ]
        
        return common_fallbacks
    
    def wire_specific_service(
        self,
        service_name: str,
        implementation: Union[Type, str],
        wire_mode: WireMode = WireMode.MANUAL
    ) -> WireResult:
        """Подключение конкретного сервиса"""
        
        with self._wire_lock:
            try:
                service_info = self.registry.get_service(service_name)
                if not service_info:
                    service_info = ServiceInfo(
                        name=service_name,
                        service_type=Type,  # Будет определен при подключении
                        implementation=implementation,
                        version_compatibility=VersionCompatibility.UNIVERSAL,
                        category=ServiceCategory.UTILITIES
                    )
                
                result = self._wire_service(service_info, wire_mode)
                self._wire_results[service_name] = result
                
                self.logger.info(f"Manually wired service {service_name}: {result.status.value}")
                return result
                
            except Exception as e:
                error_result = WireResult(
                    component_name=service_name,
                    status=ComponentStatus.FAILED,
                    error=e
                )
                self._wire_results[service_name] = error_result
                self.logger.error(f"Failed to manually wire {service_name}: {e}")
                return error_result
    
    def get_wiring_status(self) -> Dict[str, Any]:
        """Получение статуса подключения"""
        
        stats = {
            'total_components': len(self._wire_results),
            'successfully_wired': len([r for r in self._wire_results.values() if r.is_success()]),
            'failed_components': len([r for r in self._wire_results.values() if not r.is_success()]),
            'legacy_components': len([r for r in self._wire_results.values() if r.is_legacy()]),
            'modern_components': len([r for r in self._wire_results.values() if r.is_modern()]),
            'components_by_status': {},
            'dependency_graph': self._dependency_graph
        }
        
        # Статистика по статусам
        for status in ComponentStatus:
            count = len([r for r in self._wire_results.values() if r.status == status])
            stats['components_by_status'][status.value] = count
        
        return stats
    
    def get_component_status(self, component_name: str) -> ComponentStatus:
        """Получение статуса конкретного компонента"""
        return self._component_status.get(component_name, ComponentStatus.UNKNOWN)
    
    def reset_wiring(self):
        """Сброс всех подключений"""
        
        with self._wire_lock:
            self._wire_results.clear()
            self._component_status.clear()
            self._dependency_graph.clear()
            
            self.logger.info("Wiring reset completed")
    
    def export_wiring_config(self, config_path: str):
        """Экспорт конфигурации подключения"""
        
        wiring_config = {
            'wire_results': {
                name: {
                    'status': result.status.value,
                    'service_type': result.service_type.__name__ if result.service_type else None,
                    'implementation': str(result.implementation) if result.implementation else None,
                    'dependencies_resolved': result.dependencies_resolved,
                    'warnings': result.warnings
                }
                for name, result in self._wire_results.items()
            },
            'wiring_stats': self.get_wiring_status()
        }
        
        import json
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(wiring_config, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"Exported wiring config to {config_path}")

# Дополнительные импорты для ServiceInfo
from .service_registry import ServiceInfo