"""Инструменты миграции и синхронизации данных между системами памяти.

Обеспечивает:
- Постепенную миграцию данных из Legacy в Modern систему
- Синхронизацию данных в реальном времени
- Мониторинг состояния миграции
- Валидацию целостности данных
- Откат миграции при необходимости
"""

import asyncio
import json
import os
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Set, Tuple
from collections import defaultdict, deque
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor

from .legacy_memory import LegacyMemoryManager
from .modern_memory import ModernMemoryManager
from .integrated_memory import MemoryEvent


@dataclass
class MigrationTask:
    """Задача миграции события."""
    event: MemoryEvent
    source: str  # 'legacy' или 'modern'
    target: str  # 'legacy' или 'modern'
    status: str  # 'pending', 'completed', 'failed', 'skipped'
    created_at: float
    completed_at: Optional[float] = None
    error_message: Optional[str] = None
    retry_count: int = 0
    
    def to_dict(self) -> dict:
        """Конвертация в словарь."""
        return asdict(self)


@dataclass
class MigrationStats:
    """Статистика миграции."""
    total_events: int = 0
    migrated_events: int = 0
    failed_events: int = 0
    skipped_events: int = 0
    start_time: float = 0.0
    last_update: float = 0.0
    progress_percent: float = 0.0
    events_per_second: float = 0.0
    
    def update_progress(self):
        """Обновление прогресса миграции."""
        if self.total_events > 0:
            self.progress_percent = (self.migrated_events / self.total_events) * 100
    
    def calculate_speed(self):
        """Расчет скорости миграции."""
        elapsed_time = time.time() - self.start_time
        if elapsed_time > 0:
            self.events_per_second = self.migrated_events / elapsed_time


class DataSynchronizer:
    """Синхронизатор данных между системами памяти."""
    
    def __init__(self, integrated_manager):
        """Инициализация синхронизатора.
        
        Args:
            integrated_manager: Интегрированный менеджер памяти
        """
        self.integrated_manager = integrated_manager
        self.legacy_memory = integrated_manager.legacy_memory
        self.modern_memory = integrated_manager.modern_memory
        
        # Очереди синхронизации
        self._pending_events = deque()
        self._sync_lock = threading.Lock()
        self._is_sync_running = False
        self._sync_thread = None
        
        # Статистика синхронизации
        self._sync_stats = {
            "total_synced": 0,
            "last_sync": None,
            "sync_errors": 0,
            "pending_count": 0
        }
        self._stats_lock = threading.Lock()
        
        # Конфигурация
        self.batch_size = getattr(integrated_manager.config, 'migration_batch_size', 100)
        self.sync_interval = getattr(integrated_manager.config, 'migration_sync_interval', 60.0)
        self.real_time_sync = getattr(integrated_manager.config, 'enable_real_time_sync', False)
    
    async def sync_event_async(self, event: MemoryEvent):
        """Асинхронная синхронизация одного события."""
        with self._sync_lock:
            self._pending_events.append(event)
            self._sync_stats["pending_count"] = len(self._pending_events)
        
        # Если включена синхронизация в реальном времени
        if self.real_time_sync:
            await self._process_pending_sync()
    
    def sync_event(self, event: MemoryEvent):
        """Синхронная синхронизация одного события."""
        with self._sync_lock:
            self._pending_events.append(event)
            self._sync_stats["pending_count"] = len(self._pending_events)
        
        if self.real_time_sync:
            asyncio.create_task(self._process_pending_sync())
    
    async def sync_pending_events(self):
        """Синхронизация всех ожидающих событий."""
        await self._process_pending_sync()
    
    async def _process_pending_sync(self):
        """Обработка ожидающих событий для синхронизации."""
        if self._is_sync_running:
            return
        
        self._is_sync_running = True
        
        try:
            # Извлечение событий из очереди
            with self._sync_lock:
                events_to_sync = []
                while self._pending_events and len(events_to_sync) < self.batch_size:
                    events_to_sync.append(self._pending_events.popleft())
                self._sync_stats["pending_count"] = len(self._pending_events)
            
            if not events_to_sync:
                return
            
            # Синхронизация событий
            sync_tasks = []
            for event in events_to_sync:
                task = self._sync_single_event(event)
                sync_tasks.append(task)
            
            # Выполнение синхронизации
            await asyncio.gather(*sync_tasks, return_exceptions=True)
            
        except Exception as e:
            print(f"Ошибка синхронизации: {e}")
            with self._stats_lock:
                self._sync_stats["sync_errors"] += 1
        finally:
            self._is_sync_running = False
    
    async def _sync_single_event(self, event: MemoryEvent):
        """Синхронизация одного события."""
        try:
            # Определение направления синхронизации
            # Если событие пришло из Legacy, синхронизируем в Modern
            if hasattr(event, '_source') and event._source == 'legacy':
                await self.modern_memory.put_async(event.kind, event.key, event.value, event.meta)
            # Если событие пришло из Modern, синхронизируем в Legacy
            elif hasattr(event, '_source') and event._source == 'modern':
                self.legacy_memory.put(event.kind, event.key, event.value, event.meta)
            
            with self._stats_lock:
                self._sync_stats["total_synced"] += 1
                self._sync_stats["last_sync"] = time.time()
                
        except Exception as e:
            print(f"Ошибка синхронизации события {event.key}: {e}")
            with self._stats_lock:
                self._sync_stats["sync_errors"] += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Получение статистики синхронизации."""
        with self._stats_lock:
            return self._sync_stats.copy()
    
    async def close(self):
        """Закрытие синхронизатора."""
        await self.sync_pending_events()


class MigrationManager:
    """Менеджер миграции данных между системами памяти."""
    
    def __init__(self, integrated_manager):
        """Инициализация менеджера миграции.
        
        Args:
            integrated_manager: Интегрированный менеджер памяти
        """
        self.integrated_manager = integrated_manager
        self.legacy_memory = integrated_manager.legacy_memory
        self.modern_memory = integrated_manager.modern_memory
        
        # Очереди задач миграции
        self._migration_queue: deque = deque()
        self._completed_tasks: List[MigrationTask] = []
        self._failed_tasks: List[MigrationTask] = []
        
        # Статистика миграции
        self.migration_stats = MigrationStats()
        
        # Контрольные точки
        self._checkpoints = {}
        self._checkpoint_lock = threading.Lock()
        
        # Конфигурация
        self.batch_size = getattr(integrated_manager.config, 'migration_batch_size', 100)
        self.max_retries = 3
        
        # Параллелизм
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._is_migration_running = False
    
    async def start_migration(self, direction: str = "legacy_to_modern", 
                            kinds: List[str] = None, since: Optional[float] = None) -> MigrationStats:
        """Запуск миграции данных.
        
        Args:
            direction: Направление миграции ('legacy_to_modern' или 'modern_to_legacy')
            kinds: Типы событий для миграции
            since: Время для фильтрации событий
            
        Returns:
            MigrationStats: Статистика миграции
        """
        if self._is_migration_running:
            raise RuntimeError("Миграция уже выполняется")
        
        self._is_migration_running = True
        self.migration_stats = MigrationStats()
        self.migration_stats.start_time = time.time()
        self.migration_stats.last_update = time.time()
        
        try:
            # Определение типов для миграции
            if kinds is None:
                kinds = ["archive", "shadow"]
            
            # Получение всех событий для миграции
            events_to_migrate = await self._collect_events_for_migration(
                direction, kinds, since
            )
            
            self.migration_stats.total_events = len(events_to_migrate)
            
            if not events_to_migrate:
                print("Нет событий для миграции")
                return self.migration_stats
            
            print(f"Начало миграции {len(events_to_migrate)} событий в направлении {direction}")
            
            # Создание задач миграции
            self._create_migration_tasks(events_to_migrate, direction)
            
            # Выполнение миграции
            await self._execute_migration_batch()
            
            self.migration_stats.calculate_speed()
            self.migration_stats.update_progress()
            
            print(f"Миграция завершена. Успешно: {self.migration_stats.migrated_events}, "
                  f"Ошибки: {self.migration_stats.failed_events}")
            
        except Exception as e:
            print(f"Ошибка миграции: {e}")
            raise
        finally:
            self._is_migration_running = False
        
        return self.migration_stats
    
    async def _collect_events_for_migration(self, direction: str, kinds: List[str], 
                                          since: Optional[float] = None) -> List[MemoryEvent]:
        """Сбор событий для миграции."""
        events = []
        
        try:
            if direction == "legacy_to_modern":
                # Получение событий из Legacy системы
                for kind in kinds:
                    kind_events = self.legacy_memory.get(kind, since=since)
                    for event in kind_events:
                        # Добавление источника
                        event._source = 'legacy'
                        events.append(event)
            
            elif direction == "modern_to_legacy":
                # Получение событий из Modern системы
                for kind in kinds:
                    kind_events = await self.modern_memory.get_async(kind, since=since)
                    for event in kind_events:
                        # Добавление источника
                        event._source = 'modern'
                        events.append(event)
            
            # Сортировка по времени
            events.sort(key=lambda x: x.t)
            
        except Exception as e:
            print(f"Ошибка сбора событий для миграции: {e}")
            raise
        
        return events
    
    def _create_migration_tasks(self, events: List[MemoryEvent], direction: str):
        """Создание задач миграции для событий."""
        for event in events:
            if direction == "legacy_to_modern":
                target = "modern"
            else:
                target = "legacy"
            
            task = MigrationTask(
                event=event,
                source=event._source,
                target=target,
                status="pending",
                created_at=time.time()
            )
            
            self._migration_queue.append(task)
    
    async def _execute_migration_batch(self):
        """Выполнение миграции батчами."""
        while self._migration_queue:
            # Извлечение батча
            batch = []
            with self._checkpoint_lock:
                while self._migration_queue and len(batch) < self.batch_size:
                    batch.append(self._migration_queue.popleft())
            
            if not batch:
                break
            
            # Параллельное выполнение миграции батча
            migration_tasks = []
            for task in batch:
                migration_task = self._migrate_single_event(task)
                migration_tasks.append(migration_task)
            
            await asyncio.gather(*migration_tasks, return_exceptions=True)
            
            # Обновление статистики
            self.migration_stats.last_update = time.time()
            self.migration_stats.calculate_speed()
            self.migration_stats.update_progress()
            
            # Логирование прогресса
            if self.migration_stats.migrated_events % 1000 == 0:
                print(f"Прогресс миграции: {self.migration_stats.progress_percent:.1f}% "
                      f"({self.migration_stats.migrated_events}/{self.migration_stats.total_events})")
    
    async def _migrate_single_event(self, task: MigrationTask) -> MigrationTask:
        """Миграция одного события."""
        try:
            # Выполнение миграции
            if task.target == "modern":
                await self.modern_memory.put_async(
                    task.event.kind, task.event.key, task.event.value, task.event.meta
                )
            else:  # target == "legacy"
                self.legacy_memory.put(
                    task.event.kind, task.event.key, task.event.value, task.event.meta
                )
            
            # Успешное завершение
            task.status = "completed"
            task.completed_at = time.time()
            self._completed_tasks.append(task)
            self.migration_stats.migrated_events += 1
            
        except Exception as e:
            # Обработка ошибок
            task.status = "failed"
            task.error_message = str(e)
            task.completed_at = time.time()
            self._failed_tasks.append(task)
            self.migration_stats.failed_events += 1
            
            # Попытка повторной миграции
            if task.retry_count < self.max_retries:
                task.retry_count += 1
                task.status = "pending"
                self._migration_queue.appendleft(task)
        
        return task
    
    async def verify_migration(self, direction: str = "legacy_to_modern") -> Dict[str, Any]:
        """Проверка корректности миграции."""
        verification_results = {
            "total_events_migrated": 0,
            "events_match": 0,
            "events_missing": 0,
            "events_extra": 0,
            "verification_errors": []
        }
        
        try:
            if direction == "legacy_to_modern":
                # Сравнение событий между системами
                for kind in ["archive", "shadow"]:
                    legacy_events = self.legacy_memory.get(kind)
                    modern_events = await self.modern_memory.get_async(kind)
                    
                    # Создание индексов для сравнения
                    legacy_index = {(ev.key, ev.t): ev for ev in legacy_events}
                    modern_index = {(ev.key, ev.t): ev for ev in modern_events}
                    
                    verification_results["total_events_migrated"] += len(legacy_events)
                    
                    # Поиск совпадающих событий
                    for key, event in legacy_index.items():
                        if key in modern_index:
                            verification_results["events_match"] += 1
                        else:
                            verification_results["events_missing"] += 1
                    
                    # Поиск лишних событий
                    for key in modern_index:
                        if key not in legacy_index:
                            verification_results["events_extra"] += 1
            
            # Расчет процента совпадения
            if verification_results["total_events_migrated"] > 0:
                match_percentage = (
                    verification_results["events_match"] / 
                    verification_results["total_events_migrated"] * 100
                )
                verification_results["match_percentage"] = match_percentage
            
        except Exception as e:
            verification_results["verification_errors"].append(str(e))
        
        return verification_results
    
    async def create_checkpoint(self, name: str) -> Dict[str, Any]:
        """Создание контрольной точки миграции."""
        checkpoint_data = {
            "name": name,
            "created_at": time.time(),
            "migration_stats": asdict(self.migration_stats),
            "queue_size": len(self._migration_queue),
            "completed_tasks": len(self._completed_tasks),
            "failed_tasks": len(self._failed_tasks)
        }
        
        with self._checkpoint_lock:
            self._checkpoints[name] = checkpoint_data
        
        return checkpoint_data
    
    async def restore_checkpoint(self, name: str) -> bool:
        """Восстановление из контрольной точки."""
        with self._checkpoint_lock:
            if name not in self._checkpoints:
                return False
            
            checkpoint_data = self._checkpoints[name]
        
        try:
            # Остановка текущей миграции
            if self._is_migration_running:
                self._is_migration_running = False
            
            # Очистка текущего состояния
            self._migration_queue.clear()
            self._completed_tasks.clear()
            self._failed_tasks.clear()
            
            # Восстановление статистики
            self.migration_stats = MigrationStats(**checkpoint_data["migration_stats"])
            
            print(f"Восстановлена контрольная точка: {name}")
            return True
            
        except Exception as e:
            print(f"Ошибка восстановления контрольной точки: {e}")
            return False
    
    def get_migration_status(self) -> Dict[str, Any]:
        """Получение статуса миграции."""
        return {
            "is_running": self._is_migration_running,
            "stats": asdict(self.migration_stats),
            "queue_size": len(self._migration_queue),
            "completed_tasks": len(self._completed_tasks),
            "failed_tasks": len(self._failed_tasks),
            "checkpoints": list(self._checkpoints.keys())
        }
    
    async def cancel_migration(self):
        """Отмена текущей миграции."""
        self._is_migration_running = False
        print("Миграция отменена")
    
    async def retry_failed_migrations(self) -> int:
        """Повторная попытка выполнения неудачных миграций."""
        if not self._failed_tasks:
            return 0
        
        # Добавление неудачных задач обратно в очередь
        with self._checkpoint_lock:
            self._migration_queue.extend(self._failed_tasks)
            self._failed_tasks.clear()
        
        # Перезапуск миграции
        await self._execute_migration_batch()
        
        return len(self._migration_queue)
    
    async def generate_migration_report(self) -> Dict[str, Any]:
        """Генерация отчета о миграции."""
        report = {
            "generated_at": time.time(),
            "migration_summary": asdict(self.migration_stats),
            "failed_tasks": [asdict(task) for task in self._failed_tasks],
            "checkpoints": dict(self._checkpoints),
            "verification_suggestions": []
        }
        
        # Добавление предложений по верификации
        if self.migration_stats.failed_events > 0:
            report["verification_suggestions"].append(
                "Обнаружены неудачные миграции. Рекомендуется выполнить верификацию."
            )
        
        if self.migration_stats.progress_percent < 100:
            report["verification_suggestions"].append(
                "Миграция не завершена полностью. Рекомендуется проверить оставшиеся задачи."
            )
        
        return report
    
    async def export_migration_state(self, output_file: str):
        """Экспорт состояния миграции в файл."""
        migration_data = {
            "export_time": time.time(),
            "migration_status": self.get_migration_status(),
            "completed_tasks": [asdict(task) for task in self._completed_tasks],
            "failed_tasks": [asdict(task) for task in self._failed_tasks],
            "checkpoints": self._checkpoints
        }
        
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(migration_data, f, ensure_ascii=False, indent=2)
            print(f"Состояние миграции экспортировано в {output_file}")
        except Exception as e:
            print(f"Ошибка экспорта состояния миграции: {e}")
            raise
    
    async def close(self):
        """Закрытие менеджера миграции."""
        if self._is_migration_running:
            await self.cancel_migration()
        
        self._executor.shutdown(wait=True)
        print("Migration Manager закрыт")


# Дополнительные утилиты для работы с миграцией
class DataIntegrityChecker:
    """Проверка целостности данных между системами памяти."""
    
    def __init__(self, legacy_memory: LegacyMemoryManager, modern_memory: ModernMemoryManager):
        self.legacy_memory = legacy_memory
        self.modern_memory = modern_memory
    
    async def compare_systems(self, kinds: List[str] = None) -> Dict[str, Any]:
        """Сравнение данных между системами."""
        if kinds is None:
            kinds = ["archive", "shadow"]
        
        comparison_results = {}
        
        for kind in kinds:
            # Получение событий из обеих систем
            legacy_events = self.legacy_memory.get(kind)
            modern_events = await self.modern_memory.get_async(kind)
            
            # Создание сравнительных индексов
            legacy_index = self._create_event_index(legacy_events)
            modern_index = self._create_event_index(modern_events)
            
            # Анализ различий
            common_keys = set(legacy_index.keys()) & set(modern_index.keys())
            legacy_only = set(legacy_index.keys()) - set(modern_index.keys())
            modern_only = set(modern_index.keys()) - set(modern_index.keys())
            
            comparison_results[kind] = {
                "legacy_count": len(legacy_events),
                "modern_count": len(modern_events),
                "common_count": len(common_keys),
                "legacy_only_count": len(legacy_only),
                "modern_only_count": len(modern_only),
                "legacy_only_keys": list(legacy_only),
                "modern_only_keys": list(modern_only)
            }
        
        return comparison_results
    
    def _create_event_index(self, events: List[MemoryEvent]) -> Dict[tuple, MemoryEvent]:
        """Создание индекса событий по ключу и времени."""
        return {(event.key, event.t): event for event in events}


async def run_comprehensive_migration(integrated_manager, **kwargs) -> MigrationStats:
    """Выполнение комплексной миграции с проверками.
    
    Args:
        integrated_manager: Интегрированный менеджер памяти
        **kwargs: Дополнительные параметры миграции
        
    Returns:
        MigrationStats: Статистика завершенной миграции
    """
    migration_manager = MigrationManager(integrated_manager)
    
    try:
        # Запуск миграции
        stats = await migration_manager.start_migration(**kwargs)
        
        # Создание контрольной точки
        await migration_manager.create_checkpoint("comprehensive_migration")
        
        # Верификация результатов
        verification = await migration_manager.verify_migration()
        print(f"Результаты верификации: {verification}")
        
        return stats
        
    finally:
        await migration_manager.close()