"""
Улучшенная конфигурация для интегрированной архитектуры проекта Искра.

Объединяет настройки Version 1 и Version 2 с валидацией и безопасными значениями по умолчанию.
Обеспечивает backward compatibility при добавлении новых возможностей.
"""

import os
from typing import List, Optional
from pydantic import Field, validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Настройки интегрированной архитектуры Искра."""
    
    # ================== ОСНОВНЫЕ НАСТРОЙКИ ПРИЛОЖЕНИЯ ==================
    APP_NAME: str = Field(default="Iskra API (Integrated)", description="Название приложения")
    APP_VERSION: str = Field(default="1.0.0", description="Версия приложения (интегрированная)")
    DEBUG: bool = Field(default=False, description="Режим отладки")
    
    # ================== СЕТЕВЫЕ НАСТРОЙКИ ==================
    HOST: str = Field(default="0.0.0.0", description="Хост сервера")
    PORT: int = Field(default=8000, ge=1, le=65535, description="Порт сервера")
    
    # ================== CORS НАСТРОЙКИ (Version 2) ==================
    CORS_ORIGINS: str = Field(
        default="http://localhost:3000,http://localhost:8080", 
        description="Разрешенные CORS источники (через запятую)"
    )
    
    @validator('CORS_ORIGINS', pre=True)
    def parse_cors_origins(cls, v):
        """Парсинг CORS источников из строки в список"""
        if isinstance(v, str):
            origins = [origin.strip() for origin in v.split(",") if origin.strip()]
            # Безопасные значения по умолчанию для продакшена
            if not origins or origins == ["*"]:
                return ["http://localhost:3000"]
            return origins
        return v
    
    # ================== JWT НАСТРОЙКИ (Version 2 - Улучшенная безопасность) ==================
    JWT_SECRET: str = Field(
        default="",  # Пустое значение, будет сгенерировано автоматически
        description="Секретный ключ JWT (если пустой, генерируется автоматически)"
    )
    JWT_ALGORITHM: str = Field(default="HS256", description="Алгоритм JWT")
    JWT_EXPIRE_MINUTES: int = Field(
        default=30, 
        ge=5, 
        le=1440, 
        description="Время жизни токена в минутах (5 мин - 24 часа)"
    )
    
    @validator('JWT_SECRET')
    def generate_jwt_secret(cls, v):
        """Автоматическая генерация безопасного JWT секрета"""
        if not v or len(v) < 32:
            import secrets
            import base64
            return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8')
        return v
    
    # ================== НАСТРОЙКИ ПОИСКА (Version 1 + Version 2) ==================
    EVIDENCE_PATH: str = Field(
        default="memory/evidence.jsonl",
        description="Путь к файлу с данными для поиска"
    )
    MAX_SEARCH_RESULTS: int = Field(
        default=50, 
        ge=1, 
        le=100, 
        description="Максимальное количество результатов поиска"
    )
    DEFAULT_SEARCH_K: int = Field(
        default=5, 
        ge=1, 
        le=20, 
        description="Количество результатов по умолчанию для поиска"
    )
    
    # ================== НАСТРОЙКИ ПАМЯТИ (Version 2) ==================
    MEMORY_ROOT: str = Field(default="memory", description="Корневая директория для памяти")
    MEMORY_BATCH_SIZE: int = Field(
        default=50, 
        ge=10, 
        le=500, 
        description="Размер батча для асинхронной памяти"
    )
    MEMORY_FLUSH_INTERVAL: float = Field(
        default=5.0, 
        ge=1.0, 
        le=60.0, 
        description="Интервал сброса памяти в секундах"
    )
    MEMORY_COMPRESSION: bool = Field(
        default=False, 
        description="Включить сжатие для memory storage"
    )
    
    # ================== НАСТРОЙКИ КЭШИРОВАНИЯ (Version 2) ==================
    ENABLE_LRU_CACHE: bool = Field(default=True, description="Включить LRU кэширование")
    LRU_CACHE_SIZE: int = Field(
        default=1000, 
        ge=100, 
        le=10000, 
        description="Размер LRU кэша"
    )
    
    # ================== НАСТРОЙКИ ЛОГИРОВАНИЯ ==================
    LOG_LEVEL: str = Field(
        default="INFO", 
        description="Уровень логирования",
        regex="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$"
    )
    LOG_FORMAT: str = Field(
        default="json",
        description="Формат логирования (json|text)"
    )
    
    # ================== OTEL НАСТРОЙКИ (Version 2) ==================
    OTEL_ENABLED: bool = Field(default=True, description="Включить OpenTelemetry")
    OTEL_SERVICE_NAME: str = Field(
        default="iskra-api",
        description="Имя сервиса для OpenTelemetry"
    )
    
    # ================== ФАЙЛОВЫЕ ПУТИ (Version 1 совместимость) ==================
    MANIFEST_PATH: str = Field(
        default="manifest/cd_index_baseline.json",
        description="Путь к файлу манифеста"
    )
    CANON_INDEX_PATH: str = Field(
        default="docs/CANON/INDEX.md",
        description="Путь к индексу канона"
    )
    
    # ================== БЕЗОПАСНОСТЬ ==================
    RATE_LIMIT_ENABLED: bool = Field(default=True, description="Включить rate limiting")
    RATE_LIMIT_REQUESTS: int = Field(
        default=100,
        ge=10,
        le=1000,
        description="Количество запросов в минуту"
    )
    
    # ================== ПРОИЗВОДИТЕЛЬНОСТЬ (Version 2) ==================
    ASYNC_POOL_SIZE: int = Field(
        default=4,
        ge=1,
        le=16,
        description="Размер пула асинхронных операций"
    )
    CONNECTION_POOL_SIZE: int = Field(
        default=10,
        ge=5,
        le=50,
        description="Размер пула соединений для файловых операций"
    )
    
    # ================== МОНИТОРИНГ (Version 2) ==================
    METRICS_ENABLED: bool = Field(default=True, description="Включить метрики производительности")
    HEALTH_CHECK_INTERVAL: int = Field(
        default=60,
        ge=30,
        le=300,
        description="Интервал проверки здоровья системы в секундах"
    )
    
    # ================== БАЗА ДАННЫХ (для будущих расширений) ==================
    DATABASE_URL: Optional[str] = Field(default=None, description="URL базы данных")
    DATABASE_POOL_SIZE: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Размер пула соединений БД"
    )
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        
        # Схемы валидации для безопасности
        schema_extra = {
            "example": {
                "APP_NAME": "Iskra API (Integrated)",
                "APP_VERSION": "1.0.0",
                "DEBUG": False,
                "HOST": "0.0.0.0",
                "PORT": 8000,
                "CORS_ORIGINS": "http://localhost:3000,http://localhost:8080",
                "JWT_SECRET": "generated-automatically-if-empty",
                "JWT_ALGORITHM": "HS256",
                "JWT_EXPIRE_MINUTES": 30,
                "EVIDENCE_PATH": "memory/evidence.jsonl",
                "MAX_SEARCH_RESULTS": 50,
                "DEFAULT_SEARCH_K": 5,
                "MEMORY_ROOT": "memory",
                "MEMORY_BATCH_SIZE": 50,
                "MEMORY_FLUSH_INTERVAL": 5.0,
                "MEMORY_COMPRESSION": False,
                "ENABLE_LRU_CACHE": True,
                "LRU_CACHE_SIZE": 1000,
                "LOG_LEVEL": "INFO",
                "OTEL_ENABLED": True,
                "OTEL_SERVICE_NAME": "iskra-api",
                "MANIFEST_PATH": "manifest/cd_index_baseline.json",
                "CANON_INDEX_PATH": "docs/CANON/INDEX.md",
                "RATE_LIMIT_ENABLED": True,
                "RATE_LIMIT_REQUESTS": 100,
                "ASYNC_POOL_SIZE": 4,
                "CONNECTION_POOL_SIZE": 10,
                "METRICS_ENABLED": True,
                "HEALTH_CHECK_INTERVAL": 60
            }
        }
    
    def get_safe_jwt_secret(self) -> str:
        """Получение безопасного JWT секрета"""
        return self.JWT_SECRET
    
    def get_cors_origins_list(self) -> List[str]:
        """Получение списка CORS источников"""
        return self.CORS_ORIGINS if isinstance(self.CORS_ORIGINS, list) else [self.CORS_ORIGINS]
    
    def is_production_mode(self) -> bool:
        """Определение режима продакшена"""
        return not self.DEBUG
    
    def should_enable_cors_docs(self) -> bool:
        """Определение необходимости включения CORS документации"""
        return not self.is_production_mode()


# Глобальный экземпляр настроек
settings = Settings()

# Дополнительные утилиты для конфигурации
def get_logging_config() -> dict:
    """Получение конфигурации логирования"""
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json" if settings.LOG_FORMAT == "json" else "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            }
        },
        "handlers": {
            "default": {
                "formatter": settings.LOG_FORMAT,
                "class": "logging.StreamHandler",
                "stream": "ext://sys.stdout"
            }
        },
        "root": {
            "level": settings.LOG_LEVEL,
            "handlers": ["default"]
        }
    }

def get_security_headers() -> dict:
    """Получение заголовков безопасности"""
    return {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
    }