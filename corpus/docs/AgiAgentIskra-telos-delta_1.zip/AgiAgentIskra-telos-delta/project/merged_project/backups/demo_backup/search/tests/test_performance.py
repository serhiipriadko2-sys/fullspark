"""Тесты производительности интегрированной поисковой системы.

Проверяют производительность различных режимов поиска,
эффективность кэширования и масштабируемость системы.
"""

import pytest
import asyncio
import time
import statistics
import os
import json
import tempfile
from typing import List, Dict, Any
import concurrent.futures

from search.integrated_search import IntegratedSearch
from search.performance_config import (
    PerformanceConfig, SearchMode, PerformanceProfile,
    create_fast_config, create_balanced_config, create_quality_config
)

class TestPerformance:
    """Тесты производительности поисковой системы."""
    
    @pytest.fixture
    def performance_evidence_file(self):
        """Создание файла с большим количеством тестовых данных."""
        test_data = []
        
        # Генерация 100 документов по 10 чанков каждый
        for doc_id in range(100):
            for chunk_id in range(10):
                content = f"Документ {doc_id} содержит информацию о тестировании производительности поисковой системы. Чанк {chunk_id}."
                test_data.append({
                    "doc_id": f"perf_doc_{doc_id:03d}.md",
                    "chunk_id": chunk_id,
                    "content": content
                })
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False) as f:
            for item in test_data:
                f.write(json.dumps(item, ensure_ascii=False) + '\n')
            temp_path = f.name
        
        yield temp_path
        
        # Очистка
        os.unlink(temp_path)
    
    @pytest.fixture
    def performance_configs(self):
        """Различные конфигурации для тестирования."""
        return {
            'fast': create_fast_config(),
            'balanced': create_balanced_config(),
            'quality': create_quality_config()
        }
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_search_speed_comparison(self, performance_evidence_file, performance_configs):
        """Тест сравнения скорости различных режимов поиска."""
        test_query = "тестирование производительности поисковой системы"
        
        results = {}
        
        for config_name, config in performance_configs.items():
            # Настройка пути к evidence
            config.legacy_config.evidence_path = performance_evidence_file
            config.modern_config.evidence_path = performance_evidence_file
            
            async with IntegratedSearch(config) as searcher:
                # Измерение времени поиска
                start_time = time.time()
                search_results, metrics = await searcher.search(test_query)
                end_time = time.time()
                
                search_time = (end_time - start_time) * 1000  # в миллисекундах
                
                results[config_name] = {
                    'search_time_ms': search_time,
                    'results_count': len(search_results),
                    'metrics': metrics,
                    'mode_used': metrics.mode_used
                }
        
        # Проверка результатов
        assert 'fast' in results
        assert 'balanced' in results
        assert 'quality' in results
        
        # Быстрая конфигурация должна быть самой быстрой
        fast_time = results['fast']['search_time_ms']
        balanced_time = results['balanced']['search_time_ms']
        quality_time = results['quality']['search_time_ms']
        
        print(f"Время поиска - Fast: {fast_time:.2f}ms, Balanced: {balanced_time:.2f}ms, Quality: {quality_time:.2f}ms")
        
        # Быстрая конфигурация не должна быть значительно медленнее других
        assert fast_time < quality_time * 2
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_cache_effectiveness(self, performance_evidence_file):
        """Тест эффективности кэширования."""
        config = create_balanced_config()
        config.legacy_config.evidence_path = performance_evidence_file
        config.cache_size = 10
        
        async with IntegratedSearch(config) as searcher:
            test_query = "тестирование производительности"
            
            # Первый поиск (без кэша)
            start_time = time.time()
            results1, metrics1 = await searcher.search(test_query)
            first_search_time = time.time() - start_time
            
            # Второй поиск (с кэшем)
            start_time = time.time()
            results2, metrics2 = await searcher.search(test_query)
            second_search_time = time.time() - start_time
            
            # Проверка эффективности кэша
            assert metrics2.cache_hit == True
            assert len(results1) == len(results2)
            
            # Кэшированный поиск должен быть значительно быстрее
            speedup = first_search_time / second_search_time if second_search_time > 0 else float('inf')
            print(f"Ускорение от кэширования: {speedup:.2f}x")
            
            # Кэш должен давать ускорение минимум в 2 раза
            assert speedup >= 2.0
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_concurrent_searches(self, performance_evidence_file):
        """Тест параллельного выполнения поисков."""
        config = create_balanced_config()
        config.legacy_config.evidence_path = performance_evidence_file
        config.max_concurrent_searches = 5
        
        test_queries = [
            "тестирование производительности",
            "поисковая система",
            "документ информация",
            "чанк тест",
            "конфигурация поиск"
        ]
        
        async with IntegratedSearch(config) as searcher:
            # Запуск параллельных поисков
            start_time = time.time()
            
            tasks = []
            for query in test_queries:
                task = searcher.search(query)
                tasks.append(task)
            
            results = await asyncio.gather(*tasks)
            end_time = time.time()
            
            total_time = end_time - start_time
            
            # Проверка результатов
            assert len(results) == len(test_queries)
            
            for i, (search_results, metrics) in enumerate(results):
                assert isinstance(search_results, list)
                assert isinstance(metrics, SearchMetrics)
                assert metrics.mode_used in [mode.value for mode in SearchMode]
                
                print(f"Запрос '{test_queries[i]}': {len(search_results)} результатов, {metrics.search_time_ms:.2f}ms")
            
            # Общее время должно быть меньше суммы индивидуальных времен
            print(f"Общее время параллельного поиска: {total_time:.2f}s")
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_large_dataset_performance(self, performance_evidence_file):
        """Тест производительности на большом наборе данных."""
        config = create_fast_config()
        config.legacy_config.evidence_path = performance_evidence_file
        
        # Тестовые запросы разной сложности
        test_cases = [
            {"query": "документ", "expected_count": 100},  # Найдет все документы
            {"query": "тестирование производительности", "expected_count": 100},  # Специфичный поиск
            {"query": "уникальная_фраза_которой_нет_в_данных", "expected_count": 0},  # Нет результатов
            {"query": "документ 50", "expected_count": 1},  # Специфичный документ
        ]
        
        async with IntegratedSearch(config) as searcher:
            performance_results = []
            
            for i, test_case in enumerate(test_cases):
                query = test_case["query"]
                expected = test_case["expected_count"]
                
                # Многократное выполнение для получения статистики
                times = []
                for _ in range(5):
                    start_time = time.time()
                    results, metrics = await searcher.search(query, k=20)
                    end_time = time.time()
                    
                    times.append((end_time - start_time) * 1000)  # в миллисекундах
                
                avg_time = statistics.mean(times)
                std_dev = statistics.stdev(times) if len(times) > 1 else 0
                
                performance_results.append({
                    'query': query,
                    'expected_count': expected,
                    'avg_time_ms': avg_time,
                    'std_dev_ms': std_dev,
                    'actual_count': len(results)
                })
                
                print(f"Тест {i+1}: '{query}'")
                print(f"  Среднее время: {avg_time:.2f}ms (±{std_dev:.2f}ms)")
                print(f"  Найдено результатов: {len(results)} (ожидалось: {expected})")
            
            # Проверка производительности
            for result in performance_results:
                # Время поиска не должно превышать 100ms для быстрой конфигурации
                assert result['avg_time_ms'] < 100, f"Медленный поиск для запроса: {result['query']}"
                
                # Для запроса без результатов время должно быть минимальным
                if result['expected_count'] == 0:
                    assert result['avg_time_ms'] < 10, f"Слишком медленный поиск без результатов: {result['query']}"
    
    @pytest.mark.slow
    @pytest.mark.asyncio
    async def test_memory_usage(self, performance_evidence_file):
        """Тест использования памяти (базовая проверка)."""
        import psutil
        import gc
        
        config = create_balanced_config()
        config.legacy_config.evidence_path = performance_evidence_file
        config.cache_size = 50
        
        # Базовая память до поиска
        process = psutil.Process()
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        async with IntegratedSearch(config) as searcher:
            # Выполнение множественных поисков
            queries = [f"тестовый запрос {i}" for i in range(20)]
            
            for query in queries:
                await searcher.search(query)
            
            # Память после поисков
            peak_memory = process.memory_info().rss / 1024 / 1024  # MB
            
            # Проверка роста памяти
            memory_increase = peak_memory - initial_memory
            
            print(f"Использование памяти:")
            print(f"  Начальное: {initial_memory:.2f} MB")
            print(f"  После поисков: {peak_memory:.2f} MB")
            print(f"  Рост: {memory_increase:.2f} MB")
            
            # Рост памяти не должен превышать 50MB для данного теста
            assert memory_increase < 50, f"Чрезмерный рост памяти: {memory_increase:.2f} MB"
            
            # Принудительная очистка
            searcher.clear_cache()
            gc.collect()
            
            final_memory = process.memory_info().rss / 1024 / 1024  # MB
            memory_after_cleanup = final_memory - peak_memory
            
            print(f"  После очистки кэша: {final_memory:.2f} MB")
            print(f"  Освобождено: {-memory_after_cleanup:.2f} MB")
    
    @pytest.mark.asyncio
    async def test_search_result_consistency(self, performance_evidence_file):
        """Тест консистентности результатов поиска."""
        config = create_balanced_config()
        config.legacy_config.evidence_path = performance_evidence_file
        
        test_query = "тестирование производительности"
        
        async with IntegratedSearch(config) as searcher:
            # Множественные поиски одного и того же запроса
            all_results = []
            
            for _ in range(5):
                results, metrics = await searcher.search(test_query, k=10)
                all_results.append([(r.doc_id, r.chunk_id, r.score) for r in results])
            
            # Проверка консистентности
            first_result = all_results[0]
            
            for i, result_set in enumerate(all_results[1:], 1):
                # Результаты должны быть идентичными
                assert len(first_result) == len(result_set), f"Разное количество результатов в поиске {i}"
                
                for j, (doc1, chunk1, score1) in enumerate(first_result):
                    doc2, chunk2, score2 = result_set[j]
                    assert doc1 == doc2, f"Разные документы в позиции {j}, поиск {i}"
                    assert chunk1 == chunk2, f"Разные чанки в позиции {j}, поиск {i}"
                    # Допустима небольшая погрешность в оценке
                    assert abs(score1 - score2) < 0.001, f"Разные оценки в позиции {j}, поиск {i}"
            
            print(f"Консистентность: 5/5 поисков дали идентичные результаты")
    
    @pytest.mark.asyncio
    async def test_error_recovery(self, performance_evidence_file):
        """Тест восстановления после ошибок."""
        config = create_balanced_config()
        config.legacy_config.evidence_path = "nonexistent.jsonl"  # Несуществующий файл
        
        async with IntegratedSearch(config) as searcher:
            # Поиск должен работать через fallback даже с несуществующим файлом
            results, metrics = await searcher.search("test query")
            
            assert isinstance(results, list)
            assert isinstance(metrics, SearchMetrics)
            assert metrics.mode_used in ['fallback', 'error']
            
            print(f"Восстановление после ошибки: режим {metrics.mode_used}")
            
            # Повторный поиск должен продолжать работать
            results2, metrics2 = await searcher.search("another test")
            
            assert isinstance(results2, list)
            assert isinstance(metrics2, SearchMetrics)

# Вспомогательные функции для тестирования производительности
def measure_search_performance(searcher, query: str, iterations: int = 10) -> Dict[str, float]:
    """Измерение производительности поиска."""
    times = []
    
    for _ in range(iterations):
        start_time = time.time()
        # Здесь должен быть вызов поиска, но он зависит от конкретной реализации
        # results = await searcher.search(query)
        end_time = time.time()
        times.append(end_time - start_time)
    
    return {
        'mean': statistics.mean(times),
        'median': statistics.median(times),
        'std_dev': statistics.stdev(times) if len(times) > 1 else 0,
        'min': min(times),
        'max': max(times)
    }

def generate_performance_report(results: Dict[str, Any]) -> str:
    """Генерация отчета о производительности."""
    report = ["=== ОТЧЕТ О ПРОИЗВОДИТЕЛЬНОСТИ ===\\n"]
    
    for config_name, data in results.items():
        report.append(f"{config_name.upper()} КОНФИГУРАЦИЯ:")
        report.append(f"  Среднее время поиска: {data['avg_time_ms']:.2f}ms")
        report.append(f"  Стандартное отклонение: {data['std_dev_ms']:.2f}ms")
        report.append(f"  Найдено результатов: {data['actual_count']}")
        report.append("")
    
    return "\\n".join(report)

if __name__ == "__main__":
    # Запуск тестов производительности
    pytest.main([__file__, "-v", "-s", "--tb=short"])