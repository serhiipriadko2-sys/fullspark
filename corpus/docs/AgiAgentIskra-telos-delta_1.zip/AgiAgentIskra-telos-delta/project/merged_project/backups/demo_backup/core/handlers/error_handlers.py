"""Обработчики ошибок для разных уровней приложения.

Обеспечивает централизованную обработку исключений на всех уровнях архитектуры:
- HTTP Level - обработка ошибок Web API
- Service Level - обработка ошибок бизнес-логики  
- Repository Level - обработка ошибок доступа к данным
- Infrastructure Level - обработка системных ошибок

Версия: 1.0
Автор: Iskra Integration Team
"""

from typing import Dict, Any, Optional, Callable, Type, Union
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.responses import Response
import logging
import functools
from abc import ABC, abstractmethod

from .exception_hierarchy import (
    BaseIskraException, ErrorLevel, ErrorType, ErrorScope,
    AuthenticationException, AuthorizationException, NotFoundException,
    ValidationException, BusinessLogicException, DatabaseException,
    SearchException, VectorSearchException, ExternalServiceException,
    SystemException
)


# ================================
# Abstract Base Handler
# ================================

class BaseErrorHandler(ABC):
    """Базовый абстрактный класс для обработчиков ошибок."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
    
    @abstractmethod
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает исключение и возвращает Response."""
        pass
    
    def can_handle(self, exc: Exception) -> bool:
        """Проверяет, может ли обработчик обработать данное исключение."""
        return False


# ================================
# HTTP Level Handlers
# ================================

class HttpErrorHandler(BaseErrorHandler):
    """Обработчик HTTP ошибок."""
    
    def can_handle(self, exc: Exception) -> bool:
        """Обрабатывает HTTP исключения и Iskra исключения с HTTP scope."""
        return (
            isinstance(exc, HTTPException) or
            (isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.HTTP)
        )
    
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает HTTP ошибки."""
        if isinstance(exc, HTTPException):
            # Обычное FastAPI HTTPException
            return JSONResponse(
                status_code=exc.status_code,
                content={
                    "error": exc.detail,
                    "error_code": f"HTTP_{exc.status_code}",
                    "type": "http_exception"
                }
            )
        
        elif isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.HTTP:
            # Iskra исключение с HTTP scope
            self.logger.error(f"HTTP Error: {exc.to_dict()}")
            
            if exc.error_type == ErrorType.AUTHENTICATION:
                return JSONResponse(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    content={
                        "error": "Требуется аутентификация",
                        "error_code": exc.error_code,
                        "details": exc.details
                    }
                )
            elif exc.error_type == ErrorType.AUTHORIZATION:
                return JSONResponse(
                    status_code=status.HTTP_403_FORBIDDEN,
                    content={
                        "error": "Недостаточно прав доступа",
                        "error_code": exc.error_code,
                        "details": exc.details
                    }
                )
            else:
                # Общий HTTP обработчик
                return JSONResponse(
                    status_code=exc.status_code,
                    content={
                        "error": exc.message,
                        "error_code": exc.error_code,
                        "details": exc.details,
                        "level": exc.level.value
                    }
                )
        
        raise exc


class AuthenticationHandler(BaseErrorHandler):
    """Специализированный обработчик ошибок аутентификации."""
    
    def can_handle(self, exc: Exception) -> bool:
        return isinstance(exc, AuthenticationException)
    
    async def handle(self, request: Request, exc: AuthenticationException) -> Response:
        """Обрабатывает ошибки аутентификации."""
        self.logger.warning(f"Authentication failed: {exc.message}")
        
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": "authentication_error",
                "requires_auth": True
            },
            headers={"WWW-Authenticate": "Bearer"}
        )


class AuthorizationHandler(BaseErrorHandler):
    """Специализированный обработчик ошибок авторизации."""
    
    def can_handle(self, exc: Exception) -> bool:
        return isinstance(exc, AuthorizationException)
    
    async def handle(self, request: Request, exc: AuthorizationException) -> Response:
        """Обрабатывает ошибки авторизации."""
        self.logger.warning(f"Authorization failed: {exc.message}")
        
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": "authorization_error",
                "insufficient_permissions": True
            }
        )


class ValidationHandler(BaseErrorHandler):
    """Специализированный обработчик ошибок валидации."""
    
    def can_handle(self, exc: Exception) -> bool:
        return isinstance(exc, ValidationException)
    
    async def handle(self, request: Request, exc: ValidationException) -> Response:
        """Обрабатывает ошибки валидации."""
        self.logger.warning(f"Validation failed: {exc.message}")
        
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": "validation_error",
                "details": exc.details
            }
        )


class NotFoundHandler(BaseErrorHandler):
    """Специализированный обработчик ошибок 'не найдено'."""
    
    def can_handle(self, exc: Exception) -> bool:
        return isinstance(exc, NotFoundException)
    
    async def handle(self, request: Request, exc: NotFoundException) -> Response:
        """Обрабатывает ошибки 'не найдено'."""
        self.logger.info(f"Resource not found: {exc.message}")
        
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": "not_found_error"
            }
        )


# ================================
# Service Level Handlers
# ================================

class ServiceErrorHandler(BaseErrorHandler):
    """Обработчик ошибок на уровне сервиса."""
    
    def can_handle(self, exc: Exception) -> bool:
        return (
            isinstance(exc, BusinessLogicException) or
            (isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.SERVICE)
        )
    
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает ошибки бизнес-логики."""
        if isinstance(exc, BusinessLogicException):
            self.logger.error(f"Business logic error: {exc.to_dict()}")
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        elif isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.SERVICE:
            self.logger.error(f"Service error: {exc.to_dict()}")
            status_code = exc.status_code
        else:
            raise exc
        
        return JSONResponse(
            status_code=status_code,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": "service_error",
                "details": exc.details,
                "level": exc.level.value if isinstance(exc, BaseIskraException) else "medium"
            }
        )


class ConfigurationHandler(BaseErrorHandler):
    """Обработчик ошибок конфигурации."""
    
    def can_handle(self, exc: Exception) -> bool:
        from .exception_hierarchy import ConfigurationException
        return isinstance(exc, ConfigurationException)
    
    async def handle(self, request: Request, exc) -> Response:
        """Обрабатывает ошибки конфигурации."""
        self.logger.critical(f"Configuration error: {exc.to_dict()}")
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "Ошибка конфигурации системы",
                "error_code": exc.error_code,
                "type": "configuration_error",
                "details": exc.details
            }
        )


# ================================
# Repository Level Handlers
# ================================

class RepositoryErrorHandler(BaseErrorHandler):
    """Обработчик ошибок на уровне репозитория."""
    
    def can_handle(self, exc: Exception) -> bool:
        return (
            isinstance(exc, DatabaseException) or
            isinstance(exc, SearchException) or
            isinstance(exc, VectorSearchException) or
            (isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.REPOSITORY)
        )
    
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает ошибки доступа к данным."""
        self.logger.error(f"Repository error: {exc.to_dict()}")
        
        # Определяем HTTP статус код на основе типа ошибки
        if isinstance(exc, DatabaseException):
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            error_type = "database_error"
        elif isinstance(exc, SearchException):
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            error_type = "search_error"
        elif isinstance(exc, VectorSearchException):
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            error_type = "vector_search_error"
        elif isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.REPOSITORY:
            status_code = exc.status_code
            error_type = "repository_error"
        else:
            raise exc
        
        return JSONResponse(
            status_code=status_code,
            content={
                "error": exc.message,
                "error_code": exc.error_code,
                "type": error_type,
                "details": exc.details,
                "level": exc.level.value if isinstance(exc, BaseIskraException) else "medium"
            }
        )


# ================================
# Infrastructure Level Handlers
# ================================

class InfrastructureErrorHandler(BaseErrorHandler):
    """Обработчик инфраструктурных ошибок."""
    
    def can_handle(self, exc: Exception) -> bool:
        return (
            isinstance(exc, ExternalServiceException) or
            isinstance(exc, SystemException) or
            (isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.INFRASTRUCTURE)
        )
    
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает инфраструктурные ошибки."""
        if isinstance(exc, ExternalServiceException):
            self.logger.critical(f"External service error: {exc.to_dict()}")
        elif isinstance(exc, SystemException):
            self.logger.critical(f"System error: {exc.to_dict()}")
        elif isinstance(exc, BaseIskraException) and exc.scope == ErrorScope.INFRASTRUCTURE:
            self.logger.error(f"Infrastructure error: {exc.to_dict()}")
        
        # Инфраструктурные ошибки всегда 500
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "Внутренняя ошибка сервера",
                "error_code": exc.error_code,
                "type": "infrastructure_error",
                "details": exc.details
            }
        )


# ================================
# Universal Error Handler
# ================================

class UniversalErrorHandler(BaseErrorHandler):
    """Универсальный обработчик для всех остальных исключений."""
    
    def can_handle(self, exc: Exception) -> bool:
        # Обрабатывает все исключения, которые не обработаны другими handlers
        return not any(handler.can_handle(exc) for handler in self._handlers)
    
    def __init__(self, logger: Optional[logging.Logger] = None, handlers: Optional[list] = None):
        super().__init__(logger)
        self._handlers = handlers or []
    
    def set_handlers(self, handlers: list):
        """Устанавливает список обработчиков для проверки."""
        self._handlers = handlers
    
    async def handle(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает любые исключения."""
        self.logger.error(f"Unexpected error: {type(exc).__name__}: {str(exc)}")
        
        # Логируем полную информацию об ошибке
        self.logger.error(f"Traceback: ", exc_info=exc)
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "Внутренняя ошибка сервера",
                "error_code": "INTERNAL_ERROR_001",
                "type": "internal_error",
                "message": "Произошла неожиданная ошибка"
            }
        )


# ================================
# Error Handler Manager
# ================================

class ErrorHandlerManager:
    """Менеджер для управления обработчиками ошибок."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        self.logger = logger or logging.getLogger(__name__)
        self._handlers: list[BaseErrorHandler] = []
        self._setup_default_handlers()
    
    def _setup_default_handlers(self):
        """Настраивает набор обработчиков по умолчанию."""
        # HTTP handlers
        self.add_handler(NotFoundHandler(self.logger))
        self.add_handler(AuthenticationHandler(self.logger))
        self.add_handler(AuthorizationHandler(self.logger))
        self.add_handler(ValidationHandler(self.logger))
        self.add_handler(HttpErrorHandler(self.logger))
        
        # Service handlers
        self.add_handler(ConfigurationHandler(self.logger))
        self.add_handler(ServiceErrorHandler(self.logger))
        
        # Repository handlers
        self.add_handler(RepositoryErrorHandler(self.logger))
        
        # Infrastructure handlers
        self.add_handler(InfrastructureErrorHandler(self.logger))
        
        # Universal handler (должен быть последним)
        universal_handler = UniversalErrorHandler(self.logger)
        universal_handler.set_handlers(self._handlers)
        self.add_handler(universal_handler)
    
    def add_handler(self, handler: BaseErrorHandler):
        """Добавляет новый обработчик."""
        self._handlers.append(handler)
        self.logger.info(f"Added error handler: {handler.__class__.__name__}")
    
    def remove_handler(self, handler: BaseErrorHandler):
        """Удаляет обработчик."""
        if handler in self._handlers:
            self._handlers.remove(handler)
            self.logger.info(f"Removed error handler: {handler.__class__.__name__}")
    
    async def handle_error(self, request: Request, exc: Exception) -> Response:
        """Обрабатывает исключение с помощью подходящего обработчика."""
        for handler in self._handlers:
            if handler.can_handle(exc):
                self.logger.debug(f"Using {handler.__class__.__name__} for {type(exc).__name__}")
                return await handler.handle(request, exc)
        
        # Если ни один обработчик не подошел (маловероятно)
        self.logger.error(f"No handler found for {type(exc).__name__}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"error": "Internal server error"}
        )


# ================================
# Decorators для обработки ошибок
# ================================

def handle_errors(handler_manager: ErrorHandlerManager):
    """Декоратор для автоматической обработки ошибок в функциях."""
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except Exception as exc:
                # Если это FastAPI endpoint, создаем mock request
                if hasattr(func, '__name__') and 'request' not in kwargs:
                    from fastapi import Request
                    from starlette.requests import empty_scope
                    
                    # Создаем пустой request для логирования
                    scope = empty_scope()
                    request = Request(scope)
                else:
                    request = kwargs.get('request')
                
                if request:
                    response = await handler_manager.handle_error(request, exc)
                    # В FastAPI обработчики исключений должны перебрасывать исключения
                    # чтобы FastAPI мог создать правильный response
                    if isinstance(exc, BaseIskraException):
                        exc = exc.to_http_exception()
                    raise exc
                else:
                    raise exc
        
        return wrapper
    return decorator


def service_error_handler(func):
    """Декоратор для обработки ошибок в сервисах."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            if isinstance(exc, BaseIskraException):
                raise exc
            
            # Логируем неизвестную ошибку и преобразуем в IskraException
            logging.getLogger(__name__).error(
                f"Service error in {func.__name__}: {str(exc)}",
                exc_info=exc
            )
            
            raise BaseIskraException(
                message=f"Ошибка в сервисе {func.__name__}: {str(exc)}",
                error_type=ErrorType.BUSINESS_LOGIC,
                scope=ErrorScope.SERVICE,
                cause=exc
            )
    
    return wrapper


def repository_error_handler(func):
    """Декоратор для обработки ошибок в репозиториях."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            if isinstance(exc, BaseIskraException):
                raise exc
            
            # Логируем ошибку и преобразуем в RepositoryLevelException
            logging.getLogger(__name__).error(
                f"Repository error in {func.__name__}: {str(exc)}",
                exc_info=exc
            )
            
            raise RepositoryLevelException(
                message=f"Ошибка доступа к данным в {func.__name__}: {str(exc)}",
                cause=exc,
                error_type=ErrorType.DATABASE if "database" in func.__name__.lower() else ErrorType.UNKNOWN
            )
    
    return wrapper