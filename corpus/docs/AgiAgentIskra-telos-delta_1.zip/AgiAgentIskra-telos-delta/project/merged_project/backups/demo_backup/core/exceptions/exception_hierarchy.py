"""Интегрированная иерархия исключений.

Объединяет базовую обработку ошибок Version 1 с продвинутой системой Version 2.
Обеспечивает обратную совместимость и поддержку разных уровней обработки ошибок.

Версия: 1.0
Автор: Iskra Integration Team
"""

from typing import Optional, Dict, Any, Union
import traceback
import functools
from enum import Enum

# Заглушки для FastAPI, чтобы избежать зависимостей
try:
    from fastapi import HTTPException, status
    FASTAPI_AVAILABLE = True
except ImportError:
    # Создаем заглушки для FastAPI
    class HTTPException(Exception):
        def __init__(self, status_code: int = 500, detail: str = "Internal Server Error"):
            self.status_code = status_code
            self.detail = detail
            super().__init__(detail)
    
    class status:
        HTTP_200_OK = 200
        HTTP_400_BAD_REQUEST = 400
        HTTP_401_UNAUTHORIZED = 401
        HTTP_403_FORBIDDEN = 403
        HTTP_404_NOT_FOUND = 404
        HTTP_422_UNPROCESSABLE_ENTITY = 422
        HTTP_500_INTERNAL_SERVER_ERROR = 500
    
    FASTAPI_AVAILABLE = False


# ================================
# Enums для классификации ошибок
# ================================

class ErrorLevel(Enum):
    """Уровни серьезности ошибок."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ErrorType(Enum):
    """Типы ошибок по доменам."""
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    VALIDATION = "validation"
    BUSINESS_LOGIC = "business_logic"
    DATABASE = "database"
    SEARCH = "search"
    VECTOR_SEARCH = "vector_search"
    INFRASTRUCTURE = "infrastructure"
    EXTERNAL_SERVICE = "external_service"
    UNKNOWN = "unknown"


class ErrorScope(Enum):
    """Области применения ошибок."""
    HTTP = "http"
    SERVICE = "service"
    REPOSITORY = "repository"
    INFRASTRUCTURE = "infrastructure"


# ================================
# Базовые исключения
# ================================

class BaseIskraException(Exception):
    """Базовый класс исключений проекта Искра.
    
    Обеспечивает совместимость с Version 1 и Version 2.
    Поддерживает как простые, так и продвинутые возможности обработки ошибок.
    """
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        level: ErrorLevel = ErrorLevel.MEDIUM,
        error_type: ErrorType = ErrorType.UNKNOWN,
        scope: ErrorScope = ErrorScope.SERVICE,
        cause: Optional[Exception] = None,
        trace: Optional[str] = None
    ):
        self.message = message
        self.error_code = error_code or f"{error_type.value.upper()}_{scope.value.upper()}_001"
        self.details = details or {}
        self.status_code = status_code
        self.level = level
        self.error_type = error_type
        self.scope = scope
        self.cause = cause
        self.trace = trace or traceback.format_exc()
        
        # Атрибуты для обратной совместимости с Version 1
        self._version1_mode = details is None
        
        super().__init__(self.message)
    
    def to_http_exception(self) -> HTTPException:
        """Преобразует исключение в HTTP исключение FastAPI.
        
        Поддерживает как простой формат Version 1, так и продвинутый Version 2.
        """
        if self._version1_mode:
            # Version 1 совместимость
            return HTTPException(
                status_code=self.status_code,
                detail=self.message
            )
        else:
            # Version 2 формат
            return HTTPException(
                status_code=self.status_code,
                detail={
                    "error": self.message,
                    "error_code": self.error_code,
                    "details": self.details,
                    "level": self.level.value,
                    "type": self.error_type.value
                }
            )
    
    def to_dict(self) -> Dict[str, Any]:
        """Возвращает исключение в виде словаря для логирования."""
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "status_code": self.status_code,
            "level": self.level.value,
            "error_type": self.error_type.value,
            "scope": self.scope.value,
            "cause": str(self.cause) if self.cause else None,
            "trace": self.trace
        }
    
    def __str__(self) -> str:
        """Строковое представление исключения."""
        if self._version1_mode:
            return self.message
        
        return f"{self.error_code}: {self.message}"


# ================================
# Версия 1 Совместимость
# ================================

class IskraException(BaseIskraException):
    """Исключение в стиле Version 1 для обратной совместимости."""
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        # Автоматически определяем режим совместимости
        if details is None:
            status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
            level = ErrorLevel.MEDIUM
            error_type = ErrorType.UNKNOWN
            scope = ErrorScope.SERVICE
        else:
            status_code = details.get("status_code", status.HTTP_500_INTERNAL_SERVER_ERROR)
            level = ErrorLevel(details.get("level", "medium"))
            error_type = ErrorType(details.get("type", "unknown"))
            scope = ErrorScope(details.get("scope", "service"))
        
        super().__init__(
            message=message,
            error_code=error_code,
            details=details,
            status_code=status_code,
            level=level,
            error_type=error_type,
            scope=scope
        )


# ================================
# HTTP Level Exceptions
# ================================

class HttpLevelException(BaseIskraException):
    """Базовый класс для HTTP уровня ошибок."""
    
    def __init__(self, message: str, **kwargs):
        kwargs.setdefault("scope", ErrorScope.HTTP)
        super().__init__(message, **kwargs)


class AuthenticationException(HttpLevelException):
    """Исключение аутентификации."""
    
    def __init__(self, message: str = "Ошибка аутентификации"):
        super().__init__(
            message,
            status_code=status.HTTP_401_UNAUTHORIZED,
            error_type=ErrorType.AUTHENTICATION,
            level=ErrorLevel.HIGH
        )


class AuthorizationException(HttpLevelException):
    """Исключение авторизации."""
    
    def __init__(self, message: str = "Недостаточно прав доступа"):
        super().__init__(
            message,
            status_code=status.HTTP_403_FORBIDDEN,
            error_type=ErrorType.AUTHORIZATION,
            level=ErrorLevel.HIGH
        )


class NotFoundException(HttpLevelException):
    """Исключение - ресурс не найден."""
    
    def __init__(self, resource: str = "Ресурс"):
        message = f"{resource} не найден"
        super().__init__(
            message,
            status_code=status.HTTP_404_NOT_FOUND,
            error_type=ErrorType.UNKNOWN,
            level=ErrorLevel.MEDIUM
        )


class ValidationException(HttpLevelException):
    """Исключение валидации данных."""
    
    def __init__(self, message: str, field: Optional[str] = None):
        details = {}
        if field:
            details["field"] = field
        
        super().__init__(
            message,
            details=details,
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            error_type=ErrorType.VALIDATION,
            level=ErrorLevel.MEDIUM
        )


# ================================
# Service Level Exceptions
# ================================

class ServiceLevelException(BaseIskraException):
    """Базовый класс для уровня сервиса."""
    
    def __init__(self, message: str, **kwargs):
        kwargs.setdefault("scope", ErrorScope.SERVICE)
        super().__init__(message, **kwargs)


class BusinessLogicException(ServiceLevelException):
    """Исключение бизнес-логики."""
    
    def __init__(self, message: str, error_code: Optional[str] = None):
        super().__init__(
            message,
            error_code=error_code or "BIZ_001",
            error_type=ErrorType.BUSINESS_LOGIC,
            level=ErrorLevel.MEDIUM
        )


class ConfigurationException(ServiceLevelException):
    """Исключение конфигурации."""
    
    def __init__(self, message: str, config_key: Optional[str] = None):
        details = {}
        if config_key:
            details["config_key"] = config_key
        
        super().__init__(
            message,
            details=details,
            error_type=ErrorType.INFRASTRUCTURE,
            level=ErrorLevel.HIGH
        )


# ================================
# Repository Level Exceptions
# ================================

class RepositoryLevelException(BaseIskraException):
    """Базовый класс для уровня репозитория."""
    
    def __init__(self, message: str, **kwargs):
        kwargs.setdefault("scope", ErrorScope.REPOSITORY)
        super().__init__(message, **kwargs)


class DatabaseException(RepositoryLevelException):
    """Исключение базы данных."""
    
    def __init__(self, message: str = "Ошибка базы данных", cause: Optional[Exception] = None):
        super().__init__(
            message,
            cause=cause,
            error_type=ErrorType.DATABASE,
            level=ErrorLevel.HIGH
        )


class SearchException(RepositoryLevelException):
    """Исключение поиска."""
    
    def __init__(self, message: str = "Ошибка поиска", cause: Optional[Exception] = None):
        super().__init__(
            message,
            cause=cause,
            error_type=ErrorType.SEARCH,
            level=ErrorLevel.MEDIUM
        )


class VectorSearchException(RepositoryLevelException):
    """Исключение векторного поиска."""
    
    def __init__(self, message: str = "Ошибка векторного поиска", cause: Optional[Exception] = None):
        super().__init__(
            message,
            cause=cause,
            error_type=ErrorType.VECTOR_SEARCH,
            level=ErrorLevel.MEDIUM
        )


# ================================
# Infrastructure Level Exceptions
# ================================

class InfrastructureLevelException(BaseIskraException):
    """Базовый класс для инфраструктурного уровня."""
    
    def __init__(self, message: str, **kwargs):
        kwargs.setdefault("scope", ErrorScope.INFRASTRUCTURE)
        super().__init__(message, **kwargs)


class ExternalServiceException(InfrastructureLevelException):
    """Исключение внешнего сервиса."""
    
    def __init__(self, message: str, service_name: str, status_code: int = 500):
        details = {"service_name": service_name}
        super().__init__(
            message,
            details=details,
            status_code=status_code,
            error_type=ErrorType.EXTERNAL_SERVICE,
            level=ErrorLevel.HIGH
        )


class SystemException(InfrastructureLevelException):
    """Системное исключение."""
    
    def __init__(self, message: str, error_code: Optional[str] = None):
        super().__init__(
            message,
            error_code=error_code or "SYS_001",
            error_type=ErrorType.INFRASTRUCTURE,
            level=ErrorLevel.CRITICAL
        )


# ================================
# Декораторы для обработки исключений
# ================================

def error_handler(level: ErrorLevel = ErrorLevel.MEDIUM, log_error: bool = True):
    """Декоратор для автоматической обработки исключений.
    
    Позволяет обернуть функции для автоматической обработки ошибок.
    
    Args:
        level: Уровень ошибки
        log_error: Нужно ли логировать ошибку
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            try:
                return await func(*args, **kwargs)
            except BaseIskraException:
                raise  # Перебрасываем уже обработанные Iskra исключения
            except Exception as e:
                if log_error:
                    # Здесь будет интеграция с системой логирования
                    print(f"[{level.value.upper()}] {func.__name__}: {str(e)}")
                
                # Преобразуем в Iskra исключение
                raise BaseIskraException(
                    message=f"Ошибка в функции {func.__name__}: {str(e)}",
                    level=level,
                    cause=e
                )
        
        return wrapper
    return decorator


def handle_iskra_exceptions(func):
    """Декоратор для автоматической обработки Iskra исключений."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except BaseIskraException:
            raise  # Перебрасываем Iskra исключения как есть
        except Exception as e:
            # Преобразуем в Iskra исключение с базовыми параметрами
            raise BaseIskraException(
                message=str(e),
                error_code="UNKNOWN_001"
            )
    
    return wrapper


# ================================
# Утилиты для работы с исключениями
# ================================

def is_iskra_exception(exc: Exception) -> bool:
    """Проверяет, является ли исключение Iskra исключением."""
    return isinstance(exc, BaseIskraException)


def get_exception_info(exc: Exception) -> Dict[str, Any]:
    """Извлекает информацию об исключении для логирования."""
    if is_iskra_exception(exc):
        return exc.to_dict()
    
    return {
        "error_code": "UNKNOWN_001",
        "message": str(exc),
        "type": type(exc).__name__,
        "traceback": traceback.format_exc()
    }


def create_exception_from_error(
    message: str,
    error_type: Union[str, ErrorType] = ErrorType.UNKNOWN,
    status_code: int = 500,
    **kwargs
) -> BaseIskraException:
    """Создает Iskra исключение на основе параметров ошибки."""
    if isinstance(error_type, str):
        error_type = ErrorType(error_type)
    
    return BaseIskraException(
        message=message,
        error_type=error_type,
        status_code=status_code,
        **kwargs
    )