"""
Модуль валидации конфигурации.

Обеспечивает комплексную валидацию всех настроек конфигурации,
включая проверку типов, диапазонов, совместимости и безопасности.
"""

import os
import re
import logging
from typing import Dict, Any, Optional, List, Union, Tuple
from dataclasses import dataclass
from enum import Enum
import ipaddress
from urllib.parse import urlparse


class ValidationLevel(Enum):
    """Уровни строгости валидации."""
    RELAXED = "relaxed"      # Минимальная проверка
    STANDARD = "standard"    # Стандартная проверка
    STRICT = "strict"        # Строгая проверка
    SECURITY = "security"    # Проверка безопасности


@dataclass
class ValidationRule:
    """Правило валидации."""
    field_name: str
    validation_type: str  # "type", "range", "pattern", "custom", "dependency"
    constraint: Any
    error_message: str
    warning_message: Optional[str] = None
    level: ValidationLevel = ValidationLevel.STANDARD


@dataclass
class ValidationResult:
    """Результат валидации."""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    field_errors: Dict[str, List[str]]
    field_warnings: Dict[str, List[str]]
    statistics: Dict[str, int]


class ConfigValidator:
    """Валидатор конфигурации."""
    
    def __init__(self, level: ValidationLevel = ValidationLevel.STANDARD):
        """
        Инициализация валидатора.
        
        Args:
            level: Уровень строгости валидации
        """
        self.level = level
        self.validation_rules = self._initialize_validation_rules()
        self.custom_validators = {}
    
    def _initialize_validation_rules(self) -> List[ValidationRule]:
        """Инициализация правил валидации."""
        rules = []
        
        # === БАЗОВЫЕ НАСТРОЙКИ ===
        rules.extend([
            ValidationRule("APP_NAME", "type", str, "APP_NAME должно быть строкой"),
            ValidationRule("APP_VERSION", "pattern", r"^\d+\.\d+\.\d+", "APP_VERSION должно соответствовать семантическому версионированию"),
            ValidationRule("DEBUG", "type", bool, "DEBUG должно быть булевым значением"),
            ValidationRule("ENVIRONMENT_PROFILE", "choice", ["development", "production", "testing", "staging"], 
                          "ENVIRONMENT_PROFILE должен быть одним из: development, production, testing, staging"),
        ])
        
        # === СЕТЕВЫЕ НАСТРОЙКИ ===
        rules.extend([
            ValidationRule("HOST", "custom", self._validate_host, "Некорректный хост"),
            ValidationRule("PORT", "range", (1, 65535), "PORT должен быть в диапазоне 1-65535"),
        ])
        
        # === CORS НАСТРОЙКИ ===
        rules.extend([
            ValidationRule("CORS_ORIGINS", "custom", self._validate_cors_origins, "Некорректные CORS источники"),
            ValidationRule("CORS_ALLOW_CREDENTIALS", "type", bool, "CORS_ALLOW_CREDENTIALS должно быть булевым значением"),
            ValidationRule("CORS_ALLOW_METHODS", "custom", self._validate_http_methods, "Некорректные HTTP методы"),
            ValidationRule("CORS_ALLOW_HEADERS", "custom", self._validate_http_headers, "Некорректные HTTP заголовки"),
        ])
        
        # === JWT НАСТРОЙКИ ===
        rules.extend([
            ValidationRule("JWT_SECRET", "custom", self._validate_jwt_secret, "JWT_SECRET должен быть достаточно длинным и безопасным"),
            ValidationRule("JWT_ALGORITHM", "choice", ["HS256", "HS384", "HS512", "RS256", "RS384", "RS512"], 
                          "Неподдерживаемый JWT алгоритм"),
            ValidationRule("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "range", (5, 1440), "JWT_ACCESS_TOKEN_EXPIRE_MINUTES должен быть 5-1440"),
            ValidationRule("JWT_REFRESH_TOKEN_EXPIRE_DAYS", "range", (1, 30), "JWT_REFRESH_TOKEN_EXPIRE_DAYS должен быть 1-30"),
        ])
        
        # === RATE LIMITING ===
        rules.extend([
            ValidationRule("RATE_LIMIT_ENABLED", "type", bool, "RATE_LIMIT_ENABLED должно быть булевым значением"),
            ValidationRule("RATE_LIMIT_REQUESTS", "range", (10, 10000), "RATE_LIMIT_REQUESTS должен быть 10-10000"),
            ValidationRule("RATE_LIMIT_BURST", "range", (50, 50000), "RATE_LIMIT_BURST должен быть 50-50000"),
        ])
        
        # === БЕЗОПАСНОСТЬ ===
        rules.extend([
            ValidationRule("SECURITY_HEADERS_ENABLED", "type", bool, "SECURITY_HEADERS_ENABLED должно быть булевым значением"),
            ValidationRule("STRICT_TRANSPORT_SECURITY", "type", bool, "STRICT_TRANSPORT_SECURITY должно быть булевым значением"),
            ValidationRule("CONTENT_SECURITY_POLICY", "custom", self._validate_csp, "Некорректная Content Security Policy"),
        ])
        
        # === НАСТРОЙКИ ПАМЯТИ ===
        rules.extend([
            ValidationRule("MEMORY_ROOT", "custom", self._validate_path, "MEMORY_ROOT должен быть корректным путем"),
            ValidationRule("EVIDENCE_PATH", "custom", self._validate_path, "EVIDENCE_PATH должен быть корректным путем"),
            ValidationRule("WORKING_MEMORY_PATH", "custom", self._validate_path, "WORKING_MEMORY_PATH должен быть корректным путем"),
            ValidationRule("LONG_TERM_MEMORY_PATH", "custom", self._validate_path, "LONG_TERM_MEMORY_PATH должен быть корректным путем"),
            ValidationRule("MEMORY_BATCH_SIZE", "range", (1, 1000), "MEMORY_BATCH_SIZE должен быть 1-1000"),
            ValidationRule("MEMORY_FLUSH_INTERVAL", "range", (0.1, 300.0), "MEMORY_FLUSH_INTERVAL должен быть 0.1-300.0"),
            ValidationRule("MEMORY_AUTO_FLUSH", "type", bool, "MEMORY_AUTO_FLUSH должно быть булевым значением"),
            ValidationRule("MEMORY_COMPRESSION", "type", bool, "MEMORY_COMPRESSION должно быть булевым значением"),
            ValidationRule("MEMORY_MAX_SIZE_MB", "range", (10, 10240), "MEMORY_MAX_SIZE_MB должен быть 10-10240"),
            ValidationRule("MEMORY_ASYNC", "type", bool, "MEMORY_ASYNC должно быть булевым значением"),
            ValidationRule("MEMORY_CONCURRENT_OPS", "range", (1, 32), "MEMORY_CONCURRENT_OPS должен быть 1-32"),
        ])
        
        # === НАСТРОЙКИ ПОИСКА ===
        rules.extend([
            ValidationRule("DEFAULT_SEARCH_K", "range", (1, 100), "DEFAULT_SEARCH_K должен быть 1-100"),
            ValidationRule("MAX_SEARCH_RESULTS", "range", (1, 1000), "MAX_SEARCH_RESULTS должен быть 1-1000"),
            ValidationRule("SEARCH_TIMEOUT", "range", (1.0, 600.0), "SEARCH_TIMEOUT должен быть 1.0-600.0"),
            ValidationRule("SEARCH_CACHE_ENABLED", "type", bool, "SEARCH_CACHE_ENABLED должно быть булевым значением"),
            ValidationRule("SEARCH_CACHE_SIZE", "range", (10, 100000), "SEARCH_CACHE_SIZE должен быть 10-100000"),
            ValidationRule("SEARCH_CACHE_TTL", "range", (60, 86400), "SEARCH_CACHE_TTL должен быть 60-86400"),
            ValidationRule("SIMILARITY_THRESHOLD", "range", (0.0, 1.0), "SIMILARITY_THRESHOLD должен быть 0.0-1.0"),
            ValidationRule("SIMILARITY_ALGORITHM", "choice", ["cosine", "euclidean", "dot_product"], 
                          "Неподдерживаемый алгоритм схожести"),
            ValidationRule("SEARCH_PARALLEL_THREADS", "range", (1, 32), "SEARCH_PARALLEL_THREADS должен быть 1-32"),
            ValidationRule("SEARCH_BATCH_PROCESSING", "type", bool, "SEARCH_BATCH_PROCESSING должно быть булевым значением"),
        ])
        
        # === API НАСТРОЙКИ ===
        rules.extend([
            ValidationRule("API_VERSION_PREFIX", "pattern", r"^/v\d+$", "API_VERSION_PREFIX должен быть в формате /vN"),
            ValidationRule("API_VERSION_HEADER", "pattern", r"^[A-Z0-9_-]+$", "API_VERSION_HEADER должно содержать только заглавные буквы, цифры, _ и -"),
            ValidationRule("REQUEST_SIZE_LIMIT_MB", "range", (1, 1000), "REQUEST_SIZE_LIMIT_MB должен быть 1-1000"),
            ValidationRule("REQUEST_TIMEOUT", "range", (10, 3600), "REQUEST_TIMEOUT должен быть 10-3600"),
            ValidationRule("DOCS_ENABLED", "type", bool, "DOCS_ENABLED должно быть булевым значением"),
            ValidationRule("WORKERS", "range", (1, 64), "WORKERS должен быть 1-64"),
        ])
        
        # === ПРОИЗВОДИТЕЛЬНОСТЬ ===
        rules.extend([
            ValidationRule("ASYNC_POOL_SIZE", "range", (1, 64), "ASYNC_POOL_SIZE должен быть 1-64"),
            ValidationRule("ASYNC_QUEUE_SIZE", "range", (10, 100000), "ASYNC_QUEUE_SIZE должен быть 10-100000"),
            ValidationRule("ASYNC_TIMEOUT", "range", (1.0, 600.0), "ASYNC_TIMEOUT должен быть 1.0-600.0"),
            ValidationRule("IO_THREAD_POOL_SIZE", "range", (1, 128), "IO_THREAD_POOL_SIZE должен быть 1-128"),
            ValidationRule("CPU_THREAD_POOL_SIZE", "range", (1, 32), "CPU_THREAD_POOL_SIZE должен быть 1-32"),
            ValidationRule("CONNECTION_POOL_SIZE", "range", (1, 200), "CONNECTION_POOL_SIZE должен быть 1-200"),
            ValidationRule("LRU_CACHE_SIZE", "range", (10, 1000000), "LRU_CACHE_SIZE должен быть 10-1000000"),
        ])
        
        # === ЛОГИРОВАНИЕ ===
        rules.extend([
            ValidationRule("LOG_LEVEL", "choice", ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], 
                          "Неподдерживаемый уровень логирования"),
            ValidationRule("LOG_FORMAT", "choice", ["json", "text", "colored"], 
                          "Неподдерживаемый формат логирования"),
            ValidationRule("LOG_FILE_MAX_SIZE_MB", "range", (1, 1000), "LOG_FILE_MAX_SIZE_MB должен быть 1-1000"),
            ValidationRule("LOG_FILE_BACKUP_COUNT", "range", (1, 100), "LOG_FILE_BACKUP_COUNT должен быть 1-100"),
            ValidationRule("LOG_BUFFER_SIZE", "range", (10, 100000), "LOG_BUFFER_SIZE должен быть 10-100000"),
            ValidationRule("LOG_FLUSH_INTERVAL", "range", (0.1, 60.0), "LOG_FLUSH_INTERVAL должен быть 0.1-60.0"),
        ])
        
        # === МОНИТОРИНГ ===
        rules.extend([
            ValidationRule("METRICS_PORT", "range", (1000, 65535), "METRICS_PORT должен быть 1000-65535"),
            ValidationRule("HEALTH_CHECK_INTERVAL", "range", (10, 3600), "HEALTH_CHECK_INTERVAL должен быть 10-3600"),
            ValidationRule("HEALTH_CHECK_TIMEOUT", "range", (1.0, 60.0), "HEALTH_CHECK_TIMEOUT должен быть 1.0-60.0"),
            ValidationRule("ALERT_CPU_THRESHOLD", "range", (10.0, 100.0), "ALERT_CPU_THRESHOLD должен быть 10.0-100.0"),
            ValidationRule("ALERT_MEMORY_THRESHOLD", "range", (10.0, 100.0), "ALERT_MEMORY_THRESHOLD должен быть 10.0-100.0"),
        ])
        
        # === БЕЗОПАСНОСТЬ (строгие правила) ===
        if self.level in [ValidationLevel.STRICT, ValidationLevel.SECURITY]:
            rules.extend([
                ValidationRule("JWT_SECRET", "security", None, "JWT_SECRET не прошел проверку безопасности", 
                              level=ValidationLevel.SECURITY),
                ValidationRule("CORS_ORIGINS", "security", None, "CORS настройки небезопасны", 
                              level=ValidationLevel.SECURITY),
                ValidationRule("DATABASE_URL", "security", None, "DATABASE_URL не прошел проверку безопасности", 
                              level=ValidationLevel.SECURITY),
            ])
        
        return rules
    
    def validate_all_settings(self, config) -> ValidationResult:
        """
        Валидация всех настроек конфигурации.
        
        Args:
            config: Объект конфигурации
            
        Returns:
            Результат валидации
        """
        result = ValidationResult(
            is_valid=True,
            errors=[],
            warnings=[],
            field_errors={},
            field_warnings={},
            statistics={}
        )
        
        # Получение всех настроек
        settings = self._extract_all_settings(config)
        
        # Применение правил валидации
        for rule in self.validation_rules:
            if self._should_apply_rule(rule, settings):
                field_result = self._validate_field(rule, settings)
                
                if field_result["errors"]:
                    result.is_valid = False
                    result.errors.extend(field_result["errors"])
                    result.field_errors[rule.field_name] = field_result["errors"]
                
                if field_result["warnings"]:
                    result.warnings.extend(field_result["warnings"])
                    result.field_warnings[rule.field_name] = field_result["warnings"]
        
        # Применение пользовательских валидаторов
        custom_result = self._apply_custom_validators(config, settings)
        if custom_result["errors"]:
            result.is_valid = False
            result.errors.extend(custom_result["errors"])
        
        if custom_result["warnings"]:
            result.warnings.extend(custom_result["warnings"])
        
        # Валидация зависимостей
        dependency_result = self._validate_dependencies(settings)
        if dependency_result["errors"]:
            result.is_valid = False
            result.errors.extend(dependency_result["errors"])
        
        if dependency_result["warnings"]:
            result.warnings.extend(dependency_result["warnings"])
        
        # Статистика
        result.statistics = {
            "total_fields": len(settings),
            "validated_fields": len([r for r in self.validation_rules if self._should_apply_rule(r, settings)]),
            "error_fields": len(result.field_errors),
            "warning_fields": len(result.field_warnings),
            "custom_validators": len(self.custom_validators)
        }
        
        return result
    
    def _extract_all_settings(self, config) -> Dict[str, Any]:
        """Извлечение всех настроек из конфигурации."""
        settings = {}
        
        # Извлечение из различных секций конфигурации
        config_sections = [
            ('security', getattr(config, 'security', None)),
            ('memory', getattr(config, 'memory', None)),
            ('search', getattr(config, 'search', None)),
            ('api', getattr(config, 'api', None)),
            ('performance', getattr(config, 'performance', None)),
            ('logging', getattr(config, 'logging', None)),
            ('monitoring', getattr(config, 'monitoring', None)),
            ('database', getattr(config, 'database', None)),
        ]
        
        for section_name, section in config_sections:
            if section:
                for attr_name in dir(section):
                    if not attr_name.startswith('_'):
                        value = getattr(section, attr_name)
                        if not callable(value):
                            env_name = self._attr_to_env_name(section_name, attr_name)
                            settings[env_name] = value
        
        # Добавление глобальных настроек
        global_attrs = ['DEBUG', 'ENVIRONMENT_PROFILE', 'APP_NAME', 'APP_VERSION']
        for attr_name in global_attrs:
            if hasattr(config, attr_name):
                settings[attr_name] = getattr(config, attr_name)
        
        return settings
    
    def _attr_to_env_name(self, section: str, attr: str) -> str:
        """Преобразование имени атрибута в имя переменной окружения."""
        return f"{section.upper()}_{attr.upper()}"
    
    def _should_apply_rule(self, rule: ValidationRule, settings: Dict[str, Any]) -> bool:
        """Проверка применимости правила."""
        # Проверка наличия поля
        if rule.field_name not in settings:
            return False
        
        # Проверка уровня валидации
        rule_level_hierarchy = {
            ValidationLevel.RELAXED: 1,
            ValidationLevel.STANDARD: 2,
            ValidationLevel.STRICT: 3,
            ValidationLevel.SECURITY: 4
        }
        
        current_level_hierarchy = rule_level_hierarchy[self.level]
        rule_level_hierarchy_val = rule_level_hierarchy[rule.level]
        
        return rule_level_hierarchy_val <= current_level_hierarchy
    
    def _validate_field(self, rule: ValidationRule, settings: Dict[str, Any]) -> Dict[str, List[str]]:
        """Валидация одного поля."""
        errors = []
        warnings = []
        value = settings.get(rule.field_name)
        
        try:
            if rule.validation_type == "type":
                if not isinstance(value, rule.constraint):
                    errors.append(f"{rule.field_name}: {rule.error_message}")
            
            elif rule.validation_type == "range":
                min_val, max_val = rule.constraint
                if not (min_val <= value <= max_val):
                    errors.append(f"{rule.field_name}: {rule.error_message}")
            
            elif rule.validation_type == "choice":
                if value not in rule.constraint:
                    errors.append(f"{rule.field_name}: {rule.error_message}")
            
            elif rule.validation_type == "pattern":
                if not re.match(rule.constraint, str(value)):
                    errors.append(f"{rule.field_name}: {rule.error_message}")
            
            elif rule.validation_type == "custom":
                validation_func = getattr(self, f"_validate_{rule.field_name.lower()}", None)
                if validation_func:
                    result = validation_func(value)
                    if isinstance(result, dict):
                        if result.get("errors"):
                            errors.extend(result["errors"])
                        if result.get("warnings"):
                            warnings.extend(result["warnings"])
                    elif isinstance(result, str):
                        errors.append(f"{rule.field_name}: {result}")
                    elif not result:
                        errors.append(f"{rule.field_name}: {rule.error_message}")
            
            elif rule.validation_type == "security":
                security_result = self._validate_security_field(rule.field_name, value)
                if security_result["errors"]:
                    errors.extend(security_result["errors"])
                if security_result["warnings"]:
                    warnings.extend(security_result["warnings"])
            
            else:
                errors.append(f"{rule.field_name}: Неизвестный тип валидации {rule.validation_type}")
        
        except Exception as e:
            errors.append(f"{rule.field_name}: Ошибка валидации: {str(e)}")
        
        return {"errors": errors, "warnings": warnings}
    
    def _apply_custom_validators(self, config, settings: Dict[str, Any]) -> Dict[str, List[str]]:
        """Применение пользовательских валидаторов."""
        errors = []
        warnings = []
        
        for validator_name, validator_func in self.custom_validators.items():
            try:
                result = validator_func(config, settings)
                if isinstance(result, dict):
                    if result.get("errors"):
                        errors.extend(result["errors"])
                    if result.get("warnings"):
                        warnings.extend(result["warnings"])
            except Exception as e:
                errors.append(f"Ошибка в пользовательском валидаторе {validator_name}: {str(e)}")
        
        return {"errors": errors, "warnings": warnings}
    
    def _validate_dependencies(self, settings: Dict[str, Any]) -> Dict[str, List[str]]:
        """Валидация зависимостей между полями."""
        errors = []
        warnings = []
        
        # CORS и безопасность
        if settings.get("CORS_ORIGINS") == ["*"] and settings.get("SECURITY_HEADERS_ENABLED", False):
            warnings.append("CORS настройки конфликтуют с security headers")
        
        # JWT настройки
        if settings.get("JWT_ALGORITHM", "").startswith("RS") and not settings.get("JWT_SECRET"):
            errors.append("Для RS алгоритмов JWT требуется приватный ключ в JWT_SECRET")
        
        # Мониторинг
        if settings.get("METRICS_ENABLED") and not settings.get("OTEL_ENABLED"):
            warnings.append("Рекомендуется включить OTEL_ENABLED вместе с METRICS_ENABLED")
        
        # Производительность
        if settings.get("ASYNC_POOL_SIZE", 1) > os.cpu_count():
            warnings.append("ASYNC_POOL_SIZE превышает количество CPU ядер")
        
        # Память
        if settings.get("MEMORY_COMPRESSION") and not settings.get("MEMORY_ASYNC"):
            warnings.append("Сжатие памяти рекомендуется использовать с асинхронной памятью")
        
        return {"errors": errors, "warnings": warnings}
    
    def add_custom_validator(self, name: str, validator_func: callable) -> None:
        """Добавление пользовательского валидатора."""
        self.custom_validators[name] = validator_func
    
    def get_validation_report(self, result: ValidationResult) -> str:
        """Получение отчета о валидации."""
        report = []
        report.append("=" * 60)
        report.append("ОТЧЕТ ВАЛИДАЦИИ КОНФИГУРАЦИИ")
        report.append("=" * 60)
        report.append(f"Статус: {'✅ ВАЛИДНО' if result.is_valid else '❌ ЕСТЬ ОШИБКИ'}")
        report.append(f"Уровень валидации: {self.level.value}")
        report.append("")
        
        # Статистика
        stats = result.statistics
        report.append("СТАТИСТИКА:")
        report.append(f"  Всего полей: {stats['total_fields']}")
        report.append(f"  Проверено полей: {stats['validated_fields']}")
        report.append(f"  Полей с ошибками: {stats['error_fields']}")
        report.append(f"  Полей с предупреждениями: {stats['warning_fields']}")
        report.append("")
        
        # Ошибки
        if result.errors:
            report.append(f"ОШИБКИ ({len(result.errors)}):")
            for i, error in enumerate(result.errors, 1):
                report.append(f"  {i}. {error}")
            report.append("")
        
        # Предупреждения
        if result.warnings:
            report.append(f"ПРЕДУПРЕЖДЕНИЯ ({len(result.warnings)}):")
            for i, warning in enumerate(result.warnings, 1):
                report.append(f"  {i}. {warning}")
            report.append("")
        
        # Детализация по полям
        if result.field_errors:
            report.append("ОШИБКИ ПО ПОЛЯМ:")
            for field, errors in result.field_errors.items():
                report.append(f"  {field}:")
                for error in errors:
                    report.append(f"    - {error}")
            report.append("")
        
        report.append("=" * 60)
        
        return "\n".join(report)
    
    # === СПЕЦИАЛИЗИРОВАННЫЕ ВАЛИДАТОРЫ ===
    
    def _validate_host(self, value: str) -> bool:
        """Валидация хоста."""
        try:
            # Проверка IPv4, IPv6 или доменного имени
            ipaddress.ip_address(value)
            return True
        except ValueError:
            # Проверка доменного имени
            domain_pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
            return re.match(domain_pattern, value) is not None
    
    def _validate_cors_origins(self, value: Union[str, List[str]]) -> bool:
        """Валидация CORS источников."""
        if isinstance(value, str):
            origins = [origin.strip() for origin in value.split(",")]
        else:
            origins = value
        
        for origin in origins:
            if origin == "*":
                # Предупреждение о небезопасном wildcard
                continue
            
            try:
                # Проверка URL или домена
                if "://" in origin:
                    parsed = urlparse(origin)
                    if not parsed.scheme or not parsed.netloc:
                        return False
                else:
                    # Проверка доменного имени
                    if not self._validate_host(origin):
                        return False
            except Exception:
                return False
        
        return True
    
    def _validate_jwt_secret(self, value: str) -> bool:
        """Валидация JWT секрета."""
        if not value or len(value) < 32:
            return False
        
        # Проверка на слабые секреты
        weak_patterns = [
            r'^[a-zA-Z]+$',  # Только буквы
            r'^[0-9]+$',     # Только цифры
            r'^(.)\1{10,}$', # Повторяющийся символ
        ]
        
        for pattern in weak_patterns:
            if re.match(pattern, value):
                return False
        
        return True
    
    def _validate_csp(self, value: str) -> bool:
        """Валидация Content Security Policy."""
        # Базовая проверка на опасные директивы
        dangerous = ["javascript:", "data:", "vbscript:"]
        return not any(dangerous in value for dangerous in dangerous)
    
    def _validate_path(self, value: str) -> bool:
        """Валидация пути."""
        if not value:
            return False
        
        # Проверка на недопустимые символы
        invalid_chars = ["<", ">", ":", '"', "|", "?", "*"]
        return not any(char in value for char in invalid_chars)
    
    def _validate_http_methods(self, methods: List[str]) -> bool:
        """Валидация HTTP методов."""
        valid_methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS", "TRACE"]
        return all(method.upper() in valid_methods for method in methods)
    
    def _validate_http_headers(self, headers: List[str]) -> bool:
        """Валидация HTTP заголовков."""
        # Базовая проверка на допустимые символы в заголовках
        pattern = r'^[a-zA-Z0-9][a-zA-Z0-9\-]*$'
        return all(re.match(pattern, header) for header in headers)
    
    def _validate_security_field(self, field_name: str, value: Any) -> Dict[str, List[str]]:
        """Специальная проверка безопасности."""
        errors = []
        warnings = []
        
        if field_name == "CORS_ORIGINS":
            if value == ["*"]:
                warnings.append("Использование wildcard (*) в CORS небезопасно для продакшена")
        
        elif field_name == "DATABASE_URL":
            if isinstance(value, str):
                if "password=" in value and not value.startswith("postgresql"):
                    warnings.append("Пароль в DATABASE_URL должен быть в безопасном формате")
        
        elif field_name == "JWT_SECRET":
            if len(str(value)) < 32:
                errors.append("JWT_SECRET слишком короткий (минимум 32 символа)")
        
        return {"errors": errors, "warnings": warnings}