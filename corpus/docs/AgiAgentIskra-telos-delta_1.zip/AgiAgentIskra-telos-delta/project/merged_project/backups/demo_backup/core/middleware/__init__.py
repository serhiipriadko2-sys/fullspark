"""Пакет middleware для Web API.

Обеспечивает автоматическую обработку исключений на уровне FastAPI middleware.

Автор: Iskra Integration Team
Версия: 1.0
"""

from .error_middleware import (
    # Request Context
    RequestContext,
    
    # Middleware Classes
    ErrorHandlingMiddleware,
    PerformanceMonitoringMiddleware,
    AuthenticationMiddleware,
    AuditLoggingMiddleware,
    SecurityHeadersMiddleware,
    
    # Combined Stack
    IskraMiddlewareStack,
    
    # FastAPI Integration
    setup_middleware_stack,
    
    # Context Manager
    request_lifecycle_context,
)

__all__ = [
    # Request Context
    "RequestContext",
    
    # Middleware Classes
    "ErrorHandlingMiddleware",
    "PerformanceMonitoringMiddleware",
    "AuthenticationMiddleware",
    "AuditLoggingMiddleware", 
    "SecurityHeadersMiddleware",
    
    # Combined Stack
    "IskraMiddlewareStack",
    
    # FastAPI Integration
    "setup_middleware_stack",
    
    # Context Manager
    "request_lifecycle_context",
]