"""Middleware для обработки ошибок в Web API.

Обеспечивает автоматическую обработку исключений на уровне FastAPI middleware.
Интегрируется с системой обработки ошибок и логирования.

Версия: 1.0
Автор: Iskra Integration Team
"""

from typing import Callable, Dict, Any, Optional
import time
import uuid
import asyncio
from contextlib import asynccontextmanager

from fastapi import Request, Response, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
import logging

from ..handlers.error_handlers import ErrorHandlerManager
from ..logging.logging_system import CentralizedLogger, LogContext, log_request


# ================================
# Request Context Manager
# ================================

class RequestContext:
    """Управляет контекстом запроса для логирования и трассировки."""
    
    def __init__(self, request: Request):
        self.request = request
        self.request_id = str(uuid.uuid4())
        self.start_time = time.time()
        self.user_id = None
        self.correlation_id = request.headers.get("X-Correlation-ID", self.request_id)
        
        # Извлекаем информацию из заголовков
        self.user_agent = request.headers.get("User-Agent", "")
        self.ip_address = self._get_client_ip(request)
        
        # Создаем контекст для логирования
        self.log_context = LogContext(
            request_id=self.request_id,
            user_id=self.user_id,
            session_id=request.headers.get("X-Session-ID"),
            endpoint=str(request.url.path),
            method=request.method,
            user_agent=self.user_agent,
            ip_address=self.ip_address,
            correlation_id=self.correlation_id
        )
    
    def _get_client_ip(self, request: Request) -> str:
        """Извлекает IP адрес клиента."""
        # Проверяем различные заголовки для прокси
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def get_duration(self) -> float:
        """Возвращает время выполнения запроса."""
        return time.time() - self.start_time
    
    def update_user_info(self, user_id: Optional[str] = None, session_id: Optional[str] = None):
        """Обновляет информацию о пользователе."""
        if user_id:
            self.user_id = user_id
            self.log_context.user_id = user_id
        
        if session_id:
            self.log_context.session_id = session_id


# ================================
# Error Handling Middleware
# ================================

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware для автоматической обработки ошибок."""
    
    def __init__(
        self,
        app: ASGIApp,
        error_handler_manager: ErrorHandlerManager,
        logger: CentralizedLogger,
        enable_performance_logging: bool = True,
        enable_audit_logging: bool = True
    ):
        super().__init__(app)
        self.error_handler_manager = error_handler_manager
        self.logger = logger
        self.enable_performance_logging = enable_performance_logging
        self.enable_audit_logging = enable_audit_logging
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Обрабатывает запрос с автоматической обработкой ошибок."""
        # Создаем контекст запроса
        request_context = RequestContext(request)
        
        # Устанавливаем контекст для логирования
        from ..logging.logging_system import LoggerFactory
        LoggerFactory.set_context(request_context.log_context)
        
        try:
            # Выполняем запрос
            response = await call_next(request)
            
            # Логируем успешный запрос
            if self.enable_performance_logging:
                duration = request_context.get_duration()
                log_request(
                    self.logger,
                    request.method,
                    str(request.url.path),
                    response.status_code,
                    duration,
                    request_context.request_id,
                    request_context.user_id
                )
            
            # Добавляем заголовки ответа
            response.headers["X-Request-ID"] = request_context.request_id
            response.headers["X-Correlation-ID"] = request_context.correlation_id
            response.headers["X-Response-Time"] = f"{request_context.get_duration():.3f}s"
            
            return response
        
        except Exception as exc:
            # Обрабатываем исключение
            try:
                response = await self.error_handler_manager.handle_error(request, exc)
                
                # Логируем ошибку
                duration = request_context.get_duration()
                log_request(
                    self.logger,
                    request.method,
                    str(request.url.path),
                    response.status_code,
                    duration,
                    request_context.request_id,
                    request_context.user_id
                )
                
                # Логируем исключение через систему логирования
                self.logger.log_exception(
                    exc,
                    level="ERROR",
                    context=request_context.log_context.__dict__
                )
                
                # Добавляем заголовки ошибки
                response.headers["X-Request-ID"] = request_context.request_id
                response.headers["X-Correlation-ID"] = request_context.correlation_id
                response.headers["X-Response-Time"] = f"{duration:.3f}s"
                
                return response
            
            except Exception as inner_exc:
                # Критическая ошибка - логируем и возвращаем 500
                self.logger.log_exception(
                    inner_exc,
                    level="CRITICAL",
                    context=request_context.log_context.__dict__
                )
                
                # Возвращаем стандартную ошибку сервера
                error_response = JSONResponse(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    content={
                        "error": "Внутренняя ошибка сервера",
                        "error_code": "INTERNAL_ERROR_001",
                        "request_id": request_context.request_id
                    }
                )
                
                error_response.headers["X-Request-ID"] = request_context.request_id
                error_response.headers["X-Correlation-ID"] = request_context.correlation_id
                error_response.headers["X-Response-Time"] = f"{request_context.get_duration():.3f}s"
                
                return error_response


# ================================
# Performance Monitoring Middleware
# ================================

class PerformanceMonitoringMiddleware(BaseHTTPMiddleware):
    """Middleware для мониторинга производительности."""
    
    def __init__(
        self,
        app: ASGIApp,
        logger: CentralizedLogger,
        slow_request_threshold: float = 1.0,  # секунды
        enable_detailed_metrics: bool = True
    ):
        super().__init__(app)
        self.logger = logger
        self.slow_request_threshold = slow_request_threshold
        self.enable_detailed_metrics = enable_detailed_metrics
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Мониторит производительность запроса."""
        start_time = time.time()
        
        # Добавляем request_id если его нет
        if "X-Request-ID" not in request.headers:
            request.headers["X-Request-ID"] = str(uuid.uuid4())
        
        try:
            response = await call_next(request)
            
            # Подсчитываем время выполнения
            duration = time.time() - start_time
            
            # Логируем медленные запросы
            if duration > self.slow_request_threshold:
                self.logger.log_error_with_context(
                    f"Slow request detected: {request.method} {request.url.path} took {duration:.3f}s",
                    context={
                        "method": request.method,
                        "path": request.url.path,
                        "duration": duration,
                        "threshold": self.slow_request_threshold,
                        "status_code": response.status_code
                    },
                    level="WARNING"
                )
            
            # Детальные метрики
            if self.enable_detailed_metrics:
                metrics = {
                    "method": request.method,
                    "path": request.url.path,
                    "duration_ms": duration * 1000,
                    "status_code": response.status_code,
                    "query_params": dict(request.query_params) if request.query_params else {},
                    "headers_size": len(str(request.headers)),
                }
                
                self.logger.log_performance("http_request_detailed", duration, metrics)
            
            return response
        
        except Exception as exc:
            duration = time.time() - start_time
            
            # Логируем исключение с метриками
            self.logger.log_exception(
                exc,
                context={
                    "method": request.method,
                    "path": request.url.path,
                    "duration": duration
                }
            )
            
            raise


# ================================
# Authentication Middleware
# ================================

class AuthenticationMiddleware(BaseHTTPMiddleware):
    """Middleware для аутентификации и обновления контекста пользователя."""
    
    def __init__(
        self,
        app: ASGIApp,
        auth_service: Optional[Callable] = None,
        public_paths: Optional[list] = None
    ):
        super().__init__(app)
        self.auth_service = auth_service
        self.public_paths = public_paths or [
            "/docs",
            "/redoc",
            "/openapi.json",
            "/health",
            "/ping"
        ]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Обрабатывает аутентификацию."""
        # Проверяем, является ли путь публичным
        if request.url.path in self.public_paths:
            return await call_next(request)
        
        # Извлекаем токен из заголовка Authorization
        auth_header = request.headers.get("Authorization")
        user_id = None
        session_id = None
        
        if auth_header and auth_header.startswith("Bearer "):
            token = auth_header.split(" ")[1]
            
            if self.auth_service:
                try:
                    # Проверяем токен через сервис аутентификации
                    user_info = await self.auth_service.validate_token(token)
                    user_id = user_info.get("user_id")
                    session_id = user_info.get("session_id")
                except Exception as exc:
                    # Логируем ошибку аутентификации
                    logging.getLogger(__name__).warning(
                        f"Authentication failed for token ending with {token[-10:]}",
                        exc_info=exc
                    )
        
        # Обновляем контекст пользователя
        from ..logging.logging_system import LoggerFactory
        current_context = LoggerFactory._context
        if current_context:
            current_context.user_id = user_id
            current_context.session_id = session_id
        
        return await call_next(request)


# ================================
# Audit Logging Middleware
# ================================

class AuditLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware для аудита действий пользователей."""
    
    def __init__(
        self,
        app: ASGIApp,
        logger: CentralizedLogger,
        audit_paths: Optional[list] = None,
        audit_methods: Optional[list] = None
    ):
        super().__init__(app)
        self.logger = logger
        self.audit_paths = audit_paths or [
            "/api/users",
            "/api/admin",
            "/api/settings",
            "/api/data"
        ]
        self.audit_methods = audit_methods or ["POST", "PUT", "DELETE", "PATCH"]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Логирует аудит действия."""
        # Проверяем, нужно ли логировать данный запрос
        should_audit = (
            any(request.url.path.startswith(path) for path in self.audit_paths) and
            request.method in self.audit_methods
        )
        
        request_context = RequestContext(request)
        original_response = None
        
        try:
            response = await call_next(request)
            
            if should_audit:
                # Логируем аудит действие
                self.logger.log_audit(
                    action=f"{request.method} {request.url.path}",
                    user_id=request_context.user_id,
                    resource=request.url.path,
                    result="success" if 200 <= response.status_code < 300 else "failed",
                    context={
                        "status_code": response.status_code,
                        "request_id": request_context.request_id,
                        "user_agent": request_context.user_agent,
                        "ip_address": request_context.ip_address
                    }
                )
            
            return response
        
        except Exception as exc:
            if should_audit:
                # Логируем неудачный аудит
                self.logger.log_audit(
                    action=f"{request.method} {request.url.path}",
                    user_id=request_context.user_id,
                    resource=request.url.path,
                    result="error",
                    context={
                        "error": str(exc),
                        "error_type": type(exc).__name__,
                        "request_id": request_context.request_id
                    }
                )
            
            raise


# ================================
# Security Headers Middleware
# ================================

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware для добавления security headers."""
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        self.security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Content-Security-Policy": "default-src 'self'",
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Добавляет security headers."""
        response = await call_next(request)
        
        # Добавляем headers к ответу
        for header, value in self.security_headers.items():
            response.headers[header] = value
        
        # Удаляем информационные headers, которые могут быть использованы для атак
        response.headers.pop("Server", None)
        response.headers.pop("X-Powered-By", None)
        
        return response


# ================================
# Combined Middleware Stack
# ================================

class IskraMiddlewareStack:
    """Комбинированный стек middleware для Iskra приложения."""
    
    def __init__(
        self,
        app: ASGIApp,
        error_handler_manager: ErrorHandlerManager,
        logger: CentralizedLogger,
        auth_service: Optional[Callable] = None
    ):
        self.app = app
        self.error_handler_manager = error_handler_manager
        self.logger = logger
        self.auth_service = auth_service
        self._middleware_stack = None
    
    def build_stack(self) -> ASGIApp:
        """Строит стек middleware."""
        current_app = self.app
        
        # Последовательность middleware (важен порядок!)
        
        # 1. Security headers (первым для безопасности)
        current_app = SecurityHeadersMiddleware(current_app)
        
        # 2. Performance monitoring
        current_app = PerformanceMonitoringMiddleware(
            current_app,
            self.logger,
            slow_request_threshold=2.0,
            enable_detailed_metrics=True
        )
        
        # 3. Authentication
        if self.auth_service:
            current_app = AuthenticationMiddleware(
                current_app,
                self.auth_service,
                public_paths=["/docs", "/redoc", "/openapi.json", "/health", "/ping"]
            )
        
        # 4. Error handling (должен быть последним для корректной обработки)
        current_app = ErrorHandlingMiddleware(
            current_app,
            self.error_handler_manager,
            self.logger,
            enable_performance_logging=True,
            enable_audit_logging=True
        )
        
        self._middleware_stack = current_app
        return current_app
    
    def add_audit_logging(self, audit_paths: Optional[list] = None):
        """Добавляет аудит логирование в стек."""
        if self._middleware_stack:
            # Добавляем перед error handling middleware
            self._middleware_stack = AuditLoggingMiddleware(
                self._middleware_stack,
                self.logger,
                audit_paths=audit_paths
            )
    
    def get_app(self) -> ASGIApp:
        """Возвращает готовое приложение со всеми middleware."""
        if not self._middleware_stack:
            self.build_stack()
        return self._middleware_stack


# ================================
# FastAPI Integration
# ================================

def setup_middleware_stack(
    app,
    error_handler_manager: ErrorHandlerManager,
    logger: CentralizedLogger,
    auth_service: Optional[Callable] = None,
    enable_audit: bool = True
) -> IskraMiddlewareStack:
    """Настраивает стек middleware для FastAPI приложения."""
    middleware_stack = IskraMiddlewareStack(
        app,
        error_handler_manager,
        logger,
        auth_service
    )
    
    app = middleware_stack.build_stack()
    
    if enable_audit:
        middleware_stack.add_audit_logging([
            "/api/users",
            "/api/admin", 
            "/api/settings",
            "/api/data"
        ])
    
    return middleware_stack


# ================================
# Context Manager for Request Lifecycle
# ================================

@asynccontextmanager
async def request_lifecycle_context(
    request: Request,
    logger: CentralizedLogger,
    operation_name: str
):
    """Контекстный менеджер для жизненного цикла запроса."""
    context = RequestContext(request)
    
    # Устанавливаем контекст
    from ..logging.logging_system import LoggerFactory
    LoggerFactory.set_context(context.log_context)
    
    # Получаем логгер для операции
    operation_logger = logger.getChild(operation_name)
    
    try:
        operation_logger.log_error_with_context(
            f"Starting {operation_name}",
            context=context.log_context.__dict__,
            level="INFO"
        )
        
        yield context
    
    except Exception as exc:
        operation_logger.log_exception(
            exc,
            context=context.log_context.__dict__
        )
        raise
    
    finally:
        duration = context.get_duration()
        operation_logger.log_performance(
            operation_name,
            duration,
            context.log_context.__dict__
        )