#!/usr/bin/env python3
"""
Скрипт для запуска интегрированной архитектуры проекта Искра.

Автоматически настраивает окружение и запускает сервер.
"""

import os
import sys
import subprocess
from pathlib import Path

def setup_environment():
    """Настройка окружения для запуска."""
    print("🔧 Настройка окружения...")
    
    # Создаем необходимые директории
    directories = [
        "memory",
        "logs", 
        "manifest",
        "docs/CANON"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"  ✓ Создана директория: {directory}")
    
    # Проверяем наличие .env файла
    if not Path(".env").exists():
        if Path(".env.example").exists():
            import shutil
            shutil.copy(".env.example", ".env")
            print("  ✓ Создан .env файл из .env.example")
        else:
            print("  ⚠️  .env файл не найден, создайте его вручную")
    
    # Проверяем зависимости
    print("\n📦 Проверка зависимостей...")
    try:
        import fastapi
        print(f"  ✓ FastAPI: {fastapi.__version__}")
    except ImportError:
        print("  ❌ FastAPI не установлен. Выполните: pip install -r requirements.txt")
        return False
    
    try:
        import uvicorn
        print(f"  ✓ Uvicorn установлен")
    except ImportError:
        print("  ❌ Uvicorn не установлен. Выполните: pip install -r requirements.txt")
        return False
    
    return True

def run_tests():
    """Запуск тестов для проверки работоспособности."""
    print("\n🧪 Запуск базовых тестов...")
    
    try:
        # Создаем простой тест
        test_code = '''
import sys
sys.path.append(".")
try:
    from main import app
    print("✓ Основное приложение импортируется")
except Exception as e:
    print(f"❌ Ошибка импорта: {e}")
    sys.exit(1)

try:
    from core.config import settings
    print("✓ Конфигурация загружается")
except Exception as e:
    print(f"❌ Ошибка конфигурации: {e}")
    sys.exit(1)

try:
    from core.exceptions import IskraException
    print("✓ Исключения настроены")
except Exception as e:
    print(f"❌ Ошибка исключений: {e}")
    sys.exit(1)

try:
    from services.dependency_injection import get_container
    container = get_container()
    print("✓ DI контейнер инициализирован")
except Exception as e:
    print(f"❌ Ошибка DI: {e}")
    sys.exit(1)

print("✅ Все базовые компоненты работают!")
'''
        
        exec(test_code)
        return True
        
    except Exception as e:
        print(f"❌ Тесты не пройдены: {e}")
        return False

def start_server(debug=False, host="0.0.0.0", port=8000):
    """Запуск сервера."""
    print(f"\n🚀 Запуск сервера...")
    print(f"   Режим: {'Debug' if debug else 'Production'}")
    print(f"   Host: {host}")
    print(f"   Port: {port}")
    print(f"   Docs: http://{host}:{port}/docs")
    print(f"   Health: http://{host}:{port}/healthz")
    
    cmd = [
        sys.executable, "-m", "uvicorn",
        "main:app",
        "--host", host,
        "--port", str(port),
        "--reload" if debug else "",
        "--log-level", "debug" if debug else "info"
    ]
    
    # Убираем пустые аргументы
    cmd = [arg for arg in cmd if arg]
    
    print(f"\n📡 Выполняется: {' '.join(cmd)}")
    print("\n" + "="*60)
    
    try:
        subprocess.run(cmd)
    except KeyboardInterrupt:
        print("\n\n👋 Сервер остановлен")
    except Exception as e:
        print(f"\n❌ Ошибка запуска: {e}")

def main():
    """Главная функция."""
    print("="*60)
    print("🧩  ИНТЕГРИРОВАННАЯ АРХИТЕКТУРА ПРОЕКТА ИСКРА v1.0")
    print("="*60)
    print()
    print("Объединяет функциональность Version 1 с архитектурными")
    print("улучшениями Version 2 при 100% backward compatibility")
    print()
    
    # Парсим аргументы командной строки
    debug = "--debug" in sys.argv or "-d" in sys.argv
    host = "0.0.0.0"
    port = 8000
    
    # Извлекаем хост и порт из аргументов
    if "--host" in sys.argv:
        host_idx = sys.argv.index("--host")
        if host_idx + 1 < len(sys.argv):
            host = sys.argv[host_idx + 1]
    
    if "--port" in sys.argv:
        port_idx = sys.argv.index("--port")
        if port_idx + 1 < len(sys.argv):
            try:
                port = int(sys.argv[port_idx + 1])
            except ValueError:
                print("❌ Неверный порт, используется по умолчанию: 8000")
    
    # Настройка окружения
    if not setup_environment():
        sys.exit(1)
    
    # Запуск тестов
    if "--no-test" not in sys.argv:
        if not run_tests():
            print("\n⚠️  Тесты не пройдены, но продолжаем запуск...")
    
    # Запуск сервера
    start_server(debug=debug, host=host, port=port)

if __name__ == "__main__":
    main()