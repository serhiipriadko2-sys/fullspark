"""Конфигурация производительности для интегрированной поисковой системы.

Определяет режимы работы, параметры производительности и настройки
для различных сценариев использования поиска.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, Optional
import os

logger = logging.getLogger(__name__)

class SearchMode(Enum):
    """Режимы работы поисковой системы."""
    LEGACY = "legacy"           # Version 1 с GraphRAG (O(n))
    MODERN = "modern"          # Version 2 оптимизированный (O(log n))
    HYBRID = "hybrid"          # Автоматический выбор алгоритма
    GRAPHRAG = "graphrag"      # Усиленный GraphRAG режим

class PerformanceProfile(Enum):
    """Профили производительности для разных сценариев."""
    FASTEST = "fastest"        # Максимальная скорость
    BALANCED = "balanced"      # Баланс скорости и качества
    QUALITY = "quality"        # Максимальное качество
    GRAPHRAG_FOCUS = "graphrag_focus"  # Фокус на GraphRAG

@dataclass
class LegacySearchParams:
    """Параметры для legacy поиска Version 1."""
    k: int = 5
    use_graph: bool = True
    use_vector: bool = True
    graph_weight: float = 0.4
    vector_weight: float = 0.6
    evidence_path: str = "memory/evidence.jsonl"
    enable_enhanced_scoring: bool = True
    max_concurrent_graph_operations: int = 3

@dataclass
class ModernSearchParams:
    """Параметры для modern поиска Version 2."""
    cache_size: int = 1000
    max_workers: int = 4
    enable_indexing: bool = True
    index_batch_size: int = 100
    evidence_path: str = "memory/evidence.jsonl"
    async_operations: bool = True
    performance_monitoring: bool = True
    index_optimization_level: int = 1  # 0-3, где 3 - максимальная оптимизация

@dataclass
class PerformanceConfig:
    """Основная конфигурация производительности поисковой системы."""
    
    # Режим поиска по умолчанию
    default_mode: SearchMode = SearchMode.HYBRID
    
    # Базовые параметры
    default_k: int = 5
    evidence_path: str = "memory/evidence.jsonl"
    max_workers: int = 4
    cache_size: int = 500
    
    # Веса для гибридного поиска
    legacy_weight: float = 0.6
    modern_weight: float = 0.4
    
    # Параметры кэширования
    enable_result_cache: bool = True
    cache_ttl_seconds: int = 300  # 5 минут
    metrics_history_size: int = 100
    
    # Настройки производительности
    performance_profile: PerformanceProfile = PerformanceProfile.BALANCED
    enable_async_operations: bool = True
    max_concurrent_searches: int = 10
    search_timeout_seconds: float = 30.0
    
    # Автоматическая оптимизация
    auto_performance_tuning: bool = True
    performance_monitoring_interval: int = 60  # секунд
    
    # Параметры legacy поиска
    legacy_config: LegacySearchParams = field(default_factory=LegacySearchParams)
    
    # Параметры modern поиска
    modern_config: ModernSearchParams = field(default_factory=ModernSearchParams)
    
    # Дополнительные настройки
    debug_mode: bool = False
    log_search_metrics: bool = True
    enable_performance_profiling: bool = False
    
    def __post_init__(self):
        """Валидация и инициализация после создания."""
        self._apply_performance_profile()
        self._validate_configuration()
    
    def _apply_performance_profile(self):
        """Применение настроек профиля производительности."""
        profile_settings = {
            PerformanceProfile.FASTEST: {
                'default_mode': SearchMode.MODERN,
                'legacy_config': LegacySearchParams(
                    k=3,
                    use_graph=False,  # Отключаем GraphRAG для скорости
                    enable_enhanced_scoring=False
                ),
                'modern_config': ModernSearchParams(
                    cache_size=2000,
                    index_optimization_level=3,
                    performance_monitoring=False
                ),
                'cache_size': 1000,
                'max_concurrent_searches': 20
            },
            
            PerformanceProfile.BALANCED: {
                'default_mode': SearchMode.HYBRID,
                'legacy_config': LegacySearchParams(
                    k=5,
                    use_graph=True,
                    enable_enhanced_scoring=True
                ),
                'modern_config': ModernSearchParams(
                    cache_size=1000,
                    index_optimization_level=2,
                    performance_monitoring=True
                ),
                'cache_size': 500,
                'max_concurrent_searches': 10
            },
            
            PerformanceProfile.QUALITY: {
                'default_mode': SearchMode.GRAPHRAG,
                'legacy_config': LegacySearchParams(
                    k=10,
                    use_graph=True,
                    use_vector=True,
                    enable_enhanced_scoring=True,
                    graph_weight=0.6,
                    vector_weight=0.4
                ),
                'modern_config': ModernSearchParams(
                    cache_size=500,
                    index_optimization_level=1,
                    performance_monitoring=True
                ),
                'cache_size': 200,
                'max_concurrent_searches': 5
            },
            
            PerformanceProfile.GRAPHRAG_FOCUS: {
                'default_mode': SearchMode.GRAPHRAG,
                'legacy_config': LegacySearchParams(
                    k=8,
                    use_graph=True,
                    use_vector=True,
                    graph_weight=0.7,
                    vector_weight=0.3,
                    max_concurrent_graph_operations=2
                ),
                'modern_config': ModernSearchParams(
                    cache_size=300,
                    index_optimization_level=0,
                    performance_monitoring=True
                ),
                'cache_size': 100,
                'max_concurrent_searches': 3
            }
        }
        
        if self.performance_profile in profile_settings:
            profile_config = profile_settings[self.performance_profile]
            for key, value in profile_config.items():
                if hasattr(self, key):
                    setattr(self, key, value)
            
            logger.info(f"Применен профиль производительности: {self.performance_profile.value}")
    
    def _validate_configuration(self):
        """Валидация конфигурации."""
        # Проверка весов для гибридного поиска
        if not (0 <= self.legacy_weight <= 1 and 0 <= self.modern_weight <= 1):
            raise ValueError("Веса legacy и modern должны быть в диапазоне [0, 1]")
        
        if abs(self.legacy_weight + self.modern_weight - 1.0) > 0.01:
            logger.warning(f"Сумма весов ({self.legacy_weight + self.modern_weight}) не равна 1.0")
        
        # Проверка путей
        if not self.evidence_path:
            raise ValueError("Путь к evidence файлу не может быть пустым")
        
        # Проверка кэша
        if self.cache_size <= 0:
            raise ValueError("Размер кэша должен быть положительным числом")
        
        logger.debug("Конфигурация валидирована успешно")
    
    @classmethod
    def from_environment(cls) -> PerformanceConfig:
        """Создание конфигурации из переменных окружения."""
        config = cls()
        
        # Загрузка из окружения
        env_mappings = {
            'SEARCH_DEFAULT_MODE': lambda x: SearchMode(x.lower()),
            'SEARCH_DEFAULT_K': int,
            'SEARCH_CACHE_SIZE': int,
            'SEARCH_MAX_WORKERS': int,
            'SEARCH_EVIDENCE_PATH': str,
            'SEARCH_DEBUG_MODE': lambda x: x.lower() in ('true', '1', 'yes'),
            'SEARCH_LOG_METRICS': lambda x: x.lower() in ('true', '1', 'yes'),
        }
        
        for env_var, converter in env_mappings.items():
            value = os.getenv(env_var)
            if value is not None:
                try:
                    converted_value = converter(value)
                    if env_var == 'SEARCH_DEFAULT_MODE':
                        config.default_mode = converted_value
                    elif env_var == 'SEARCH_DEFAULT_K':
                        config.default_k = converted_value
                    elif env_var == 'SEARCH_CACHE_SIZE':
                        config.cache_size = converted_value
                    elif env_var == 'SEARCH_MAX_WORKERS':
                        config.max_workers = converted_value
                    elif env_var == 'SEARCH_EVIDENCE_PATH':
                        config.evidence_path = converted_value
                        config.legacy_config.evidence_path = converted_value
                        config.modern_config.evidence_path = converted_value
                    elif env_var == 'SEARCH_DEBUG_MODE':
                        config.debug_mode = converted_value
                    elif env_var == 'SEARCH_LOG_METRICS':
                        config.log_search_metrics = converted_value
                        
                except Exception as e:
                    logger.warning(f"Ошибка при обработке {env_var}={value}: {e}")
        
        logger.info("Конфигурация загружена из переменных окружения")
        return config
    
    @classmethod
    def from_file(cls, config_path: str) -> PerformanceConfig:
        """Загрузка конфигурации из файла."""
        import json
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            # Создание базовой конфигурации
            config = cls()
            
            # Применение настроек из файла
            for key, value in config_data.items():
                if hasattr(config, key):
                    if key == 'performance_profile':
                        try:
                            setattr(config, key, PerformanceProfile(value))
                        except ValueError:
                            logger.warning(f"Неизвестный профиль производительности: {value}")
                    else:
                        setattr(config, key, value)
            
            # Применение профиля если указан
            if 'performance_profile' in config_data:
                config._apply_performance_profile()
            
            logger.info(f"Конфигурация загружена из файла: {config_path}")
            return config
            
        except FileNotFoundError:
            logger.warning(f"Файл конфигурации не найден: {config_path}")
            return cls()
        except Exception as e:
            logger.error(f"Ошибка загрузки конфигурации из файла: {e}")
            return cls()
    
    def save_to_file(self, config_path: str):
        """Сохранение конфигурации в файл."""
        import json
        
        config_data = {
            'default_mode': self.default_mode.value,
            'default_k': self.default_k,
            'evidence_path': self.evidence_path,
            'max_workers': self.max_workers,
            'cache_size': self.cache_size,
            'legacy_weight': self.legacy_weight,
            'modern_weight': self.modern_weight,
            'enable_result_cache': self.enable_result_cache,
            'cache_ttl_seconds': self.cache_ttl_seconds,
            'performance_profile': self.performance_profile.value,
            'enable_async_operations': self.enable_async_operations,
            'max_concurrent_searches': self.max_concurrent_searches,
            'debug_mode': self.debug_mode,
            'log_search_metrics': self.log_search_metrics,
        }
        
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Конфигурация сохранена в файл: {config_path}")
        except Exception as e:
            logger.error(f"Ошибка сохранения конфигурации: {e}")
    
    def optimize_for_query_type(self, query: str) -> Dict[str, Any]:
        """Оптимизация конфигурации для типа запроса.
        
        Args:
            query: Поисковый запрос
            
        Returns:
            Оптимизированные параметры поиска
        """
        query_lower = query.lower()
        query_length = len(query.split())
        
        optimizations = {}
        
        # Анализ типа запроса
        if any(keyword in query_lower for keyword in ['что', 'кто', 'где', 'когда', 'почему']):
            optimizations['mode'] = SearchMode.GRAPHRAG
            optimizations['k'] = min(self.default_k + 2, 10)
            optimizations['use_graph'] = True
            
        elif any(keyword in query_lower for keyword in ['найти', 'поиск', 'искать']):
            optimizations['mode'] = SearchMode.MODERN
            optimizations['k'] = max(self.default_k - 1, 3)
            optimizations['use_index'] = True
            
        elif query_length <= 2:
            # Короткие запросы - быстрый поиск
            optimizations['mode'] = SearchMode.MODERN
            optimizations['k'] = max(self.default_k - 2, 3)
            optimizations['use_index'] = True
            
        elif query_length >= 15:
            # Длинные запросы - качественный поиск
            optimizations['mode'] = SearchMode.QUALITY
            if hasattr(self.performance_profile, 'QUALITY'):
                self.performance_profile = PerformanceProfile.QUALITY
            optimizations['k'] = min(self.default_k + 3, 15)
            optimizations['use_graph'] = True
        
        return optimizations
    
    def get_recommended_settings(self, use_case: str) -> Dict[str, Any]:
        """Получение рекомендуемых настроек для различных сценариев.
        
        Args:
            use_case: Сценарий использования ('real_time', 'batch', 'analytics', etc.)
            
        Returns:
            Рекомендуемые настройки
        """
        use_case_settings = {
            'real_time': {
                'default_mode': SearchMode.MODERN,
                'max_concurrent_searches': 20,
                'cache_size': 2000,
                'search_timeout_seconds': 5.0,
                'performance_monitoring': False
            },
            'batch': {
                'default_mode': SearchMode.MODERN,
                'max_concurrent_searches': 5,
                'cache_size': 500,
                'search_timeout_seconds': 60.0,
                'performance_monitoring': True
            },
            'analytics': {
                'default_mode': SearchMode.GRAPHRAG,
                'max_concurrent_searches': 3,
                'cache_size': 100,
                'search_timeout_seconds': 120.0,
                'performance_monitoring': True
            },
            'development': {
                'default_mode': SearchMode.HYBRID,
                'max_concurrent_searches': 10,
                'cache_size': 100,
                'debug_mode': True,
                'log_search_metrics': True,
                'enable_performance_profiling': True
            }
        }
        
        return use_case_settings.get(use_case, {})
    
    def __str__(self) -> str:
        return (f"PerformanceConfig("
                f"mode={self.default_mode.value}, "
                f"profile={self.performance_profile.value}, "
                f"k={self.default_k}, "
                f"cache={self.cache_size})")
    
    def __repr__(self) -> str:
        return self.__str__()

# Предустановленные конфигурации для удобства
def create_fast_config() -> PerformanceConfig:
    """Конфигурация для максимальной скорости."""
    config = PerformanceConfig()
    config.performance_profile = PerformanceProfile.FASTEST
    return config

def create_balanced_config() -> PerformanceConfig:
    """Сбалансированная конфигурация."""
    config = PerformanceConfig()
    config.performance_profile = PerformanceProfile.BALANCED
    return config

def create_quality_config() -> PerformanceConfig:
    """Конфигурация для максимального качества."""
    config = PerformanceConfig()
    config.performance_profile = PerformanceProfile.QUALITY
    return config

def create_graphrag_config() -> PerformanceConfig:
    """Конфигурация с фокусом на GraphRAG."""
    config = PerformanceConfig()
    config.performance_profile = PerformanceProfile.GRAPHRAG_FOCUS
    return config

# Утилиты для работы с конфигурацией
def load_config(config_source: Optional[str] = None) -> PerformanceConfig:
    """Загрузка конфигурации из различных источников.
    
    Args:
        config_source: Источник конфигурации (путь к файлу, 'env' или None)
        
    Returns:
        Загруженная конфигурация
    """
    if config_source is None:
        # Попытка загрузки из env, затем default
        try:
            return PerformanceConfig.from_environment()
        except Exception as e:
            logger.warning(f"Ошибка загрузки конфигурации из env: {e}")
            return PerformanceConfig()
    
    elif config_source.lower() == 'env':
        return PerformanceConfig.from_environment()
    
    else:
        # Загрузка из файла
        return PerformanceConfig.from_file(config_source)