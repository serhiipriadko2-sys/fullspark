# Production Deployment Guide

## Предварительные требования

### Системные требования
- **ОС**: Ubuntu 20.04+ LTS, CentOS 8+, Debian 11+
- **RAM**: Минимум 8GB (рекомендуется 16GB+)
- **Диск**: Минимум 50GB SSD
- **Процессор**: 4+ ядер
- **Сеть**: Пропускная способность 100Mbps+

### Сетевые требования
- **Входящие порты**: 80, 443, 8000
- **Исходящие порты**: 443, 5432, 6379
- **IP версии**: IPv4 и IPv6

### Зависимости
- **Python**: 3.11+ (последняя стабильная)
- **PostgreSQL**: 14+ или 15+
- **Redis**: 6.2+ или 7.0+
- **Nginx**: 1.18+
- **SSL сертификат**: Let's Encrypt или корпоративный

### Лицензии
- **GPL v3**: Основной код
- **MIT**: Отдельные компоненты
- **Apache 2.0**: Зависимости

## Архитектура продакшена

### Компоненты системы
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     Nginx       │    │   Load Balancer │    │   CDN           │
│   (Reverse      │    │   (Optional)    │    │   (Optional)    │
│    Proxy)       │    │                 │    │                 │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          └──────────────────────┼──────────────────────┘
                                 │
          ┌──────────────────────┴──────────────────────┐
          │                Application Server          │
          │               (Python + FastAPI)           │
          └──────────────────────┬──────────────────────┘
                                 │
    ┌────────────────────────────┼────────────────────────────┐
    │                            │                            │
┌───┴────┐                 ┌────┴────┐                 ┌────┴────┐
│PostgreSQL│                │  Redis   │                │Monitoring│
│ (Master) │                │ (Cache)  │                │(Grafana) │
└─────────┘                 └─────────┘                 └─────────┘
```

### Масштабирование
- **Горизонтальное**: 2-4+ application servers
- **База данных**: Master-Slave репликация
- **Кэш**: Redis Cluster
- **Load Balancer**: Nginx или HAProxy

## Установка

### Шаг 1: Подготовка сервера

#### Обновление системы
```bash
# Ubuntu/Debian
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git build-essential

# CentOS/RHEL
sudo yum update -y
sudo yum install -y curl wget git gcc gcc-c++ make
```

#### Создание пользователя приложения
```bash
# Создание пользователя
sudo useradd -m -s /bin/bash diapp
sudo usermod -aG sudo diapp

# Настройка прав доступа
sudo mkdir -p /opt/diapp
sudo chown diapp:diapp /opt/diapp

# Переключение на пользователя приложения
sudo su - diapp
```

#### Настройка SSH ключей
```bash
# Копирование SSH ключей
ssh-copy-id diapp@server_ip

# Проверка подключения
ssh diapp@server_ip
```

### Шаг 2: Установка Python и зависимостей

#### Установка Python 3.11+
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y software-properties-common
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update
sudo apt install -y python3.11 python3.11-venv python3.11-dev

# CentOS/RHEL
sudo dnf install -y python3.11 python3.11-devel python3.11-pip
```

#### Установка системных зависимостей
```bash
# Ubuntu/Debian
sudo apt install -y \
    postgresql postgresql-contrib \
    redis-server \
    nginx \
    supervisor \
    fail2ban \
    ufw

# CentOS/RHEL
sudo dnf install -y \
    postgresql postgresql-server postgresql-contrib \
    redis \
    nginx \
    supervisor \
    fail2ban \
    firewalld
```

### Шаг 3: Настройка базы данных

#### PostgreSQL
```bash
# Инициализация базы данных
sudo postgresql-setup --initdb --unit postgresql

# Запуск и автозагрузка
sudo systemctl enable postgresql
sudo systemctl start postgresql

# Создание пользователя и базы данных
sudo -u postgres psql << EOF
CREATE USER diapp WITH PASSWORD 'secure_password_here';
CREATE DATABASE diapp_production OWNER diapp;
GRANT ALL PRIVILEGES ON DATABASE diapp_production TO diapp;
\q
EOF

# Проверка подключения
psql -U diapp -d diapp_production -h localhost
```

#### PostgreSQL оптимизация
```bash
# Редактирование конфигурации
sudo nano /etc/postgresql/14/main/postgresql.conf

# Основные параметры
max_connections = 200
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
```

```bash
# Перезапуск PostgreSQL
sudo systemctl restart postgresql
```

### Шаг 4: Настройка Redis

#### Установка и настройка Redis
```bash
# Редактирование конфигурации
sudo nano /etc/redis/redis.conf

# Основные параметры
bind 127.0.0.1
port 6379
timeout 0
tcp-keepalive 300
maxmemory 256mb
maxmemory-policy allkeys-lru
save 900 1
save 300 10
save 60 10000
```

```bash
# Перезапуск Redis
sudo systemctl enable redis-server
sudo systemctl restart redis-server

# Проверка
redis-cli ping
```

### Шаг 5: Развертывание приложения

#### Клонирование и установка
```bash
# Переход в директорию приложения
cd /opt/diapp

# Клонирование репозитория
git clone <repository_url> .
git checkout main

# Создание виртуального окружения
python3.11 -m venv venv
source venv/bin/activate

# Обновление pip
pip install --upgrade pip setuptools wheel

# Установка зависимостей
pip install -r requirements.txt
pip install -r config/requirements.txt

# Установка в режиме разработки
pip install -e .
```

#### Конфигурация продакшена
```bash
# Создание файла окружения
cp .env.example .env
nano .env
```

**Конфигурация .env для продакшена:**
```bash
# Основные настройки
APP_NAME=MergedDIApp
APP_ENV=production
APP_DEBUG=false
APP_PORT=8000
HOST=0.0.0.0
WORKERS=4

# Безопасность
SECRET_KEY=your-super-secure-secret-key-256-bits
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com,localhost
CORS_ORIGINS=https://yourdomain.com
SSL_REQUIRED=true

# База данных
DATABASE_TYPE=postgresql
DATABASE_URL=postgresql://diapp:secure_password_here@localhost:5432/diapp_production
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30
DATABASE_TIMEOUT=60

# Кэширование
CACHE_TYPE=redis
REDIS_URL=redis://localhost:6379/0
REDIS_PASSWORD=redis_password_here
REDIS_SOCKET_TIMEOUT=60
REDIS_CONNECTION_POOL_SIZE=50

# Логирование
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=/opt/diapp/logs/app.log
LOG_ROTATION=100MB
LOG_RETENTION=30
LOG_COMPRESSION=true

# API
API_VERSION=v2
API_RATE_LIMIT=1000
API_TIMEOUT=30
API_DOCS_ENABLED=false
API_DOCS_URL=/docs

# Производительность
WORKER_CONNECTIONS=1000
MAX_REQUESTS=10000
MAX_REQUESTS_JITTER=1000
TIMEOUT=120
KEEPALIVE=2

# Мониторинг
HEALTH_CHECK_ENABLED=true
METRICS_ENABLED=true
PROMETHEUS_METRICS=true
PROFILING_ENABLED=false

# Интеграция
INTEGRATION_TIMEOUT=60
RETRY_ATTEMPTS=3
RETRY_BACKOFF=1.0
FALLBACK_ENABLED=true
CircuitBreaker_THRESHOLD=10
CircuitBreaker_TIMEOUT=30

# Безопасность
SECURE_HEADERS=true
HSTS_ENABLED=true
HSTS_MAX_AGE=31536000
CONTENT_SECURITY_POLICY=default-src 'self'
X_FRAME_OPTIONS=DENY
X_CONTENT_TYPE_OPTIONS=nosniff

# Email (опционально)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@domain.com
SMTP_PASSWORD=your_app_password
SMTP_USE_TLS=true
```

#### Создание необходимых директорий
```bash
mkdir -p logs cache backups static
chmod 755 logs cache backups static
```

### Шаг 6: Настройка веб-сервера

#### Nginx конфигурация
```bash
sudo nano /etc/nginx/sites-available/diapp
```

```nginx
# /etc/nginx/sites-available/diapp
upstream diapp_backend {
    server 127.0.0.1:8000;
    keepalive 32;
}

server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    # SSL сертификаты
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    
    # SSL настройки
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;

    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    # Основные заголовки безопасности
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https:;" always;

    # Ограничения размера файлов
    client_max_body_size 100M;

    # Логирование
    access_log /var/log/nginx/diapp.access.log;
    error_log /var/log/nginx/diapp.error.log;

    # Статические файлы
    location /static/ {
        alias /opt/diapp/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Health check
    location /health {
        proxy_pass http://diapp_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        access_log off;
    }

    # Основная проксификация
    location / {
        proxy_pass http://diapp_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeouts
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        
        # Буферизация
        proxy_buffering on;
        proxy_buffer_size 128k;
        proxy_buffers 4 256k;
        proxy_busy_buffers_size 256k;
        
        # WebSocket поддержка (если нужна)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # API документация (только в режиме разработки)
    location /docs {
        proxy_pass http://diapp_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

#### Активация конфигурации
```bash
# Создание символической ссылки
sudo ln -s /etc/nginx/sites-available/diapp /etc/nginx/sites-enabled/

# Проверка конфигурации
sudo nginx -t

# Перезапуск Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### Шаг 7: SSL сертификат

#### Let's Encrypt
```bash
# Установка Certbot
sudo apt install -y certbot python3-certbot-nginx

# Получение сертификата
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Автообновление сертификатов
sudo crontab -e
# Добавить строку:
0 12 * * * /usr/bin/certbot renew --quiet
```

### Шаг 8: Systemd сервис

#### Создание сервиса
```bash
sudo nano /etc/systemd/system/diapp.service
```

```ini
# /etc/systemd/system/diapp.service
[Unit]
Description=Merged DI Application
After=network.target postgresql.service redis.service

[Service]
Type=exec
User=diapp
Group=diapp
WorkingDirectory=/opt/diapp
EnvironmentFile=/opt/diapp/.env
ExecStart=/opt/diapp/venv/bin/gunicorn main:app \
    --bind 0.0.0.0:8000 \
    --workers 4 \
    --worker-class uvicorn.workers.UvicornWorker \
    --worker-connections 1000 \
    --max-requests 10000 \
    --max-requests-jitter 1000 \
    --timeout 120 \
    --keepalive 2 \
    --access-logfile /opt/diapp/logs/gunicorn.access.log \
    --error-logfile /opt/diapp/logs/gunicorn.error.log \
    --log-level info \
    --capture-output \
    --enable-stdio-inheritance
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always
RestartSec=10
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
```

#### Активация сервиса
```bash
# Перезагрузка systemd
sudo systemctl daemon-reload

# Запуск и автозагрузка
sudo systemctl enable diapp
sudo systemctl start diapp

# Проверка статуса
sudo systemctl status diapp
```

### Шаг 9: Настройка брандмауэра

#### UFW (Ubuntu)
```bash
# Включение UFW
sudo ufw enable

# Разрешение SSH
sudo ufw allow ssh

# Разрешение HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Разрешение HTTP для Let's Encrypt
sudo ufw allow 80/tcp comment 'Allow ACME HTTP-01 challenge'

# Проверка статуса
sudo ufw status
```

#### Firewalld (CentOS)
```bash
# Запуск и автозагрузка
sudo systemctl enable firewalld
sudo systemctl start firewalld

# Открытие портов
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload

# Проверка
sudo firewall-cmd --list-all
```

## Проверка

### Health Checks
```bash
# Проверка статуса сервиса
sudo systemctl status diapp

# Проверка HTTP статуса
curl -I https://yourdomain.com/health

# Детальная проверка
curl https://yourdomain.com/api/v2/status

# Проверка базы данных
psql -U diapp -d diapp_production -h localhost -c "SELECT version();"

# Проверка Redis
redis-cli ping
```

### Функциональные тесты
```bash
cd /opt/diapp

# Запуск тестов
source venv/bin/activate
python -m pytest tests/ -v --tb=short

# Тестирование производительности
python -c "
import time
import requests
import statistics

response_times = []
for i in range(100):
    start = time.time()
    response = requests.get('https://yourdomain.com/health')
    end = time.time()
    response_times.append(end - start)
    if response.status_code != 200:
        print(f'Ошибка в запросе {i}')
        break

avg_time = statistics.mean(response_times)
print(f'Среднее время ответа: {avg_time:.3f}s')
print(f'Медиана: {statistics.median(response_times):.3f}s')
print(f'Максимум: {max(response_times):.3f}s')
print(f'Минимум: {min(response_times):.3f}s')
"
```

### Нагрузочное тестирование
```bash
# Установка Apache Bench
sudo apt install -y apache2-utils

# Тестирование
ab -n 1000 -c 10 https://yourdomain.com/health

# Установка и запуск wrk (лучше)
cd /tmp
git clone https://github.com/wg/wrk.git
cd wrk && make
sudo cp wrk /usr/local/bin/

# Тестирование с wrk
wrk -t4 -c100 -d30s https://yourdomain.com/health
```

### Проверка безопасности
```bash
# Проверка SSL/TLS
sslyze yourdomain.com
nmap --script ssl-enum-ciphers -p 443 yourdomain.com

# Проверка заголовков безопасности
curl -I https://yourdomain.com/ | grep -E "(X-|Strict-Transport-Security|Content-Security-Policy)"

# Проверка открытых портов
nmap -sS -O yourdomain.com

# Проверка уязвимостей (опционально)
sudo apt install -y nikto
nikto -h https://yourdomain.com
```

## Мониторинг

### Метрики системы
```bash
# Создание скрипта мониторинга
cat > /opt/diapp/scripts/monitor.sh << 'EOF'
#!/bin/bash

# Логирование
LOG_FILE="/var/log/diapp/system_monitor.log"
TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# Проверка статуса сервиса
if ! systemctl is-active --quiet diapp; then
    echo "[$TIMESTAMP] ALERT: diapp service is not running" >> $LOG_FILE
    systemctl restart diapp
fi

# Проверка диска
DISK_USAGE=$(df /opt/diapp | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    echo "[$TIMESTAMP] ALERT: Disk usage is ${DISK_USAGE}%" >> $LOG_FILE
fi

# Проверка памяти
MEM_USAGE=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
if (( $(echo "$MEM_USAGE > 90" | bc -l) )); then
    echo "[$TIMESTAMP] ALERT: Memory usage is ${MEM_USAGE}%" >> $LOG_FILE
fi

# Проверка HTTP статуса
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://yourdomain.com/health)
if [ $HTTP_CODE -ne 200 ]; then
    echo "[$TIMESTAMP] ALERT: HTTP status is $HTTP_CODE" >> $LOG_FILE
fi
EOF

chmod +x /opt/diapp/scripts/monitor.sh

# Добавление в crontab
(crontab -l 2>/dev/null; echo "*/5 * * * * /opt/diapp/scripts/monitor.sh") | crontab -
```

### Логирование и ротация
```bash
# Настройка logrotate
sudo nano /etc/logrotate.d/diapp
```

```
/opt/diapp/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    sharedscripts
    postrotate
        systemctl reload diapp
    endscript
}
```

### Алерты по email
```bash
# Установка mailutils
sudo apt install -y mailutils

# Создание скрипта алертов
cat > /opt/diapp/scripts/alert.sh << 'EOF'
#!/bin/bash
SUBJECT="[DIAPP] Alert: $1"
EMAIL="admin@yourdomain.com"

echo "$2" | mail -s "$SUBJECT" $EMAIL
EOF

chmod +x /opt/diapp/scripts/alert.sh
```

## Оптимизация производительности

### PostgreSQL оптимизация
```bash
# Анализ производительности
sudo -u postgres psql -d diapp_production << EOF
-- Включение расширения статистики
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Анализ медленных запросов
SELECT query, mean_time, calls 
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
EOF
```

### Redis оптимизация
```bash
# Мониторинг Redis
redis-cli info stats
redis-cli info memory
redis-cli info persistence

# Анализ использования памяти
redis-cli --bigkeys
```

### Application оптимизация
```bash
# Профилирование Python
python -c "
import cProfile
import pstats
from io import StringIO

# Профилирование основных операций
profiler = cProfile.Profile()
profiler.enable()

# Здесь должен быть ваш код для профилирования
import requests
requests.get('https://yourdomain.com/health')

profiler.disable()
stream = StringIO()
stats = pstats.Stats(profiler, stream=stream)
stats.sort_stats('cumulative')
stats.print_stats(10)
print(stream.getvalue())
"
```

## Резервное копирование

### Автоматические бэкапы
```bash
# Создание директории для бэкапов
mkdir -p /opt/diapp/backups/{database,files}

# Скрипт бэкапа БД
cat > /opt/diapp/scripts/backup_db.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/diapp/backups/database"
DATE=$(date +%Y%m%d_%H%M%S)

# Бэкап PostgreSQL
pg_dump -U diapp -h localhost diapp_production | gzip > $BACKUP_DIR/diapp_production_$DATE.sql.gz

# Удаление старых бэкапов (старше 30 дней)
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete

echo "Database backup completed: diapp_production_$DATE.sql.gz"
EOF

# Скрипт бэкапа файлов
cat > /opt/diapp/scripts/backup_files.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/diapp/backups/files"
DATE=$(date +%Y%m%d_%H%M%S)

# Бэкап конфигурации и статических файлов
tar -czf $BACKUP_DIR/diapp_files_$DATE.tar.gz \
    /opt/diapp/.env \
    /opt/diapp/static/ \
    /opt/diapp/logs/ \
    --exclude='*.log'

# Удаление старых бэкапов
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

echo "Files backup completed: diapp_files_$DATE.tar.gz"
EOF

chmod +x /opt/diapp/scripts/backup_*.sh

# Добавление в crontab
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/diapp/scripts/backup_db.sh") | crontab -
(crontab -l 2>/dev/null; echo "0 3 * * * /opt/diapp/scripts/backup_files.sh") | crontab -
```

### Восстановление из бэкапа
```bash
# Восстановление PostgreSQL
gunzip -c /opt/diapp/backups/database/diapp_production_20231101_020000.sql.gz | \
    psql -U diapp -h localhost diapp_production

# Восстановление файлов
tar -xzf /opt/diapp/backups/files/diapp_files_20231101_030000.tar.gz -C /
sudo systemctl restart diapp
```

## Безопасность

### Hardening системы
```bash
# Отключение неиспользуемых сервисов
sudo systemctl disable bluetooth
sudo systemctl disable cups
sudo systemctl disable avahi-daemon

# Настройка fail2ban
sudo nano /etc/fail2ban/jail.local
```

```
[DEFAULT]
bantime = 3600
findtime = 600
maxretry = 3
destemail = admin@yourdomain.com
sender = fail2ban@yourdomain.com
action = %(action_mwl)s

[nginx-http-auth]
enabled = true

[nginx-noscript]
enabled = true

[nginx-badbots]
enabled = true

[nginx-noproxy]
enabled = true
```

```bash
# Перезапуск fail2ban
sudo systemctl restart fail2ban
```

### Обновления безопасности
```bash
# Автоматические обновления безопасности
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure unattended-upgrades

# Обновления безопасности вручную
sudo apt update
sudo apt list --upgradable | grep -i security
sudo apt upgrade -y
```

## Решение проблем

### Частые проблемы

#### Высокая нагрузка CPU
```bash
# Поиск процессов с высокой нагрузкой
top -p $(pgrep -d, -f diapp)

# Анализ Python процессов
ps aux | grep python

# Проверка логов на ошибки
tail -100 /opt/diapp/logs/gunicorn.error.log
```

#### Проблемы с базой данных
```bash
# Проверка подключений PostgreSQL
sudo -u postgres psql -c "SELECT count(*) FROM pg_stat_activity;"

# Проверка медленных запросов
sudo -u postgres psql -d diapp_production -c "SELECT * FROM pg_stat_activity WHERE state = 'active';"

# Перезапуск при необходимости
sudo systemctl restart postgresql
```

#### Проблемы с памятью
```bash
# Мониторинг использования памяти
watch -n 5 'free -h && echo && ps aux --sort=-%mem | head -10'

# Очистка кэша (осторожно!)
sync && echo 3 | sudo tee /proc/sys/vm/drop_caches
```

#### SSL сертификаты
```bash
# Проверка срока действия сертификата
openssl x509 -in /etc/letsencrypt/live/yourdomain.com/fullchain.pem -text -noout | grep "Not After"

# Принудительное обновление сертификата
sudo certbot renew --force-renewal
sudo systemctl reload nginx
```

### Отладка

#### Логи приложения
```bash
# Просмотр логов в реальном времени
sudo journalctl -u diapp -f

# Логи Gunicorn
tail -f /opt/diapp/logs/gunicorn.error.log

# Логи Nginx
sudo tail -f /var/log/nginx/diapp.error.log
```

#### Сетевые подключения
```bash
# Проверка портов
sudo netstat -tlnp | grep :8000
sudo netstat -tlnp | grep :443
sudo netstat -tlnp | grep :5432

# Проверка соединений
ss -tuln | grep :8000
```

#### Производительность
```bash
# Мониторинг I/O
iostat -x 1

# Мониторинг сети
iftop -i eth0

# Мониторинг системы
htop
iotop
```

## Масштабирование

### Горизонтальное масштабирование
```bash
# Добавление дополнительного сервера приложений
# 1. Повторить установку на новом сервере
# 2. Настроить load balancer (HAProxy/Nginx)

# Пример HAProxy конфигурации
cat > /etc/haproxy/haproxy.cfg << 'EOF'
global
    daemon
    maxconn 4096

defaults
    mode http
    timeout connect 5000ms
    timeout client 50000ms
    timeout server 50000ms

frontend diapp_frontend
    bind *:80
    bind *:443 ssl crt /etc/ssl/private/diapp.pem
    redirect scheme https if !{ ssl_fc }
    default_backend diapp_backend

backend diapp_backend
    balance roundrobin
    option httpchk GET /health
    server app1 10.0.1.10:8000 check
    server app2 10.0.1.11:8000 check
EOF

sudo systemctl restart haproxy
```

### Вертикальное масштабирование
```bash
# Увеличение количества workers
sudo systemctl edit diapp

[Service]
ExecStart=/opt/diapp/venv/bin/gunicorn main:app \
    --bind 0.0.0.0:8000 \
    --workers 8 \
    --worker-class uvicorn.workers.UvicornWorker \
    --max-requests 10000 \
    --timeout 120

sudo systemctl daemon-reload
sudo systemctl restart diapp
```

## Обслуживание

### Плановое обслуживание
```bash
# Процедура обновления
# 1. Бэкап
# 2. Перевод в режим обслуживания
# 3. Обновление кода
# 4. Миграция базы данных
# 5. Перезапуск сервисов
# 6. Проверка функциональности

cat > /opt/diapp/scripts/maintenance.sh << 'EOF'
#!/bin/bash

echo "Starting maintenance mode..."

# Перевод в режим обслуживания
echo "Maintenance mode" > /opt/diapp/maintenance.flag

# Бэкап
/opt/diapp/scripts/backup_db.sh
/opt/diapp/scripts/backup_files.sh

# Обновление
cd /opt/diapp
git pull origin main
source venv/bin/activate
pip install -r requirements.txt

# Миграция базы данных (если есть)
# python manage.py migrate

# Перезапуск сервисов
sudo systemctl restart diapp

# Проверка
sleep 30
if curl -f https://yourdomain.com/health; then
    echo "Maintenance completed successfully"
    rm /opt/diapp/maintenance.flag
else
    echo "Maintenance failed - service may be down"
    exit 1
fi
EOF

chmod +x /opt/diapp/scripts/maintenance.sh
```

### Миграция данных
См. [migration_deployment.md](migration_deployment.md)

---

**Поддержка**: Все вопросы и проблемы документируйте в системе мониторинга. Регулярно обновляйте документацию и конфигурации.
