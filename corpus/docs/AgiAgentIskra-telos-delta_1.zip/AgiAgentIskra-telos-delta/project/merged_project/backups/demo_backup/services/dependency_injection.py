"""
Система Dependency Injection для интегрированной архитектуры.

Обеспечивает управление зависимостями и поддержку gradual migration от Version 1 к Version 2.
"""

import asyncio
from typing import Any, Dict, Optional, Type, TypeVar, Generic, get_type_hints
from abc import ABC, abstractmethod
import inspect

T = TypeVar('T')


class Container:
    """DI контейнер для управления зависимостями."""
    
    def __init__(self):
        self._singletons: Dict[Type, Any] = {}
        self._factories: Dict[Type, Any] = {}
        self._configs: Dict[str, Any] = {}
        self._initialized = False
    
    def register_singleton(self, interface: Type[T], implementation: Type[T] = None, config: Dict[str, Any] = None):
        """Регистрация singleton зависимости."""
        if implementation is None:
            implementation = interface
        
        if config:
            self._configs[interface] = config
        
        self._singletons[interface] = implementation
        if implementation not in self._singletons:
            self._singletons[implementation] = implementation
    
    def register_factory(self, interface: Type[T], factory: callable, config: Dict[str, Any] = None):
        """Регистрация фабрики зависимости."""
        if config:
            self._configs[interface] = config
        
        self._factories[interface] = factory
    
    def register_instance(self, interface: Type[T], instance: Any):
        """Регистрация готового экземпляра."""
        self._singletons[interface] = instance
        self._singletons[type(instance)] = instance
    
    def get(self, interface: Type[T]) -> T:
        """Получение зависимости."""
        # Сначала проверяем готовые экземпляры
        if interface in self._singletons:
            impl = self._singletons[interface]
            
            # Если это уже готовый экземпляр
            if not inspect.isclass(impl):
                return impl
            
            # Если это класс - создаем экземпляр
            instance = self._create_instance(impl)
            # Кэшируем как singleton
            self._singletons[interface] = instance
            return instance
        
        # Проверяем фабрики
        if interface in self._factories:
            factory = self._factories[interface]
            return factory()
        
        raise ValueError(f"Dependency {interface} not registered")
    
    def _create_instance(self, cls: Type[T], *args, **kwargs) -> T:
        """Создание экземпляра с автоматическим resolution зависимостей."""
        try:
            # Получаем type hints для конструктора
            hints = get_type_hints(cls.__init__)
            init_params = {}
            
            # Проверяем параметры конструктора
            sig = inspect.signature(cls.__init__)
            for param_name, param in sig.parameters.items():
                if param_name == 'self':
                    continue
                
                if param_name in kwargs:
                    init_params[param_name] = kwargs[param_name]
                elif param_name in hints:
                    param_type = hints[param_name]
                    try:
                        init_params[param_name] = self.get(param_type)
                    except ValueError:
                        # Если зависимость не найдена, используем default или пропускаем
                        if param.default != inspect.Parameter.empty:
                            continue
                        raise
                else:
                    # Если тип не определен и есть default, используем его
                    if param.default != inspect.Parameter.empty:
                        continue
                    raise ValueError(f"Cannot resolve parameter {param_name} for {cls.__name__}")
            
            return cls(*args, **init_params)
        
        except Exception as e:
            # Fallback: пытаемся создать без автоматического resolution
            try:
                return cls(*args, **kwargs)
            except Exception:
                raise ValueError(f"Cannot create instance of {cls.__name__}: {e}")
    
    def is_registered(self, interface: Type) -> bool:
        """Проверка регистрации зависимости."""
        return interface in self._singletons or interface in self._factories
    
    def clear(self):
        """Очистка контейнера."""
        self._singletons.clear()
        self._factories.clear()
        self._configs.clear()
        self._initialized = False


class ServiceRegistry:
    """Реестр сервисов для backward compatibility."""
    
    def __init__(self, container: Container):
        self.container = container
        self._legacy_services: Dict[str, Any] = {}
        self._version2_services: Dict[str, Any] = {}
    
    def register_legacy_service(self, name: str, service: Any):
        """Регистрация legacy сервиса (Version 1)."""
        self._legacy_services[name] = service
    
    def register_v2_service(self, name: str, service: Any):
        """Регистрация V2 сервиса."""
        self._version2_services[name] = service
    
    def get_legacy_service(self, name: str) -> Any:
        """Получение legacy сервиса."""
        if name not in self._legacy_services:
            raise ValueError(f"Legacy service {name} not found")
        return self._legacy_services[name]
    
    def get_v2_service(self, name: str) -> Any:
        """Получение V2 сервиса."""
        if name not in self._version2_services:
            raise ValueError(f"V2 service {name} not found")
        return self._version2_services[name]
    
    def get_service(self, name: str, preferred_version: str = "v2") -> Any:
        """Получение сервиса с предпочтением версии."""
        if preferred_version == "v2" and name in self._version2_services:
            return self._version2_services[name]
        elif preferred_version == "legacy" and name in self._legacy_services:
            return self._legacy_services[name]
        elif name in self._legacy_services:
            return self._legacy_services[name]
        elif name in self._version2_services:
            return self._version2_services[name]
        else:
            raise ValueError(f"Service {name} not found in any version")


# Глобальный контейнер
_global_container: Optional[Container] = None
_global_registry: Optional[ServiceRegistry] = None


def get_container() -> Container:
    """Получение глобального DI контейнера."""
    global _global_container
    if _global_container is None:
        _global_container = Container()
    return _global_container


def get_service_registry() -> ServiceRegistry:
    """Получение глобального реестра сервисов."""
    global _global_registry
    if _global_registry is None:
        container = get_container()
        _global_registry = ServiceRegistry(container)
    return _global_registry


# Декораторы для автоматической регистрации
def singleton(cls: Type[T]) -> Type[T]:
    """Декоратор для автоматической регистрации singleton."""
    def wrapper():
        container = get_container()
        container.register_singleton(cls)
        return container.get(cls)
    return wrapper()


def injectable(cls: Type[T]) -> Type[T]:
    """Декоратор для автоматической регистрации injectable класса."""
    def wrapper():
        container = get_container()
        container.register_singleton(cls)
        return cls
    return wrapper


# Утилиты для backward compatibility
def legacy_service(name: str):
    """Декоратор для marking legacy service."""
    def decorator(cls):
        registry = get_service_registry()
        registry.register_legacy_service(name, cls)
        return cls
    return decorator


def v2_service(name: str):
    """Декоратор для marking V2 service."""
    def decorator(cls):
        registry = get_service_registry()
        registry.register_v2_service(name, cls)
        return cls
    return decorator


# Утилиты для async dependency resolution
async def get_async_service(service_type: Type[T]) -> T:
    """Асинхронное получение сервиса."""
    container = get_container()
    
    # Создаем синхронный экземпляр в thread pool
    def create_service():
        return container.get(service_type)
    
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, create_service)