# Синхронизированная система конфигурации

## Обзор

Синхронизированная система конфигурации для интегрированной архитектуры Искра обеспечивает единообразную работу всех компонентов системы путем объединения настроек из Version 1 и Version 2 с обеспечением полной совместимости.

## Архитектура

### Компоненты системы

```
config/
├── __init__.py                 # Инициализация пакета
├── unified_config.py           # Основная конфигурация
├── environment.py              # Управление переменными окружения
├── compatibility.py            # Совместимость между версиями
├── migration.py                # Миграция конфигурации
├── validation.py               # Валидация настроек
└── defaults.py                 # Значения по умолчанию
```

### Основные классы

#### UnifiedConfig
Главный класс конфигурации, объединяющий все настройки:

```python
from merged_project.config import UnifiedConfig, EnvironmentProfile

# Создание конфигурации
config = UnifiedConfig(
    config_path="config.json",
    profile=EnvironmentProfile.PRODUCTION
)

# Доступ к настройкам
print(f"JWT Algorithm: {config.security.jwt_algorithm}")
print(f"Memory Root: {config.memory.memory_root}")
print(f"Search Cache Size: {config.search.search_cache_size}")
```

#### EnvironmentManager
Менеджер переменных окружения:

```python
from merged_project.config import EnvironmentManager

env_manager = EnvironmentManager()

# Загрузка переменных из окружения
env_vars = env_manager.load_from_environment()

# Валидация окружения
validation = env_manager.validate_environment()

# Генерация шаблона .env файла
env_manager.generate_env_template(".env.template")
```

#### VersionCompatibility
Менеджер совместимости версий:

```python
from merged_project.config import VersionCompatibility

compatibility = VersionCompatibility()

# Миграция конфигурации
migrated_config = compatibility.migrate_config(config_data)

# Генерация отчета о совместимости
report = compatibility.generate_compatibility_report(config_data)
```

## Профили конфигурации

### EnvironmentProfile

- **DEVELOPMENT** - Максимальные возможности для разработки
- **PRODUCTION** - Оптимизированная производительность и безопасность
- **TESTING** - Изолированные настройки для тестов
- **STAGING** - Промежуточная среда для тестирования

### DefaultProfile

- **MINIMAL** - Минимальные настройки
- **DEVELOPMENT** - Разработка
- **PRODUCTION** - Продакшен
- **TESTING** - Тестирование
- **SECURITY** - Максимальная безопасность
- **PERFORMANCE** - Максимальная производительность

## Категории настроек

### 1. SecuritySettings - Настройки безопасности

```python
config.security.jwt_secret                 # JWT секрет
config.security.jwt_algorithm              # Алгоритм JWT (HS256, RS256, etc.)
config.security.jwt_access_token_expire_minutes  # Время жизни токена
config.security.cors_origins              # Разрешенные CORS источники
config.security.rate_limit_enabled        # Включение rate limiting
config.security.rate_limit_requests_per_minute  # Лимит запросов
```

### 2. MemorySettings - Настройки памяти

```python
config.memory.memory_root                  # Корневая директория памяти
config.memory.evidence_path               # Путь к evidence файлу
config.memory.memory_batch_size           # Размер батча
config.memory.memory_flush_interval_seconds  # Интервал сброса
config.memory.memory_compression_enabled  # Включение сжатия
config.memory.memory_async_enabled        # Асинхронная память
```

### 3. SearchSettings - Настройки поиска

```python
config.search.default_search_k            # Количество результатов по умолчанию
config.search.max_search_results          # Максимальное количество результатов
config.search.search_cache_enabled        # Включение кэширования
config.search.search_cache_size           # Размер кэша
config.search.similarity_threshold        # Порог схожести
config.search.search_parallel_threads     # Количество потоков
```

### 4. APISettings - Настройки API

```python
config.api.host                           # Хост сервера
config.api.port                           # Порт сервера
config.api.api_version_prefix             # Префикс версии API
config.api.docs_enabled                   # Включение документации
config.api.request_size_limit_mb          # Лимит размера запроса
config.api.middleware_enabled             # Включение middleware
```

### 5. PerformanceSettings - Настройки производительности

```python
config.performance.async_pool_size        # Размер пула async операций
config.performance.connection_pool_size   # Размер пула соединений
config.performance.lru_cache_enabled      # Включение LRU кэша
config.performance.lru_cache_size         # Размер LRU кэша
config.performance.memory_pool_enabled    # Включение пула памяти
```

### 6. LoggingSettings - Настройки логирования

```python
config.logging.log_level                  # Уровень логирования
config.logging.log_format                 # Формат лога (json, text, colored)
config.logging.console_logging            # Логирование в консоль
config.logging.file_logging               # Логирование в файл
config.logging.structured_logging         # Структурированное логирование
```

### 7. MonitoringSettings - Настройки мониторинга

```python
config.monitoring.metrics_enabled         # Включение метрик
config.monitoring.health_check_enabled    # Включение проверок здоровья
config.monitoring.otel_enabled            # Включение OpenTelemetry
config.monitoring.otel_service_name       # Имя сервиса для OTEL
```

### 8. DatabaseSettings - Настройки базы данных

```python
config.database.database_url              # URL подключения к БД
config.database.database_pool_size        # Размер пула соединений БД
config.database.database_echo             # Echo SQL запросов
config.database.migration_enabled         # Включение миграций
```

## Использование

### Базовое использование

```python
from merged_project.config import create_config, EnvironmentProfile

# Быстрое создание конфигурации
config = create_config(profile=EnvironmentProfile.DEVELOPMENT)

# Проверка режима
if config.is_production_mode():
    print("Продакшен режим")
elif config.is_development_mode():
    print("Режим разработки")

# Использование настроек
jwt_secret = config.security.jwt_secret
memory_root = config.memory.memory_root
```

### Продвинутое использование

```python
from merged_project.config import (
    UnifiedConfig, 
    EnvironmentManager, 
    ConfigValidator,
    EnvironmentProfile
)

# Создание конфигурации с файлом
config = UnifiedConfig(
    config_path="config.json", 
    profile=EnvironmentProfile.PRODUCTION
)

# Валидация конфигурации
validator = ConfigValidator(level=ValidationLevel.STRICT)
result = validator.validate_all_settings(config)

if not result.is_valid:
    print("Ошибки валидации:")
    for error in result.errors:
        print(f"  - {error}")

# Экспорт в .env файл
config.export_to_env_file(".env.production")

# Получение сводки конфигурации
summary = config.get_config_summary()
print(f"Профиль: {summary['profile']}")
print(f"JWT алгоритм: {summary['security']['jwt_algorithm']}")
```

### Миграция конфигурации

```python
from merged_project.config import ConfigMigrator

# Создание мигратора
migrator = ConfigMigrator()

# Определение версии конфигурации
current_version = migrator.detect_config_version(config_data)
print(f"Текущая версия: {current_version}")

# Миграция на унифицированную версию
migrated_config = migrator.migrate_config(config_data, target_version="unified")

# Создание отчета о миграции
report = migrator.create_migration_report(config_data, migrated_config)
print(report)
```

### Работа с переменными окружения

```python
from merged_project.config import EnvironmentManager

# Создание менеджера окружения
env_manager = EnvironmentManager()

# Загрузка переменных из окружения
env_vars = env_manager.load_from_environment()

# Валидация переменных
validation = env_manager.validate_environment()
if validation["errors"]:
    print("Ошибки в переменных окружения:")
    for error in validation["errors"]:
        print(f"  - {error}")

# Получение информации о переменной
var_info = env_manager.get_variable_info("JWT_SECRET")
print(f"Описание: {var_info.description}")
print(f"Тип: {var_info.type}")

# Генерация шаблона .env файла
env_manager.generate_env_template(".env.template")
```

### Проверка совместимости

```python
from merged_project.config import check_compatibility

# Быстрая проверка совместимости
compatibility_report = check_compatibility(config_data)

print(f"Режим совместимости: {compatibility_report['detected_mode']}")
print(f"Версия: {compatibility_report['version']}")
print(f"Совместимо: {compatibility_report['is_fully_compatible']}")

if compatibility_report['deprecated_usage']:
    print("Устаревшие настройки:")
    for deprecated in compatibility_report['deprecated_usage']:
        print(f"  - {deprecated}")
```

## Конфигурационные файлы

### .env файл

```bash
# Основные настройки
APP_NAME=Iskra API
APP_VERSION=1.0.0
DEBUG=false
ENVIRONMENT_PROFILE=production

# JWT настройки
JWT_SECRET=your-secret-key-here
JWT_ALGORITHM=HS256
JWT_ACCESS_TOKEN_EXPIRE_MINUTES=30

# CORS настройки
CORS_ORIGINS=https://yourdomain.com,https://app.yourdomain.com
CORS_ALLOW_CREDENTIALS=true

# Настройки памяти
MEMORY_ROOT=memory
MEMORY_BATCH_SIZE=50
MEMORY_FLUSH_INTERVAL=5.0
MEMORY_COMPRESSION=false

# Настройки поиска
DEFAULT_SEARCH_K=5
MAX_SEARCH_RESULTS=50
SEARCH_CACHE_ENABLED=true
SEARCH_CACHE_SIZE=1000

# Производительность
ASYNC_POOL_SIZE=4
CONNECTION_POOL_SIZE=10
LRU_CACHE_SIZE=1000

# Логирование
LOG_LEVEL=INFO
LOG_FORMAT=json
CONSOLE_LOGGING=false
FILE_LOGGING=true
LOG_FILE_PATH=/var/log/iskra/app.log

# Мониторинг
METRICS_ENABLED=true
HEALTH_CHECK_ENABLED=true
OTEL_ENABLED=true
```

### config.json

```json
{
  "app_name": "Iskra API",
  "app_version": "1.0.0",
  "profile": "production",
  "security": {
    "jwt_algorithm": "HS256",
    "jwt_access_token_expire_minutes": 30,
    "cors_origins": ["https://yourdomain.com"],
    "rate_limit_enabled": true,
    "rate_limit_requests_per_minute": 100
  },
  "memory": {
    "memory_root": "memory",
    "memory_batch_size": 50,
    "memory_flush_interval_seconds": 5.0,
    "memory_compression_enabled": false
  },
  "search": {
    "default_search_k": 5,
    "max_search_results": 50,
    "search_cache_enabled": true,
    "search_cache_size": 1000
  },
  "api": {
    "host": "0.0.0.0",
    "port": 8000,
    "docs_enabled": false
  },
  "performance": {
    "async_pool_size": 4,
    "connection_pool_size": 10,
    "lru_cache_enabled": true,
    "lru_cache_size": 1000
  },
  "logging": {
    "log_level": "INFO",
    "log_format": "json",
    "console_logging": false,
    "file_logging": true,
    "log_file_path": "/var/log/iskra/app.log"
  },
  "monitoring": {
    "metrics_enabled": true,
    "health_check_enabled": true,
    "otel_enabled": true,
    "otel_service_name": "iskra-api"
  }
}
```

## Безопасность

### Рекомендации по безопасности

1. **JWT Secret**:
   - Минимум 32 символа
   - Случайная строка
   - Не использовать в коде

2. **CORS**:
   - Указывать конкретные домены
   - Избегать wildcard (*) в продакшене

3. **Rate Limiting**:
   - Включать в продакшене
   - Умеренные лимиты

4. **Логирование**:
   - Не логировать чувствительные данные
   - Использовать структурированное логирование

5. **Мониторинг**:
   - Включать в продакшене
   - Настроить алерты

### Проверки безопасности

```python
from merged_project.config import ConfigValidator, ValidationLevel

# Валидация с проверкой безопасности
validator = ConfigValidator(level=ValidationLevel.SECURITY)
result = validator.validate_all_settings(config)

if not result.is_valid:
    print("Проблемы безопасности:")
    for error in result.errors:
        print(f"  - {error}")
```

## Миграция и совместимость

### Автоматическая миграция

Система автоматически мигрирует настройки из старых версий:

1. **Legacy → Version 1.0**: Добавление базовых настроек
2. **Version 1.0 → Version 2.0**: Расширенные возможности
3. **Version 2.0 → Unified**: Полная интеграция

### Обратная совместимость

Система обеспечивает обратную совместимость:

```python
# Старые настройки Version 1
config.JWT_SECRET          # Совместимость с Version 1
config.CORS_ORIGINS        # Совместимость с Version 1
config.EVIDENCE_PATH       # Совместимость с Version 1

# Новые настройки Version 2
config.security.jwt_access_token_expire_minutes  # Version 2
config.memory.memory_root                        # Version 2
config.monitoring.otel_enabled                   # Version 2
```

### Ручная миграция

```python
from merged_project.config import generate_migration_script

# Генерация скрипта миграции
generate_migration_script("migrate_config.py")

# Выполнение миграции
# python migrate_config.py
```

## Профили производительности

### Development Profile

```python
profile = EnvironmentProfile.DEVELOPMENT
# - DEBUG: true
# - LOG_LEVEL: DEBUG
# - DOCS_ENABLED: true
# - RATE_LIMIT_ENABLED: false
# - AUTO_RELOAD: true
```

### Production Profile

```python
profile = EnvironmentProfile.PRODUCTION
# - DEBUG: false
# - LOG_LEVEL: WARNING
# - DOCS_ENABLED: false
# - RATE_LIMIT_ENABLED: true
# - WORKERS: 4
# - FILE_LOGGING: true
# - SECURITY_HEADERS_ENABLED: true
```

### Testing Profile

```python
profile = EnvironmentProfile.TESTING
# - DEBUG: false
# - LOG_LEVEL: ERROR
# - METRICS_ENABLED: false
# - OTEL_ENABLED: false
# - ASYNC_LOGGING: false
```

## Мониторинг и метрики

### Встроенная поддержка метрик

```python
config.monitoring.metrics_enabled          # Prometheus метрики
config.monitoring.metrics_port             # Порт для метрик
config.monitoring.health_check_enabled     # Health checks
config.monitoring.otel_enabled             # OpenTelemetry
```

### Интеграция с мониторингом

```python
# Метрики доступны по адресу: http://localhost:9090/metrics
# Health check: http://localhost:8000/health
```

## Отладка и диагностика

### Логирование конфигурации

```python
import logging

# Включение детального логирования конфигурации
logging.getLogger('merged_project.config').setLevel(logging.DEBUG)
```

### Диагностические команды

```python
from merged_project.config import get_version_info

# Информация о версии
version_info = get_version_info()
print(f"Версия: {version_info['version']}")
print(f"Поддерживаемые профили: {version_info['supported_profiles']}")

# Проверка инициализации
config = get_config()
summary = config.get_config_summary()
print(f"Конфигурация инициализирована для профиля: {summary['profile']}")
```

## Интеграция

### С FastAPI

```python
from fastapi import FastAPI
from merged_project.config import get_config

app = FastAPI()
config = get_config()

# Настройка CORS
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.security.cors_origins,
    allow_credentials=config.security.cors_allow_credentials,
    allow_methods=config.security.cors_allow_methods,
    allow_headers=config.security.cors_allow_headers,
)
```

### С базой данных

```python
from merged_project.config import get_config

config = get_config()

# Подключение к БД
DATABASE_URL = config.database.database_url
DATABASE_POOL_SIZE = config.database.database_pool_size

# Использование в SQLAlchemy
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool

engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=DATABASE_POOL_SIZE,
    max_overflow=config.database.database_max_overflow,
    pool_recycle=config.database.database_pool_recycle,
    echo=config.database.database_echo,
)
```

## Расширение системы

### Добавление пользовательских настроек

```python
from merged_project.config import UnifiedConfig, ValidationRule, ValidationLevel

class CustomConfig(UnifiedConfig):
    def _create_custom_settings(self):
        # Ваши пользовательские настройки
        self.custom = CustomSettings(
            custom_option_1=self.config_data.get("CUSTOM_OPTION_1", "default"),
            custom_option_2=self.config_data.get("CUSTOM_OPTION_2", 100),
        )

# Добавление валидации
validator = ConfigValidator()
validator.validation_rules.append(
    ValidationRule(
        "CUSTOM_OPTION_1", 
        "type", 
        str, 
        "CUSTOM_OPTION_1 должно быть строкой"
    )
)
```

### Пользовательские валидаторы

```python
from merged_project.config import ConfigValidator

def custom_validator(config, settings):
    errors = []
    
    # Ваша логика валидации
    if settings.get("CUSTOM_OPTION_1") == "invalid":
        errors.append("Недопустимое значение CUSTOM_OPTION_1")
    
    return {"errors": errors, "warnings": []}

# Добавление валидатора
validator = ConfigValidator()
validator.add_custom_validator("custom_check", custom_validator)
```

## Заключение

Синхронизированная система конфигурации обеспечивает:

- ✅ **Единообразие** - все компоненты используют одну систему настроек
- ✅ **Совместимость** - поддержка Version 1 и Version 2
- ✅ **Безопасность** - встроенные проверки безопасности
- ✅ **Гибкость** - множество профилей и опций
- ✅ **Производительность** - оптимизированные настройки
- ✅ **Мониторинг** - встроенные метрики и проверки здоровья
- ✅ **Миграция** - автоматическая миграция между версиями

Для получения дополнительной информации см. исходный код модулей или обратитесь к документации API.