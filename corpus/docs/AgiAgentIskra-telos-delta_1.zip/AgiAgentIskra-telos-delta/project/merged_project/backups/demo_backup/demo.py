"""Демонстрация интегрированной системы обработки ошибок Iskra.

Показывает использование всех компонентов системы в реальном приложении.

Автор: Iskra Integration Team
Версия: 1.0
"""

import asyncio
import logging
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# Импортируем нашу систему обработки ошибок
from core import setup_error_system
from core.exceptions import (
    BaseIskraException, IskraException,
    AuthenticationException, AuthorizationException, 
    ValidationException, NotFoundException,
    BusinessLogicException, DatabaseException,
    ErrorLevel, ErrorType, ErrorScope
)
from core.handlers import ErrorHandlerManager, service_error_handler
from core.logging import CentralizedLogger, LogContext, setup_logging
from core.middleware import setup_middleware_stack, request_lifecycle_context

# ================================
# Модели данных
# ================================

class UserCreate(BaseModel):
    username: str
    email: str
    age: int

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    age: int

# ================================
# Mock сервисы
# ================================

class MockAuthService:
    """Mock сервис аутентификации для демонстрации."""
    
    async def validate_token(self, token: str) -> dict:
        """Валидирует токен и возвращает информацию о пользователе."""
        if token == "valid_token":
            return {"user_id": "user123", "session_id": "session456"}
        elif token == "expired_token":
            raise AuthenticationException("Токен истек")
        else:
            raise AuthenticationException("Недействительный токен")

class MockDatabase:
    """Mock база данных для демонстрации."""
    
    def __init__(self):
        self.users = [
            {"id": 1, "username": "john", "email": "john@example.com", "age": 25},
            {"id": 2, "username": "jane", "email": "jane@example.com", "age": 30},
        ]
        self.next_id = 3
    
    def get_user(self, user_id: int) -> Optional[dict]:
        """Получает пользователя по ID."""
        return next((user for user in self.users if user["id"] == user_id), None)
    
    def create_user(self, username: str, email: str, age: int) -> dict:
        """Создает нового пользователя."""
        if age < 0:
            raise ValidationException("Возраст не может быть отрицательным", field="age")
        
        if any(user["username"] == username for user in self.users):
            raise ValidationException("Пользователь с таким именем уже существует", field="username")
        
        user = {
            "id": self.next_id,
            "username": username,
            "email": email,
            "age": age
        }
        self.users.append(user)
        self.next_id += 1
        return user
    
    def delete_user(self, user_id: int):
        """Удаляет пользователя."""
        user = self.get_user(user_id)
        if not user:
            raise NotFoundException(f"Пользователь с ID {user_id}")
        
        self.users.remove(user)

# ================================
# Сервисы приложения
# ================================

class UserService:
    """Сервис для работы с пользователями."""
    
    def __init__(self, database: MockDatabase, logger: CentralizedLogger):
        self.database = database
        self.logger = logger
    
    @service_error_handler
    def get_user_by_id(self, user_id: int) -> dict:
        """Получает пользователя по ID с обработкой ошибок."""
        user = self.database.get_user(user_id)
        if not user:
            raise NotFoundException(f"Пользователь с ID {user_id}")
        return user
    
    @service_error_handler  
    def create_user(self, user_data: UserCreate) -> dict:
        """Создает нового пользователя."""
        return self.database.create_user(
            user_data.username, 
            user_data.email, 
            user_data.age
        )
    
    @service_error_handler
    def delete_user(self, user_id: int) -> None:
        """Удаляет пользователя."""
        self.database.delete_user(user_id)
    
    def simulate_business_error(self):
        """Симулирует ошибку бизнес-логики."""
        raise BusinessLogicException("Нельзя удалить администратора")


class SearchService:
    """Сервис поиска для демонстрации обработки ошибок поиска."""
    
    def __init__(self, database: MockDatabase, logger: CentralizedLogger):
        self.database = database
        self.logger = logger
    
    def search_users(self, query: str):
        """Поиск пользователей по запросу."""
        if not query:
            raise ValidationException("Запрос не может быть пустым", field="query")
        
        if len(query) < 2:
            raise ValidationException("Запрос должен содержать минимум 2 символа", field="query")
        
        # Симулируем ошибку поиска
        if query == "error":
            from core.exceptions import SearchException
            raise SearchException("Ошибка при выполнении поиска")
        
        # Имитируем поиск
        matches = [user for user in self.database.users 
                  if query.lower() in user["username"].lower()]
        
        return matches


# ================================
# Создание FastAPI приложения
# ================================

def create_app() -> FastAPI:
    """Создает и настраивает FastAPI приложение."""
    
    # Настраиваем систему обработки ошибок
    error_manager, logger, _ = setup_error_system(
        log_level="INFO",
        log_file="logs/iskra_demo.log",
        enable_async_logging=False
    )
    
    # Создаем FastAPI приложение
    app = FastAPI(
        title="Iskra Error Handling Demo",
        description="Демонстрация интегрированной системы обработки ошибок",
        version="1.0.0"
    )
    
    # Настраиваем middleware stack
    auth_service = MockAuthService()
    middleware_stack = setup_middleware_stack(
        app,
        error_manager,
        logger,
        auth_service
    )
    
    # Получаем готовое приложение с middleware
    app = middleware_stack.get_app()
    
    # Создаем сервисы
    database = MockDatabase()
    user_service = UserService(database, logger)
    search_service = SearchService(database, logger)
    
    # ================================
    # API Endpoints
    # ================================
    
    @app.get("/")
    async def root():
        """Главная страница с информацией о системе."""
        return {
            "message": " Iskra Error Handling Demo",
            "version": "1.0.0",
            "features": [
                "Интегрированная система обработки ошибок",
                "Централизованное логирование", 
                "Middleware для Web API",
                "Поддержка всех уровней ошибок",
                "Обратная совместимость с Version 1"
            ]
        }
    
    @app.get("/health")
    async def health_check():
        """Проверка состояния приложения."""
        return {"status": "healthy", "timestamp": "2025-11-01T11:25:23Z"}
    
    # Endpoints для демонстрации обработки ошибок
    @app.get("/api/users/{user_id}", response_model=UserResponse)
    async def get_user(user_id: int, request: Request):
        """Получает пользователя по ID (демонстрация NotFoundException)."""
        with request_lifecycle_context(request, logger, "get_user"):
            user = user_service.get_user_by_id(user_id)
            return UserResponse(**user)
    
    @app.post("/api/users", response_model=UserResponse)
    async def create_user(user_data: UserCreate, request: Request):
        """Создает нового пользователя (демонстрация ValidationException)."""
        with request_lifecycle_context(request, logger, "create_user"):
            user = user_service.create_user(user_data)
            return UserResponse(**user)
    
    @app.delete("/api/users/{user_id}")
    async def delete_user(user_id: int, request: Request):
        """Удаляет пользователя (демонстрация авторизации)."""
        # Симулируем проверку авторизации
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            raise AuthenticationException("Требуется токен аутентификации")
        
        token = auth_header.split(" ")[1]
        if token == "invalid_token":
            raise AuthenticationException("Недействительный токен")
        
        user_service.delete_user(user_id)
        return {"message": f"Пользователь {user_id} удален"}
    
    @app.get("/api/search")
    async def search_users(query: str, request: Request):
        """Поиск пользователей (демонстрация SearchException)."""
        with request_lifecycle_context(request, logger, "search_users"):
            results = search_service.search_users(query)
            return {"results": results, "count": len(results)}
    
    # Endpoints для демонстрации различных ошибок
    @app.get("/api/demo/business-error")
    async def demo_business_error():
        """Демонстрация ошибки бизнес-логики."""
        user_service.simulate_business_error()
    
    @app.get("/api/demo/auth-error")
    async def demo_auth_error():
        """Демонстрация ошибки аутентификации."""
        raise AuthenticationException("Демонстрационная ошибка аутентификации")
    
    @app.get("/api/demo/validation-error") 
    async def demo_validation_error():
        """Демонстрация ошибки валидации."""
        raise ValidationException("Демонстрационная ошибка валидации", field="test_field")
    
    @app.get("/api/demo/database-error")
    async def demo_database_error():
        """Демонстрация ошибки базы данных."""
        from core.exceptions import DatabaseException
        raise DatabaseException("Демонстрационная ошибка базы данных")
    
    @app.get("/api/demo/version1-compatible")
    async def demo_version1_compatible():
        """Демонстрация совместимости с Version 1."""
        # Используем старый стиль исключений для обратной совместимости
        raise IskraException("Это ошибка в стиле Version 1")
    
    return app


# ================================
# Демонстрация использования
# ================================

async def demo_error_handling():
    """Демонстрирует работу системы обработки ошибок."""
    print("🚀 Запуск демонстрации системы обработки ошибок Iskra")
    print("=" * 60)
    
    # Создаем приложение
    app = create_app()
    
    # Демонстрируем создание различных исключений
    print("\n📋 Создание различных типов исключений:")
    print("-" * 40)
    
    # Version 1 совместимость
    v1_exc = IskraException("Ошибка Version 1", details={"custom": "data"})
    print(f"Version 1: {v1_exc}")
    
    # Новые исключения
    auth_exc = AuthenticationException()
    print(f"Authentication: {auth_exc}")
    
    validation_exc = ValidationException("Неверный формат email", field="email")
    print(f"Validation: {validation_exc}")
    
    business_exc = BusinessLogicException("Некорректная бизнес-операция")
    print(f"Business Logic: {business_exc}")
    
    # Преобразование в HTTP исключения
    print("\n🔄 Преобразование в HTTP исключения:")
    print("-" * 40)
    
    http_exc = auth_exc.to_http_exception()
    print(f"HTTP Status: {http_exc.status_code}")
    print(f"HTTP Detail: {http_exc.detail}")
    
    # Демонстрация контекстного логирования
    print("\n📝 Контекстное логирование:")
    print("-" * 40)
    
    logger = CentralizedLogger("demo", format_type="text")
    
    # Логирование с контекстом
    context = LogContext(
        request_id="req123",
        user_id="user456",
        endpoint="/api/test",
        method="GET"
    )
    
    logger.log_error_with_context(
        "Тестовое сообщение",
        context=context.__dict__,
        level="INFO"
    )
    
    print("✅ Логи записаны в консоль и файл")
    
    # Демонстрация декораторов
    print("\n🎯 Декораторы для обработки ошибок:")
    print("-" * 40)
    
    @service_error_handler
    def test_service_function():
        """Тестовая функция сервиса."""
        raise BusinessLogicException("Ошибка в бизнес-логике")
    
    try:
        test_service_function()
    except BaseIskraException as exc:
        print(f"Поймано Iskra исключение: {exc.error_code}")
    
    print("\n✨ Демонстрация завершена!")
    print("💡 Запустите сервер командой: python -m uvicorn demo:create_app --reload")
    print("📊 Проверьте логи в файле: logs/iskra_demo.log")


# ================================
# Запуск приложения
# ================================

if __name__ == "__main__":
    import uvicorn
    
    # Создаем приложение
    app = create_app()
    
    print("""
    🎯 Iskra Error Handling System Demo
    ====================================
    
    Доступные endpoints:
    - GET  /                     - Главная страница
    - GET  /health              - Проверка состояния
    - GET  /api/users/{id}      - Получить пользователя
    - POST /api/users           - Создать пользователя
    - DELETE /api/users/{id}    - Удалить пользователя
    - GET  /api/search?q=query  - Поиск пользователей
    
    Демонстрационные ошибки:
    - GET  /api/demo/business-error     - Ошибка бизнес-логики
    - GET  /api/demo/auth-error         - Ошибка аутентификации
    - GET  /api/demo/validation-error   - Ошибка валидации
    - GET  /api/demo/database-error     - Ошибка базы данных
    - GET  /api/demo/version1-compatible - Совместимость с Version 1
    
    📝 Логи сохраняются в: logs/iskra_demo.log
    🚀 Для запуска: python -m uvicorn demo:create_app --reload --host 0.0.0.0 --port 8000
    """)
    
    # Запускаем сервер
    uvicorn.run(
        "demo:create_app", 
        host="0.0.0.0", 
        port=8000, 
        reload=True,
        log_level="info"
    )