# Kubernetes Deployment Guide

## Предварительные требования

### Системные требования
- **ОС**: Linux, macOS, Windows с WSL2
- **RAM**: Минимум 4GB (рекомендуется 8GB+)
- **Диск**: Минимум 20GB свободного места
- **Процессор**: 2+ ядра с поддержкой виртуализации
- **Сеть**: Стабильное интернет-соединение

### Зависимости
- **kubectl**: 1.25+ (последняя стабильная версия)
- **minikube**: 1.28+ (для локального развертывания)
- **helm**: 3.8+ (для управления пакетами)
- **Docker**: 20.10+ (для сборки образов)

### Облачные платформы
- **AWS EKS**: Elastic Kubernetes Service
- **Google GKE**: Google Kubernetes Engine
- **Azure AKS**: Azure Kubernetes Service
- **DigitalOcean**: Managed Kubernetes

## Архитектура Kubernetes

### Компоненты системы
```
┌─────────────────────────────────────────────────────────────┐
│                    Ingress Controller                       │
│                  (Nginx/Traefik)                            │
└─────────────────────┬───────────────────────────────────────┘
                      │
    ┌─────────────────┼─────────────────┐
    │                 │                 │
┌───┴───┐         ┌───┴───┐         ┌───┴───┐
│ Pod 1 │         │ Pod 2 │         │ Pod N │
│ App   │         │ App   │         │ App   │
└───┬───┘         └───┬───┘         └───┬───┘
    │                 │                 │
    └─────────────────┼─────────────────┘
                      │
              ┌───────┴───────┐
              │  Service      │
              │ (Load Balancer)│
              └───────┬───────┘
                      │
    ┌─────────────────┼─────────────────┐
    │                 │                 │
┌───┴───┐         ┌───┴───┐         ┌───┴───┐
│Persistent│     │       │     │Monitoring│
│Volume   │     │Redis  │     │ (Prometheus│
│ (PostgreSQL)│     │       │     │ Grafana) │
└─────────┘     └───────┘     └──────────┘
```

### Структура манифестов
```
k8s/
├── namespace.yaml              # Пространство имен
├── configmap.yaml             # Конфигурация
├── secret.yaml                # Секреты
├── postgres/
│   ├── pvc.yaml              # Persistent Volume Claim
│   ├── deployment.yaml       # Deployment PostgreSQL
│   └── service.yaml          # Service PostgreSQL
├── redis/
│   ├── pvc.yaml
│   ├── deployment.yaml
│   └── service.yaml
├── app/
│   ├── deployment.yaml       # Deployment приложения
│   ├── service.yaml          # Service приложения
│   └── hpa.yaml              # Horizontal Pod Autoscaler
├── ingress/
│   └── ingress.yaml          # Правила маршрутизации
├── monitoring/
│   ├── prometheus/
│   │   ├── configmap.yaml
│   │   ├── deployment.yaml
│   │   └── service.yaml
│   └── grafana/
│       ├── configmap.yaml
│       ├── deployment.yaml
│       └── service.yaml
└── scripts/
    ├── deploy.sh             # Скрипт развертывания
    ├── cleanup.sh            # Скрипт очистки
    └── migrate.sh            # Скрипт миграции
```

## Установка

### Шаг 1: Подготовка окружения

#### Локальное развертывание (Minikube)
```bash
# Установка Minikube (Ubuntu/Debian)
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube

# Установка Minikube (macOS)
brew install minikube

# Запуск кластера
minikube start --driver=docker --memory=4096 --cpus=2

# Проверка статуса
minikube status
kubectl cluster-info
```

#### Облачное развертывание
```bash
# AWS EKS
aws eks update-kubeconfig --region us-west-2 --name my-cluster

# Google GKE
gcloud container clusters get-credentials my-cluster --zone us-central1-a

# Azure AKS
az aks get-credentials --resource-group myResourceGroup --name myAKSCluster
```

### Шаг 2: Создание Docker образов

#### Сборка и загрузка образов
```bash
# Переход в директорию проекта
cd merged_project

# Сборка образа приложения
docker build -t diapp:latest .

# Загрузка в registry (локальный minikube)
minikube image load diapp:latest

# Или загрузка в Docker Hub
docker tag diapp:latest username/diapp:latest
docker push username/diapp:latest

# Загрузка в private registry
docker tag diapp:latest registry.domain.com/diapp:latest
docker push registry.domain.com/diapp:latest
```

### Шаг 3: Создание манифестов

#### Namespace
```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: diapp
  labels:
    name: diapp
    environment: production
```

#### ConfigMap
```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: diapp-config
  namespace: diapp
data:
  # Основная конфигурация
  APP_ENV: "production"
  APP_DEBUG: "false"
  LOG_LEVEL: "INFO"
  LOG_FORMAT: "json"
  
  # API конфигурация
  API_VERSION: "v2"
  API_RATE_LIMIT: "1000"
  API_TIMEOUT: "30"
  
  # Производительность
  WORKERS: "4"
  WORKER_CONNECTIONS: "1000"
  MAX_REQUESTS: "10000"
  
  # Интеграция
  INTEGRATION_TIMEOUT: "60"
  RETRY_ATTEMPTS: "3"
  FALLBACK_ENABLED: "true"
```

#### Secrets
```yaml
# k8s/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: diapp-secrets
  namespace: diapp
type: Opaque
stringData:
  # База данных
  DATABASE_URL: "postgresql://diapp:secure_password@diapp-postgres:5432/diapp"
  
  # Redis
  REDIS_URL: "redis://:redis_password@diapp-redis:6379/0"
  
  # Безопасность
  SECRET_KEY: "your-super-secure-secret-key-256-bits"
  
  # Дополнительные секреты
  SMTP_PASSWORD: "email_password_here"
  JWT_SECRET: "jwt_secret_key_here"
  
  # API ключи (если нужны)
  EXTERNAL_API_KEY: "external_api_key_here"
```

#### PostgreSQL Deployment
```yaml
# k8s/postgres/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: diapp-postgres
  namespace: diapp
  labels:
    app: postgres
    component: database
spec:
  replicas: 1
  selector:
    matchLabels:
      app: postgres
      component: database
  template:
    metadata:
      labels:
        app: postgres
        component: database
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        ports:
        - containerPort: 5432
          name: postgres
        env:
        - name: POSTGRES_DB
          value: "diapp"
        - name: POSTGRES_USER
          value: "diapp"
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: diapp-secrets
              key: database_password
        - name: PGDATA
          value: "/var/lib/postgresql/data/pgdata"
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
        - name: postgres-config
          mountPath: /etc/postgresql
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          exec:
            command:
            - pg_isready
            - -U
            - diapp
            - -d
            - diapp
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          exec:
            command:
            - pg_isready
            - -U
            - diapp
            - -d
            - diapp
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: postgres-storage
        persistentVolumeClaim:
          claimName: diapp-postgres-pvc
      - name: postgres-config
        configMap:
          name: postgres-config
---
apiVersion: v1
kind: Service
metadata:
  name: diapp-postgres
  namespace: diapp
  labels:
    app: postgres
    component: database
spec:
  type: ClusterIP
  ports:
  - port: 5432
    targetPort: 5432
    protocol: TCP
    name: postgres
  selector:
    app: postgres
    component: database
```

#### Redis Deployment
```yaml
# k8s/redis/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: diapp-redis
  namespace: diapp
  labels:
    app: redis
    component: cache
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
      component: cache
  template:
    metadata:
      labels:
        app: redis
        component: cache
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        command:
        - redis-server
        - /usr/local/etc/redis/redis.conf
        ports:
        - containerPort: 6379
          name: redis
        env:
        - name: REDIS_PASSWORD
          valueFrom:
            secretKeyRef:
              name: diapp-secrets
              key: redis_password
        volumeMounts:
        - name: redis-config
          mountPath: /usr/local/etc/redis
        - name: redis-storage
          mountPath: /data
        resources:
          requests:
            memory: "256Mi"
            cpu: "100m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          exec:
            command:
            - redis-cli
            - ping
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          exec:
            command:
            - redis-cli
            - ping
          initialDelaySeconds: 5
          periodSeconds: 5
      volumes:
      - name: redis-config
        configMap:
          name: redis-config
      - name: redis-storage
        emptyDir: {}
---
apiVersion: v1
kind: Service
metadata:
  name: diapp-redis
  namespace: diapp
  labels:
    app: redis
    component: cache
spec:
  type: ClusterIP
  ports:
  - port: 6379
    targetPort: 6379
    protocol: TCP
    name: redis
  selector:
    app: redis
    component: cache
```

#### Приложение Deployment
```yaml
# k8s/app/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: diapp-app
  namespace: diapp
  labels:
    app: diapp
    component: application
spec:
  replicas: 3
  selector:
    matchLabels:
      app: diapp
      component: application
  template:
    metadata:
      labels:
        app: diapp
        component: application
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "8000"
        prometheus.io/path: "/metrics"
    spec:
      containers:
      - name: diapp
        image: diapp:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 8000
          name: http
          protocol: TCP
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: diapp-secrets
              key: DATABASE_URL
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: diapp-secrets
              key: REDIS_URL
        - name: SECRET_KEY
          valueFrom:
            secretKeyRef:
              name: diapp-secrets
              key: SECRET_KEY
        envFrom:
        - configMapRef:
            name: diapp-config
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 3
        volumeMounts:
        - name: app-logs
          mountPath: /app/logs
        - name: app-cache
          mountPath: /app/cache
      volumes:
      - name: app-logs
        emptyDir: {}
      - name: app-cache
        emptyDir: {}
      imagePullSecrets:
      - name: regcred
---
apiVersion: v1
kind: Service
metadata:
  name: diapp-app
  namespace: diapp
  labels:
    app: diapp
    component: application
spec:
  type: ClusterIP
  ports:
  - port: 8000
    targetPort: 8000
    protocol: TCP
    name: http
  selector:
    app: diapp
    component: application
```

#### Horizontal Pod Autoscaler
```yaml
# k8s/app/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: diapp-app-hpa
  namespace: diapp
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: diapp-app
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 100
        periodSeconds: 60
```

#### Ingress
```yaml
# k8s/ingress/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: diapp-ingress
  namespace: diapp
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "100m"
    nginx.ingress.kubernetes.io/proxy-connect-timeout: "60"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "60"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "60"
    nginx.ingress.kubernetes.io/rate-limit: "1000"
    nginx.ingress.kubernetes.io/rate-limit-window: "1m"
spec:
  tls:
  - hosts:
    - yourdomain.com
    - www.yourdomain.com
    secretName: diapp-tls-secret
  rules:
  - host: yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: diapp-app
            port:
              number: 8000
  - host: www.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: diapp-app
            port:
              number: 8000
```

#### Persistent Volume Claims
```yaml
# k8s/postgres/pvc.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: diapp-postgres-pvc
  namespace: diapp
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
  storageClassName: standard
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: diapp-redis-pvc
  namespace: diapp
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 5Gi
  storageClassName: standard
```

### Шаг 4: Helm Chart (опционально)

#### Структура Helm Chart
```
helm-chart/
├── Chart.yaml
├── values.yaml
├── templates/
│   ├── namespace.yaml
│   ├── configmap.yaml
│   ├── secret.yaml
│   ├── postgres/
│   │   ├── deployment.yaml
│   │   ├── service.yaml
│   │   └── pvc.yaml
│   ├── redis/
│   │   ├── deployment.yaml
│   │   └── service.yaml
│   ├── app/
│   │   ├── deployment.yaml
│   │   ├── service.yaml
│   │   └── hpa.yaml
│   └── ingress.yaml
└── .helmignore
```

#### Chart.yaml
```yaml
# helm-chart/Chart.yaml
apiVersion: v2
name: diapp
description: Merged DI Application
type: application
version: 1.0.0
appVersion: "1.0.0"
home: https://github.com/your-org/diapp
sources:
  - https://github.com/your-org/diapp
maintainers:
  - name: Your Name
    email: your.email@domain.com
```

#### values.yaml
```yaml
# helm-chart/values.yaml
# Глобальные настройки
global:
  imageRegistry: ""
  imagePullSecrets: []
  storageClass: ""

# Настройки namespace
namespace:
  create: true
  name: diapp

# Настройки образа
image:
  registry: docker.io
  repository: username/diapp
  tag: "latest"
  pullPolicy: IfNotPresent

# Настройки реплик
replicaCount: 3

# Настройки ресурсов
resources:
  limits:
    cpu: 500m
    memory: 1Gi
  requests:
    cpu: 250m
    memory: 512Mi

# Настройки автоскейлинга
autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70
  targetMemoryUtilizationPercentage: 80

# Настройки базы данных
postgresql:
  enabled: true
  auth:
    username: diapp
    password: postgres_password_here
    database: diapp
  primary:
    persistence:
      enabled: true
      size: 20Gi
  resources:
    requests:
      memory: 512Mi
      cpu: 250m
    limits:
      memory: 2Gi
      cpu: 1000m

# Настройки Redis
redis:
  enabled: true
  auth:
    password: redis_password_here
  master:
    persistence:
      enabled: true
      size: 5Gi
  resources:
    requests:
      memory: 256Mi
      cpu: 100m
    limits:
      memory: 1Gi
      cpu: 500m

# Настройки Ingress
ingress:
  enabled: true
  className: nginx
  annotations:
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/force-ssl-redirect: "true"
  hosts:
    - host: yourdomain.com
      paths:
        - path: /
          pathType: Prefix
    - host: www.yourdomain.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: diapp-tls-secret
      hosts:
        - yourdomain.com
        - www.yourdomain.com

# Настройки мониторинга
monitoring:
  enabled: true
  serviceMonitor:
    enabled: true
    interval: 30s
    path: /metrics

# Настройки логов
logging:
  level: INFO
  format: json
  output: stdout

# Настройки безопасности
security:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  runAsNonRoot: true
  runAsUser: 1000
  capabilities:
    drop:
    - ALL
```

### Шаг 5: Скрипты развертывания

#### Скрипт развертывания
```bash
#!/bin/bash
# k8s/scripts/deploy.sh

set -e

NAMESPACE="diapp"
APP_NAME="diapp"

echo "🚀 Начинаем развертывание в Kubernetes..."

# Проверка kubectl
if ! command -v kubectl &> /dev/null; then
    echo "❌ kubectl не установлен"
    exit 1
fi

# Создание namespace
echo "📦 Создание namespace..."
kubectl apply -f k8s/namespace.yaml

# Применение ConfigMap и Secrets
echo "🔧 Применение конфигурации..."
kubectl apply -f k8s/configmap.yaml -n $NAMESPACE
kubectl apply -f k8s/secret.yaml -n $NAMESPACE

# Развертывание PostgreSQL
echo "🗄️ Развертывание PostgreSQL..."
kubectl apply -f k8s/postgres/ -n $NAMESPACE

# Развертывание Redis
echo "⚡ Развертывание Redis..."
kubectl apply -f k8s/redis/ -n $NAMESPACE

# Ожидание готовности PostgreSQL
echo "⏳ Ожидание готовности PostgreSQL..."
kubectl wait --for=condition=ready pod -l app=postgres,component=database -n $NAMESPACE --timeout=300s

# Ожидание готовности Redis
echo "⏳ Ожидание готовности Redis..."
kubectl wait --for=condition=ready pod -l app=redis,component=cache -n $NAMESPACE --timeout=300s

# Развертывание приложения
echo "🚀 Развертывание приложения..."
kubectl apply -f k8s/app/ -n $NAMESPACE

# Развертывание Ingress
echo "🌐 Развертывание Ingress..."
kubectl apply -f k8s/ingress/ -n $NAMESPACE

# Ожидание готовности приложения
echo "⏳ Ожидание готовности приложения..."
kubectl wait --for=condition=ready pod -l app=diapp,component=application -n $NAMESPACE --timeout=300s

# Проверка статуса
echo "📊 Проверка статуса развертывания..."
kubectl get all -n $NAMESPACE

# Получение информации о сервисах
echo "🔗 Информация о сервисах:"
kubectl get svc -n $NAMESPACE

# Получение информации о ingress
echo "🌐 Информация об Ingress:"
kubectl get ingress -n $NAMESPACE

echo "✅ Развертывание завершено успешно!"

# Получение URL для доступа (для локального окружения)
if command -v minikube &> /dev/null; then
    echo ""
    echo "🔗 URL для доступа:"
    echo "  - Приложение: $(minikube service diapp-app --url -n $NAMESPACE)"
    echo "  - Health Check: $(minikube service diapp-app --url -n $NAMESPACE)/health"
fi
```

#### Скрипт очистки
```bash
#!/bin/bash
# k8s/scripts/cleanup.sh

set -e

NAMESPACE="diapp"

echo "🧹 Начинаем очистку ресурсов..."

# Удаление ingress
echo "🌐 Удаление Ingress..."
kubectl delete -f k8s/ingress/ -n $NAMESPACE 2>/dev/null || true

# Удаление приложения
echo "🚀 Удаление приложения..."
kubectl delete -f k8s/app/ -n $NAMESPACE 2>/dev/null || true

# Удаление Redis
echo "⚡ Удаление Redis..."
kubectl delete -f k8s/redis/ -n $NAMESPACE 2>/dev/null || true

# Удаление PostgreSQL
echo "🗄️ Удаление PostgreSQL..."
kubectl delete -f k8s/postgres/ -n $NAMESPACE 2>/dev/null || true

# Удаление ConfigMap и Secrets
echo "🔧 Удаление конфигурации..."
kubectl delete -f k8s/configmap.yaml -n $NAMESPACE 2>/dev/null || true
kubectl delete -f k8s/secret.yaml -n $NAMESPACE 2>/dev/null || true

# Удаление namespace
echo "📦 Удаление namespace..."
kubectl delete -f k8s/namespace.yaml 2>/dev/null || true

echo "✅ Очистка завершена!"
```

#### Скрипт миграции данных
```bash
#!/bin/bash
# k8s/scripts/migrate.sh

set -e

NAMESPACE="diapp"

echo "🔄 Начинаем миграцию данных..."

# Запуск job для миграции
kubectl apply -f k8s/migrations/migration-job.yaml -n $NAMESPACE

# Ожидание завершения миграции
echo "⏳ Ожидание завершения миграции..."
kubectl wait --for=condition=complete job/migration-job -n $NAMESPACE --timeout=600s

# Проверка логов миграции
echo "📋 Логи миграции:"
kubectl logs job/migration-job -n $NAMESPACE

# Удаление job после завершения
kubectl delete job migration-job -n $NAMESPACE

echo "✅ Миграция данных завершена!"
```

#### Makefile для Kubernetes
```makefile
# Makefile.k8s
.PHONY: help build deploy rollback status logs shell clean update backup restore dev prod

# Переменные
NAMESPACE=diapp
APP_NAME=diapp
IMAGE_TAG=latest

# По умолчанию
help:
	@echo "Доступные команды Kubernetes:"
	@echo "  build       - Сборка Docker образа"
	@echo "  deploy      - Развертывание в кластере"
	@echo "  rollback    - Откат к предыдущей версии"
	@echo "  status      - Проверка статуса развертывания"
	@echo "  logs        - Просмотр логов подов"
	@echo "  shell       - Вход в под приложения"
	@echo "  scale       - Масштабирование подов"
	@echo "  update      - Обновление образа"
	@echo "  backup      - Создание бэкапа данных"
	@echo "  restore     - Восстановление из бэкапа"
	@echo "  dev         - Развертывание в режиме разработки"
	@echo "  prod        - Развертывание в режиме продакшена"
	@echo "  clean       - Очистка всех ресурсов"

# Основные команды
build:
	docker build -t $(APP_NAME):$(IMAGE_TAG) .

load:
	minikube image load $(APP_NAME):$(IMAGE_TAG)

deploy: build load
	./k8s/scripts/deploy.sh

deploy-dev:
	./k8s/scripts/deploy.sh --dev

deploy-prod:
	./k8s/scripts/deploy.sh --prod

rollback:
	kubectl rollout undo deployment/diapp-app -n $(NAMESPACE)

status:
	kubectl get all -n $(NAMESPACE)
	kubectl get events -n $(NAMESPACE) --sort-by='.lastTimestamp'

logs:
	kubectl logs -f deployment/$(APP_NAME)-app -n $(NAMESPACE)

logs-postgres:
	kubectl logs -f deployment/$(APP_NAME)-postgres -n $(NAMESPACE)

logs-redis:
	kubectl logs -f deployment/$(APP_NAME)-redis -n $(NAMESPACE)

shell:
	kubectl exec -it deployment/$(APP_NAME)-app -n $(NAMESPACE) -- /bin/bash

# Масштабирование
scale-up:
	kubectl scale deployment $(APP_NAME)-app --replicas=5 -n $(NAMESPACE)

scale-down:
	kubectl scale deployment $(APP_NAME)-app --replicas=2 -n $(NAMESPACE)

autoscaling-on:
	kubectl apply -f k8s/app/hpa.yaml -n $(NAMESPACE)

autoscaling-off:
	kubectl delete -f k8s/app/hpa.yaml -n $(NAMESPACE)

# Обновление
update:
	docker build -t $(APP_NAME):$(IMAGE_TAG) .
	minikube image load $(APP_NAME):$(IMAGE_TAG)
	kubectl set image deployment/$(APP_NAME)-app $(APP_NAME)=$(APP_NAME):$(IMAGE_TAG) -n $(NAMESPACE)

# Мониторинг
events:
	kubectl get events -n $(NAMESPACE) --sort-by='.lastTimestamp' | tail -20

describe:
	kubectl describe deployment $(APP_NAME)-app -n $(NAMESPACE)

# Мониторинг ресурсов
top:
	kubectl top pods -n $(NAMESPACE)

top-nodes:
	kubectl top nodes

# Health checks
health:
	kubectl get pods -n $(NAMESPACE)
	kubectl describe pods -n $(NAMESPACE) | grep -A 5 "Conditions:"

# Бэкап и восстановление
backup:
	./k8s/scripts/backup.sh

restore:
	./k8s/scripts/restore.sh

# Отладка
debug:
	kubectl debug -it $(APP_NAME)-app-xxx -n $(NAMESPACE) --image=busybox

port-forward:
	kubectl port-forward service/$(APP_NAME)-app 8000:8000 -n $(NAMESPACE)

# Очистка
clean:
	./k8s/scripts/cleanup.sh

# Информация
info:
	@echo "Информация о кластере:"
	kubectl cluster-info
	kubectl get nodes
	@echo ""
	@echo "Пространства имен:"
	kubectl get namespaces
	@echo ""
	@echo "Развертывания в namespace $(NAMESPACE):"
	kubectl get deployments -n $(NAMESPACE)
```

## Запуск

### Развертывание в локальном кластере
```bash
# Запуск Minikube
minikube start --driver=docker --memory=4096 --cpus=2

# Сборка и загрузка образа
make build
make load

# Развертывание
make deploy

# Проверка статуса
make status
make health
```

### Развертывание с Helm
```bash
# Установка зависимостей
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

# Установка приложения
helm install diapp ./helm-chart/ \
  --namespace $(NAMESPACE) \
  --create-namespace \
  --set image.tag=$(IMAGE_TAG)

# Обновление значений
helm upgrade diapp ./helm-chart/ \
  --namespace $(NAMESPACE) \
  --set replicaCount=5 \
  --set resources.limits.cpu=1000m \
  --set resources.limits.memory=2Gi

# Удаление
helm uninstall diapp --namespace $(NAMESPACE)
```

## Проверка

### Проверка состояния подов
```bash
# Просмотр всех подов
kubectl get pods -n diapp

# Детальная информация о подах
kubectl describe pods -n diapp

# Логи подов
kubectl logs -f deployment/diapp-app -n diapp

# Логи конкретного пода
kubectl logs diapp-app-xxx -n diapp
```

### Health Checks
```bash
# Проверка readiness и liveness probes
kubectl get pods -n diapp -o wide

# Проверка HTTP статуса
kubectl port-forward service/diapp-app 8000:8000 -n diapp &
curl http://localhost:8000/health

# Проверка базы данных
kubectl exec -it deployment/diapp-postgres -n diapp -- pg_isready -U diapp

# Проверка Redis
kubectl exec -it deployment/diapp-redis -n diapp -- redis-cli ping
```

### Функциональное тестирование
```bash
# Вход в под приложения
make shell

# Запуск тестов внутри пода
python -m pytest tests/ -v

# Проверка переменных окружения
env | grep -E "(DATABASE|REDIS|SECRET)"

# Проверка файловой структуры
ls -la /app
```

## Мониторинг

### Встроенный мониторинг
```bash
# Просмотр метрик пода
kubectl top pod diapp-app-xxx -n diapp

# Просмотр метрик всех подов
make top

# Просмотр событий
make events

# Проверка ресурсов
kubectl get hpa -n diapp
kubectl describe hpa diapp-app-hpa -n diapp
```

### Prometheus интеграция
```yaml
# Добавление в deployment.yaml приложения
annotations:
  prometheus.io/scrape: "true"
  prometheus.io/port: "8000"
  prometheus.io/path: "/metrics"
```

### Grafana дашборды
```bash
# Установка Grafana через Helm
helm install grafana prometheus-community/kube-prometheus-stack \
  --namespace monitoring --create-namespace

# Получение пароля Grafana
kubectl get secret grafana-admin-credentials -n monitoring -o jsonpath='{.data.admin-password}' | base64 -d
```

## Управление

### Масштабирование
```bash
# Горизонтальное масштабирование
kubectl scale deployment diapp-app --replicas=5 -n diapp

# Автомасштабирование
make autoscaling-on

# Проверка HPA
kubectl get hpa -n diapp
```

### Обновление
```bash
# Обновление образа
make update

# Rolling Update с проверкой
kubectl set image deployment/diapp-app diapp=diapp:new-tag -n diapp
kubectl rollout status deployment/diapp-app -n diapp

# Откат в случае проблем
make rollback
```

### Резервное копирование
```bash
# Бэкап базы данных
kubectl exec deployment/diapp-postgres -n diapp -- pg_dump -U diapp diapp > backup.sql

# Бэкап PV (Persistent Volume)
kubectl create --from-file=backup.sql backup-job
```

### Мониторинг и алерты
```bash
# Создание ServiceMonitor
kubectl apply -f k8s/monitoring/servicemonitor.yaml

# Настройка алертов
kubectl apply -f k8s/monitoring/alerts.yaml
```

## Решение проблем

### Частые проблемы

#### Pod в состоянии Pending
```bash
# Проверка причин
kubectl describe pod <pod-name> -n diapp

# Возможные причины:
# - Недостаточно ресурсов
# - Проблемы с PV/PVC
# - Ошибки в конфигурации
```

#### Ошибки ImagePullBackOff
```bash
# Проверка образов
kubectl describe pod <pod-name> -n diapp

# Возможные решения:
# - Проверить название и тег образа
# - Проверить доступность registry
# - Настроить imagePullSecrets
```

#### Проблемы с ресурсами
```bash
# Проверка использования ресурсов
kubectl top pods -n diapp

# Проверка лимитов
kubectl describe pod <pod-name> -n diapp | grep -A 10 Limits

# Изменение ресурсов
kubectl patch deployment diapp-app -p '{"spec":{"template":{"spec":{"containers":[{"name":"diapp","resources":{"limits":{"memory":"2Gi"},"requests":{"memory":"1Gi"}}}]}}}}' -n diapp
```

### Отладка

#### Вход в отладочный контейнер
```bash
# Создание отладочного пода
kubectl run debug --rm -it --image=busybox --restart=Never -n diapp -- sh

# Подключение к запущенному контейнеру
kubectl debug diapp-app-xxx -it --image=busybox -n diapp
```

#### Анализ сетевых проблем
```bash
# Проверка сетевых политик
kubectl get networkpolicies -n diapp

# Проверка сервисов
kubectl get svc -n diapp
kubectl describe svc diapp-app -n diapp

# Проверка endpoints
kubectl get endpoints -n diapp
```

#### Анализ логов
```bash
# Логи с временными метками
kubectl logs -f diapp-app-xxx -n diapp --timestamps

# Логи предыдущего контейнера
kubectl logs diapp-app-xxx -n diapp --previous

# Логи всех подов приложения
kubectl logs -l app=diapp,component=application -n diapp --tail=100
```

## Производительность

### Оптимизация ресурсов
```yaml
# Оптимизированный deployment
resources:
  requests:
    memory: "256Mi"
    cpu: "100m"
  limits:
    memory: "512Mi"
    cpu: "500m"
```

### Настройка HPA
```yaml
# Тонкая настройка автоскейлинга
metrics:
- type: Resource
  resource:
    name: cpu
    target:
      type: Utilization
      averageUtilization: 50  # Снижено для более раннего масштабирования
```

### Мониторинг производительности
```bash
# Профилирование приложения
kubectl exec -it deployment/diapp-app -n diapp -- python -m cProfile -o profile.stats main.py

# Анализ использования памяти
kubectl exec -it deployment/diapp-app -n diapp -- python -c "import tracemalloc; tracemalloc.start(); ..."
```

## Безопасность

### Network Policies
```yaml
# k8s/security/network-policy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: diapp-network-policy
  namespace: diapp
spec:
  podSelector:
    matchLabels:
      app: diapp
      component: application
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 8000
  egress:
  - to:
    - podSelector:
        matchLabels:
          app: postgres
    ports:
    - protocol: TCP
      port: 5432
  - to:
    - podSelector:
        matchLabels:
          app: redis
    ports:
    - protocol: TCP
      port: 6379
```

### RBAC
```yaml
# k8s/security/rbac.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: diapp
  name: diapp-role
rules:
- apiGroups: [""]
  resources: ["configmaps", "secrets"]
  verbs: ["get", "list"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: diapp-rolebinding
  namespace: diapp
subjects:
- kind: ServiceAccount
  name: diapp-sa
  namespace: diapp
roleRef:
  kind: Role
  name: diapp-role
  apiGroup: rbac.authorization.k8s.io
```

### Security Context
```yaml
# Добавление в pod spec
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  fsGroup: 1000
  capabilities:
    drop:
    - ALL
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
```

---

**Поддержка**: Регулярно обновляйте образы и проверяйте конфигурации безопасности в кластере.
