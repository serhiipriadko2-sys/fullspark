"""
Реестр сервисов для централизованного управления зависимостями

Обеспечивает автоматическую регистрацию сервисов из Version 1 и Version 2
с поддержкой backward compatibility.
"""

import logging
from typing import Any, Dict, List, Optional, Type, Union
from abc import ABC, abstractmethod
from enum import Enum
import importlib
import inspect
from pathlib import Path

from .di_container import DIContainer, ServiceLifetime, VersionCompatibility

class ServiceCategory(Enum):
    """Категории сервисов для группировки"""
    MEMORY = "memory"                    # Система памяти
    SEARCH = "search"                    # Система поиска
    API = "api"                         # API слой
    SECURITY = "security"               # Безопасность
    CONFIG = "config"                   # Конфигурация
    UTILITIES = "utilities"             # Утилиты
    COGNITIVE = "cognitive"             # Когнитивные функции

class ServiceInfo:
    """Информация о сервисе для регистрации"""
    
    def __init__(
        self,
        name: str,
        service_type: Type,
        implementation: Union[Type, str],
        version_compatibility: VersionCompatibility,
        category: ServiceCategory,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None,
        description: str = ""
    ):
        self.name = name
        self.service_type = service_type
        self.implementation = implementation
        self.version_compatibility = version_compatibility
        self.category = category
        self.config = config or {}
        self.dependencies = dependencies or []
        self.description = description
        self.registered = False

class ServiceRegistry:
    """
    Реестр сервисов для автоматической регистрации и управления
    
    Особенности:
    - Автоматическое обнаружение сервисов
    - Конфигурируемая регистрация
    - Поддержка множественных версий
    - Backward compatibility mapping
    """
    
    def __init__(self, container: DIContainer):
        self.container = container
        self.logger = logging.getLogger(__name__)
        self._services: Dict[str, ServiceInfo] = {}
        self._auto_registered = False
        
        # Мапинг Version 1 -> Version 2 сервисов
        self._version_mappings = {
            'legacy_memory': 'modern_memory',
            'legacy_search': 'modern_search',
            'legacy_config': 'modern_config',
            'legacy_security': 'modern_security'
        }
        
        # Пути к модулям для автообнаружения
        self._scan_paths = [
            'lib',           # Version 1 компоненты
            'optimized',     # Version 2 компоненты  
            'architecture',  # Архитектурные компоненты
            'fixed'          # Исправленные компоненты
        ]
    
    def register_service(
        self,
        name: str,
        service_type: Type,
        implementation: Union[Type, str] = None,
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT,
        version_compatibility: VersionCompatibility = VersionCompatibility.UNIVERSAL,
        category: ServiceCategory = ServiceCategory.UTILITIES,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None,
        description: str = ""
    ) -> 'ServiceRegistry':
        """
        Регистрация сервиса в реестре
        
        Args:
            name: Уникальное имя сервиса
            service_type: Тип сервиса (интерфейс)
            implementation: Реализация сервиса
            lifetime: Время жизни сервиса
            version_compatibility: Совместимость с версиями
            category: Категория сервиса
            config: Конфигурация
            dependencies: Зависимости
            description: Описание сервиса
        """
        if implementation is None:
            implementation = service_type
        
        service_info = ServiceInfo(
            name=name,
            service_type=service_type,
            implementation=implementation,
            version_compatibility=version_compatibility,
            category=category,
            config=config,
            dependencies=dependencies,
            description=description
        )
        
        self._services[name] = service_info
        self.logger.debug(f"Registered service info: {name}")
        
        return self
    
    def register_memory_services(self):
        """Регистрация сервисов системы памяти"""
        
        # Version 1 (Legacy) Memory Service
        self.register_service(
            name="legacy_memory",
            service_type=Type,  # Будет определен при импорте
            implementation="lib.memory.MemoryManager",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.V1_ONLY,
            category=ServiceCategory.MEMORY,
            description="Legacy memory system from Version 1"
        )
        
        # Version 2 (Modern) Memory Service
        self.register_service(
            name="modern_memory",
            service_type=Type,  # Будет определен при импорте
            implementation="optimized.memory.OptimizedMemoryManager",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.V2_ONLY,
            category=ServiceCategory.MEMORY,
            description="Modern memory system from Version 2"
        )
        
        # Unified Memory Service (HYBRID)
        self.register_service(
            name="unified_memory",
            service_type=Type,  # Будет определен при импорте
            implementation="core.memory.UnifiedMemoryManager",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.MEMORY,
            config={'mode': 'hybrid'},
            description="Unified memory service supporting both versions"
        )
    
    def register_search_services(self):
        """Регистрация сервисов системы поиска"""
        
        # Version 1 (Legacy) Search Service
        self.register_service(
            name="legacy_search",
            service_type=Type,
            implementation="lib.vector_search.VectorSearch",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.V1_ONLY,
            category=ServiceCategory.SEARCH,
            description="Legacy vector search from Version 1"
        )
        
        # Version 2 (Modern) Search Service
        self.register_service(
            name="modern_search",
            service_type=Type,
            implementation="optimized.vector_search.OptimizedVectorSearch",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.V2_ONLY,
            category=ServiceCategory.SEARCH,
            description="Modern optimized vector search from Version 2"
        )
        
        # Unified Search Service (HYBRID)
        self.register_service(
            name="unified_search",
            service_type=Type,
            implementation="core.search.UnifiedVectorSearch",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.SEARCH,
            config={'mode': 'hybrid'},
            description="Unified search service supporting both versions"
        )
    
    def register_api_services(self):
        """Регистрация API сервисов"""
        
        self.register_service(
            name="api_router",
            service_type=Type,
            implementation="core.api.ApiRouter",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.API,
            description="Unified API router supporting both versions"
        )
        
        self.register_service(
            name="auth_service",
            service_type=Type,
            implementation="core.security.AuthService",
            lifetime=ServiceLifetime.SCOPED,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.SECURITY,
            description="Authentication service with backward compatibility"
        )
    
    def register_security_services(self):
        """Регистрация сервисов безопасности"""
        
        self.register_service(
            name="jwt_manager",
            service_type=Type,
            implementation="core.security.JWTManager",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.SECURITY,
            config={'secure_mode': True},
            description="Secure JWT manager replacing hardcoded secrets"
        )
        
        self.register_service(
            name="cors_manager",
            service_type=Type,
            implementation="core.security.CORSManager",
            lifetime=ServiceLifetime.SINGLETON,
            version_compatibility=VersionCompatibility.HYBRID,
            category=ServiceCategory.SECURITY,
            config={'restrict_origins': True},
            description="CORS manager with configurable policies"
        )
        
        self.register_service(
            name="rate_limiter",
            service_type=Type,
            implementation="core.security.RateLimiter",
            lifetime=ServiceLifetime.SCOPED,
            version_compatibility=VersionCompatibility.V2_ONLY,
            category=ServiceCategory.SECURITY,
            description="Rate limiting service"
        )
    
    def register_all_services(self):
        """Регистрация всех сервисов"""
        self.register_memory_services()
        self.register_search_services()
        self.register_api_services()
        self.register_security_services()
        
        self.logger.info(f"Registered {len(self._services)} services in registry")
    
    def auto_discover_services(self, base_path: str = "."):
        """Автоматическое обнаружение сервисов в коде"""
        
        self.logger.info("Starting auto-discovery of services...")
        
        for scan_path in self._scan_paths:
            path = Path(base_path) / scan_path
            if path.exists():
                self._scan_directory(path, scan_path)
        
        self._auto_registered = True
        self.logger.info(f"Auto-discovered {len(self._services)} services")
    
    def _scan_directory(self, path: Path, namespace: str):
        """Сканирование директории для поиска сервисов"""
        
        for file_path in path.rglob("*.py"):
            if file_path.name.startswith("_"):
                continue
                
            try:
                module_name = str(file_path.relative_to(path.parent)).replace("/", ".").replace(".py", "")
                self._scan_module(module_name, file_path)
            except Exception as e:
                self.logger.warning(f"Failed to scan module {file_path}: {e}")
    
    def _scan_module(self, module_name: str, file_path: Path):
        """Сканирование модуля для поиска сервисов"""
        
        try:
            module = importlib.import_module(module_name)
            
            # Поиск классов, помеченных как сервисы
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if hasattr(obj, '_is_service') and obj._is_service:
                    service_config = getattr(obj, '_service_config', {})
                    self.register_service(
                        name=service_config.get('name', name.lower()),
                        service_type=obj,
                        version_compatibility=VersionCompatibility.UNIVERSAL,
                        category=ServiceCategory(service_config.get('category', 'utilities')),
                        description=service_config.get('description', '')
                    )
                    
        except ImportError as e:
            self.logger.debug(f"Could not import {module_name}: {e}")
        except Exception as e:
            self.logger.warning(f"Error scanning {module_name}: {e}")
    
    def resolve_service_name(self, name: str, version_mode: VersionCompatibility = None) -> Optional[str]:
        """
        Разрешение имени сервиса на основе режима версии
        
        Args:
            name: Базовое имя сервиса
            version_mode: Режим совместимости версий
            
        Returns:
            Имя соответствующего сервиса или None
        """
        if version_mode is None:
            version_mode = VersionCompatibility.HYBRID
        
        # Поиск точного совпадения
        if name in self._services:
            service_info = self._services[name]
            if self._is_compatible(service_info.version_compatibility, version_mode):
                return name
        
        # Поиск в мапинге версий
        if name in self._version_mappings:
            mapped_name = self._version_mappings[name]
            if mapped_name in self._services:
                service_info = self._services[mapped_name]
                if self._is_compatible(service_info.version_compatibility, version_mode):
                    return mapped_name
        
        # Поиск по префиксам
        for service_name, service_info in self._services.items():
            if service_name.startswith(name) and service_name.endswith(version_mode.value.split('_')[0]):
                if self._is_compatible(service_info.version_compatibility, version_mode):
                    return service_name
        
        return None
    
    def _is_compatible(self, service_compatibility: VersionCompatibility, requested_mode: VersionCompatibility) -> bool:
        """Проверка совместимости сервиса с запрошенным режимом"""
        
        if service_compatibility == VersionCompatibility.UNIVERSAL:
            return True
        elif service_compatibility == requested_mode:
            return True
        elif requested_mode == VersionCompatibility.HYBRID:
            # В гибридном режиме поддерживаются все, кроме V1_ONLY и V2_ONLY
            return service_compatibility in [VersionCompatibility.HYBRID, VersionCompatibility.UNIVERSAL]
        
        return False
    
    def get_service(self, name: str) -> Optional[ServiceInfo]:
        """Получение информации о сервисе"""
        return self._services.get(name)
    
    def get_services_by_category(self, category: ServiceCategory) -> List[ServiceInfo]:
        """Получение сервисов по категории"""
        return [info for info in self._services.values() if info.category == category]
    
    def get_all_services(self) -> Dict[str, ServiceInfo]:
        """Получение всех сервисов"""
        return self._services.copy()
    
    def get_registry_stats(self) -> Dict[str, Any]:
        """Получение статистики реестра"""
        categories = {}
        for service_info in self._services.values():
            category = service_info.category.value
            if category not in categories:
                categories[category] = {'total': 0, 'registered': 0}
            categories[category]['total'] += 1
            if service_info.registered:
                categories[category]['registered'] += 1
        
        return {
            'total_services': len(self._services),
            'auto_discovered': self._auto_registered,
            'categories': categories,
            'version_mappings': self._version_mappings
        }