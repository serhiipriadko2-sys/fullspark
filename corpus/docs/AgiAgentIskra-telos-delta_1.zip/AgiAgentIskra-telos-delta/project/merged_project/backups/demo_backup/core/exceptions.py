"""
Исключения для интегрированной архитектуры проекта Искра.

Централизованная обработка ошибок для обеспечения согласованного API.
"""

from typing import Any, Dict, Optional
from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse


class IskraException(Exception):
    """Базовое исключение для проекта Искра."""
    
    def __init__(
        self, 
        message: str, 
        status_code: int = 500,
        details: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None
    ):
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        self.error_code = error_code or self.__class__.__name__
        super().__init__(self.message)
    
    def to_http_exception(self) -> JSONResponse:
        """Конвертация в HTTP исключение."""
        return JSONResponse(
            status_code=self.status_code,
            content={
                "error": {
                    "message": self.message,
                    "code": self.error_code,
                    "details": self.details
                }
            }
        )


class AuthenticationError(IskraException):
    """Ошибки аутентификации."""
    
    def __init__(self, message: str = "Authentication failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=401, details=details, error_code="AUTHENTICATION_ERROR")


class AuthorizationError(IskraException):
    """Ошибки авторизации."""
    
    def __init__(self, message: str = "Insufficient permissions", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=403, details=details, error_code="AUTHORIZATION_ERROR")


class ValidationError(IskraException):
    """Ошибки валидации данных."""
    
    def __init__(self, message: str = "Validation failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=422, details=details, error_code="VALIDATION_ERROR")


class NotFoundError(IskraException):
    """Ошибки отсутствия ресурсов."""
    
    def __init__(self, message: str = "Resource not found", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=404, details=details, error_code="NOT_FOUND_ERROR")


class SearchError(IskraException):
    """Ошибки поиска."""
    
    def __init__(self, message: str = "Search operation failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=500, details=details, error_code="SEARCH_ERROR")


class MemoryError(IskraException):
    """Ошибки работы с памятью."""
    
    def __init__(self, message: str = "Memory operation failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=500, details=details, error_code="MEMORY_ERROR")


class ChatError(IskraException):
    """Ошибки чат системы."""
    
    def __init__(self, message: str = "Chat operation failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=500, details=details, error_code="CHAT_ERROR")


class ConfigurationError(IskraException):
    """Ошибки конфигурации."""
    
    def __init__(self, message: str = "Configuration error", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=500, details=details, error_code="CONFIGURATION_ERROR")


class CompatibilityError(IskraException):
    """Ошибки обратной совместимости."""
    
    def __init__(self, message: str = "Compatibility error", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=500, details=details, error_code="COMPATIBILITY_ERROR")


# Утилиты для обработки исключений
def handle_legacy_exception(exc: Exception) -> IskraException:
    """Конвертация legacy исключений в IskraException."""
    
    # Обработка JWT исключений
    if "expired" in str(exc).lower():
        return AuthenticationError("Token has expired", details={"token_status": "expired"})
    
    if "invalid" in str(exc).lower():
        return AuthenticationError("Invalid token", details={"token_status": "invalid"})
    
    # Обработка file not found
    if "no such file" in str(exc).lower() or "not found" in str(exc).lower():
        return NotFoundError(f"Resource not found: {str(exc)}")
    
    # Обработка permission errors
    if "permission" in str(exc).lower():
        return AuthorizationError(f"Permission denied: {str(exc)}")
    
    # Обработка validation errors
    if "validation" in str(exc).lower() or "validator" in str(exc).lower():
        return ValidationError(f"Validation failed: {str(exc)}")
    
    # По умолчанию - общее исключение
    return IskraException(
        f"Unexpected error: {str(exc)}",
        details={"exception_type": type(exc).__name__}
    )