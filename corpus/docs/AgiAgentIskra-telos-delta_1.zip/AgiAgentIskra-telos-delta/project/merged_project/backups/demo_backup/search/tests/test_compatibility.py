"""Тесты совместимости для интегрированной поисковой системы.

Проверяют корректность работы всех режимов поиска,
совместимость между Version 1 и Version 2,
и производительность различных конфигураций.
"""

import pytest
import asyncio
import os
import json
import tempfile
import time
from typing import List, Dict, Any
from unittest.mock import Mock, patch

# Импорт тестируемых модулей
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from search.integrated_search import IntegratedSearch, SearchResult, SearchMetrics
from search.legacy_adapter import LegacyVectorSearch, LegacySearchConfig
from search.modern_adapter import ModernVectorSearch, ModernSearchConfig
from search.performance_config import (
    PerformanceConfig, SearchMode, PerformanceProfile,
    create_fast_config, create_balanced_config
)

class TestIntegratedSearch:
    """Тесты основного класса интегрированного поиска."""
    
    @pytest.fixture
    def temp_evidence_file(self):
        """Создание временного файла с тестовыми данными."""
        test_data = [
            {"doc_id": "test1.md", "chunk_id": 0, "content": "Тестовый документ один"},
            {"doc_id": "test1.md", "chunk_id": 1, "content": "Второй чанк документа"},
            {"doc_id": "test2.md", "chunk_id": 0, "content": "Другой тестовый документ"},
            {"doc_id": "test3.md", "chunk_id": 0, "content": "Третий документ для тестирования"}
        ]
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False) as f:
            for item in test_data:
                f.write(json.dumps(item, ensure_ascii=False) + '\n')
            temp_path = f.name
        
        yield temp_path
        
        # Очистка
        os.unlink(temp_path)
    
    @pytest.fixture
    def performance_config(self):
        """Конфигурация для тестирования."""
        return create_balanced_config()
    
    @pytest.fixture
    def integrated_search(self, performance_config):
        """Инициализация интегрированного поиска."""
        return IntegratedSearch(performance_config)
    
    def test_initialization(self, integrated_search):
        """Тест инициализации поисковой системы."""
        assert integrated_search is not None
        assert integrated_search.legacy_search is not None
        assert integrated_search.modern_search is not None
        assert integrated_search.config is not None
    
    @pytest.mark.asyncio
    async def test_legacy_search_mode(self, integrated_search, temp_evidence_file):
        """Тест поиска в legacy режиме."""
        config = integrated_search.config
        config.legacy_config.evidence_path = temp_evidence_file
        
        results, metrics = await integrated_search.search(
            "тестовый документ", 
            mode=SearchMode.LEGACY.value,
            k=5
        )
        
        assert isinstance(results, list)
        assert len(results) >= 0
        assert isinstance(metrics, SearchMetrics)
        assert metrics.mode_used == SearchMode.LEGACY.value
    
    @pytest.mark.asyncio
    async def test_modern_search_mode(self, integrated_search, temp_evidence_file):
        """Тест поиска в modern режиме."""
        config = integrated_search.config
        config.modern_config.evidence_path = temp_evidence_file
        
        results, metrics = await integrated_search.search(
            "тестовый документ",
            mode=SearchMode.MODERN.value,
            k=5
        )
        
        assert isinstance(results, list)
        assert isinstance(metrics, SearchMetrics)
        assert metrics.mode_used == SearchMode.MODERN.value
    
    @pytest.mark.asyncio
    async def test_hybrid_search_mode(self, integrated_search, temp_evidence_file):
        """Тест гибридного поиска."""
        config = integrated_search.config
        config.legacy_config.evidence_path = temp_evidence_file
        config.modern_config.evidence_path = temp_evidence_file
        
        results, metrics = await integrated_search.search(
            "тестовый документ",
            mode=SearchMode.HYBRID.value,
            k=5
        )
        
        assert isinstance(results, list)
        assert isinstance(metrics, SearchMetrics)
        assert metrics.mode_used == SearchMode.HYBRID.value
    
    @pytest.mark.asyncio
    async def test_cache_functionality(self, integrated_search, temp_evidence_file):
        """Тест работы кэша."""
        config = integrated_search.config
        config.legacy_config.evidence_path = temp_evidence_file
        
        query = "тестовый документ"
        
        # Первый поиск
        results1, metrics1 = await integrated_search.search(query)
        
        # Второй поиск с тем же запросом (должен браться из кэша)
        results2, metrics2 = await integrated_search.search(query)
        
        assert metrics2.cache_hit == True
        assert len(results1) == len(results2)
    
    @pytest.mark.asyncio
    async def test_performance_monitoring(self, integrated_search, temp_evidence_file):
        """Тест мониторинга производительности."""
        config = integrated_search.config
        config.legacy_config.evidence_path = temp_evidence_file
        
        # Выполнение нескольких поисков
        queries = ["тестовый", "документ", "тестирование"]
        for query in queries:
            await integrated_search.search(query)
        
        # Проверка отчета о производительности
        report = integrated_search.get_performance_report()
        
        assert 'total_searches' in report
        assert report['total_searches'] == 3
        assert 'average_search_time_ms' in report
        assert 'mode_distribution' in report

class TestLegacyAdapter:
    """Тесты адаптера для Version 1."""
    
    def test_legacy_config_creation(self):
        """Тест создания конфигурации legacy поиска."""
        config = LegacySearchConfig(
            k=10,
            use_graph=True,
            use_vector=False,
            evidence_path="test_path.jsonl"
        )
        
        assert config.k == 10
        assert config.use_graph == True
        assert config.use_vector == False
        assert config.evidence_path == "test_path.jsonl"
    
    def test_legacy_initialization(self):
        """Тест инициализации legacy поиска."""
        config = LegacySearchConfig()
        searcher = LegacyVectorSearch(config)
        
        assert searcher.config == config
        assert searcher._evidence_cache == {}
    
    def test_evidence_statistics(self, temp_evidence_file):
        """Тест получения статистики evidence."""
        config = LegacySearchConfig(evidence_path=temp_evidence_file)
        searcher = LegacyVectorSearch(config)
        
        stats = searcher.get_evidence_statistics()
        
        assert 'documents_count' in stats
        assert 'chunks_count' in stats
        assert stats['chunks_count'] == 4  # из тестовых данных
    
    @pytest.mark.asyncio
    async def test_fallback_search(self):
        """Тест fallback поиска при ошибках."""
        config = LegacySearchConfig(evidence_path="nonexistent.jsonl")
        searcher = LegacyVectorSearch(config)
        
        results = await searcher.search("test query")
        
        # Fallback должен вернуть пустой список, а не вызвать исключение
        assert isinstance(results, list)
        assert len(results) == 0

class TestModernAdapter:
    """Тесты адаптера для Version 2."""
    
    def test_modern_config_creation(self):
        """Тест создания конфигурации modern поиска."""
        config = ModernSearchConfig(
            cache_size=2000,
            max_workers=8,
            enable_indexing=False
        )
        
        assert config.cache_size == 2000
        assert config.max_workers == 8
        assert config.enable_indexing == False
    
    def test_modern_initialization(self):
        """Тест инициализации modern поиска."""
        config = ModernSearchConfig()
        searcher = ModernVectorSearch(config)
        
        assert searcher.config == config
        assert searcher.searcher is None  # Загружается лениво
        assert searcher._index_built == False
    
    def test_index_status(self):
        """Тест получения статуса индекса."""
        config = ModernSearchConfig()
        searcher = ModernVectorSearch(config)
        
        status = searcher.get_index_status()
        
        assert 'index_built' in status
        assert 'searcher_available' in status
        assert 'enable_indexing' in status
        assert status['index_built'] == False
    
    def test_performance_stats(self):
        """Тест получения статистики производительности."""
        config = ModernSearchConfig()
        searcher = ModernVectorSearch(config)
        
        stats = searcher.get_performance_stats()
        
        assert 'search_count' in stats
        assert 'cache_hits' in stats
        assert stats['search_count'] == 0
    
    @pytest.mark.asyncio
    async def test_index_building(self, temp_evidence_file):
        """Тест построения индекса."""
        config = ModernSearchConfig(evidence_path=temp_evidence_file)
        searcher = ModernVectorSearch(config)
        
        # Попытка построения индекса
        await searcher.build_index()
        
        status = searcher.get_index_status()
        # Индекс может быть построен или нет в зависимости от доступности Version 2
        assert 'index_built' in status

class TestPerformanceConfig:
    """Тесты конфигурации производительности."""
    
    def test_default_config(self):
        """Тест конфигурации по умолчанию."""
        config = PerformanceConfig()
        
        assert config.default_mode == SearchMode.HYBRID
        assert config.default_k == 5
        assert config.cache_size == 500
        assert config.legacy_weight + config.modern_weight == 1.0
    
    def test_fast_config(self):
        """Тест быстрой конфигурации."""
        config = create_fast_config()
        
        assert config.performance_profile == PerformanceProfile.FASTEST
        assert config.default_mode == SearchMode.MODERN
        assert config.cache_size >= 1000
    
    def test_balanced_config(self):
        """Тест сбалансированной конфигурации."""
        config = create_balanced_config()
        
        assert config.performance_profile == PerformanceProfile.BALANCED
        assert config.default_mode == SearchMode.HYBRID
    
    def test_config_validation(self):
        """Тест валидации конфигурации."""
        # Некорректные веса должны вызвать исключение
        with pytest.raises(ValueError):
            config = PerformanceConfig()
            config.legacy_weight = 2.0  # > 1
            config._validate_configuration()
    
    def test_query_optimization(self):
        """Тест оптимизации для типа запроса."""
        config = PerformanceConfig()
        
        # Короткий запрос
        optimizations = config.optimize_for_query_type("тест")
        assert 'mode' in optimizations
        
        # Вопросительный запрос
        optimizations = config.optimize_for_query_type("что такое тест")
        assert optimizations.get('use_graph') == True
        
        # Длинный запрос
        long_query = " ".join(["слово"] * 20)
        optimizations = config.optimize_for_query_type(long_query)
        assert optimizations.get('k') > config.default_k
    
    def test_environment_config(self):
        """Тест загрузки конфигурации из окружения."""
        # Установка переменных окружения
        os.environ['SEARCH_DEFAULT_MODE'] = 'modern'
        os.environ['SEARCH_DEFAULT_K'] = '10'
        os.environ['SEARCH_CACHE_SIZE'] = '1000'
        
        config = PerformanceConfig.from_environment()
        
        assert config.default_mode == SearchMode.MODERN
        assert config.default_k == 10
        assert config.cache_size == 1000
        
        # Очистка
        del os.environ['SEARCH_DEFAULT_MODE']
        del os.environ['SEARCH_DEFAULT_K']
        del os.environ['SEARCH_CACHE_SIZE']

class TestSearchResult:
    """Тесты класса SearchResult."""
    
    def test_search_result_creation(self):
        """Тест создания результата поиска."""
        result = SearchResult(
            doc_id="test.md",
            chunk_id=0,
            content="Тестовый контент",
            score=0.8,
            source="legacy",
            search_mode="legacy"
        )
        
        assert result.doc_id == "test.md"
        assert result.chunk_id == 0
        assert result.content == "Тестовый контент"
        assert result.score == 0.8
        assert result.source == "legacy"
        assert result.search_mode == "legacy"
    
    def test_search_result_with_metadata(self):
        """Тест результата поиска с метаданными."""
        result = SearchResult(
            doc_id="test.md",
            chunk_id=0,
            content="Тестовый контент",
            score=0.8,
            source="legacy",
            search_mode="legacy",
            metadata={"importance": "high"}
        )
        
        assert result.metadata["importance"] == "high"

class TestSearchMetrics:
    """Тесты класса SearchMetrics."""
    
    def test_search_metrics_creation(self):
        """Тест создания метрик поиска."""
        metrics = SearchMetrics(
            search_time_ms=100.5,
            mode_used="modern",
            results_count=5
        )
        
        assert metrics.search_time_ms == 100.5
        assert metrics.mode_used == "modern"
        assert metrics.results_count == 5
        assert metrics.cache_hit == False
    
    def test_metrics_with_additional_info(self):
        """Тест метрик с дополнительной информацией."""
        metrics = SearchMetrics(
            search_time_ms=100.5,
            mode_used="hybrid",
            results_count=5,
            additional_info={"cache_size": 100, "index_built": True}
        )
        
        assert metrics.additional_info["cache_size"] == 100
        assert metrics.additional_info["index_built"] == True

class TestIntegration:
    """Интеграционные тесты."""
    
    @pytest.mark.asyncio
    async def test_full_integration(self, temp_evidence_file):
        """Полный интеграционный тест."""
        # Создание конфигурации
        config = create_balanced_config()
        config.legacy_config.evidence_path = temp_evidence_file
        config.modern_config.evidence_path = temp_evidence_file
        
        # Тестирование всех режимов
        modes = [SearchMode.LEGACY, SearchMode.MODERN, SearchMode.HYBRID]
        
        async with IntegratedSearch(config) as searcher:
            for mode in modes:
                results, metrics = await searcher.search(
                    "тестовый документ",
                    mode=mode.value,
                    k=3
                )
                
                assert isinstance(results, list)
                assert isinstance(metrics, SearchMetrics)
                assert metrics.mode_used == mode.value
                assert len(results) <= 3
        
        # Проверка финального отчета
        final_report = searcher.get_performance_report()
        assert final_report['total_searches'] == len(modes)
    
    @pytest.mark.asyncio
    async def test_error_handling(self, temp_evidence_file):
        """Тест обработки ошибок."""
        config = create_balanced_config()
        config.legacy_config.evidence_path = "nonexistent.jsonl"
        
        async with IntegratedSearch(config) as searcher:
            # Поиск с несуществующим файлом должен работать через fallback
            results, metrics = await searcher.search("test query")
            
            assert isinstance(results, list)
            assert isinstance(metrics, SearchMetrics)
            assert metrics.mode_used in ['fallback', 'error']

# Утилиты для тестирования
def create_test_evidence_file(num_docs: int = 10, chunks_per_doc: int = 5) -> str:
    """Создание тестового файла evidence для тестирования."""
    test_data = []
    
    for doc_id in range(num_docs):
        for chunk_id in range(chunks_per_doc):
            content = f"Документ {doc_id}, чанк {chunk_id}. Тестовый контент для поиска."
            test_data.append({
                "doc_id": f"doc_{doc_id}.md",
                "chunk_id": chunk_id,
                "content": content
            })
    
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
    for item in test_data:
        temp_file.write(json.dumps(item, ensure_ascii=False) + '\n')
    temp_file.close()
    
    return temp_file.name

if __name__ == "__main__":
    # Запуск тестов напрямую
    pytest.main([__file__, "-v"])