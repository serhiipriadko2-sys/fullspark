"""
Модуль миграции конфигурации для синхронизированной системы.

Обеспечивает автоматическую миграцию между версиями конфигурации,
обновление устаревших настроек и перенос данных.
"""

import os
import json
import shutil
import logging
from typing import Dict, Any, Optional, List, Tuple, Union
from pathlib import Path
from dataclasses import dataclass
from enum import Enum
import copy
import re
import hashlib
from datetime import datetime


class MigrationStatus(Enum):
    """Статус миграции."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class MigrationRule:
    """Правило миграции."""
    from_version: str
    to_version: str
    description: str
    apply_func: callable
    rollback_func: Optional[callable] = None
    requires_backup: bool = True
    force: bool = False


@dataclass
class MigrationResult:
    """Результат миграции."""
    success: bool
    from_version: str
    to_version: str
    description: str
    changes_applied: List[str]
    errors: List[str]
    warnings: List[str]
    backup_path: Optional[str] = None
    timestamp: str = ""


class ConfigMigrator:
    """Мигратор конфигурации."""
    
    # Версии конфигурации
    VERSION_1_0 = "1.0"
    VERSION_1_1 = "1.1"
    VERSION_2_0 = "2.0"
    VERSION_UNIFIED = "unified"
    
    def __init__(self, backup_dir: str = "config_backups"):
        """
        Инициализация мигратора.
        
        Args:
            backup_dir: Директория для резервных копий
        """
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(exist_ok=True)
        
        self.migration_rules = self._initialize_migration_rules()
        self.migration_history = []
    
    def _initialize_migration_rules(self) -> List[MigrationRule]:
        """Инициализация правил миграции."""
        return [
            MigrationRule(
                from_version="legacy",
                to_version=self.VERSION_1_0,
                description="Миграция с legacy конфигурации Version 1",
                apply_func=self._migrate_legacy_to_v1,
                requires_backup=True
            ),
            MigrationRule(
                from_version=self.VERSION_1_0,
                to_version=self.VERSION_2_0,
                description="Миграция с Version 1.0 на Version 2.0",
                apply_func=self._migrate_v1_to_v2,
                requires_backup=True
            ),
            MigrationRule(
                from_version=self.VERSION_2_0,
                to_version=self.VERSION_UNIFIED,
                description="Миграция на унифицированную конфигурацию",
                apply_func=self._migrate_to_unified,
                requires_backup=True
            ),
            MigrationRule(
                from_version=self.VERSION_1_0,
                to_version=self.VERSION_UNIFIED,
                description="Прямая миграция на унифицированную конфигурацию",
                apply_func=self._migrate_v1_to_unified,
                requires_backup=True
            ),
        ]
    
    def detect_config_version(self, config_data: Dict[str, Any]) -> str:
        """
        Определение версии конфигурации.
        
        Args:
            config_data: Данные конфигурации
            
        Returns:
            Обнаруженная версия
        """
        
        # Проверка на legacy Version 1
        v1_indicators = ["JWT_SECRET", "CORS_ORIGINS", "EVIDENCE_PATH"]
        v1_count = sum(1 for indicator in v1_indicators if indicator in config_data)
        
        if v1_count >= 2:
            # Проверка на наличие новых настроек Version 2
            v2_indicators = ["JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "MEMORY_ROOT", "OTEL_SERVICE_NAME"]
            v2_count = sum(1 for indicator in v2_indicators if indicator in config_data)
            
            if v2_count == 0:
                return self.VERSION_1_0
            elif v2_count >= 2:
                return self.VERSION_2_0
        
        # Проверка на унифицированную конфигурацию
        unified_indicators = ["unified_config_version", "config_profile"]
        if any(indicator in config_data for indicator in unified_indicators):
            return self.VERSION_UNIFIED
        
        # Если не удалось определить, считаем legacy
        return "legacy"
    
    def migrate_config(self, config_data: Dict[str, Any], target_version: Optional[str] = None) -> Dict[str, Any]:
        """
        Миграция конфигурации до целевой версии.
        
        Args:
            config_data: Исходные данные конфигурации
            target_version: Целевая версия (по умолчанию - унифицированная)
            
        Returns:
            Мигрированные данные конфигурации
        """
        if target_version is None:
            target_version = self.VERSION_UNIFIED
        
        current_version = self.detect_config_version(config_data)
        
        if current_version == target_version:
            logging.info(f"Конфигурация уже имеет целевую версию: {target_version}")
            return config_data
        
        logging.info(f"Начало миграции: {current_version} -> {target_version}")
        
        # Создание резервной копии
        backup_path = None
        if self._requires_backup_for_migration(current_version, target_version):
            backup_path = self._create_backup(config_data, current_version)
        
        try:
            # Пошаговая миграция
            migrated_data = config_data.copy()
            migration_path = self._plan_migration_path(current_version, target_version)
            
            changes_applied = []
            
            for step in migration_path:
                rule = self._find_migration_rule(step["from"], step["to"])
                if rule:
                    logging.info(f"Применение правила миграции: {rule.description}")
                    
                    result = self._apply_migration_rule(rule, migrated_data)
                    
                    if result.success:
                        changes_applied.extend(result.changes_applied)
                        migrated_data = result.changes_applied[-1] if result.changes_applied else migrated_data
                    else:
                        logging.error(f"Ошибка миграции: {result.errors}")
                        raise Exception(f"Миграция не удалась: {'; '.join(result.errors)}")
            
            # Добавление метаданных версии
            migrated_data["config_version"] = target_version
            migrated_data["migration_timestamp"] = datetime.now().isoformat()
            migrated_data["migration_changes"] = changes_applied
            
            logging.info(f"Миграция завершена успешно. Применено {len(changes_applied)} изменений")
            
            return migrated_data
            
        except Exception as e:
            logging.error(f"Ошибка миграции: {e}")
            
            # Откат в случае ошибки
            if backup_path:
                self._rollback_from_backup(backup_path)
            
            raise
    
    def _plan_migration_path(self, current_version: str, target_version: str) -> List[Dict[str, str]]:
        """Планирование пути миграции."""
        # Простая реализация - последовательная миграция
        if current_version == "legacy":
            if target_version == self.VERSION_UNIFIED:
                return [
                    {"from": "legacy", "to": self.VERSION_1_0},
                    {"from": self.VERSION_1_0, "to": self.VERSION_UNIFIED}
                ]
            else:
                return [{"from": "legacy", "to": current_version}]
        
        elif current_version == self.VERSION_1_0:
            if target_version == self.VERSION_2_0:
                return [{"from": self.VERSION_1_0, "to": self.VERSION_2_0}]
            elif target_version == self.VERSION_UNIFIED:
                return [{"from": self.VERSION_1_0, "to": self.VERSION_UNIFIED}]
        
        elif current_version == self.VERSION_2_0:
            if target_version == self.VERSION_UNIFIED:
                return [{"from": self.VERSION_2_0, "to": self.VERSION_UNIFIED}]
        
        # Если путь не найден, выполняем прямую миграцию
        return [{"from": current_version, "to": target_version}]
    
    def _find_migration_rule(self, from_version: str, to_version: str) -> Optional[MigrationRule]:
        """Поиск правила миграции."""
        for rule in self.migration_rules:
            if rule.from_version == from_version and rule.to_version == to_version:
                return rule
        return None
    
    def _apply_migration_rule(self, rule: MigrationRule, config_data: Dict[str, Any]) -> MigrationResult:
        """Применение правила миграции."""
        try:
            logging.info(f"Применение миграции: {rule.description}")
            
            # Глубокое копирование для безопасности
            original_data = copy.deepcopy(config_data)
            result_data = copy.deepcopy(config_data)
            
            # Применение функции миграции
            changes = rule.apply_func(result_data)
            
            return MigrationResult(
                success=True,
                from_version=rule.from_version,
                to_version=rule.to_version,
                description=rule.description,
                changes_applied=changes or [],
                errors=[],
                warnings=[]
            )
            
        except Exception as e:
            return MigrationResult(
                success=False,
                from_version=rule.from_version,
                to_version=rule.to_version,
                description=rule.description,
                changes_applied=[],
                errors=[str(e)],
                warnings=[]
            )
    
    def _migrate_legacy_to_v1(self, config_data: Dict[str, Any]) -> List[str]:
        """Миграция с legacy на Version 1.0."""
        changes = []
        
        # Обеспечение базовых настроек JWT
        if "JWT_SECRET" not in config_data:
            import secrets
            import base64
            config_data["JWT_SECRET"] = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8')
            changes.append("Добавлен автоматически сгенерированный JWT_SECRET")
        
        # Обеспечение настроек CORS
        if "CORS_ORIGINS" not in config_data:
            config_data["CORS_ORIGINS"] = "http://localhost:3000"
            changes.append("Добавлены настройки CORS по умолчанию")
        
        # Обеспечение настроек поиска
        if "EVIDENCE_PATH" not in config_data:
            config_data["EVIDENCE_PATH"] = "memory/evidence.jsonl"
            changes.append("Добавлен путь к evidence файлу")
        
        if "MAX_SEARCH_RESULTS" not in config_data:
            config_data["MAX_SEARCH_RESULTS"] = 10
            changes.append("Добавлен лимит результатов поиска")
        
        if "DEFAULT_SEARCH_K" not in config_data:
            config_data["DEFAULT_SEARCH_K"] = 5
            changes.append("Добавлено значение K по умолчанию для поиска")
        
        # Обеспечение настроек логирования
        if "LOG_LEVEL" not in config_data:
            config_data["LOG_LEVEL"] = "INFO"
            changes.append("Добавлен уровень логирования")
        
        # Обеспечение OpenTelemetry настроек
        if "OTEL_ENABLED" not in config_data:
            config_data["OTEL_ENABLED"] = True
            changes.append("Включен OpenTelemetry")
        
        return changes
    
    def _migrate_v1_to_v2(self, config_data: Dict[str, Any]) -> List[str]:
        """Миграция с Version 1.0 на Version 2.0."""
        changes = []
        
        # Переименование JWT настроек
        if "JWT_EXPIRE_MINUTES" in config_data:
            config_data["JWT_ACCESS_TOKEN_EXPIRE_MINUTES"] = config_data.pop("JWT_EXPIRE_MINUTES")
            changes.append("JWT_EXPIRE_MINUTES переименован в JWT_ACCESS_TOKEN_EXPIRE_MINUTES")
        
        # Добавление настроек памяти
        if "MEMORY_ROOT" not in config_data:
            config_data["MEMORY_ROOT"] = "memory"
            changes.append("Добавлена настройка MEMORY_ROOT")
        
        if "MEMORY_BATCH_SIZE" not in config_data:
            config_data["MEMORY_BATCH_SIZE"] = 50
            changes.append("Добавлена настройка MEMORY_BATCH_SIZE")
        
        if "MEMORY_FLUSH_INTERVAL" not in config_data:
            config_data["MEMORY_FLUSH_INTERVAL"] = 5.0
            changes.append("Добавлена настройка MEMORY_FLUSH_INTERVAL")
        
        if "MEMORY_ASYNC" not in config_data:
            config_data["MEMORY_ASYNC"] = True
            changes.append("Включена асинхронная память")
        
        # Добавление настроек производительности
        if "ASYNC_POOL_SIZE" not in config_data:
            config_data["ASYNC_POOL_SIZE"] = 4
            changes.append("Добавлена настройка ASYNC_POOL_SIZE")
        
        if "CONNECTION_POOL_SIZE" not in config_data:
            config_data["CONNECTION_POOL_SIZE"] = 10
            changes.append("Добавлена настройка CONNECTION_POOL_SIZE")
        
        # Добавление настроек мониторинга
        if "OTEL_SERVICE_NAME" not in config_data:
            config_data["OTEL_SERVICE_NAME"] = "iskra-api"
            changes.append("Добавлена настройка OTEL_SERVICE_NAME")
        
        if "METRICS_ENABLED" not in config_data:
            config_data["METRICS_ENABLED"] = True
            changes.append("Включены метрики")
        
        if "HEALTH_CHECK_ENABLED" not in config_data:
            config_data["HEALTH_CHECK_ENABLED"] = True
            changes.append("Включены проверки здоровья")
        
        # Добавление настроек безопасности
        if "RATE_LIMIT_ENABLED" not in config_data:
            config_data["RATE_LIMIT_ENABLED"] = True
            changes.append("Включен rate limiting")
        
        if "RATE_LIMIT_REQUESTS" not in config_data:
            config_data["RATE_LIMIT_REQUESTS"] = 100
            changes.append("Добавлена настройка RATE_LIMIT_REQUESTS")
        
        # Добавление настроек кэширования
        if "LRU_CACHE_SIZE" not in config_data:
            config_data["LRU_CACHE_SIZE"] = 1000
            changes.append("Добавлена настройка LRU_CACHE_SIZE")
        
        # Добавление настроек API
        if "API_VERSION_PREFIX" not in config_data:
            config_data["API_VERSION_PREFIX"] = "/v1"
            changes.append("Добавлен префикс версии API")
        
        if "REQUEST_TIMEOUT" not in config_data:
            config_data["REQUEST_TIMEOUT"] = 300
            changes.append("Добавлен таймаут запросов")
        
        return changes
    
    def _migrate_to_unified(self, config_data: Dict[str, Any]) -> List[str]:
        """Миграция на унифицированную конфигурацию."""
        changes = []
        
        # Добавление метаданных унифицированной конфигурации
        config_data["unified_config_version"] = self.VERSION_UNIFIED
        changes.append("Добавлены метаданные унифицированной конфигурации")
        
        # Обеспечение всех необходимых настроек
        unified_defaults = {
            "CORS_ALLOW_CREDENTIALS": True,
            "CORS_ALLOW_METHODS": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "CORS_ALLOW_HEADERS": ["Authorization", "Content-Type", "X-Requested-With"],
            "MEMORY_AUTO_FLUSH": True,
            "MEMORY_COMPRESSION": False,
            "SEARCH_CACHE_ENABLED": True,
            "SEARCH_CACHE_TTL": 3600,
            "VECTOR_INDEX_ENABLED": True,
            "MIDDLEWARE_ENABLED": True,
            "CORS_MIDDLEWARE_ENABLED": True,
            "AUTH_MIDDLEWARE_ENABLED": True,
            "LOGGING_MIDDLEWARE_ENABLED": True,
            "ASYNC_QUEUE_SIZE": 1000,
            "ASYNC_TIMEOUT": 30.0,
            "IO_THREAD_POOL_SIZE": 10,
            "CPU_THREAD_POOL_SIZE": 4,
            "CONNECTION_POOL_MAX_OVERFLOW": 20,
            "CONNECTION_POOL_TIMEOUT": 30,
            "MEMORY_POOL_ENABLED": True,
            "GC_OPTIMIZATION": True,
            "REDIS_CACHE_ENABLED": False,
            "LOG_FORMAT": "json",
            "LOG_DATE_FORMAT": "%Y-%m-%d %H:%M:%S",
            "CONSOLE_LOGGING": True,
            "FILE_LOGGING": False,
            "SYSLOG_LOGGING": False,
            "LOG_FILE_PATH": "logs/app.log",
            "LOG_FILE_MAX_SIZE_MB": 100,
            "LOG_FILE_BACKUP_COUNT": 5,
            "ASYNC_LOGGING": True,
            "LOG_BUFFER_SIZE": 1000,
            "LOG_FLUSH_INTERVAL": 1.0,
            "STRUCTURED_LOGGING": True,
            "INCLUDE_TRACE_ID": True,
            "INCLUDE_USER_ID": False,
            "METRICS_PORT": 9090,
            "METRICS_PATH": "/metrics",
            "HEALTH_CHECK_INTERVAL": 60,
            "HEALTH_CHECK_TIMEOUT": 5.0,
            "OTEL_SERVICE_VERSION": "1.0.0",
            "ALERTS_ENABLED": False,
            "ALERT_CPU_THRESHOLD": 80.0,
            "ALERT_MEMORY_THRESHOLD": 85.0,
            "DATABASE_POOL_SIZE": 5,
            "DATABASE_MAX_OVERFLOW": 10,
            "DATABASE_TIMEOUT": 30,
            "DATABASE_ECHO": False,
            "DATABASE_POOL_RECYCLE": 3600,
            "MIGRATION_ENABLED": True,
            "MIGRATION_PATH": "migrations",
        }
        
        for key, default_value in unified_defaults.items():
            if key not in config_data:
                config_data[key] = default_value
                changes.append(f"Добавлена настройка {key}")
        
        # Профилирование настроек
        if "config_profile" not in config_data:
            config_data["config_profile"] = os.getenv("ENVIRONMENT_PROFILE", "development")
            changes.append("Добавлен профиль конфигурации")
        
        return changes
    
    def _migrate_v1_to_unified(self, config_data: Dict[str, Any]) -> List[str]:
        """Прямая миграция с Version 1.0 на унифицированную конфигурацию."""
        changes = []
        
        # Комбинированная миграция
        changes.extend(self._migrate_v1_to_v2(config_data))
        changes.extend(self._migrate_to_unified(config_data))
        
        # Специфические для прямой миграции изменения
        if "JWT_SECRET_LENGTH" not in config_data:
            config_data["JWT_SECRET_LENGTH"] = 32
            changes.append("Добавлена настройка длины JWT секрета")
        
        if "COMPATIBILITY_MODE" not in config_data:
            config_data["COMPATIBILITY_MODE"] = "unified"
            changes.append("Установлен режим совместимости unified")
        
        return changes
    
    def _create_backup(self, config_data: Dict[str, Any], version: str) -> str:
        """Создание резервной копии конфигурации."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"config_backup_{version}_{timestamp}.json"
        backup_path = self.backup_dir / filename
        
        backup_info = {
            "version": version,
            "timestamp": timestamp,
            "config_data": config_data,
            "checksum": self._calculate_checksum(config_data)
        }
        
        with open(backup_path, 'w', encoding='utf-8') as f:
            json.dump(backup_info, f, indent=2, ensure_ascii=False)
        
        logging.info(f"Резервная копия создана: {backup_path}")
        return str(backup_path)
    
    def _rollback_from_backup(self, backup_path: str) -> None:
        """Откат из резервной копии."""
        try:
            with open(backup_path, 'r', encoding='utf-8') as f:
                backup_info = json.load(f)
            
            # Здесь можно было бы автоматически восстановить,
            # но для безопасности просто логируем
            logging.warning(f"Доступна резервная копия для отката: {backup_path}")
            logging.warning(f"Версия в резервной копии: {backup_info.get('version')}")
            
        except Exception as e:
            logging.error(f"Ошибка при чтении резервной копии: {e}")
    
    def _calculate_checksum(self, data: Dict[str, Any]) -> str:
        """Вычисление контрольной суммы данных."""
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode('utf-8')).hexdigest()
    
    def _requires_backup_for_migration(self, from_version: str, to_version: str) -> bool:
        """Проверка необходимости резервной копии."""
        for rule in self.migration_rules:
            if rule.from_version == from_version and rule.to_version == to_version:
                return rule.requires_backup
        return True
    
    def get_migration_history(self) -> List[Dict[str, Any]]:
        """Получение истории миграций."""
        return self.migration_history.copy()
    
    def validate_migration(self, original_data: Dict[str, Any], migrated_data: Dict[str, Any]) -> Dict[str, Any]:
        """Валидация результата миграции."""
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {}
        }
        
        try:
            # Проверка наличия обязательных полей
            required_fields = [
                "JWT_SECRET", "CORS_ORIGINS", "LOG_LEVEL"
            ]
            
            for field in required_fields:
                if field not in migrated_data:
                    validation_result["errors"].append(f"Отсутствует обязательное поле: {field}")
                    validation_result["is_valid"] = False
            
            # Проверка типов данных
            type_checks = [
                ("JWT_SECRET", str),
                ("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", int),
                ("MEMORY_BATCH_SIZE", int),
                ("LOG_LEVEL", str),
            ]
            
            for field, expected_type in type_checks:
                if field in migrated_data and not isinstance(migrated_data[field], expected_type):
                    validation_result["errors"].append(
                        f"Неверный тип поля {field}: ожидается {expected_type.__name__}"
                    )
                    validation_result["is_valid"] = False
            
            # Статистика изменений
            validation_result["statistics"] = {
                "original_keys": len(original_data),
                "migrated_keys": len(migrated_data),
                "added_keys": len(set(migrated_data.keys()) - set(original_data.keys())),
                "removed_keys": len(set(original_data.keys()) - set(migrated_data.keys())),
                "unchanged_keys": len(set(migrated_data.keys()) & set(original_data.keys()))
            }
            
        except Exception as e:
            validation_result["errors"].append(f"Ошибка валидации: {str(e)}")
            validation_result["is_valid"] = False
        
        return validation_result
    
    def create_migration_report(self, original_data: Dict[str, Any], migrated_data: Dict[str, Any]) -> str:
        """Создание отчета о миграции."""
        validation = self.validate_migration(original_data, migrated_data)
        
        report = []
        report.append("=" * 50)
        report.append("ОТЧЕТ О МИГРАЦИИ КОНФИГУРАЦИИ")
        report.append("=" * 50)
        report.append("")
        
        report.append(f"Исходная версия: {self.detect_config_version(original_data)}")
        report.append(f"Целевая версия: {self.detect_config_version(migrated_data)}")
        report.append(f"Статус: {'УСПЕШНО' if validation['is_valid'] else 'ОШИБКА'}")
        report.append("")
        
        if validation["statistics"]:
            stats = validation["statistics"]
            report.append("СТАТИСТИКА ИЗМЕНЕНИЙ:")
            report.append(f"  Исходных ключей: {stats['original_keys']}")
            report.append(f"  Итоговых ключей: {stats['migrated_keys']}")
            report.append(f"  Добавлено: +{stats['added_keys']}")
            report.append(f"  Удалено: -{stats['removed_keys']}")
            report.append(f"  Неизменено: {stats['unchanged_keys']}")
            report.append("")
        
        if validation["errors"]:
            report.append("ОШИБКИ:")
            for error in validation["errors"]:
                report.append(f"  ❌ {error}")
            report.append("")
        
        if validation["warnings"]:
            report.append("ПРЕДУПРЕЖДЕНИЯ:")
            for warning in validation["warnings"]:
                report.append(f"  ⚠️  {warning}")
            report.append("")
        
        report.append("=" * 50)
        
        return "\n".join(report)
    
    def cleanup_old_backups(self, keep_count: int = 10) -> None:
        """Очистка старых резервных копий."""
        try:
            backup_files = list(self.backup_dir.glob("config_backup_*.json"))
            backup_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
            
            if len(backup_files) > keep_count:
                for backup_file in backup_files[keep_count:]:
                    backup_file.unlink()
                    logging.info(f"Удалена старая резервная копия: {backup_file}")
        
        except Exception as e:
            logging.error(f"Ошибка при очистке резервных копий: {e}")