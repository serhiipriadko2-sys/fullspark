"""
Менеджер переменных окружения для синхронизированной конфигурации.

Обеспечивает безопасную загрузку, валидацию и управление переменными окружения
с поддержкой различных форматов и типов данных.
"""

import os
import json
import typing
from typing import Dict, Any, Optional, List, Union
from pathlib import Path
import logging
import re
from dataclasses import dataclass, field
from enum import Enum


class EnvVarType(Enum):
    """Типы переменных окружения."""
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    LIST = "list"
    DICT = "dict"
    PATH = "path"
    URL = "url"
    EMAIL = "email"
    SECRET = "secret"


@dataclass
class EnvVarDefinition:
    """Определение переменной окружения."""
    name: str
    type: EnvVarType
    description: str
    default: Any = None
    required: bool = False
    choices: Optional[List[Any]] = None
    regex: Optional[str] = None
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    deprecated: bool = False
    deprecation_message: str = ""


class EnvironmentManager:
    """Менеджер переменных окружения."""
    
    # Словарь всех доступных переменных окружения
    ENV_VARIABLES = {
        # === ОСНОВНЫЕ НАСТРОЙКИ ПРИЛОЖЕНИЯ ===
        "APP_NAME": EnvVarDefinition(
            "APP_NAME", EnvVarType.STRING, 
            "Название приложения", default="Iskra API"
        ),
        "APP_VERSION": EnvVarDefinition(
            "APP_VERSION", EnvVarType.STRING,
            "Версия приложения", default="1.0.0"
        ),
        "DEBUG": EnvVarDefinition(
            "DEBUG", EnvVarType.BOOLEAN,
            "Режим отладки", default=False
        ),
        "ENVIRONMENT_PROFILE": EnvVarDefinition(
            "ENVIRONMENT_PROFILE", EnvVarType.STRING,
            "Профиль окружения (development, production, testing, staging)",
            choices=["development", "production", "testing", "staging"]
        ),
        
        # === СЕТЕВЫЕ НАСТРОЙКИ ===
        "HOST": EnvVarDefinition(
            "HOST", EnvVarType.STRING,
            "Хост сервера", default="0.0.0.0"
        ),
        "PORT": EnvVarDefinition(
            "PORT", EnvVarType.INTEGER,
            "Порт сервера", default=8000, min_value=1, max_value=65535
        ),
        
        # === CORS НАСТРОЙКИ ===
        "CORS_ORIGINS": EnvVarDefinition(
            "CORS_ORIGINS", EnvVarType.STRING,
            "Разрешенные CORS источники (через запятую)",
            default="http://localhost:3000"
        ),
        "CORS_ALLOW_CREDENTIALS": EnvVarDefinition(
            "CORS_ALLOW_CREDENTIALS", EnvVarType.BOOLEAN,
            "Разрешить CORS credentials", default=True
        ),
        "CORS_ALLOW_METHODS": EnvVarDefinition(
            "CORS_ALLOW_METHODS", EnvVarType.LIST,
            "Разрешенные CORS методы", 
            default=["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        ),
        "CORS_ALLOW_HEADERS": EnvVarDefinition(
            "CORS_ALLOW_HEADERS", EnvVarType.LIST,
            "Разрешенные CORS заголовки",
            default=["Authorization", "Content-Type", "X-Requested-With"]
        ),
        
        # === JWT НАСТРОЙКИ ===
        "JWT_SECRET": EnvVarDefinition(
            "JWT_SECRET", EnvVarType.SECRET,
            "Секретный ключ JWT (если пустой, генерируется автоматически)"
        ),
        "JWT_ALGORITHM": EnvVarDefinition(
            "JWT_ALGORITHM", EnvVarType.STRING,
            "Алгоритм JWT", default="HS256",
            choices=["HS256", "HS384", "HS512", "RS256", "RS384", "RS512"]
        ),
        "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": EnvVarDefinition(
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES", EnvVarType.INTEGER,
            "Время жизни access токена в минутах", 
            default=30, min_value=5, max_value=1440
        ),
        "JWT_REFRESH_TOKEN_EXPIRE_DAYS": EnvVarDefinition(
            "JWT_REFRESH_TOKEN_EXPIRE_DAYS", EnvVarType.INTEGER,
            "Время жизни refresh токена в днях",
            default=7, min_value=1, max_value=30
        ),
        
        # === RATE LIMITING ===
        "RATE_LIMIT_ENABLED": EnvVarDefinition(
            "RATE_LIMIT_ENABLED", EnvVarType.BOOLEAN,
            "Включить rate limiting", default=True
        ),
        "RATE_LIMIT_REQUESTS": EnvVarDefinition(
            "RATE_LIMIT_REQUESTS", EnvVarType.INTEGER,
            "Количество запросов в минуту", 
            default=100, min_value=10, max_value=1000
        ),
        "RATE_LIMIT_BURST": EnvVarDefinition(
            "RATE_LIMIT_BURST", EnvVarType.INTEGER,
            "Размер burst для rate limiting", 
            default=200, min_value=50, max_value=1000
        ),
        
        # === БЕЗОПАСНОСТЬ ===
        "SECURITY_HEADERS_ENABLED": EnvVarDefinition(
            "SECURITY_HEADERS_ENABLED", EnvVarType.BOOLEAN,
            "Включить security headers", default=True
        ),
        "STRICT_TRANSPORT_SECURITY": EnvVarDefinition(
            "STRICT_TRANSPORT_SECURITY", EnvVarType.BOOLEAN,
            "Включить HSTS", default=True
        ),
        "CONTENT_SECURITY_POLICY": EnvVarDefinition(
            "CONTENT_SECURITY_POLICY", EnvVarType.STRING,
            "Content Security Policy", 
            default="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
        ),
        
        # === НАСТРОЙКИ ПАМЯТИ ===
        "MEMORY_ROOT": EnvVarDefinition(
            "MEMORY_ROOT", EnvVarType.PATH,
            "Корневая директория для памяти", default="memory"
        ),
        "EVIDENCE_PATH": EnvVarDefinition(
            "EVIDENCE_PATH", EnvVarType.PATH,
            "Путь к файлу с данными для поиска", default="memory/evidence.jsonl"
        ),
        "WORKING_MEMORY_PATH": EnvVarDefinition(
            "WORKING_MEMORY_PATH", EnvVarType.PATH,
            "Путь к файлу рабочей памяти", default="memory/working.jsonl"
        ),
        "LONG_TERM_MEMORY_PATH": EnvVarDefinition(
            "LONG_TERM_MEMORY_PATH", EnvVarType.PATH,
            "Путь к файлу долговременной памяти", default="memory/long_term.jsonl"
        ),
        "MEMORY_BATCH_SIZE": EnvVarDefinition(
            "MEMORY_BATCH_SIZE", EnvVarType.INTEGER,
            "Размер батча для асинхронной памяти", 
            default=50, min_value=10, max_value=500
        ),
        "MEMORY_FLUSH_INTERVAL": EnvVarDefinition(
            "MEMORY_FLUSH_INTERVAL", EnvVarType.FLOAT,
            "Интервал сброса памяти в секундах", 
            default=5.0, min_value=1.0, max_value=60.0
        ),
        "MEMORY_AUTO_FLUSH": EnvVarDefinition(
            "MEMORY_AUTO_FLUSH", EnvVarType.BOOLEAN,
            "Автоматический сброс памяти", default=True
        ),
        "MEMORY_COMPRESSION": EnvVarDefinition(
            "MEMORY_COMPRESSION", EnvVarType.BOOLEAN,
            "Включить сжатие для memory storage", default=False
        ),
        "MEMORY_COMPRESSION_ALGORITHM": EnvVarDefinition(
            "MEMORY_COMPRESSION_ALGORITHM", EnvVarType.STRING,
            "Алгоритм сжатия", 
            default="gzip", choices=["gzip", "bz2", "lzma"]
        ),
        "MEMORY_MAX_SIZE_MB": EnvVarDefinition(
            "MEMORY_MAX_SIZE_MB", EnvVarType.INTEGER,
            "Максимальный размер памяти в МБ", 
            default=1024, min_value=100, max_value=10240
        ),
        "MEMORY_ASYNC": EnvVarDefinition(
            "MEMORY_ASYNC", EnvVarType.BOOLEAN,
            "Асинхронная память", default=True
        ),
        "MEMORY_CONCURRENT_OPS": EnvVarDefinition(
            "MEMORY_CONCURRENT_OPS", EnvVarType.INTEGER,
            "Количество конкурентных операций памяти",
            default=4, min_value=1, max_value=16
        ),
        
        # === НАСТРОЙКИ ПОИСКА ===
        "DEFAULT_SEARCH_K": EnvVarDefinition(
            "DEFAULT_SEARCH_K", EnvVarType.INTEGER,
            "Количество результатов по умолчанию для поиска", 
            default=5, min_value=1, max_value=20
        ),
        "MAX_SEARCH_RESULTS": EnvVarDefinition(
            "MAX_SEARCH_RESULTS", EnvVarType.INTEGER,
            "Максимальное количество результатов поиска", 
            default=50, min_value=1, max_value=100
        ),
        "SEARCH_TIMEOUT": EnvVarDefinition(
            "SEARCH_TIMEOUT", EnvVarType.FLOAT,
            "Таймаут поиска в секундах",
            default=30.0, min_value=1.0, max_value=300.0
        ),
        "SEARCH_CACHE_ENABLED": EnvVarDefinition(
            "SEARCH_CACHE_ENABLED", EnvVarType.BOOLEAN,
            "Включить кэширование поиска", default=True
        ),
        "SEARCH_CACHE_SIZE": EnvVarDefinition(
            "SEARCH_CACHE_SIZE", EnvVarType.INTEGER,
            "Размер кэша поиска",
            default=1000, min_value=100, max_value=10000
        ),
        "SEARCH_CACHE_TTL": EnvVarDefinition(
            "SEARCH_CACHE_TTL", EnvVarType.INTEGER,
            "Время жизни кэша поиска в секундах",
            default=3600, min_value=60, max_value=86400
        ),
        "VECTOR_INDEX_ENABLED": EnvVarDefinition(
            "VECTOR_INDEX_ENABLED", EnvVarType.BOOLEAN,
            "Включить векторные индексы", default=True
        ),
        "VECTOR_INDEX_REFRESH": EnvVarDefinition(
            "VECTOR_INDEX_REFRESH", EnvVarType.INTEGER,
            "Интервал обновления векторного индекса в секундах",
            default=300, min_value=60, max_value=3600
        ),
        "VECTOR_INDEX_AUTO_REBUILD": EnvVarDefinition(
            "VECTOR_INDEX_AUTO_REBUILD", EnvVarType.BOOLEAN,
            "Автоматическая перестройка векторного индекса", default=True
        ),
        "SIMILARITY_THRESHOLD": EnvVarDefinition(
            "SIMILARITY_THRESHOLD", EnvVarType.FLOAT,
            "Порог схожести", 
            default=0.7, min_value=0.0, max_value=1.0
        ),
        "SIMILARITY_ALGORITHM": EnvVarDefinition(
            "SIMILARITY_ALGORITHM", EnvVarType.STRING,
            "Алгоритм вычисления схожести",
            default="cosine", choices=["cosine", "euclidean", "dot_product"]
        ),
        "SEARCH_PARALLEL_THREADS": EnvVarDefinition(
            "SEARCH_PARALLEL_THREADS", EnvVarType.INTEGER,
            "Количество потоков для параллельного поиска",
            default=4, min_value=1, max_value=16
        ),
        "SEARCH_BATCH_PROCESSING": EnvVarDefinition(
            "SEARCH_BATCH_PROCESSING", EnvVarType.BOOLEAN,
            "Пакетная обработка поисковых запросов", default=True
        ),
        
        # === API НАСТРОЙКИ ===
        "API_VERSION_PREFIX": EnvVarDefinition(
            "API_VERSION_PREFIX", EnvVarType.STRING,
            "Префикс версии API", default="/v1"
        ),
        "API_VERSION_HEADER": EnvVarDefinition(
            "API_VERSION_HEADER", EnvVarType.STRING,
            "Заголовок для версии API", default="X-API-Version"
        ),
        "MIDDLEWARE_ENABLED": EnvVarDefinition(
            "MIDDLEWARE_ENABLED", EnvVarType.BOOLEAN,
            "Включить middleware", default=True
        ),
        "CORS_MIDDLEWARE_ENABLED": EnvVarDefinition(
            "CORS_MIDDLEWARE_ENABLED", EnvVarType.BOOLEAN,
            "Включить CORS middleware", default=True
        ),
        "AUTH_MIDDLEWARE_ENABLED": EnvVarDefinition(
            "AUTH_MIDDLEWARE_ENABLED", EnvVarType.BOOLEAN,
            "Включить auth middleware", default=True
        ),
        "LOGGING_MIDDLEWARE_ENABLED": EnvVarDefinition(
            "LOGGING_MIDDLEWARE_ENABLED", EnvVarType.BOOLEAN,
            "Включить logging middleware", default=True
        ),
        "REQUEST_SIZE_LIMIT_MB": EnvVarDefinition(
            "REQUEST_SIZE_LIMIT_MB", EnvVarType.INTEGER,
            "Лимит размера запроса в МБ",
            default=100, min_value=1, max_value=1000
        ),
        "REQUEST_TIMEOUT": EnvVarDefinition(
            "REQUEST_TIMEOUT", EnvVarType.INTEGER,
            "Таймаут запроса в секундах",
            default=300, min_value=30, max_value=3600
        ),
        "DOCS_ENABLED": EnvVarDefinition(
            "DOCS_ENABLED", EnvVarType.BOOLEAN,
            "Включить документацию API", default=True
        ),
        "DOCS_URL": EnvVarDefinition(
            "DOCS_URL", EnvVarType.STRING,
            "URL документации", default="/docs"
        ),
        "REDOC_URL": EnvVarDefinition(
            "REDOC_URL", EnvVarType.STRING,
            "URL ReDoc", default="/redoc"
        ),
        "AUTO_RELOAD": EnvVarDefinition(
            "AUTO_RELOAD", EnvVarType.BOOLEAN,
            "Автоматическая перезагрузка при изменении кода", default=False
        ),
        "WORKERS": EnvVarDefinition(
            "WORKERS", EnvVarType.INTEGER,
            "Количество воркеров",
            default=1, min_value=1, max_value=16
        ),
        
        # === ПРОИЗВОДИТЕЛЬНОСТЬ ===
        "ASYNC_POOL_SIZE": EnvVarDefinition(
            "ASYNC_POOL_SIZE", EnvVarType.INTEGER,
            "Размер пула асинхронных операций",
            default=4, min_value=1, max_value=16
        ),
        "ASYNC_QUEUE_SIZE": EnvVarDefinition(
            "ASYNC_QUEUE_SIZE", EnvVarType.INTEGER,
            "Размер очереди асинхронных операций",
            default=1000, min_value=100, max_value=10000
        ),
        "ASYNC_TIMEOUT": EnvVarDefinition(
            "ASYNC_TIMEOUT", EnvVarType.FLOAT,
            "Таймаут асинхронных операций в секундах",
            default=30.0, min_value=1.0, max_value=300.0
        ),
        "IO_THREAD_POOL_SIZE": EnvVarDefinition(
            "IO_THREAD_POOL_SIZE", EnvVarType.INTEGER,
            "Размер пула для I/O операций",
            default=10, min_value=1, max_value=50
        ),
        "CPU_THREAD_POOL_SIZE": EnvVarDefinition(
            "CPU_THREAD_POOL_SIZE", EnvVarType.INTEGER,
            "Размер пула для CPU операций",
            default=4, min_value=1, max_value=16
        ),
        "CONNECTION_POOL_SIZE": EnvVarDefinition(
            "CONNECTION_POOL_SIZE", EnvVarType.INTEGER,
            "Размер пула соединений",
            default=10, min_value=5, max_value=50
        ),
        "CONNECTION_POOL_MAX_OVERFLOW": EnvVarDefinition(
            "CONNECTION_POOL_MAX_OVERFLOW", EnvVarType.INTEGER,
            "Максимальное переполнение пула соединений",
            default=20, min_value=0, max_value=100
        ),
        "CONNECTION_POOL_TIMEOUT": EnvVarDefinition(
            "CONNECTION_POOL_TIMEOUT", EnvVarType.INTEGER,
            "Таймаут пула соединений в секундах",
            default=30, min_value=5, max_value=300
        ),
        "MEMORY_POOL_ENABLED": EnvVarDefinition(
            "MEMORY_POOL_ENABLED", EnvVarType.BOOLEAN,
            "Включить пул памяти", default=True
        ),
        "GC_OPTIMIZATION": EnvVarDefinition(
            "GC_OPTIMIZATION", EnvVarType.BOOLEAN,
            "Оптимизация сборщика мусора", default=True
        ),
        "LRU_CACHE_ENABLED": EnvVarDefinition(
            "LRU_CACHE_ENABLED", EnvVarType.BOOLEAN,
            "Включить LRU кэширование", default=True
        ),
        "LRU_CACHE_SIZE": EnvVarDefinition(
            "LRU_CACHE_SIZE", EnvVarType.INTEGER,
            "Размер LRU кэша",
            default=1000, min_value=100, max_value=10000
        ),
        "REDIS_CACHE_ENABLED": EnvVarDefinition(
            "REDIS_CACHE_ENABLED", EnvVarType.BOOLEAN,
            "Включить Redis кэширование", default=False
        ),
        
        # === ЛОГИРОВАНИЕ ===
        "LOG_LEVEL": EnvVarDefinition(
            "LOG_LEVEL", EnvVarType.STRING,
            "Уровень логирования",
            default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        ),
        "LOG_FORMAT": EnvVarDefinition(
            "LOG_FORMAT", EnvVarType.STRING,
            "Формат логирования", default="json", choices=["json", "text", "colored"]
        ),
        "LOG_DATE_FORMAT": EnvVarDefinition(
            "LOG_DATE_FORMAT", EnvVarType.STRING,
            "Формат даты в логах", default="%Y-%m-%d %H:%M:%S"
        ),
        "CONSOLE_LOGGING": EnvVarDefinition(
            "CONSOLE_LOGGING", EnvVarType.BOOLEAN,
            "Логирование в консоль", default=True
        ),
        "FILE_LOGGING": EnvVarDefinition(
            "FILE_LOGGING", EnvVarType.BOOLEAN,
            "Логирование в файл", default=False
        ),
        "SYSLOG_LOGGING": EnvVarDefinition(
            "SYSLOG_LOGGING", EnvVarType.BOOLEAN,
            "Логирование в syslog", default=False
        ),
        "LOG_FILE_PATH": EnvVarDefinition(
            "LOG_FILE_PATH", EnvVarType.PATH,
            "Путь к файлу логов", default="logs/app.log"
        ),
        "LOG_FILE_MAX_SIZE_MB": EnvVarDefinition(
            "LOG_FILE_MAX_SIZE_MB", EnvVarType.INTEGER,
            "Максимальный размер файла логов в МБ",
            default=100, min_value=10, max_value=1000
        ),
        "LOG_FILE_BACKUP_COUNT": EnvVarDefinition(
            "LOG_FILE_BACKUP_COUNT", EnvVarType.INTEGER,
            "Количество备份 файлов логов",
            default=5, min_value=1, max_value=50
        ),
        "ASYNC_LOGGING": EnvVarDefinition(
            "ASYNC_LOGGING", EnvVarType.BOOLEAN,
            "Асинхронное логирование", default=True
        ),
        "LOG_BUFFER_SIZE": EnvVarDefinition(
            "LOG_BUFFER_SIZE", EnvVarType.INTEGER,
            "Размер буфера логирования",
            default=1000, min_value=100, max_value=10000
        ),
        "LOG_FLUSH_INTERVAL": EnvVarDefinition(
            "LOG_FLUSH_INTERVAL", EnvVarType.FLOAT,
            "Интервал сброса логов в секундах",
            default=1.0, min_value=0.1, max_value=60.0
        ),
        "STRUCTURED_LOGGING": EnvVarDefinition(
            "STRUCTURED_LOGGING", EnvVarType.BOOLEAN,
            "Структурированное логирование", default=True
        ),
        "INCLUDE_TRACE_ID": EnvVarDefinition(
            "INCLUDE_TRACE_ID", EnvVarType.BOOLEAN,
            "Включать trace ID в логи", default=True
        ),
        "INCLUDE_USER_ID": EnvVarDefinition(
            "INCLUDE_USER_ID", EnvVarType.BOOLEAN,
            "Включать user ID в логи", default=False
        ),
        
        # === МОНИТОРИНГ ===
        "METRICS_ENABLED": EnvVarDefinition(
            "METRICS_ENABLED", EnvVarType.BOOLEAN,
            "Включить метрики", default=True
        ),
        "METRICS_PORT": EnvVarDefinition(
            "METRICS_PORT", EnvVarType.INTEGER,
            "Порт для метрик",
            default=9090, min_value=1000, max_value=65535
        ),
        "METRICS_PATH": EnvVarDefinition(
            "METRICS_PATH", EnvVarType.STRING,
            "Путь для метрик", default="/metrics"
        ),
        "HEALTH_CHECK_ENABLED": EnvVarDefinition(
            "HEALTH_CHECK_ENABLED", EnvVarType.BOOLEAN,
            "Включить проверки здоровья", default=True
        ),
        "HEALTH_CHECK_INTERVAL": EnvVarDefinition(
            "HEALTH_CHECK_INTERVAL", EnvVarType.INTEGER,
            "Интервал проверки здоровья в секундах",
            default=60, min_value=30, max_value=300
        ),
        "HEALTH_CHECK_TIMEOUT": EnvVarDefinition(
            "HEALTH_CHECK_TIMEOUT", EnvVarType.FLOAT,
            "Таймаут проверки здоровья в секундах",
            default=5.0, min_value=1.0, max_value=30.0
        ),
        "OTEL_ENABLED": EnvVarDefinition(
            "OTEL_ENABLED", EnvVarType.BOOLEAN,
            "Включить OpenTelemetry", default=True
        ),
        "OTEL_SERVICE_NAME": EnvVarDefinition(
            "OTEL_SERVICE_NAME", EnvVarType.STRING,
            "Имя сервиса для OpenTelemetry", default="iskra-api"
        ),
        "OTEL_SERVICE_VERSION": EnvVarDefinition(
            "OTEL_SERVICE_VERSION", EnvVarType.STRING,
            "Версия сервиса для OpenTelemetry", default="1.0.0"
        ),
        "ALERTS_ENABLED": EnvVarDefinition(
            "ALERTS_ENABLED", EnvVarType.BOOLEAN,
            "Включить алерты", default=False
        ),
        "ALERT_WEBHOOK_URL": EnvVarDefinition(
            "ALERT_WEBHOOK_URL", EnvVarType.URL,
            "URL webhook для алертов"
        ),
        "ALERT_CPU_THRESHOLD": EnvVarDefinition(
            "ALERT_CPU_THRESHOLD", EnvVarType.FLOAT,
            "Порог CPU для алертов в процентах",
            default=80.0, min_value=50.0, max_value=100.0
        ),
        "ALERT_MEMORY_THRESHOLD": EnvVarDefinition(
            "ALERT_MEMORY_THRESHOLD", EnvVarType.FLOAT,
            "Порог памяти для алертов в процентах",
            default=85.0, min_value=50.0, max_value=100.0
        ),
        
        # === БАЗА ДАННЫХ ===
        "DATABASE_URL": EnvVarDefinition(
            "DATABASE_URL", EnvVarType.URL,
            "URL подключения к базе данных"
        ),
        "DATABASE_POOL_SIZE": EnvVarDefinition(
            "DATABASE_POOL_SIZE", EnvVarType.INTEGER,
            "Размер пула соединений БД",
            default=5, min_value=1, max_value=20
        ),
        "DATABASE_MAX_OVERFLOW": EnvVarDefinition(
            "DATABASE_MAX_OVERFLOW", EnvVarType.INTEGER,
            "Максимальное переполнение пула БД",
            default=10, min_value=0, max_value=50
        ),
        "DATABASE_TIMEOUT": EnvVarDefinition(
            "DATABASE_TIMEOUT", EnvVarType.INTEGER,
            "Таймаут подключения к БД в секундах",
            default=30, min_value=5, max_value=300
        ),
        "DATABASE_ECHO": EnvVarDefinition(
            "DATABASE_ECHO", EnvVarType.BOOLEAN,
            "Echo SQL запросов", default=False
        ),
        "DATABASE_POOL_RECYCLE": EnvVarDefinition(
            "DATABASE_POOL_RECYCLE", EnvVarType.INTEGER,
            "Время переиспользования соединения БД в секундах",
            default=3600, min_value=300, max_value=86400
        ),
        "MIGRATION_ENABLED": EnvVarDefinition(
            "MIGRATION_ENABLED", EnvVarType.BOOLEAN,
            "Включить миграции БД", default=True
        ),
        "MIGRATION_PATH": EnvVarDefinition(
            "MIGRATION_PATH", EnvVarType.PATH,
            "Путь к миграциям", default="migrations"
        ),
    }
    
    def __init__(self):
        """Инициализация менеджера окружения."""
        self.loaded_vars = {}
        self.validation_errors = []
    
    def load_from_environment(self, prefix: str = "") -> Dict[str, Any]:
        """
        Загрузка переменных из окружения.
        
        Args:
            prefix: Префикс для поиска переменных
            
        Returns:
            Словарь с загруженными переменными
        """
        result = {}
        
        for var_name, var_def in self.ENV_VARIABLES.items():
            # Применяем префикс если указан
            env_name = f"{prefix}{var_name}" if prefix else var_name
            
            # Получаем значение из окружения
            env_value = os.getenv(env_name)
            
            # Пропускаем если не найдено и не обязательно
            if env_value is None:
                if var_def.required:
                    self.validation_errors.append(f"Обязательная переменная {env_name} не установлена")
                continue
            
            # Парсинг и валидация значения
            try:
                parsed_value = self._parse_value(env_value, var_def)
                result[var_name] = parsed_value
                self.loaded_vars[env_name] = parsed_value
                
                # Проверка deprecated переменных
                if var_def.deprecated:
                    logging.warning(f"Переменная {env_name} устарела: {var_def.deprecation_message}")
                    
            except Exception as e:
                self.validation_errors.append(f"Ошибка парсинга переменной {env_name}: {e}")
                logging.error(f"Не удалось распарсить переменную {env_name}: {e}")
        
        return result
    
    def _parse_value(self, value: str, var_def: EnvVarDefinition) -> Any:
        """Парсинг значения переменной окружения."""
        # Преобразование базовых типов
        if var_def.type == EnvVarType.STRING:
            return value.strip()
        
        elif var_def.type == EnvVarType.INTEGER:
            return int(value.strip())
        
        elif var_def.type == EnvVarType.FLOAT:
            return float(value.strip())
        
        elif var_def.type == EnvVarType.BOOLEAN:
            return value.strip().lower() in ("true", "1", "yes", "on", "enabled")
        
        elif var_def.type == EnvVarType.LIST:
            if value.strip() == "":
                return []
            
            # Попробуем JSON список
            if value.strip().startswith(('[', '{')):
                try:
                    return json.loads(value)
                except json.JSONDecodeError:
                    pass
            
            # Парсинг через запятую
            return [item.strip() for item in value.split(',') if item.strip()]
        
        elif var_def.type == EnvVarType.DICT:
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                raise ValueError(f"Неверный JSON формат для словаря: {value}")
        
        elif var_def.type == EnvVarType.PATH:
            return value.strip()
        
        elif var_def.type == EnvVarType.URL:
            if not re.match(r'^https?://', value.strip()):
                raise ValueError(f"Некорректный URL: {value}")
            return value.strip()
        
        elif var_def.type == EnvVarType.EMAIL:
            if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', value.strip()):
                raise ValueError(f"Некорректный email: {value}")
            return value.strip()
        
        elif var_def.type == EnvVarType.SECRET:
            return value.strip()
        
        else:
            return value
    
    def validate_environment(self) -> Dict[str, Any]:
        """Валидация переменных окружения."""
        errors = []
        warnings = []
        
        # Проверка обязательных переменных
        for var_name, var_def in self.ENV_VARIABLES.items():
            if var_def.required and var_name not in os.environ:
                errors.append(f"Обязательная переменная {var_name} не установлена")
            
            # Проверка deprecated переменных
            if var_def.deprecated and var_name in os.environ:
                warnings.append(f"Переменная {var_name} устарела: {var_def.deprecation_message}")
        
        # Проверка выборок (choices)
        for var_name, var_def in self.ENV_VARIABLES.items():
            if var_def.choices and var_name in os.environ:
                env_value = os.getenv(var_name)
                if env_value not in var_def.choices:
                    errors.append(
                        f"Переменная {var_name} имеет недопустимое значение '{env_value}'. "
                        f"Допустимые значения: {var_def.choices}"
                    )
        
        # Проверка регулярных выражений
        for var_name, var_def in self.ENV_VARIABLES.items():
            if var_def.regex and var_name in os.environ:
                env_value = os.getenv(var_name)
                if not re.match(var_def.regex, env_value):
                    errors.append(f"Переменная {var_name} не соответствует паттерну {var_def.regex}")
        
        result = {
            "errors": errors,
            "warnings": warnings,
            "is_valid": len(errors) == 0
        }
        
        if errors:
            logging.error("Ошибки валидации переменных окружения:")
            for error in errors:
                logging.error(f"  - {error}")
        
        if warnings:
            logging.warning("Предупреждения валидации переменных окружения:")
            for warning in warnings:
                logging.warning(f"  - {warning}")
        
        return result
    
    def get_variable_info(self, var_name: str) -> Optional[EnvVarDefinition]:
        """Получение информации о переменной."""
        return self.ENV_VARIABLES.get(var_name)
    
    def list_variables(self, include_deprecated: bool = False) -> Dict[str, EnvVarDefinition]:
        """Список всех переменных."""
        if include_deprecated:
            return self.ENV_VARIABLES
        
        return {name: var for name, var in self.ENV_VARIABLES.items() if not var.deprecated}
    
    def generate_env_template(self, output_path: str = ".env.template") -> None:
        """Генерация шаблона .env файла."""
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# Шаблон переменных окружения для Iskra API\n")
            f.write("# Скопируйте в .env и заполните значениями\n\n")
            
            for var_name, var_def in self.ENV_VARIABLES.items():
                if var_def.deprecated:
                    continue
                    
                f.write(f"# {var_def.description}\n")
                f.write(f"# Тип: {var_def.type.value}")
                
                if var_def.choices:
                    f.write(f", Допустимые значения: {var_def.choices}")
                if var_def.required:
                    f.write(", Обязательная")
                
                f.write("\n")
                
                # Пример значения
                if var_def.default is not None:
                    f.write(f"# Пример: {var_def.default}\n")
                
                f.write(f"{var_name}=")
                
                if var_def.type == EnvVarType.SECRET:
                    f.write("your-secret-key-here\n")
                elif var_def.type == EnvVarType.LIST:
                    f.write("value1,value2,value3\n")
                elif var_def.type == EnvVarType.DICT:
                    f.write('{"key1": "value1", "key2": "value2"}\n')
                else:
                    f.write(f"{var_def.default or ''}\n")
                
                f.write("\n")
        
        logging.info(f"Шаблон .env файла создан: {output_path}")
    
    def config_to_env_vars(self, config) -> Dict[str, str]:
        """Преобразование конфигурации обратно в переменные окружения."""
        env_vars = {}
        
        # Безопасные настройки
        if hasattr(config, 'security'):
            env_vars["JWT_SECRET"] = config.security.jwt_secret
            env_vars["JWT_ALGORITHM"] = config.security.jwt_algorithm
            env_vars["JWT_ACCESS_TOKEN_EXPIRE_MINUTES"] = str(config.security.jwt_access_token_expire_minutes)
            env_vars["CORS_ORIGINS"] = ",".join(config.security.cors_origins)
            env_vars["CORS_ALLOW_CREDENTIALS"] = str(config.security.cors_allow_credentials).lower()
            env_vars["RATE_LIMIT_ENABLED"] = str(config.security.rate_limit_enabled).lower()
            env_vars["RATE_LIMIT_REQUESTS"] = str(config.security.rate_limit_requests_per_minute)
        
        # API настройки
        if hasattr(config, 'api'):
            env_vars["HOST"] = config.api.host
            env_vars["PORT"] = str(config.api.port)
            env_vars["DOCS_ENABLED"] = str(config.api.docs_enabled).lower()
        
        # Memory настройки
        if hasattr(config, 'memory'):
            env_vars["MEMORY_ROOT"] = config.memory.memory_root
            env_vars["MEMORY_BATCH_SIZE"] = str(config.memory.memory_batch_size)
            env_vars["MEMORY_COMPRESSION"] = str(config.memory.memory_compression_enabled).lower()
        
        # Logging настройки
        if hasattr(config, 'logging'):
            env_vars["LOG_LEVEL"] = config.logging.log_level
            env_vars["LOG_FORMAT"] = config.logging.log_format
            env_vars["CONSOLE_LOGGING"] = str(config.logging.console_logging).lower()
            env_vars["FILE_LOGGING"] = str(config.logging.file_logging).lower()
        
        # Monitoring настройки
        if hasattr(config, 'monitoring'):
            env_vars["METRICS_ENABLED"] = str(config.monitoring.metrics_enabled).lower()
            env_vars["HEALTH_CHECK_ENABLED"] = str(config.monitoring.health_check_enabled).lower()
            env_vars["OTEL_ENABLED"] = str(config.monitoring.otel_enabled).lower()
        
        return env_vars
    
    def get_loaded_variables(self) -> Dict[str, Any]:
        """Получение загруженных переменных."""
        return self.loaded_vars.copy()
    
    def get_validation_errors(self) -> List[str]:
        """Получение ошибок валидации."""
        return self.validation_errors.copy()