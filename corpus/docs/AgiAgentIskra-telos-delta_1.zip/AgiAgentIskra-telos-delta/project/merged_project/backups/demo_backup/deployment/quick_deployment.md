# Быстрое развертывание для разработки

## Предварительные требования

### Системные требования
- **ОС**: Linux, macOS или Windows 10+
- **RAM**: Минимум 4GB (рекомендуется 8GB)
- **Диск**: Минимум 2GB свободного места
- **Процессор**: 2+ ядра

### Зависимости
- **Python**: 3.9+ (рекомендуется 3.11+)
- **Git**: Последняя версия
- **pip**: Обновленный пакетный менеджер Python

### Опциональные зависимости
- **Docker**: 20.10+ (для контейнеризации)
- **Docker Compose**: 2.0+ (для управления сервисами)
- **PostgreSQL**: 14+ (для production)
- **Redis**: 6+ (для кэширования)

## Установка

### Шаг 1: Клонирование репозитория
```bash
# Клонирование проекта
git clone <repository_url>
cd merged_project

# Проверка структуры
ls -la
```

### Шаг 2: Создание виртуального окружения
```bash
# Создание виртуального окружения
python -m venv venv

# Активация (Linux/Mac)
source venv/bin/activate

# Активация (Windows)
venv\Scripts\activate

# Проверка активации
which python
python --version
```

### Шаг 3: Установка зависимостей
```bash
# Обновление pip
pip install --upgrade pip setuptools wheel

# Установка основных зависимостей
pip install -r requirements.txt

# Установка дополнительных пакетов для разработки
pip install -r config/requirements.txt

# Установка тестовых зависимостей
pip install pytest pytest-cov black flake8 mypy
```

### Шаг 4: Базовая конфигурация
```bash
# Создание файла окружения
cp .env.example .env

# Редактирование настроек (используйте ваш любимый редактор)
nano .env
```

**Минимальный .env для разработки:**
```bash
# Основные настройки
APP_NAME=MergedDIApp
APP_ENV=development
APP_DEBUG=true
APP_PORT=8000

# База данных (SQLite для быстрого старта)
DATABASE_TYPE=sqlite
DATABASE_URL=sqlite:///./dev.db

# Кэширование
CACHE_TYPE=memory
REDIS_URL=redis://localhost:6379/0

# Логирование
LOG_LEVEL=DEBUG
LOG_FORMAT=simple

# Безопасность
SECRET_KEY=dev-secret-key-change-in-production
```

### Шаг 5: Инициализация компонентов
```bash
# Инициализация памяти
python -c "from memory.integrated_memory import IntegratedMemory; IntegratedMemory().initialize()"

# Инициализация поиска
python -c "from search.integrated_search import IntegratedSearch; IntegratedSearch().initialize()"

# Инициализация API
python -c "from api.unified_api import UnifiedAPI; UnifiedAPI().initialize()"
```

### Шаг 6: Запуск приложения
```bash
# Основной запуск
python main.py

# Или с отладкой
python -m debugpy --listen 0.0.0.0:5678 --wait-for-client main.py

# Альтернативный запуск
python run.py --dev --reload
```

### Шаг 7: Проверка запуска
```bash
# Проверка статуса
curl http://localhost:8000/health

# Проверка API документации
open http://localhost:8000/docs

# Проверка основных эндпоинтов
curl http://localhost:8000/api/v1/status
curl http://localhost:8000/api/v2/status
```

## Проверка работоспособности

### Health Checks
```bash
# Основная проверка
python -c "
import requests
import sys

try:
    response = requests.get('http://localhost:8000/health', timeout=5)
    if response.status_code == 200:
        print('✅ Приложение успешно запущено')
        print(f'Статус: {response.json()}')
    else:
        print('❌ Приложение не отвечает корректно')
        sys.exit(1)
except Exception as e:
    print(f'❌ Ошибка подключения: {e}')
    sys.exit(1)
"
```

### Функциональные тесты
```bash
# Запуск базовых тестов
python -m pytest tests/ -v --tb=short

# Тестирование памяти
python -c "from memory.tests.test_integration import test_memory_basic; test_memory_basic()"

# Тестирование поиска
python -c "from search.tests.test_compatibility import test_search_basic; test_search_basic()"

# Тестирование API
python -c "from api.tests.test_unified_api import test_api_basic; test_api_basic()"
```

### Тестирование производительности
```bash
# Базовый нагрузочный тест
python -c "
import time
import requests

start_time = time.time()
for i in range(10):
    response = requests.get('http://localhost:8000/health')
    print(f'Запрос {i+1}: {response.status_code}')

end_time = time.time()
print(f'Время выполнения: {end_time - start_time:.2f} секунд')
"
```

## Конфигурация разработки

### Переменные окружения (.env)
```bash
# Разработка
APP_ENV=development
APP_DEBUG=true
APP_PORT=8000
HOST=127.0.0.1

# Автоперезагрузка
AUTO_RELOAD=true
RELOAD_DIRS=core,api,memory,search

# Отладка
DEBUG_LEVEL=DEBUG
PROFILING_ENABLED=true
PERFORMANCE_MONITORING=true

# База данных
DATABASE_TYPE=sqlite
DATABASE_URL=sqlite:///./dev.db
DATABASE_POOL_SIZE=5
DATABASE_TIMEOUT=30

# Кэширование
CACHE_TYPE=file
CACHE_DIR=./cache
CACHE_TTL=3600
CACHE_SIZE=1000

# Логирование
LOG_LEVEL=DEBUG
LOG_FORMAT=detailed
LOG_FILE=logs/dev.log
LOG_ROTATION=1MB
LOG_RETENTION=7

# API
API_VERSION=v2
API_RATE_LIMIT=1000
API_TIMEOUT=30

# Безопасность
SECRET_KEY=dev-secret-key
ALLOWED_HOSTS=localhost,127.0.0.1
CORS_ORIGINS=http://localhost:3000,http://localhost:8080

# Интеграция
INTEGRATION_TIMEOUT=60
RETRY_ATTEMPTS=3
FALLBACK_ENABLED=true
```

### Настройка IDE

#### VS Code
```json
// .vscode/launch.json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Main",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/main.py",
            "console": "integratedTerminal",
            "envFile": "${workspaceFolder}/.env"
        },
        {
            "name": "Python: Debug",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/main.py",
            "args": ["--debug"],
            "console": "integratedTerminal",
            "envFile": "${workspaceFolder}/.env"
        }
    ]
}
```

#### PyCharm
```python
# Run/Debug Configuration
Script path: $PROJECT_DIR$/main.py
Working directory: $PROJECT_DIR$
Environment variables: (import from .env file)
```

## Мониторинг разработки

### Логи
```bash
# Просмотр логов в реальном времени
tail -f logs/dev.log

# Фильтрация ошибок
grep "ERROR" logs/dev.log

# Мониторинг производительности
tail -f logs/performance.log
```

### Метрики
```bash
# Получение метрик
curl http://localhost:8000/metrics

# Проверка производительности
curl http://localhost:8000/perf
```

### Отладка
```bash
# Запуск с отладчиком
python -m pdb main.py

# Профилирование
python -m cProfile -o profile.stats main.py

# Анализ профиля
python -c "
import pstats
stats = pstats.Stats('profile.stats')
stats.sort_stats('cumulative').print_stats(10)
"
```

## Решение проблем

### Частые ошибки

#### Ошибка импорта модулей
```bash
# Добавление путей
export PYTHONPATH=$PYTHONPATH:/path/to/merged_project

# Установка в режиме разработки
pip install -e .
```

#### Проблемы с базой данных
```bash
# Проверка SQLite файла
ls -la *.db
sqlite3 dev.db ".tables"

# Очистка и пересоздание
rm dev.db
python -c "from memory.integrated_memory import IntegratedMemory; IntegratedMemory().initialize()"
```

#### Проблемы с портом
```bash
# Поиск процесса на порту 8000
lsof -i :8000
netstat -tulpn | grep 8000

# Завершение процесса
kill -9 <PID>
```

#### Проблемы с зависимостями
```bash
# Обновление pip
pip install --upgrade pip

# Очистка кэша pip
pip cache purge

# Переустановка зависимостей
pip uninstall -r requirements.txt -y
pip install -r requirements.txt
```

### Отладочные команды
```bash
# Проверка версий
python --version
pip list | grep -E "(flask|fastapi|redis|sqlalchemy)"

# Проверка окружения
python -c "import sys; print(sys.path)"
python -c "import os; print([key for key in os.environ if 'PATH' in key or 'PYTHON' in key])"

# Проверка модулей
python -c "import memory.integrated_memory; print('Memory OK')"
python -c "import search.integrated_search; print('Search OK')"
python -c "import api.unified_api; print('API OK')"
```

## Оптимизация разработки

### Автоматизация
```bash
# Создание aliases
cat >> ~/.bashrc << 'EOF'
alias di-run='cd /path/to/merged_project && source venv/bin/activate && python main.py'
alias di-test='cd /path/to/merged_project && source venv/bin/activate && python -m pytest'
alias di-logs='cd /path/to/merged_project && tail -f logs/dev.log'
alias di-shell='cd /path/to/merged_project && source venv/bin/activate && python'
EOF

# Применение изменений
source ~/.bashrc
```

### Автоматический мониторинг
```bash
# Создание скрипта автосброса
cat > watch_restart.sh << 'EOF'
#!/bin/bash
while true; do
    if pgrep -f "python.*main.py" > /dev/null; then
        echo "Приложение работает"
    else
        echo "Перезапуск приложения..."
        python main.py &
    fi
    sleep 10
done
EOF

chmod +x watch_restart.sh
./watch_restart.sh
```

## Следующие шаги

1. **Настройка базы данных**: [production_deployment.md](production_deployment.md)
2. **Контейнеризация**: [docker_deployment.md](docker_deployment.md)
3. **Мониторинг**: [monitoring_setup.md](monitoring_setup.md)
4. **Решение проблем**: [troubleshooting.md](troubleshooting.md)

## Поддержка

- **Документация**: `docs/`
- **Логи**: `logs/`
- **Тесты**: `tests/`
- **Конфигурация**: `.env`

---

**Примечание**: Данное руководство предназначено для быстрого развертывания в среде разработки. Для продакшена используйте соответствующие руководства.
