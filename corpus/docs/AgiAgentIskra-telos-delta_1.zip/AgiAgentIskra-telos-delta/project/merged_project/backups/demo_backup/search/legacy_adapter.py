"""Адаптер для интеграции Version 1 поисковой системы.

Обеспечивает совместимость с GraphRAG возможностями из Version 1
через унифицированный интерфейс поиска.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Any, Iterable
import json

logger = logging.getLogger(__name__)

@dataclass
class LegacySearchConfig:
    """Конфигурация для legacy поиска Version 1."""
    k: int = 5
    use_graph: bool = True
    use_vector: bool = True
    graph_weight: float = 0.4
    vector_weight: float = 0.6
    evidence_path: str = "memory/evidence.jsonl"
    enable_enhanced_scoring: bool = True

@dataclass
class EvidenceChunk:
    """Часть доказательства (совместимость с Version 1)."""
    doc_id: str
    chunk_id: int
    content: str
    score: float
    source: str = 'vector'
    metadata: Optional[Dict[str, Any]] = None

class LegacyVectorSearch:
    """Адаптер для поисковой системы Version 1 с GraphRAG возможностями."""
    
    def __init__(self, config: LegacySearchConfig):
        """Инициализация legacy поиска.
        
        Args:
            config: Конфигурация поиска
        """
        self.config = config
        self._graph_available = self._check_graph_availability()
        self._evidence_cache = {}
        logger.info(f"Legacy поиск инициализирован (GraphRAG: {self._graph_available})")
    
    def _check_graph_availability(self) -> bool:
        """Проверка доступности GraphRAG."""
        try:
            # Попытка импорта graphrag модуля
            import sys
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 
                                       'user_input_files', 'extracted_v1', 'iskra_project'))
            
            from iskra_project.lib.vector_search import hybrid_search
            return True
        except ImportError as e:
            logger.warning(f"GraphRAG недоступен: {e}")
            return False
    
    async def search(self, query: str, **kwargs) -> List[EvidenceChunk]:
        """Основной метод поиска в legacy режиме.
        
        Args:
            query: Поисковый запрос
            **kwargs: Дополнительные параметры
            
        Returns:
            Список результатов поиска
        """
        # Параметры поиска
        search_kwargs = {
            'k': kwargs.get('k', self.config.k),
            'use_graph': kwargs.get('use_graph', self.config.use_graph) and self._graph_available,
            'use_vector': kwargs.get('use_vector', self.config.use_vector),
            'evidence_path': kwargs.get('evidence_path', self.config.evidence_path)
        }
        
        logger.debug(f"Legacy поиск: query='{query}', kwargs={search_kwargs}")
        
        try:
            # Импорт функций из Version 1
            import sys
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 
                                       'user_input_files', 'extracted_v1', 'iskra_project'))
            
            from iskra_project.lib.vector_search import (
                hybrid_search, vector_search, SearchConfig
            )
            
            # Создание конфигурации поиска
            version1_config = SearchConfig(
                k=search_kwargs['k'],
                use_graph=search_kwargs['use_graph'],
                use_vector=search_kwargs['use_vector'],
                graph_weight=self.config.graph_weight,
                vector_weight=self.config.vector_weight,
                evidence_path=search_kwargs['evidence_path']
            )
            
            start_time = time.time()
            
            if search_kwargs['use_graph'] and self._graph_available:
                # Использование hybrid search с GraphRAG
                results = await self._run_hybrid_search(query, version1_config)
            else:
                # Только vector search
                results = await self._run_vector_search(query, search_kwargs['k'], 
                                                     search_kwargs['evidence_path'])
            
            search_time = time.time() - start_time
            logger.debug(f"Legacy поиск завершен за {search_time:.3f}s, найдено {len(results)} результатов")
            
            return results
            
        except Exception as e:
            logger.error(f"Ошибка в legacy поиске: {e}")
            # Fallback к базовому поиску
            return await self._fallback_search(query, search_kwargs)
    
    async def _run_hybrid_search(self, query: str, config) -> List[EvidenceChunk]:
        """Выполнение hybrid search с GraphRAG."""
        try:
            # Попытка использовать async версию если доступна
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(
                None, hybrid_search, query, config
            )
            return results
        except Exception as e:
            logger.warning(f"Hybrid search не удался, использую vector search: {e}")
            # Fallback к vector search
            return await self._run_vector_search(query, config.k, config.evidence_path)
    
    async def _run_vector_search(self, query: str, k: int, evidence_path: str) -> List[EvidenceChunk]:
        """Выполнение векторного поиска."""
        try:
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(
                None, self._vector_search_sync, query, k, evidence_path
            )
            return results
        except Exception as e:
            logger.error(f"Vector search не удался: {e}")
            return []
    
    def _vector_search_sync(self, query: str, k: int, evidence_path: str) -> List[EvidenceChunk]:
        """Синхронный векторный поиск."""
        try:
            import sys
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 
                                       'user_input_files', 'extracted_v1', 'iskra_project'))
            
            from iskra_project.lib.vector_search import vector_search as v1_vector_search
            
            return v1_vector_search(query, k, evidence_path)
        except Exception as e:
            logger.error(f"Ошибка синхронного векторного поиска: {e}")
            return []
    
    async def _fallback_search(self, query: str, kwargs: Dict) -> List[EvidenceChunk]:
        """Fallback поиск при ошибках."""
        logger.warning("Использую fallback поиск")
        
        try:
            # Простой fallback без GraphRAG
            fallback_kwargs = {
                'k': kwargs['k'],
                'use_graph': False,
                'use_vector': True,
                'evidence_path': kwargs['evidence_path']
            }
            return await self._run_vector_search(query, fallback_kwargs['k'], 
                                               fallback_kwargs['evidence_path'])
        except Exception as e:
            logger.error(f"Fallback поиск также не удался: {e}")
            return []
    
    def build_knowledge_graph(self, evidence_path: str = None) -> Dict[str, Any]:
        """Построение графа знаний (если доступен GraphRAG)."""
        if not self._graph_available:
            return {"error": "GraphRAG недоступен"}
        
        try:
            import sys
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 
                                       'user_input_files', 'extracted_v1', 'iskra_project'))
            
            from iskra_project.lib.vector_search import build_knowledge_graph as v1_build_graph
            
            evidence_path = evidence_path or self.config.evidence_path
            return v1_build_graph(evidence_path)
        except Exception as e:
            logger.error(f"Ошибка построения графа знаний: {e}")
            return {"error": str(e)}
    
    def get_available_features(self) -> Dict[str, bool]:
        """Получение информации о доступных функциях."""
        return {
            "graphrag": self._graph_available,
            "hybrid_search": self._graph_available,
            "entity_extraction": self._graph_available,
            "relationship_analysis": self._graph_available,
            "community_detection": self._graph_available,
            "enhanced_scoring": self.config.enable_enhanced_scoring
        }
    
    def get_evidence_statistics(self, evidence_path: str = None) -> Dict[str, Any]:
        """Получение статистики по данным."""
        evidence_path = evidence_path or self.config.evidence_path
        
        try:
            if not os.path.exists(evidence_path):
                return {"error": f"Файл {evidence_path} не найден"}
            
            doc_count = 0
            chunk_count = 0
            total_content_length = 0
            unique_docs = set()
            
            with open(evidence_path, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        obj = json.loads(line.strip())
                        if obj.get('doc_id') and obj.get('content'):
                            unique_docs.add(obj['doc_id'])
                            doc_count += 1
                            chunk_count += 1
                            total_content_length += len(obj['content'])
                    except json.JSONDecodeError:
                        continue
            
            return {
                "documents_count": len(unique_docs),
                "chunks_count": chunk_count,
                "total_content_length": total_content_length,
                "average_chunk_length": total_content_length / chunk_count if chunk_count > 0 else 0,
                "evidence_file_exists": True,
                "evidence_path": evidence_path
            }
        except Exception as e:
            logger.error(f"Ошибка получения статистики: {e}")
            return {"error": str(e)}
    
    def clear_cache(self):
        """Очистка кэша данных."""
        self._evidence_cache.clear()
        logger.info("Legacy cache очищен")
    
    def configure_graph_weights(self, graph_weight: float, vector_weight: float):
        """Настройка весов для гибридного поиска."""
        if 0 <= graph_weight <= 1 and 0 <= vector_weight <= 1:
            self.config.graph_weight = graph_weight
            self.config.vector_weight = vector_weight
            logger.info(f"Веса настроены: graph={graph_weight}, vector={vector_weight}")
        else:
            raise ValueError("Веса должны быть в диапазоне [0, 1]")
    
    def set_evidence_path(self, evidence_path: str):
        """Установка пути к файлу с доказательствами."""
        self.config.evidence_path = evidence_path
        logger.info(f"Путь к evidence установлен: {evidence_path}")
    
    def __str__(self) -> str:
        features = self.get_available_features()
        return (f"LegacyVectorSearch("
                f"graphrag={features['graphrag']}, "
                f"hybrid={features['hybrid_search']}, "
                f"enhanced_scoring={features['enhanced_scoring']})")
    
    def __repr__(self) -> str:
        return self.__str__()