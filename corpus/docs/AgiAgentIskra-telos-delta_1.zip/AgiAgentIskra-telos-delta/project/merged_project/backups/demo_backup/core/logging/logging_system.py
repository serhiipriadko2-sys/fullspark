"""Система централизованного логирования.

Обеспечивает единообразное логирование всех типов ошибок и событий в приложении.
Интегрируется с системой обработки исключений для полного мониторинга.

Версия: 1.0
Автор: Iskra Integration Team
"""

import logging
import logging.config
import sys
import json
import traceback
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
import os
from dataclasses import dataclass, asdict
from enum import Enum
import asyncio
from concurrent.futures import ThreadPoolExecutor

from .exception_hierarchy import BaseIskraException, ErrorLevel, ErrorType, get_exception_info


# ================================
# Константы и Enums
# ================================

class LogFormat(Enum):
    """Форматы логирования."""
    JSON = "json"
    TEXT = "text"
    COLORED = "colored"


class LogDestination(Enum):
    """Назначения логов."""
    CONSOLE = "console"
    FILE = "file"
    DATABASE = "database"
    ELASTICSEARCH = "elasticsearch"
    KAFKA = "kafka"


@dataclass
class LogContext:
    """Контекст для логирования."""
    request_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    endpoint: Optional[str] = None
    method: Optional[str] = None
    user_agent: Optional[str] = None
    ip_address: Optional[str] = None
    correlation_id: Optional[str] = None


@dataclass
class LogEntry:
    """Запись лога."""
    timestamp: str
    level: str
    logger: str
    message: str
    module: str
    function: str
    line_number: int
    context: Dict[str, Any]
    exception_info: Optional[Dict[str, Any]] = None
    performance_metrics: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразует запись в словарь."""
        return asdict(self)
    
    def to_json(self) -> str:
        """Преобразует запись в JSON строку."""
        return json.dumps(self.to_dict(), ensure_ascii=False, default=str)


# ================================
# Custom Formatters
# ================================

class IskraJSONFormatter(logging.Formatter):
    """JSON formatter для структурированного логирования."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Форматирует запись в JSON."""
        log_entry = LogEntry(
            timestamp=datetime.fromtimestamp(record.created).isoformat(),
            level=record.levelname,
            logger=record.name,
            message=record.getMessage(),
            module=record.module,
            function=record.funcName,
            line_number=record.lineno,
            context=getattr(record, 'context', {}),
            exception_info=getattr(record, 'exception_info', None),
            performance_metrics=getattr(record, 'performance_metrics', None)
        )
        
        return log_entry.to_json()


class IskraTextFormatter(logging.Formatter):
    """Текстовый formatter для читаемого логирования."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Форматирует запись в читаемый текст."""
        # Базовое форматирование
        formatted = f"{record.levelname:8} | {record.name:20} | {record.getMessage()}"
        
        # Добавляем контекст, если есть
        context = getattr(record, 'context', {})
        if context:
            context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
            formatted += f" | Context: {context_str}"
        
        # Добавляем информацию об исключении, если есть
        if record.exc_info:
            formatted += f"\nException: {record.exc_info[1]}"
            formatted += f"\nTraceback: {''.join(traceback.format_exception(*record.exc_info))}"
        
        return formatted


# ================================
# Context Manager для логирования
# ================================

class LoggingContext:
    """Контекстный менеджер для логирования с контекстом."""
    
    def __init__(self, logger: logging.Logger, context: LogContext):
        self.logger = logger
        self.context = context
        self.old_logging_context = None
    
    def __enter__(self):
        # Сохраняем текущий контекст
        self.old_logging_context = getattr(logging.LogRecord, '_iskra_context', None)
        
        # Устанавливаем новый контекст
        logging.LogRecord._iskra_context = self.context.__dict__
        
        # Обновляем логгеры с контекстом
        for handler in self.logger.handlers:
            for record in handler.format.__self__.records if hasattr(handler.format, 'records') else []:
                record.context = self.context.__dict__
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Восстанавливаем контекст
        if self.old_logging_context is not None:
            logging.LogRecord._iskra_context = self.old_logging_context
        else:
            if hasattr(logging.LogRecord, '_iskra_context'):
                delattr(logging.LogRecord, '_iskra_context')


# ================================
# Logger Factory
# ================================

class LoggerFactory:
    """Фабрика для создания логгеров."""
    
    _loggers: Dict[str, logging.Logger] = {}
    _config: Dict[str, Any] = {}
    _context: Optional[LogContext] = None
    
    @classmethod
    def configure(cls, config: Dict[str, Any]):
        """Настраивает систему логирования."""
        cls._config = config
        logging.config.dictConfig(config)
    
    @classmethod
    def get_logger(cls, name: str, context: Optional[LogContext] = None) -> logging.Logger:
        """Получает логгер с именем."""
        if name not in cls._loggers:
            cls._loggers[name] = logging.getLogger(name)
        
        if context:
            cls._context = context
        
        return cls._loggers[name]
    
    @classmethod
    def get_error_logger(cls) -> logging.Logger:
        """Получает логгер для ошибок."""
        return cls.get_logger("iskra.errors")
    
    @classmethod
    def get_performance_logger(cls) -> logging.Logger:
        """Получает логгер для метрик производительности."""
        return cls.get_logger("iskra.performance")
    
    @classmethod
    def get_audit_logger(cls) -> logging.Logger:
        """Получает логгер для аудита."""
        return cls.get_logger("iskra.audit")
    
    @classmethod
    def set_context(cls, context: LogContext):
        """Устанавливает контекст для всех логгеров."""
        cls._context = context


# ================================
# Centralized Logging System
# ================================

class CentralizedLogger:
    """Централизованная система логирования."""
    
    def __init__(
        self,
        name: str,
        format_type: LogFormat = LogFormat.JSON,
        destinations: Optional[List[LogDestination]] = None,
        log_file: Optional[str] = None,
        level: str = "INFO"
    ):
        self.name = name
        self.format_type = format_type
        self.destinations = destinations or [LogDestination.CONSOLE]
        self.log_file = log_file
        self.level = level
        self.logger = logging.getLogger(name)
        self._setup_logger()
    
    def _setup_logger(self):
        """Настраивает логгер."""
        # Устанавливаем уровень
        self.logger.setLevel(getattr(logging, self.level.upper()))
        
        # Очищаем существующие handlers
        for handler in self.logger.handlers[:]:
            self.logger.removeHandler(handler)
        
        # Добавляем handlers в зависимости от destinations
        if LogDestination.CONSOLE in self.destinations:
            self._add_console_handler()
        
        if LogDestination.FILE in self.destinations and self.log_file:
            self._add_file_handler()
    
    def _add_console_handler(self):
        """Добавляет консольный handler."""
        handler = logging.StreamHandler(sys.stdout)
        
        if self.format_type == LogFormat.JSON:
            formatter = IskraJSONFormatter()
        else:
            formatter = IskraTextFormatter()
        
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def _add_file_handler(self):
        """Добавляет файловый handler."""
        # Создаем директорию для логов
        log_path = Path(self.log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        handler = logging.FileHandler(self.log_file, encoding='utf-8')
        
        if self.format_type == LogFormat.JSON:
            formatter = IskraJSONFormatter()
        else:
            formatter = IskraTextFormatter()
        
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def log_exception(
        self,
        exc: Exception,
        level: str = "ERROR",
        context: Optional[Dict[str, Any]] = None,
        performance_metrics: Optional[Dict[str, Any]] = None
    ):
        """Логирует исключение."""
        # Получаем информацию об исключении
        exc_info = get_exception_info(exc)
        
        # Создаем дополнительный контекст
        log_context = context or {}
        if hasattr(exc, 'details') and exc.details:
            log_context.update(exc.details)
        
        # Создаем LogRecord с дополнительной информацией
        record = self.logger.makeRecord(
            self.logger.name,
            getattr(logging, level.upper()),
            __file__,
            0,
            str(exc),
            (),
            None,
            exc.__class__.__name__
        )
        record.context = log_context
        record.exception_info = exc_info
        record.performance_metrics = performance_metrics
        
        # Логируем
        self.logger.handle(record)
    
    def log_error_with_context(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        exc_info: Optional[Any] = None,
        level: str = "ERROR"
    ):
        """Логирует ошибку с контекстом."""
        record = self.logger.makeRecord(
            self.logger.name,
            getattr(logging, level.upper()),
            __file__,
            0,
            message,
            (),
            exc_info
        )
        record.context = context or {}
        
        self.logger.handle(record)
    
    def log_performance(
        self,
        operation: str,
        duration: float,
        context: Optional[Dict[str, Any]] = None
    ):
        """Логирует метрики производительности."""
        metrics = {
            "operation": operation,
            "duration_ms": duration * 1000,
            "timestamp": datetime.now().isoformat()
        }
        
        if context:
            metrics.update(context)
        
        record = self.logger.makeRecord(
            "iskra.performance",
            logging.INFO,
            __file__,
            0,
            f"Performance: {operation} took {duration:.3f}s",
            (),
            None
        )
        record.performance_metrics = metrics
        
        LoggerFactory.get_performance_logger().handle(record)
    
    def log_audit(
        self,
        action: str,
        user_id: Optional[str] = None,
        resource: Optional[str] = None,
        result: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ):
        """Логирует аудит действия."""
        audit_data = {
            "action": action,
            "user_id": user_id,
            "resource": resource,
            "result": result,
            "timestamp": datetime.now().isoformat()
        }
        
        if context:
            audit_data.update(context)
        
        record = self.logger.makeRecord(
            "iskra.audit",
            logging.INFO,
            __file__,
            0,
            f"Audit: {action}",
            (),
            None
        )
        record.context = audit_data
        
        LoggerFactory.get_audit_logger().handle(record)


# ================================
# Async Logging Support
# ================================

class AsyncLogger:
    """Асинхронный логгер для высоконагруженных систем."""
    
    def __init__(self, base_logger: CentralizedLogger):
        self.base_logger = base_logger
        self.executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="iskra-logger")
    
    async def log_exception_async(
        self,
        exc: Exception,
        level: str = "ERROR",
        context: Optional[Dict[str, Any]] = None
    ):
        """Асинхронно логирует исключение."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            self.executor,
            self.base_logger.log_exception,
            exc, level, context
        )
    
    async def log_error_async(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        level: str = "ERROR"
    ):
        """Асинхронно логирует ошибку."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            self.executor,
            self.base_logger.log_error_with_context,
            message, context, None, level
        )
    
    async def log_performance_async(
        self,
        operation: str,
        duration: float,
        context: Optional[Dict[str, Any]] = None
    ):
        """Асинхронно логирует метрики производительности."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            self.executor,
            self.base_logger.log_performance,
            operation, duration, context
        )
    
    async def log_audit_async(
        self,
        action: str,
        user_id: Optional[str] = None,
        resource: Optional[str] = None,
        result: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ):
        """Асинхронно логирует аудит."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            self.executor,
            self.base_logger.log_audit,
            action, user_id, resource, result, context
        )
    
    def __del__(self):
        """Очистка ресурсов."""
        if hasattr(self, 'executor'):
            self.executor.shutdown(wait=False)


# ================================
# Utility Functions
# ================================

def setup_logging(
    log_level: str = "INFO",
    log_format: LogFormat = LogFormat.JSON,
    log_file: Optional[str] = None,
    enable_async: bool = False
) -> CentralizedLogger:
    """Настраивает систему логирования."""
    
    # Создаем централизованный логгер
    central_logger = CentralizedLogger(
        name="iskra.main",
        format_type=log_format,
        destinations=[LogDestination.CONSOLE] + ([LogDestination.FILE] if log_file else []),
        log_file=log_file,
        level=log_level
    )
    
    # Настраиваем логгеры для разных целей
    error_logger = CentralizedLogger(
        "iskra.errors",
        format_type=log_format,
        destinations=[LogDestination.CONSOLE, LogDestination.FILE] if log_file else [LogDestination.CONSOLE],
        log_file=f"{log_file}.errors" if log_file else None,
        level="ERROR"
    )
    
    performance_logger = CentralizedLogger(
        "iskra.performance",
        format_type=LogFormat.JSON,
        destinations=[LogDestination.FILE] if log_file else [LogDestination.CONSOLE],
        log_file=f"{log_file}.performance" if log_file else None,
        level="INFO"
    )
    
    audit_logger = CentralizedLogger(
        "iskra.audit",
        format_type=LogFormat.JSON,
        destinations=[LogDestination.FILE] if log_file else [LogDestination.CONSOLE],
        log_file=f"{log_file}.audit" if log_file else None,
        level="INFO"
    )
    
    if enable_async:
        return AsyncLogger(central_logger)
    
    return central_logger


def get_logger(name: str, context: Optional[LogContext] = None) -> CentralizedLogger:
    """Получает логгер с именем."""
    return CentralizedLogger(name)


def log_request(
    logger: CentralizedLogger,
    method: str,
    path: str,
    status_code: int,
    duration: float,
    request_id: Optional[str] = None,
    user_id: Optional[str] = None
):
    """Логирует HTTP запрос."""
    context = {
        "method": method,
        "path": path,
        "status_code": status_code,
        "request_id": request_id,
        "user_id": user_id
    }
    
    level = "INFO" if 200 <= status_code < 400 else "WARNING" if 400 <= status_code < 500 else "ERROR"
    
    logger.log_performance("http_request", duration, context)
    logger.log_error_with_context(
        f"{method} {path} - {status_code}",
        context=context,
        level=level
    )


def log_database_operation(
    logger: CentralizedLogger,
    operation: str,
    table: str,
    duration: float,
    success: bool,
    context: Optional[Dict[str, Any]] = None
):
    """Логирует операцию с базой данных."""
    op_context = {
        "operation": operation,
        "table": table,
        "success": success,
        **(context or {})
    }
    
    level = "INFO" if success else "ERROR"
    message = f"DB {operation} on {table} - {'success' if success else 'failed'}"
    
    logger.log_performance("database_operation", duration, op_context)
    logger.log_error_with_context(message, context=op_context, level=level)


def log_search_operation(
    logger: CentralizedLogger,
    query: str,
    results_count: int,
    duration: float,
    search_type: str,
    context: Optional[Dict[str, Any]] = None
):
    """Логирует операцию поиска."""
    search_context = {
        "query": query,
        "results_count": results_count,
        "search_type": search_type,
        **(context or {})
    }
    
    message = f"Search '{query}' - {results_count} results ({search_type})"
    
    logger.log_performance("search_operation", duration, search_context)
    logger.log_error_with_context(message, context=search_context, level="INFO")