#!/usr/bin/env python3
"""
Простой тест компонентов конфигурации без внешних зависимостей.

Тестирует базовую функциональность без pydantic и других внешних библиотек.
"""

import sys
import os
from pathlib import Path
from enum import Enum

def test_basic_structures():
    """Тест базовых структур данных."""
    print("🔧 Тестирование базовых структур...")
    
    try:
        # Тест Enum
        class TestEnum(Enum):
            DEVELOPMENT = "development"
            PRODUCTION = "production"
            TESTING = "testing"
        
        assert TestEnum.DEVELOPMENT.value == "development"
        print("✅ Enum работает корректно")
        
        # Тест dataclass (базовая версия без pydantic)
        class MockSettings:
            def __init__(self, host="0.0.0.0", port=8000):
                self.host = host
                self.port = port
        
        settings = MockSettings()
        assert settings.host == "0.0.0.0"
        assert settings.port == 8000
        print("✅ Простые классы работают")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return False


def test_file_structure():
    """Тест структуры файлов."""
    print("\n🔧 Тестирование структуры файлов...")
    
    try:
        base_path = Path(__file__).parent
        
        expected_files = [
            "__init__.py",
            "unified_config.py",
            "environment.py",
            "compatibility.py",
            "migration.py",
            "validation.py",
            "defaults.py",
            "README.md",
            "examples/config_examples.py",
            "requirements.txt"
        ]
        
        missing_files = []
        for file_path in expected_files:
            full_path = base_path / file_path
            if not full_path.exists():
                missing_files.append(file_path)
        
        if missing_files:
            print(f"⚠️  Отсутствующие файлы: {missing_files}")
        else:
            print("✅ Все файлы присутствуют")
        
        return len(missing_files) == 0
    except Exception as e:
        print(f"❌ Ошибка проверки файлов: {e}")
        return False


def test_basic_functions():
    """Тест базовых функций."""
    print("\n🔧 Тестирование базовых функций...")
    
    try:
        # Простая функция конфигурации
        def get_default_config():
            return {
                "host": "0.0.0.0",
                "port": 8000,
                "debug": False,
                "log_level": "INFO"
            }
        
        config = get_default_config()
        assert config["host"] == "0.0.0.0"
        assert config["port"] == 8000
        assert config["debug"] == False
        print("✅ Базовые функции работают")
        
        # Функция валидации
        def validate_port(port):
            return isinstance(port, int) and 1 <= port <= 65535
        
        assert validate_port(8000) == True
        assert validate_port(0) == False
        assert validate_port(70000) == False
        print("✅ Функции валидации работают")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования функций: {e}")
        return False


def test_import_structure():
    """Тест структуры импортов."""
    print("\n🔧 Тестирование структуры импортов...")
    
    try:
        # Проверяем, что файлы можно импортировать как модули
        sys.path.insert(0, str(Path(__file__).parent))
        
        # Попытка импорта с обработкой ошибок
        try:
            from unified_config import EnvironmentProfile
            print("✅ Можно импортировать unified_config")
        except ImportError as e:
            print(f"⚠️  Не удалось импортировать unified_config: {e}")
        
        try:
            from environment import EnvironmentManager
            print("✅ Можно импортировать environment")
        except ImportError as e:
            print(f"⚠️  Не удалось импортировать environment: {e}")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования импортов: {e}")
        return False


def test_json_config():
    """Тест работы с JSON конфигурацией."""
    print("\n🔧 Тестирование JSON конфигурации...")
    
    try:
        import json
        
        # Создание тестовой конфигурации
        test_config = {
            "app_name": "Iskra API",
            "version": "1.0.0",
            "debug": False,
            "server": {
                "host": "0.0.0.0",
                "port": 8000
            },
            "security": {
                "jwt_secret": "test-secret",
                "jwt_algorithm": "HS256"
            }
        }
        
        # Сериализация
        json_str = json.dumps(test_config, indent=2)
        print("✅ Сериализация JSON работает")
        
        # Десериализация
        restored_config = json.loads(json_str)
        assert restored_config["app_name"] == "Iskra API"
        assert restored_config["server"]["port"] == 8000
        print("✅ Десериализация JSON работает")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования JSON: {e}")
        return False


def test_environment_variables():
    """Тест работы с переменными окружения."""
    print("\n🔧 Тестирование переменных окружения...")
    
    try:
        # Установка тестовых переменных
        test_vars = {
            "TEST_HOST": "127.0.0.1",
            "TEST_PORT": "8080",
            "TEST_DEBUG": "true"
        }
        
        for key, value in test_vars.items():
            os.environ[key] = value
        
        # Чтение переменных
        host = os.getenv("TEST_HOST")
        port = int(os.getenv("TEST_PORT", "0"))
        debug = os.getenv("TEST_DEBUG", "false").lower() == "true"
        
        assert host == "127.0.0.1"
        assert port == 8080
        assert debug == True
        
        print("✅ Переменные окружения работают")
        
        # Очистка
        for key in test_vars.keys():
            del os.environ[key]
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования окружения: {e}")
        return False


def test_file_operations():
    """Тест файловых операций."""
    print("\n🔧 Тестирование файловых операций...")
    
    try:
        # Создание временного файла
        test_file = Path(__file__).parent / "test_temp.txt"
        
        with open(test_file, 'w') as f:
            f.write("test content\n")
        
        # Чтение файла
        with open(test_file, 'r') as f:
            content = f.read()
        
        assert "test content" in content
        print("✅ Запись и чтение файлов работает")
        
        # Удаление файла
        test_file.unlink()
        
        return True
    except Exception as e:
        print(f"❌ Ошибка файловых операций: {e}")
        return False


def main():
    """Главная функция тестирования."""
    print("🚀 ПРОСТОЕ ТЕСТИРОВАНИЕ СИСТЕМЫ КОНФИГУРАЦИИ")
    print("=" * 60)
    
    tests = [
        ("Базовая структура", test_basic_structures),
        ("Структура файлов", test_file_structure),
        ("Базовые функции", test_basic_functions),
        ("Структура импортов", test_import_structure),
        ("JSON конфигурация", test_json_config),
        ("Переменные окружения", test_environment_variables),
        ("Файловые операции", test_file_operations),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"❌ Критическая ошибка в тесте '{test_name}': {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("📊 РЕЗУЛЬТАТЫ ПРОСТОГО ТЕСТИРОВАНИЯ")
    print("=" * 60)
    print(f"✅ Пройдено: {passed}")
    print(f"❌ Провалено: {failed}")
    print(f"📈 Процент успеха: {(passed / (passed + failed)) * 100:.1f}%")
    
    if failed == 0:
        print("\n🎉 Все простые тесты пройдены!")
        print("💡 Для полного тестирования установите зависимости:")
        print("   pip install pydantic pydantic-settings")
    else:
        print(f"\n⚠️  {failed} тестов провалено")
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)