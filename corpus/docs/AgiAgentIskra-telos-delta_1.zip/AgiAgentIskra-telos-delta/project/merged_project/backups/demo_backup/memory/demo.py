"""Демонстрационный скрипт интегрированной системы памяти.

Показывает использование всех режимов памяти:
- Legacy Mode (Version 1)
- Modern Mode (Version 2) 
- Hybrid Mode (дублирование)
- Migration Mode (постепенная миграция)
"""

import asyncio
import time
import json
import os
from pathlib import Path

# Импорт модулей системы памяти
from memory.integrated_memory import (
    IntegratedMemoryManager, MemoryMode, MemoryConfig
)
from memory.legacy_memory import LegacyMemoryManager
from memory.modern_memory import ModernMemoryManager
from memory.migration_tools import run_comprehensive_migration


async def demo_legacy_mode():
    """Демонстрация Legacy Mode (Version 1)."""
    print("\n=== Демонстрация Legacy Mode (Version 1) ===")
    
    config = MemoryConfig(
        mode=MemoryMode.LEGACY,
        root_path="./demo_memory_legacy"
    )
    
    with IntegratedMemoryManager(config) as memory:
        print("Сохранение событий в Legacy системе...")
        
        # Сохранение нескольких событий
        for i in range(5):
            event = memory.put(
                kind="archive",
                key=f"legacy_key_{i}",
                value={
                    "index": i,
                    "data": f"legacy_data_{i}",
                    "timestamp": time.time()
                }
            )
            print(f"Сохранено событие: {event.key}")
        
        # Получение событий
        events = memory.get(kind="archive")
        print(f"Получено событий из Legacy системы: {len(events)}")
        
        # Показ статистики
        stats = memory.get_stats()
        print(f"Статистика Legacy: {stats['total_operations']} операций")


async def demo_modern_mode():
    """Демонстрация Modern Mode (Version 2)."""
    print("\n=== Демонстрация Modern Mode (Version 2) ===")
    
    config = MemoryConfig(
        mode=MemoryMode.MODERN,
        root_path="./demo_memory_modern",
        modern_batch_size=10,
        modern_compress=True
    )
    
    with IntegratedMemoryManager(config) as memory:
        print("Сохранение событий в Modern системе...")
        
        # Асинхронное сохранение нескольких событий
        tasks = []
        for i in range(8):
            task = memory.put_async(
                kind="archive",
                key=f"modern_key_{i}",
                value={
                    "index": i,
                    "data": f"modern_data_{i}",
                    "async": True,
                    "timestamp": time.time()
                }
            )
            tasks.append(task)
        
        # Ожидание завершения всех задач
        await asyncio.gather(*tasks)
        print("Все асинхронные операции завершены")
        
        # Ожидание сброса буфера
        await asyncio.sleep(0.2)
        
        # Асинхронное получение событий
        events = await memory.get_async(kind="archive")
        print(f"Получено событий из Modern системы: {len(events)}")
        
        # Показ статистики
        stats = memory.get_stats()
        print(f"Статистика Modern: {stats['events_stored']} событий")
        if 'archive_buffer' in stats:
            buffer_stats = stats['archive_buffer']
            print(f"Буфер: {buffer_stats['buffer_size']} событий, сжатие: {buffer_stats.get('compression_enabled', False)}")


async def demo_hybrid_mode():
    """Демонстрация Hybrid Mode."""
    print("\n=== Демонстрация Hybrid Mode ===")
    
    config = MemoryConfig(
        mode=MemoryMode.HYBRID,
        root_path="./demo_memory_hybrid",
        modern_batch_size=5
    )
    
    with IntegratedMemoryManager(config) as memory:
        print("Сохранение событий в обе системы...")
        
        # Сохранение с дублированием
        results = memory.put(
            kind="archive",
            key="hybrid_key",
            value={
                "mode": "hybrid",
                "data": "saved_to_both_systems",
                "timestamp": time.time()
            }
        )
        
        # Результат содержит события из обеих систем
        legacy_event, modern_event = results
        print(f"Legacy событие: {legacy_event.key}")
        print(f"Modern событие: {modern_event.key}")
        
        # Получение из обеих систем
        hybrid_results = memory.get(kind="archive", key="hybrid_key")
        print(f"Результат Hybrid получения: {len(hybrid_results)} систем")
        
        if isinstance(hybrid_results, dict):
            print(f"Legacy события: {len(hybrid_results.get('legacy', []))}")
            print(f"Modern события: {len(hybrid_results.get('modern', []))}")


async def demo_migration_mode():
    """Демонстрация Migration Mode."""
    print("\n=== Демонстрация Migration Mode ===")
    
    config = MemoryConfig(
        mode=MemoryMode.MIGRATION,
        root_path="./demo_memory_migration",
        migration_auto_sync=True,
        migration_batch_size=5
    )
    
    with IntegratedMemoryManager(config) as memory:
        print("Сохранение событий в Migration режиме...")
        
        # Сохранение событий (они автоматически синхронизируются)
        for i in range(10):
            await memory.put_async(
                kind="archive",
                key=f"migration_key_{i}",
                value={
                    "index": i,
                    "mode": "migration",
                    "timestamp": time.time()
                }
            )
            
            if i % 3 == 0:  # Каждые 3 события
                print(f"Сохранено событие {i+1}/10")
        
        # Ожидание синхронизации
        await asyncio.sleep(0.5)
        
        # Проверка доступности в Legacy системе
        legacy_events = memory.legacy_memory.get(kind="archive")
        print(f"Событий в Legacy системе: {len(legacy_events)}")
        
        # Проверка доступности в Modern системе
        modern_events = await memory.modern_memory.get_async(kind="archive")
        print(f"Событий в Modern системе: {len(modern_events)}")
        
        # Статистика синхронизации
        if memory.data_synchronizer:
            sync_stats = memory.data_synchronizer.get_stats()
            print(f"Статистика синхронизации: {sync_stats}")


async def demo_migration_tools():
    """Демонстрация инструментов миграции."""
    print("\n=== Демонстрация инструментов миграции ===")
    
    # Создание тестовых данных в Legacy системе
    print("Создание тестовых данных в Legacy системе...")
    legacy_dir = "./demo_legacy_data"
    legacy_memory = LegacyMemoryManager(root=legacy_dir)
    
    # Создание большого количества тестовых данных
    for i in range(50):
        legacy_memory.put(
            kind="archive",
            key=f"migration_test_{i:03d}",
            value={
                "index": i,
                "test_data": f"test_value_{i}",
                "created_at": time.time(),
                "metadata": {"source": "legacy", "batch": i // 10}
            }
        )
    
    print(f"Создано 50 тестовых событий в Legacy системе")
    
    # Создание Modern системы для миграции
    modern_dir = "./demo_modern_data"
    modern_memory = ModernMemoryManager(root=modern_dir)
    
    # Выполнение комплексной миграции
    print("\nЗапуск комплексной миграции...")
    
    # Создание интегрированной системы для миграции
    config = MemoryConfig(
        mode=MemoryMode.MIGRATION,
        root_path="./demo_migration"
    )
    
    integrated_memory = IntegratedMemoryManager(config)
    
    try:
        # Выполнение миграции
        migration_stats = await run_comprehensive_migration(
            integrated_memory,
            direction="legacy_to_modern",
            kinds=["archive"]
        )
        
        print(f"\nРезультаты миграции:")
        print(f"Всего событий: {migration_stats.total_events}")
        print(f"Успешно мигрировано: {migration_stats.migrated_events}")
        print(f"Ошибок: {migration_stats.failed_events}")
        print(f"Прогресс: {migration_stats.progress_percent:.1f}%")
        
        # Проверка результатов миграции
        print("\nПроверка целостности данных...")
        migrated_events = await modern_memory.get_async(kind="archive")
        print(f"Мигрированных событий в Modern системе: {len(migrated_events)}")
        
    finally:
        await integrated_memory.close()
        
        # Очистка тестовых данных
        import shutil
        for dir_path in [legacy_dir, modern_dir]:
            if os.path.exists(dir_path):
                shutil.rmtree(dir_path)


async def demo_performance_comparison():
    """Сравнение производительности разных режимов."""
    print("\n=== Сравнение производительности ===")
    
    test_data = {
        "sample_data": "x" * 200,  # 200 байт данных
        "metadata": {"test": True, "batch": 0}
    }
    
    # Тест Legacy режима
    print("\nТестирование Legacy режима...")
    legacy_config = MemoryConfig(
        mode=MemoryMode.LEGACY,
        root_path="./perf_legacy"
    )
    
    start_time = time.time()
    with IntegratedMemoryManager(legacy_config) as legacy_memory:
        for i in range(20):
            legacy_memory.put(
                kind="archive",
                key=f"perf_legacy_{i}",
                value=test_data
            )
    
    legacy_time = time.time() - start_time
    print(f"Legacy режим: 20 операций за {legacy_time:.3f}s ({20/legacy_time:.1f} ops/sec)")
    
    # Тест Modern режима
    print("\nТестирование Modern режима...")
    modern_config = MemoryConfig(
        mode=MemoryMode.MODERN,
        root_path="./perf_modern",
        modern_batch_size=10
    )
    
    start_time = time.time()
    with IntegratedMemoryManager(modern_config) as modern_memory:
        tasks = []
        for i in range(20):
            task = modern_memory.put_async(
                kind="archive",
                key=f"perf_modern_{i}",
                value=test_data
            )
            tasks.append(task)
        
        await asyncio.gather(*tasks)
    
    modern_time = time.time() - start_time
    print(f"Modern режим: 20 операций за {modern_time:.3f}s ({20/modern_time:.1f} ops/sec)")
    
    # Тест Hybrid режима
    print("\nТестирование Hybrid режима...")
    hybrid_config = MemoryConfig(
        mode=MemoryMode.HYBRID,
        root_path="./perf_hybrid"
    )
    
    start_time = time.time()
    with IntegratedMemoryManager(hybrid_config) as hybrid_memory:
        for i in range(20):
            hybrid_memory.put(
                kind="archive",
                key=f"perf_hybrid_{i}",
                value=test_data
            )
    
    hybrid_time = time.time() - start_time
    print(f"Hybrid режим: 20 операций за {hybrid_time:.3f}s ({20/hybrid_time:.1f} ops/sec)")
    
    print(f"\nОтносительная производительность:")
    print(f"Legacy: {legacy_time/legacy_time:.1f}x")
    print(f"Modern: {legacy_time/modern_time:.1f}x от Legacy")
    print(f"Hybrid: {legacy_time/hybrid_time:.1f}x от Legacy")


async def demo_error_handling():
    """Демонстрация обработки ошибок."""
    print("\n=== Демонстрация обработки ошибок ===")
    
    config = MemoryConfig(
        mode=MemoryMode.LEGACY,
        root_path="./demo_error_handling"
    )
    
    memory = IntegratedMemoryManager(config)
    
    # Сохранение корректных данных
    try:
        memory.put(
            kind="archive",
            key="valid_key",
            value={"valid": True}
        )
        print("Корректные данные сохранены успешно")
    except Exception as e:
        print(f"Ошибка сохранения корректных данных: {e}")
    
    # Попытка получения несуществующих данных
    try:
        events = memory.get(kind="archive", key="nonexistent_key")
        print(f"Получено событий для несуществующего ключа: {len(events)}")
    except Exception as e:
        print(f"Ошибка получения несуществующих данных: {e}")
    
    # Проверка обработки поврежденных файлов
    try:
        # Ручное создание поврежденного файла
        archive_path = os.path.join("./demo_error_handling", "main_archive.jsonl")
        with open(archive_path, 'a', encoding='utf-8') as f:
            f.write('{"invalid": "json"}\n')
            f.write('{"t": "invalid_timestamp", "kind": "archive", "key": "bad_key", "value": {"bad": true}}\n')
        
        # Чтение должно игнорировать поврежденные данные
        events = memory.get(kind="archive")
        print(f"Обработано событий (поврежденные данные игнорированы): {len(events)}")
        
    except Exception as e:
        print(f"Ошибка при тестировании поврежденных данных: {e}")
    
    memory.close()


async def cleanup_demo_files():
    """Очистка файлов демонстрации."""
    print("\n=== Очистка демонстрационных файлов ===")
    
    demo_dirs = [
        "./demo_memory_legacy",
        "./demo_memory_modern", 
        "./demo_memory_hybrid",
        "./demo_memory_migration",
        "./demo_migration",
        "./perf_legacy",
        "./perf_modern",
        "./perf_hybrid",
        "./demo_error_handling"
    ]
    
    import shutil
    for dir_path in demo_dirs:
        if os.path.exists(dir_path):
            try:
                shutil.rmtree(dir_path)
                print(f"Удалена директория: {dir_path}")
            except Exception as e:
                print(f"Ошибка удаления {dir_path}: {e}")


async def main():
    """Главная функция демонстрации."""
    print("🎯 Демонстрация интегрированной системы памяти")
    print("=" * 60)
    
    try:
        # Выполнение всех демонстраций
        await demo_legacy_mode()
        await demo_modern_mode()
        await demo_hybrid_mode()
        await demo_migration_mode()
        await demo_migration_tools()
        await demo_performance_comparison()
        await demo_error_handling()
        
        print("\n✅ Все демонстрации завершены успешно!")
        
    except Exception as e:
        print(f"\n❌ Ошибка во время демонстрации: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Очистка файлов
        await cleanup_demo_files()


if __name__ == "__main__":
    # Запуск демонстрации
    asyncio.run(main())