"""
Базовые тесты для интегрированной архитектуры проекта Искра.

Тестируют backward compatibility с Version 1 и новые возможности Version 2.
"""

import pytest
import asyncio
import time
from unittest.mock import Mock, patch
from fastapi.testclient import TestClient

# Импорты для тестирования
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from main import app


class TestLegacyAPICompatibility:
    """Тесты совместимости с Version 1 API."""
    
    def setup_method(self):
        """Настройка для каждого теста."""
        self.client = TestClient(app)
    
    def test_healthz_endpoint(self):
        """Тест health check endpoint."""
        response = self.client.get("/healthz")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "time" in data
        assert data["status"] == "ok"
    
    def test_version_endpoint(self):
        """Тест endpoint версии."""
        response = self.client.get("/v1/version")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
        assert "Integrated" in data["name"]
    
    def test_canon_index_endpoint(self):
        """Тест endpoint канонического индекса."""
        response = self.client.get("/v1/canon/index")
        assert response.status_code == 200
        data = response.json()
        assert "lines" in data
        assert isinstance(data["lines"], list)
    
    def test_login_endpoint_basic(self):
        """Тест базовой аутентификации."""
        login_data = {
            "username": "admin",
            "password": "admin123"
        }
        
        response = self.client.post("/auth/login", json=login_data)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "token_type" in data
        assert data["token_type"] == "bearer"
    
    def test_search_endpoint_without_auth(self):
        """Тест поиска без аутентификации (должен вернуть 401)."""
        search_data = {
            "query": "test query",
            "k": 5
        }
        
        response = self.client.post("/v1/search", json=search_data)
        assert response.status_code == 401
    
    @patch('main.app.state.legacy_bridge')
    def test_search_endpoint_with_auth(self, mock_bridge):
        """Тест поиска с аутентификацией."""
        # Мокаем legacy bridge
        mock_bridge.search_evidence.return_value = [
            {
                "doc_id": "test_doc_1",
                "score": 0.95,
                "content": "Test content for search"
            }
        ]
        
        # Получаем токен
        login_response = self.client.post("/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Делаем поиск
        search_data = {
            "query": "test query",
            "k": 5
        }
        
        response = self.client.post(
            "/v1/search", 
            json=search_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        
        assert response.status_code == 200
        data = response.json()
        assert "query" in data
        assert "chunks" in data
        assert "latency_ms" in data
        assert len(data["chunks"]) > 0


class TestVersion2API:
    """Тесты новых возможностей Version 2."""
    
    def setup_method(self):
        """Настройка для каждого теста."""
        self.client = TestClient(app)
    
    def test_v2_health_endpoint(self):
        """Тест улучшенного health check."""
        response = self.client.get("/api/v2/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "version" in data
        assert "enhanced" in data
        assert data["enhanced"] == True
    
    def test_v2_version_endpoint(self):
        """Тест улучшенной информации о версии."""
        response = self.client.get("/api/v2/version")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "enhanced_features" in data
        assert isinstance(data["enhanced_features"], list)
    
    def test_root_endpoint(self):
        """Тест корневого endpoint."""
        response = self.client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "version" in data
        assert "compatibility" in data
        assert "api_versions" in data


class TestConfiguration:
    """Тесты конфигурации."""
    
    def test_settings_loading(self):
        """Тест загрузки настроек."""
        from core.config import settings
        
        assert settings.APP_NAME is not None
        assert settings.APP_VERSION is not None
        assert isinstance(settings.JWT_EXPIRE_MINUTES, int)
        assert settings.JWT_EXPIRE_MINUTES > 0
    
    def test_jwt_secret_generation(self):
        """Тест генерации JWT секрета."""
        from core.config import settings
        
        # Если JWT_SECRET пустой, он должен быть сгенерирован
        secret = settings.get_safe_jwt_secret()
        assert secret is not None
        assert len(secret) >= 32
    
    def test_cors_origins_parsing(self):
        """Тест парсинга CORS origins."""
        from core.config import settings
        
        origins = settings.get_cors_origins_list()
        assert isinstance(origins, list)
        assert len(origins) > 0


class TestExceptionHandling:
    """Тесты обработки исключений."""
    
    def setup_method(self):
        """Настройка для каждого теста."""
        self.client = TestClient(app)
    
    def test_invalid_login_credentials(self):
        """Тест неверных учетных данных."""
        login_data = {
            "username": "invalid_user",
            "password": "wrong_password"
        }
        
        response = self.client.post("/auth/login", json=login_data)
        assert response.status_code == 401
        assert "detail" in response.json()
    
    def test_invalid_search_query(self):
        """Тест невалидного поискового запроса."""
        # Нужно сначала получить токен
        login_response = self.client.post("/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Невалидный запрос (пустая строка)
        search_data = {
            "query": "",  # Пустая строка должна вызвать ошибку валидации
            "k": 5
        }
        
        response = self.client.post(
            "/v1/search", 
            json=search_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 422  # Validation error
    
    def test_missing_auth_header(self):
        """Тест отсутствующего заголовка авторизации."""
        search_data = {
            "query": "test query",
            "k": 5
        }
        
        response = self.client.post("/v1/search", json=search_data)
        assert response.status_code == 401
    
    def test_invalid_auth_header(self):
        """Тест невалидного заголовка авторизации."""
        search_data = {
            "query": "test query",
            "k": 5
        }
        
        response = self.client.post(
            "/v1/search", 
            json=search_data,
            headers={"Authorization": "Invalid token"}
        )
        assert response.status_code == 401


class TestDependencyInjection:
    """Тесты системы Dependency Injection."""
    
    def test_container_initialization(self):
        """Тест инициализации DI контейнера."""
        from services.dependency_injection import get_container, get_service_registry
        
        container = get_container()
        registry = get_service_registry()
        
        assert container is not None
        assert registry is not None
        assert registry.container is container
    
    def test_service_registration(self):
        """Тест регистрации сервисов."""
        from services.dependency_injection import get_container
        
        container = get_container()
        
        # Тестовый сервис
        class TestService:
            def __init__(self):
                self.name = "test_service"
        
        # Регистрация
        container.register_singleton(TestService)
        
        # Получение
        service = container.get(TestService)
        assert isinstance(service, TestService)
        assert service.name == "test_service"


class TestPerformance:
    """Тесты производительности."""
    
    def setup_method(self):
        """Настройка для каждого теста."""
        self.client = TestClient(app)
    
    @pytest.mark.asyncio
    async def test_health_check_performance(self):
        """Тест производительности health check."""
        start_time = time.perf_counter()
        
        response = self.client.get("/healthz")
        
        end_time = time.perf_counter()
        response_time_ms = (end_time - start_time) * 1000
        
        assert response.status_code == 200
        assert response_time_ms < 100  # Должен отвечать меньше чем за 100ms
    
    @pytest.mark.asyncio
    async def test_login_performance(self):
        """Тест производительности аутентификации."""
        login_data = {
            "username": "admin",
            "password": "admin123"
        }
        
        start_time = time.perf_counter()
        
        response = self.client.post("/auth/login", json=login_data)
        
        end_time = time.perf_counter()
        response_time_ms = (end_time - start_time) * 1000
        
        assert response.status_code == 200
        assert response_time_ms < 200  # Аутентификация должна быть быстрой


if __name__ == "__main__":
    # Запуск тестов
    pytest.main([__file__, "-v"])