# Docker Deployment Guide

## Предварительные требования

### Системные требования
- **ОС**: Linux, macOS 10.14+, Windows 10+ с WSL2
- **RAM**: Минимум 4GB (рекомендуется 8GB+)
- **Диск**: Минимум 10GB свободного места
- **Процессор**: 2+ ядра с поддержкой виртуализации

### Зависимости
- **Docker**: 20.10+ (рекомендуется 24.0+)
- **Docker Compose**: 2.0+ (рекомендуется 2.20+)
- **Git**: Последняя версия

### Проверка требований
```bash
# Проверка Docker
docker --version
docker info

# Проверка Docker Compose
docker-compose --version
docker compose version

# Проверка ресурсов системы
free -h
df -h
nproc
```

## Архитектура контейнеризации

### Сервисы в Docker Compose
```
┌─────────────────────────────────────────┐
│              Nginx Reverse Proxy        │
│              (Load Balancer)            │
└─────────────────┬───────────────────────┘
                  │
    ┌─────────────┼─────────────┐
    │             │             │
┌───┴───┐     ┌───┴───┐     ┌───┴───┐
│ App 1 │     │ App 2 │     │ App N │
│(Python│     │(Python│     │(Python│
│ FastAPI)│   │ FastAPI)│   │ FastAPI)│
└───┬───┘     └───┬───┘     └───┬───┘
    │             │             │
┌───┴───┐     ┌───┴───┐     ┌───┴───┐
│PostgreSQL│   │ Redis  │     │ Monitoring│
│(Master)  │   │ (Cache)│     │(Prometheus)│
└─────────┘     └────────┘     └──────────┘
```

### Структура директорий
```
merged_project/
├── docker-compose.yml          # Основная конфигурация
├── docker-compose.dev.yml      # Режим разработки
├── docker-compose.prod.yml     # Режим продакшена
├── docker-compose.monitoring.yml # Мониторинг
├── .env                        # Переменные окружения
├── Dockerfile                  # Основной образ
├── Dockerfile.dev             # Образ для разработки
├── Dockerfile.prod            # Образ для продакшена
├── nginx/
│   ├── nginx.conf            # Основная конфигурация
│   ├── sites-available/
│   │   └── diapp.conf       # Настройки сайта
│   └── ssl/                 # SSL сертификаты
├── postgres/
│   ├── Dockerfile           # Образ PostgreSQL
│   ├── init.sql            # Инициализация БД
│   └── conf/               # Конфигурация
├── redis/
│   ├── Dockerfile          # Образ Redis
│   └── redis.conf          # Конфигурация
├── prometheus/
│   ├── Dockerfile          # Образ Prometheus
│   └── prometheus.yml      # Конфигурация мониторинга
└── scripts/
    ├── entrypoint.sh       # Точка входа приложения
    ├── backup.sh           # Скрипт бэкапа
    └── healthcheck.sh      # Проверка здоровья
```

## Установка

### Шаг 1: Подготовка проекта

#### Клонирование и настройка
```bash
# Клонирование проекта
git clone <repository_url>
cd merged_project

# Создание необходимых директорий
mkdir -p nginx/sites-available nginx/ssl postgres/conf redis prometheus scripts

# Установка прав доступа
chmod +x scripts/*.sh
```

### Шаг 2: Создание Dockerfile

#### Основной Dockerfile
```dockerfile
# Dockerfile
FROM python:3.11-slim

# Установка системных зависимостей
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    libpq-dev \
    && rm -rf /var/lib/apt/lists/*

# Создание пользователя приложения
RUN useradd --create-home --shell /bin/bash app

# Установка рабочей директории
WORKDIR /app

# Копирование файлов зависимостей
COPY requirements.txt config/requirements.txt ./

# Установка Python зависимостей
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir -r requirements.txt && \
    pip install --no-cache-dir -r config/requirements.txt

# Копирование исходного кода
COPY --chown=app:app . .

# Переключение на пользователя приложения
USER app

# Переменные окружения по умолчанию
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1
ENV APP_ENV=production

# Открытие порта
EXPOSE 8000

# Точка входа
CMD ["python", "main.py"]
```

#### Dockerfile для разработки
```dockerfile
# Dockerfile.dev
FROM python:3.11-slim

# Установка системных зависимостей
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    libpq-dev \
    vim \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Создание пользователя приложения
RUN useradd --create-home --shell /bin/bash app

# Установка рабочей директории
WORKDIR /app

# Установка Python зависимостей
RUN pip install --no-cache-dir --upgrade pip setuptools wheel

# Копирование файлов зависимостей
COPY requirements.txt config/requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt && \
    pip install --no-cache-dir -r config/requirements.txt

# Установка дополнительных инструментов разработки
RUN pip install --no-cache-dir \
    pytest pytest-cov \
    black flake8 mypy \
    debugpy \
    ipython \
    jupyter

# Копирование исходного кода
COPY --chown=app:app . .

# Переключение на пользователя приложения
USER app

# Переменные окружения
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1
ENV APP_ENV=development
ENV AUTO_RELOAD=true

# Открытие портов
EXPOSE 8000 5678 8888

# Точка входа
CMD ["python", "-m", "debugpy", "--listen", "0.0.0.0:5678", "--wait-for-client", "main.py"]
```

#### Dockerfile для продакшена
```dockerfile
# Dockerfile.prod
FROM python:3.11-slim AS builder

# Установка системных зависимостей для сборки
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    libpq-dev \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Создание виртуального окружения
RUN python -m venv /opt/venv
ENV PATH="/opt/venv/bin:$PATH"

# Копирование файлов зависимостей
COPY requirements.txt config/requirements.txt ./

# Установка зависимостей
RUN pip install --no-cache-dir --upgrade pip && \
    pip install --no-cache-dir -r requirements.txt && \
    pip install --no-cache-dir -r config/requirements.txt

# Финальный образ
FROM python:3.11-slim

# Установка минимальных системных зависимостей
RUN apt-get update && apt-get install -y \
    libpq5 \
    curl \
    && rm -rf /var/lib/apt/lists/*

# Копирование виртуального окружения из builder
COPY --from=builder /opt/venv /opt/venv

# Создание пользователя приложения
RUN useradd --create-home --shell /bin/bash app

# Установка рабочей директории
WORKDIR /app

# Копирование исходного кода
COPY --chown=app:app . .

# Переключение на пользователя приложения
USER app

# Переменные окружения
ENV PATH="/opt/venv/bin:$PATH"
ENV PYTHONPATH=/app
ENV PYTHONUNBUFFERED=1
ENV APP_ENV=production

# Открытие порта
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=30s --start-period=60s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Точка входа
CMD ["gunicorn", "main:app", "-w", "4", "-k", "uvicorn.workers.UvicornWorker", "-b", "0.0.0.0:8000"]
```

### Шаг 3: Создание Docker Compose

#### Основная конфигурация (docker-compose.yml)
```yaml
# docker-compose.yml
version: '3.8'

services:
  # Приложение
  app:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: diapp
    restart: unless-stopped
    environment:
      - DATABASE_URL=postgresql://diapp:password@postgres:5432/diapp
      - REDIS_URL=redis://redis:6379/0
    env_file:
      - .env
    volumes:
      - ./logs:/app/logs
      - ./cache:/app/cache
      - ./backups:/app/backups
    ports:
      - "8000:8000"
    depends_on:
      - postgres
      - redis
    networks:
      - diapp-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s

  # База данных PostgreSQL
  postgres:
    image: postgres:15-alpine
    container_name: diapp-postgres
    restart: unless-stopped
    environment:
      - POSTGRES_DB=diapp
      - POSTGRES_USER=diapp
      - POSTGRES_PASSWORD=password
      - POSTGRES_INITDB_ARGS=--encoding=UTF-8 --lc-collate=C --lc-ctype=C
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./postgres/init.sql:/docker-entrypoint-initdb.d/init.sql:ro
      - ./postgres/conf:/etc/postgresql/conf.d:ro
    ports:
      - "5432:5432"
    networks:
      - diapp-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U diapp -d diapp"]
      interval: 30s
      timeout: 10s
      retries: 5

  # Redis кэш
  redis:
    image: redis:7-alpine
    container_name: diapp-redis
    restart: unless-stopped
    command: redis-server /usr/local/etc/redis/redis.conf
    environment:
      - REDIS_PASSWORD=redis_password
    volumes:
      - redis_data:/data
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf:ro
    ports:
      - "6379:6379"
    networks:
      - diapp-network
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    container_name: diapp-nginx
    restart: unless-stopped
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./nginx/sites-available:/etc/nginx/conf.d:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - ./logs/nginx:/var/log/nginx
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - app
    networks:
      - diapp-network
    healthcheck:
      test: ["CMD", "nginx", "-t"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  postgres_data:
    driver: local
  redis_data:
    driver: local

networks:
  diapp-network:
    driver: bridge
```

#### Конфигурация для разработки (docker-compose.dev.yml)
```yaml
# docker-compose.dev.yml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile.dev
    container_name: diapp-dev
    environment:
      - DATABASE_URL=postgresql://diapp:password@postgres:5432/diapp_dev
      - REDIS_URL=redis://redis:6379/1
      - APP_ENV=development
      - DEBUG=true
      - AUTO_RELOAD=true
    env_file:
      - .env.dev
    volumes:
      - .:/app
      - /app/__pycache__
      - ./logs:/app/logs
      - ./cache:/app/cache
    ports:
      - "8000:8000"
      - "5678:5678"  # Debug port
    depends_on:
      - postgres
      - redis
    networks:
      - diapp-network
    command: python -m debugpy --listen 0.0.0.0:5678 --wait-for-client main.py

  postgres:
    environment:
      - POSTGRES_DB=diapp_dev

  redis:
    command: redis-server /usr/local/etc/redis/redis.conf

volumes:
  postgres_data:

networks:
  diapp-network:
    driver: bridge
```

#### Конфигурация для продакшена (docker-compose.prod.yml)
```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile.prod
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2.0'
          memory: 2G
        reservations:
          cpus: '1.0'
          memory: 1G
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3
        window: 120s
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 60s
    restart: always

  nginx:
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
    restart: always

  postgres:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
    restart: always

  redis:
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 1G
    restart: always
```

#### Конфигурация мониторинга (docker-compose.monitoring.yml)
```yaml
# docker-compose.monitoring.yml
version: '3.8'

services:
  # Prometheus для метрик
  prometheus:
    image: prom/prometheus:latest
    container_name: diapp-prometheus
    restart: unless-stopped
    volumes:
      - ./prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'
      - '--web.enable-lifecycle'
    ports:
      - "9090:9090"
    networks:
      - diapp-network

  # Grafana для визуализации
  grafana:
    image: grafana/grafana:latest
    container_name: diapp-grafana
    restart: unless-stopped
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin123
    volumes:
      - grafana_data:/var/lib/grafana
      - ./grafana/provisioning:/etc/grafana/provisioning:ro
    ports:
      - "3000:3000"
    networks:
      - diapp-network

  # Node Exporter для системных метрик
  node-exporter:
    image: prom/node-exporter:latest
    container_name: diapp-node-exporter
    restart: unless-stopped
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    ports:
      - "9100:9100"
    networks:
      - diapp-network

volumes:
  prometheus_data:
  grafana_data:

networks:
  diapp-network:
    external: true
```

### Шаг 4: Конфигурация компонентов

#### Nginx конфигурация
```nginx
# nginx/nginx.conf
events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;
    
    # Логирование
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /var/log/nginx/access.log main;
    error_log /var/log/nginx/error.log warn;
    
    # Основные настройки
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    client_max_body_size 100M;
    
    # Gzip сжатие
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;
    
    # Upstream для приложения
    upstream diapp_backend {
        server app:8000;
        keepalive 32;
    }
    
    # Включение сайтов
    include /etc/nginx/conf.d/*.conf;
}
```

```nginx
# nginx/sites-available/diapp.conf
server {
    listen 80;
    server_name localhost yourdomain.com;
    
    # Безопасность
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    
    # Health check
    location /health {
        proxy_pass http://diapp_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        access_log off;
    }
    
    # Основная проксификация
    location / {
        proxy_pass http://diapp_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Настройки прокси
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
        proxy_buffering on;
        proxy_buffer_size 128k;
        proxy_buffers 4 256k;
        proxy_busy_buffers_size 256k;
    }
}
```

#### PostgreSQL конфигурация
```sql
-- postgres/init.sql
-- Создание базы данных и пользователя
CREATE DATABASE diapp;
CREATE DATABASE diapp_dev;

-- Создание пользователей
CREATE USER diapp WITH PASSWORD 'password';
CREATE USER diapp_dev WITH PASSWORD 'password';

-- Граны
GRANT ALL PRIVILEGES ON DATABASE diapp TO diapp;
GRANT ALL PRIVILEGES ON DATABASE diapp_dev TO diapp_dev;

-- Настройки расширений
\c diapp;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

\c diapp_dev;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
```

```ini
# postgres/conf/postgresql.conf
# Основные настройки для Docker
max_connections = 100
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1
effective_io_concurrency = 200
```

#### Redis конфигурация
```conf
# redis/redis.conf
# Основные настройки
bind 0.0.0.0
port 6379
protected-mode yes
requirepass redis_password

# Производительность
tcp-keepalive 300
timeout 0
tcp-backlog 511

# Память
maxmemory 512mb
maxmemory-policy allkeys-lru

# Персистентность
save 900 1
save 300 10
save 60 10000

# Логирование
loglevel notice
logfile ""

# Безопасность
rename-command FLUSHDB ""
rename-command FLUSHALL ""
rename-command CONFIG ""
```

### Шаг 5: Переменные окружения

#### Базовый .env файл
```bash
# .env
# Основные настройки
APP_NAME=MergedDIApp
APP_ENV=production
APP_DEBUG=false
APP_PORT=8000
HOST=0.0.0.0
WORKERS=4

# Безопасность
SECRET_KEY=your-super-secure-secret-key-256-bits-here
ALLOWED_HOSTS=localhost,yourdomain.com
CORS_ORIGINS=http://localhost:3000

# База данных
DATABASE_TYPE=postgresql
DATABASE_URL=postgresql://diapp:password@postgres:5432/diapp
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Redis
REDIS_URL=redis://redis:6379/0
REDIS_PASSWORD=redis_password
REDIS_SOCKET_TIMEOUT=60

# Логирование
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=/app/logs/app.log

# Производительность
WORKER_CONNECTIONS=1000
MAX_REQUESTS=10000
TIMEOUT=120
```

#### .env для разработки
```bash
# .env.dev
APP_ENV=development
APP_DEBUG=true
AUTO_RELOAD=true
DATABASE_URL=postgresql://diapp:password@postgres:5432/diapp_dev
REDIS_URL=redis://redis:6379/1
LOG_LEVEL=DEBUG
SECRET_KEY=dev-secret-key
```

### Шаг 6: Скрипты

#### Скрипт запуска
```bash
#!/bin/bash
# scripts/start.sh

set -e

echo "🚀 Запуск Docker Compose..."

# Проверка Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker не установлен"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose не установлен"
    exit 1
fi

# Создание сетей и томов
docker network create diapp-network 2>/dev/null || true

# Запуск сервисов
docker-compose up -d

# Ожидание готовности сервисов
echo "⏳ Ожидание запуска сервисов..."
sleep 30

# Проверка состояния
if docker-compose ps | grep -q "Up"; then
    echo "✅ Все сервисы запущены успешно"
    
    echo ""
    echo "📊 Статус сервисов:"
    docker-compose ps
    
    echo ""
    echo "🔗 URLs для доступа:"
    echo "  - Приложение: http://localhost:8000"
    echo "  - API Docs: http://localhost:8000/docs"
    echo "  - Health Check: http://localhost:8000/health"
    
    echo ""
    echo "📝 Логи:"
    echo "  - docker-compose logs -f app"
    echo "  - docker-compose logs -f nginx"
else
    echo "❌ Ошибка запуска сервисов"
    docker-compose logs
    exit 1
fi
```

#### Скрипт остановки
```bash
#!/bin/bash
# scripts/stop.sh

echo "🛑 Остановка сервисов..."

docker-compose down

echo "✅ Все сервисы остановлены"
```

#### Скрипт обновления
```bash
#!/bin/bash
# scripts/update.sh

set -e

echo "🔄 Обновление приложения..."

# Бэкап базы данных
echo "💾 Создание бэкапа..."
docker-compose exec -T postgres pg_dump -U diapp diapp > "backups/backup_$(date +%Y%m%d_%H%M%S).sql"

# Остановка и обновление
echo "🔄 Обновление образов..."
docker-compose pull
docker-compose down

# Пересборка и запуск
echo "🏗️ Пересборка и запуск..."
docker-compose build --no-cache
docker-compose up -d

# Ожидание
echo "⏳ Ожидание запуска..."
sleep 30

# Проверка
if curl -f http://localhost:8000/health > /dev/null; then
    echo "✅ Обновление завершено успешно"
else
    echo "❌ Ошибка обновления"
    docker-compose logs
    exit 1
fi
```

#### Скрипт бэкапа
```bash
#!/bin/bash
# scripts/backup.sh

set -e

BACKUP_DIR="backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

echo "💾 Создание бэкапа..."

# Бэкап PostgreSQL
echo "📊 Бэкап PostgreSQL..."
docker-compose exec -T postgres pg_dump -U diapp diapp | gzip > "$BACKUP_DIR/postgres_$DATE.sql.gz"

# Бэкап Redis
echo "📊 Бэкап Redis..."
docker-compose exec -T redis redis-cli --rdb - > "$BACKUP_DIR/redis_$DATE.rdb"

# Бэкап файлов
echo "📁 Бэкап файлов..."
tar -czf "$BACKUP_DIR/files_$DATE.tar.gz" logs/ cache/ --exclude="*.log"

# Очистка старых бэкапов
find $BACKUP_DIR -name "*.sql.gz" -mtime +7 -delete
find $BACKUP_DIR -name "*.rdb" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "✅ Бэкап завершен: $DATE"
```

#### Скрипт health check
```bash
#!/bin/bash
# scripts/healthcheck.sh

set -e

echo "🔍 Проверка здоровья сервисов..."

# Проверка Docker сервисов
if ! docker-compose ps | grep -q "Up"; then
    echo "❌ Некоторые сервисы не запущены"
    docker-compose ps
    exit 1
fi

# Проверка HTTP статуса
if ! curl -f -s http://localhost:8000/health > /dev/null; then
    echo "❌ Приложение не отвечает на /health"
    exit 1
fi

# Проверка базы данных
if ! docker-compose exec -T postgres pg_isready -U diapp > /dev/null; then
    echo "❌ PostgreSQL недоступен"
    exit 1
fi

# Проверка Redis
if ! docker-compose exec -T redis redis-cli ping | grep -q PONG; then
    echo "❌ Redis недоступен"
    exit 1
fi

echo "✅ Все сервисы работают корректно"
```

### Шаг 7: Makefile

```makefile
# Makefile
.PHONY: help build up down restart logs shell test clean backup restore dev prod

# Переменные
COMPOSE_FILE=docker-compose.yml
COMPOSE_DEV_FILE=docker-compose.dev.yml
COMPOSE_PROD_FILE=docker-compose.prod.yml

# По умолчанию
help:
	@echo "Доступные команды:"
	@echo "  build      - Пересборка образов"
	@echo "  up         - Запуск всех сервисов"
	@echo "  down       - Остановка всех сервисов"
	@echo "  restart    - Перезапуск сервисов"
	@echo "  logs       - Просмотр логов"
	@echo "  shell      - Вход в контейнер приложения"
	@echo "  test       - Запуск тестов"
	@echo "  backup     - Создание бэкапа"
	@echo "  restore    - Восстановление из бэкапа"
	@echo "  dev        - Запуск в режиме разработки"
	@echo "  prod       - Запуск в режиме продакшена"
	@echo "  clean      - Очистка неиспользуемых ресурсов"

# Основные команды
build:
	docker-compose build --no-cache

up:
	docker-compose up -d

down:
	docker-compose down

restart:
	docker-compose restart

logs:
	docker-compose logs -f

logs-app:
	docker-compose logs -f app

logs-nginx:
	docker-compose logs -f nginx

logs-postgres:
	docker-compose logs -f postgres

# Разработка
dev:
	docker-compose -f $(COMPOSE_DEV_FILE) up -d

dev-build:
	docker-compose -f $(COMPOSE_DEV_FILE) build --no-cache

dev-logs:
	docker-compose -f $(COMPOSE_DEV_FILE) logs -f

shell:
	docker-compose exec app bash

dev-shell:
	docker-compose -f $(COMPOSE_DEV_FILE) exec app bash

# Продакшен
prod:
	docker-compose -f $(COMPOSE_PROD_FILE) up -d

prod-build:
	docker-compose -f $(COMPOSE_PROD_FILE) build --no-cache

prod-logs:
	docker-compose -f $(COMPOSE_PROD_FILE) logs -f

# Тестирование
test:
	docker-compose exec app python -m pytest tests/ -v

test-cov:
	docker-compose exec app python -m pytest tests/ --cov=. --cov-report=html

# Мониторинг
monitor:
	docker-compose -f docker-compose.monitoring.yml up -d

monitor-logs:
	docker-compose -f docker-compose.monitoring.yml logs -f

# Бэкап и восстановление
backup:
	./scripts/backup.sh

restore:
	@read -p "Введите имя файла бэкапа: " BACKUP_FILE; \
	docker-compose exec -T postgres psql -U diapp diapp < $$BACKUP_FILE

# Очистка
clean:
	docker system prune -f
	docker volume prune -f
	docker network prune -f

clean-all:
	docker-compose down -v --remove-orphans
	docker system prune -af
	docker volume prune -af

# Здоровье системы
health:
	./scripts/healthcheck.sh

status:
	docker-compose ps

# Обновление
update:
	./scripts/update.sh

# Остановка с очисткой
stop:
	docker-compose down
	docker-compose -f $(COMPOSE_DEV_FILE) down
	docker-compose -f $(COMPOSE_PROD_FILE) down

# Информация
info:
	@echo "Сервисы:"
	@docker-compose ps
	@echo ""
	@echo "Образы:"
	@docker images | grep diapp
	@echo ""
	@echo "Сети:"
	@docker network ls | grep diapp
	@echo ""
	@echo "Тома:"
	@docker volume ls | grep diapp
```

## Запуск

### Базовый запуск
```bash
# Клонирование и переход в директорию
git clone <repository_url>
cd merged_project/deployment

# Сборка образов
make build

# Запуск сервисов
make up

# Проверка статуса
make status
make health
```

### Режим разработки
```bash
# Запуск в режиме разработки
make dev

# Просмотр логов разработки
make dev-logs

# Вход в контейнер разработки
make dev-shell

# Запуск тестов
make test
```

### Режим продакшена
```bash
# Запуск в режиме продакшена
make prod

# Просмотр логов продакшена
make prod-logs

# Мониторинг
make monitor
```

### Остановка и очистка
```bash
# Остановка сервисов
make down

# Полная очистка
make clean-all
```

## Проверка

### Проверка здоровья сервисов
```bash
# Общая проверка
make health

# Проверка отдельных сервисов
curl http://localhost:8000/health
docker-compose exec postgres pg_isready -U diapp
docker-compose exec redis redis-cli ping

# Детальная проверка
make status
make info
```

### Функциональное тестирование
```bash
# Запуск тестов
make test

# Тестирование покрытия
make test-cov

# Ручное тестирование API
curl http://localhost:8000/api/v2/status
curl http://localhost:8000/api/v2/health
```

### Производительность
```bash
# Нагрузочное тестирование
docker-compose exec app python -c "
import time
import requests
import statistics

def performance_test():
    response_times = []
    for i in range(100):
        start = time.time()
        response = requests.get('http://localhost:8000/health')
        end = time.time()
        if response.status_code == 200:
            response_times.append(end - start)
    
    print(f'Тестов выполнено: {len(response_times)}')
    print(f'Среднее время: {statistics.mean(response_times):.3f}s')
    print(f'Медиана: {statistics.median(response_times):.3f}s')
    print(f'Минимум: {min(response_times):.3f}s')
    print(f'Максимум: {max(response_times):.3f}s')

performance_test()
"
```

## Мониторинг

### Prometheus метрики
```bash
# Доступ к Prometheus
open http://localhost:9090

# Основные метрики для мониторинга:
# - http_requests_total (общее количество HTTP запросов)
# - http_request_duration_seconds (время обработки запросов)
# - database_connections (активные подключения к БД)
# - redis_connected_clients (подключенные клиенты Redis)
```

### Grafana дашборды
```bash
# Доступ к Grafana
open http://localhost:3000
# Логин: admin
# Пароль: admin123

# Полезные дашборды:
# - System Overview (системные метрики)
# - Application Metrics (метрики приложения)
# - Database Performance (производительность БД)
# - Cache Performance (производительность кэша)
```

### Логирование
```bash
# Просмотр логов всех сервисов
make logs

# Просмотр логов конкретного сервиса
make logs-app
make logs-nginx
make logs-postgres

# Поиск ошибок в логах
docker-compose logs app | grep ERROR
docker-compose logs nginx | grep ERROR
```

## Управление

### Масштабирование
```bash
# Масштабирование приложения
docker-compose up -d --scale app=3

# Проверка статуса
docker-compose ps

# Мониторинг нагрузки
docker stats
```

### Обновление
```bash
# Обновление без простоя
make update

# Принудительное обновление
docker-compose pull
docker-compose up -d --force-recreate

# Обновление с пересборкой
make build
make restart
```

### Резервное копирование
```bash
# Создание бэкапа
make backup

# Восстановление из бэкапа
make restore
```

### Миграция данных
См. [migration_deployment.md](migration_deployment.md)

## Решение проблем

### Частые проблемы

#### Проблемы с подключением к базе данных
```bash
# Проверка статуса PostgreSQL
docker-compose exec postgres pg_isready -U diapp

# Проверка логов PostgreSQL
docker-compose logs postgres

# Подключение к БД
docker-compose exec postgres psql -U diapp diapp

# Проверка сетей Docker
docker network ls
docker network inspect diapp-network
```

#### Проблемы с памятью
```bash
# Проверка использования ресурсов
docker stats

# Ограничение памяти для контейнеров
# Добавить в docker-compose.yml:
# services:
#   app:
#     mem_limit: 1g
#     mem_reservation: 512m
```

#### Проблемы с дисковым пространством
```bash
# Проверка использования диска
docker system df

# Очистка неиспользуемых ресурсов
make clean

# Очистка логов
docker-compose exec app truncate -s 0 /app/logs/*.log
```

#### Проблемы с сетью
```bash# Проверка сетевых подключений
docker-compose exec app netstat -tulpn

# Проверка DNS
docker-compose exec app nslookup postgres
docker-compose exec app nslookup redis

# Перезапуск сетей
docker-compose down
docker network prune
docker-compose up -d
```

### Отладка

#### Вход в контейнеры
```bash
# Вход в контейнер приложения
make shell

# Вход в контейнер PostgreSQL
docker-compose exec postgres bash

# Вход в контейнер Redis
docker-compose exec redis sh

# Вход в контейнер Nginx
docker-compose exec nginx sh
```

#### Исследование файловой системы
```bash
# Просмотр файловой системы контейнера
docker-compose exec app ls -la /app

# Просмотр переменных окружения
docker-compose exec app env

# Просмотр процессов
docker-compose exec app ps aux
```

#### Мониторинг в реальном времени
```bash
# Мониторинг ресурсов
docker stats

# Мониторинг логов
make logs

# Мониторинг сетевых подключений
docker-compose exec app watch -n 1 'netstat -tuln'
```

## Безопасность

### Сканирование уязвимостей
```bash
# Сканирование образов на уязвимости
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
    aquasec/trivy image diapp:latest

# Проверка конфигураций
docker run --rm -v $(pwd):/workspace \
    -w /workspace hadolint/hadolint Dockerfile
```

### Секреты
```bash
# Использование Docker secrets
# Создание секрета
echo "my-secret-password" | docker secret create db_password -

# Использование в docker-compose
services:
  postgres:
    secrets:
      - db_password
    environment:
      POSTGRES_PASSWORD_FILE: /run/secrets/db_password

secrets:
  db_password:
    external: true
```

### Изоляция сетей
```bash
# Создание отдельной сети
docker network create --driver bridge \
    --subnet 172.20.0.0/16 \
    --gateway 172.20.0.1 \
    diapp-private

# Использование в сервисах
services:
  app:
    networks:
      - diapp-private
      - diapp-network

networks:
  diapp-private:
    driver: bridge
    internal: true
```

---

**Поддержка**: Регулярно обновляйте базовые образы и проверяйте безопасность конфигураций.
