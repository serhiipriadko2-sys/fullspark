"""
Главный DI контейнер для управления зависимостями

Поддерживает backward compatibility с Version 1 и плавную миграцию к Version 2.
"""

import logging
from typing import Any, Dict, List, Optional, Type, Union, Callable, TypeVar
from abc import ABC, abstractmethod
from enum import Enum
import threading
import time
import weakref

T = TypeVar('T')

class ServiceLifetime(Enum):
    """Временные жизни сервисов"""
    TRANSIENT = "transient"      # Новый экземпляр каждый раз
    SCOPED = "scoped"            # Один экземпляр на область
    SINGLETON = "singleton"      # Один экземпляр на всю жизнь

class ServiceDescriptor:
    """Дескриптор сервиса для регистрации в контейнере"""
    
    def __init__(
        self,
        service_type: Type,
        implementation: Union[Type, Callable],
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT,
        factory_method: Optional[Callable] = None,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None
    ):
        self.service_type = service_type
        self.implementation = implementation
        self.lifetime = lifetime
        self.factory_method = factory_method
        self.config = config or {}
        self.dependencies = dependencies or []
        self.instance = None
        self.created_at = None
        self.access_count = 0
        self.lock = threading.RLock()

class VersionCompatibility(Enum):
    """Уровни совместимости с версиями"""
    V1_ONLY = "v1_only"          # Только для Version 1
    V2_ONLY = "v2_only"          # Только для Version 2  
    HYBRID = "hybrid"            # Гибридный режим
    UNIVERSAL = "universal"      # Универсальный

class DIContainer:
    """
    Главный DI контейнер
    
    Особенности:
    - Thread-safe операции
    - Lazy loading сервисов
    - Cycle detection
    - Metrics и мониторинг
    - Backward compatibility с Version 1
    """
    
    def __init__(self):
        self._services: Dict[Type, ServiceDescriptor] = {}
        self._scopes: Dict[str, Dict[Type, Any]] = {}
        self._current_scope = "default"
        self._singletons: Dict[Type, Any] = {}
        self._version_mode: VersionCompatibility = VersionCompatibility.HYBRID
        
        # Метрики и мониторинг
        self._metrics = {
            'registrations': 0,
            'resolutions': 0,
            'errors': 0,
            'circular_deps_detected': 0
        }
        
        # Защита от циклических зависимостей
        self._resolution_stack: List[Type] = []
        self._logger = logging.getLogger(__name__)
        
        # Регистрация встроенных сервисов
        self._register_builtin_services()
    
    def _register_builtin_services(self):
        """Регистрация встроенных сервисов контейнера"""
        self.register_singleton(DIContainer, self)
        self.register_singleton(ServiceRegistry, ServiceRegistry(self))
        self.register_singleton(DependencyWiring, DependencyWiring(self, ServiceRegistry(self)))
    
    def register(
        self,
        service_type: Type,
        implementation: Union[Type, Callable] = None,
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT,
        factory_method: Optional[Callable] = None,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None,
        compatibility: VersionCompatibility = VersionCompatibility.UNIVERSAL
    ) -> 'DIContainer':
        """
        Регистрация сервиса в контейнере
        
        Args:
            service_type: Тип сервиса (интерфейс)
            implementation: Реализация сервиса (класс или функция)
            lifetime: Время жизни сервиса
            factory_method: Метод фабрики для создания
            config: Конфигурация сервиса
            dependencies: Зависимости сервиса
            compatibility: Уровень совместимости с версиями
        """
        if implementation is None:
            implementation = service_type
            
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation=implementation,
            lifetime=lifetime,
            factory_method=factory_method,
            config=config or {},
            dependencies=dependencies or []
        )
        
        with self._get_service_lock(service_type):
            self._services[service_type] = descriptor
            self._metrics['registrations'] += 1
            self._logger.debug(f"Registered service: {service_type.__name__} ({lifetime.value})")
        
        return self
    
    def register_transient(
        self,
        service_type: Type,
        implementation: Union[Type, Callable] = None,
        **kwargs
    ) -> 'DIContainer':
        """Регистрация transient сервиса"""
        return self.register(service_type, implementation, ServiceLifetime.TRANSIENT, **kwargs)
    
    def register_scoped(
        self,
        service_type: Type,
        implementation: Union[Type, Callable] = None,
        **kwargs
    ) -> 'DIContainer':
        """Регистрация scoped сервиса"""
        return self.register(service_type, implementation, ServiceLifetime.SCOPED, **kwargs)
    
    def register_singleton(
        self,
        service_type: Type,
        implementation: Union[Type, Callable] = None,
        **kwargs
    ) -> 'DIContainer':
        """Регистрация singleton сервиса"""
        return self.register(service_type, ServiceLifetime.SINGLETON, implementation, **kwargs)
    
    def resolve(self, service_type: Type, scope: Optional[str] = None) -> Optional[Any]:
        """
        Получение сервиса из контейнера
        
        Args:
            service_type: Тип требуемого сервиса
            scope: Область видимости (для scoped сервисов)
            
        Returns:
            Экземпляр сервиса или None если не найден
        """
        scope = scope or self._current_scope
        
        # Проверка циклических зависимостей
        if service_type in self._resolution_stack:
            self._metrics['circular_deps_detected'] += 1
            self._logger.error(f"Circular dependency detected for {service_type.__name__}")
            raise RuntimeError(f"Circular dependency detected for {service_type.__name__}")
        
        self._resolution_stack.append(service_type)
        self._metrics['resolutions'] += 1
        
        try:
            descriptor = self._services.get(service_type)
            if not descriptor:
                self._logger.warning(f"Service not registered: {service_type.__name__}")
                return None
            
            # Создание экземпляра в зависимости от lifetime
            with descriptor.lock:
                descriptor.access_count += 1
                
                if descriptor.lifetime == ServiceLifetime.SINGLETON:
                    return self._get_singleton(descriptor)
                elif descriptor.lifetime == ServiceLifetime.SCOPED:
                    return self._get_scoped(descriptor, scope)
                else:  # TRANSIENT
                    return self._create_instance(descriptor)
                    
        finally:
            self._resolution_stack.remove(service_type)
    
    def _get_singleton(self, descriptor: ServiceDescriptor) -> Any:
        """Получение singleton экземпляра"""
        if descriptor.instance is None:
            descriptor.instance = self._create_instance(descriptor)
            descriptor.created_at = time.time()
        return descriptor.instance
    
    def _get_scoped(self, descriptor: ServiceDescriptor, scope: str) -> Any:
        """Получение scoped экземпляра"""
        if scope not in self._scopes:
            self._scopes[scope] = {}
        
        scope_instances = self._scopes[scope]
        
        if service_type := descriptor.service_type not in scope_instances:
            scope_instances[service_type] = self._create_instance(descriptor)
        
        return scope_instances[service_type]
    
    def _create_instance(self, descriptor: ServiceDescriptor) -> Any:
        """Создание нового экземпляра сервиса"""
        try:
            if descriptor.factory_method:
                # Использование фабричного метода
                return descriptor.factory_method(
                    self, 
                    descriptor.config,
                    descriptor.dependencies
                )
            elif callable(descriptor.implementation):
                # Функция-конструктор
                return self._call_constructor(descriptor)
            else:
                # Класс-конструктор
                return self._call_constructor(descriptor)
                
        except Exception as e:
            self._metrics['errors'] += 1
            self._logger.error(f"Failed to create instance of {descriptor.service_type.__name__}: {e}")
            raise
    
    def _call_constructor(self, descriptor: ServiceDescriptor) -> Any:
        """Вызов конструктора с разрешением зависимостей"""
        implementation = descriptor.implementation
        dependencies = []
        
        # Разрешение зависимостей
        for dep_type in descriptor.dependencies:
            dep_instance = self.resolve(dep_type)
            if dep_instance is None:
                self._logger.warning(f"Dependency {dep_type.__name__} not resolved")
            dependencies.append(dep_instance)
        
        # Вызов конструктора
        try:
            if dependencies:
                return implementation(*dependencies)
            else:
                return implementation()
        except TypeError as e:
            # Если конструктор не принимает параметры, попробуем без них
            if dependencies:
                self._logger.warning(f"Constructor of {implementation.__name__} doesn't accept dependencies: {e}")
                return implementation()
            raise
    
    def create_scope(self, scope_name: str) -> 'DIContainer':
        """Создание новой области видимости"""
        if scope_name not in self._scopes:
            self._scopes[scope_name] = {}
        return self
    
    def set_current_scope(self, scope_name: str):
        """Установка текущей области видимости"""
        self._current_scope = scope_name
    
    def _get_service_lock(self, service_type: Type) -> threading.RLock:
        """Получение лока для сервиса (для избежания deadlock)"""
        if service_type not in self._services:
            return self._services.setdefault(service_type, ServiceDescriptor(service_type, service_type)).lock
        return self._services[service_type].lock
    
    def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик использования контейнера"""
        return {
            **self._metrics,
            'registered_services': len(self._services),
            'active_scopes': len(self._scopes),
            'version_mode': self._version_mode.value
        }
    
    def clear_scope(self, scope_name: str):
        """Очистка области видимости"""
        if scope_name in self._scopes:
            self._scopes.pop(scope_name)
            self._logger.debug(f"Cleared scope: {scope_name}")
    
    def reset(self):
        """Сброс контейнера (для тестирования)"""
        self._services.clear()
        self._scopes.clear()
        self._singletons.clear()
        self._resolution_stack.clear()
        self._metrics = {
            'registrations': 0,
            'resolutions': 0, 
            'errors': 0,
            'circular_deps_detected': 0
        }
        self._register_builtin_services()
    
    def is_registered(self, service_type: Type) -> bool:
        """Проверка регистрации сервиса"""
        return service_type in self._services
    
    def get_all_registrations(self) -> List[Dict[str, Any]]:
        """Получение всех регистраций для отладки"""
        registrations = []
        for service_type, descriptor in self._services.items():
            registrations.append({
                'service_type': service_type.__name__,
                'implementation': descriptor.implementation.__name__ if hasattr(descriptor.implementation, '__name__') else str(descriptor.implementation),
                'lifetime': descriptor.lifetime.value,
                'dependencies': [dep.__name__ for dep in descriptor.dependencies],
                'access_count': descriptor.access_count
            })
        return registrations