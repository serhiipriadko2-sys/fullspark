"""Пакет обработчиков ошибок для разных уровней приложения.

Обеспечивает централизованную обработку исключений на всех уровнях архитектуры.

Автор: Iskra Integration Team  
Версия: 1.0
"""

from .error_handlers import (
    # Abstract Base
    BaseErrorHandler,
    
    # HTTP Level Handlers
    HttpErrorHandler,
    AuthenticationHandler,
    AuthorizationHandler,
    ValidationHandler,
    NotFoundHandler,
    
    # Service Level Handlers
    ServiceErrorHandler,
    ConfigurationHandler,
    
    # Repository Level Handlers
    RepositoryErrorHandler,
    
    # Infrastructure Level Handlers
    InfrastructureErrorHandler,
    
    # Universal Handler
    UniversalErrorHandler,
    
    # Manager
    ErrorHandlerManager,
    
    # Decorators
    handle_errors,
    service_error_handler,
    repository_error_handler,
)

__all__ = [
    # Abstract Base
    "BaseErrorHandler",
    
    # HTTP Level Handlers
    "HttpErrorHandler",
    "AuthenticationHandler",
    "AuthorizationHandler", 
    "ValidationHandler",
    "NotFoundHandler",
    
    # Service Level Handlers
    "ServiceErrorHandler",
    "ConfigurationHandler",
    
    # Repository Level Handlers
    "RepositoryErrorHandler",
    
    # Infrastructure Level Handlers
    "InfrastructureErrorHandler",
    
    # Universal Handler
    "UniversalErrorHandler",
    
    # Manager
    "ErrorHandlerManager",
    
    # Decorators
    "handle_errors",
    "service_error_handler",
    "repository_error_handler",
]