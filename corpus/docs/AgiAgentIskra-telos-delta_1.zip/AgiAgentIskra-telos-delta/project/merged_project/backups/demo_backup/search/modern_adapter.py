"""Адаптер для интеграции Version 2 оптимизированной поисковой системы.

Обеспечивает высокопроизводительный поиск с O(log n) сложностью,
инвертированными индексами и кэшированием.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Any, Tuple
import json

logger = logging.getLogger(__name__)

@dataclass
class ModernSearchConfig:
    """Конфигурация для современного поиска Version 2."""
    cache_size: int = 1000
    max_workers: int = 4
    enable_indexing: bool = True
    index_batch_size: int = 100
    evidence_path: str = "memory/evidence.jsonl"
    async_operations: bool = True
    performance_monitoring: bool = True

@dataclass
class EvidenceChunk:
    """Часть доказательства (совместимость с Version 2)."""
    doc_id: str
    chunk_id: int
    content: str
    score: float
    metadata: Optional[Dict[str, Any]] = None

class ModernVectorSearch:
    """Высокопроизводительный поиск с оптимизациями Version 2."""
    
    def __init__(self, config: ModernSearchConfig):
        """Инициализация современного поиска.
        
        Args:
            config: Конфигурация поиска
        """
        self.config = config
        self.searcher = None
        self._index_built = False
        self._performance_stats = {
            'search_count': 0,
            'cache_hits': 0,
            'index_builds': 0,
            'total_search_time': 0.0
        }
        
        logger.info("Modern поиск инициализирован")
    
    def _load_optimized_searcher(self):
        """Загрузка оптимизированного поисковика из Version 2."""
        try:
            import sys
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 
                                       'user_input_files', 'extracted_v2', 'code', 'optimized'))
            
            from vector_search import OptimizedVectorSearcher
            
            if self.searcher is None:
                self.searcher = OptimizedVectorSearcher(
                    evidence_path=self.config.evidence_path,
                    cache_size=self.config.cache_size,
                    max_workers=self.config.max_workers
                )
                logger.debug("Оптимизированный поисковик загружен")
            
            return True
        except ImportError as e:
            logger.error(f"Не удалось загрузить OptimizedVectorSearcher: {e}")
            return False
        except Exception as e:
            logger.error(f"Ошибка загрузки поисковика: {e}")
            return False
    
    async def build_index(self):
        """Построение индекса для быстрого поиска."""
        if not self.config.enable_indexing:
            logger.info("Индексация отключена в конфигурации")
            return
        
        if self._index_built:
            logger.debug("Индекс уже построен")
            return
        
        logger.info("Начинаю построение индекса...")
        
        if not self._load_optimized_searcher():
            logger.error("Не удалось загрузить поисковик для индексации")
            return
        
        try:
            start_time = time.time()
            await self.searcher.build_index()
            build_time = time.time() - start_time
            
            self._index_built = True
            self._performance_stats['index_builds'] += 1
            
            # Получение статистики индекса
            stats = self.get_performance_stats()
            logger.info(f"Индекс построен за {build_time:.2f}s. "
                       f"Документов: {stats.get('documents_indexed', 0)}, "
                       f"токенов: {stats.get('unique_tokens', 0)}")
            
        except Exception as e:
            logger.error(f"Ошибка построения индекса: {e}")
    
    async def search_async(self, query: str, **kwargs) -> List[EvidenceChunk]:
        """Асинхронный поиск с оптимизацией.
        
        Args:
            query: Поисковый запрос
            **kwargs: Дополнительные параметры
            
        Returns:
            Список результатов поиска
        """
        if not self._load_optimized_searcher():
            logger.error("Поисковик не загружен, использую fallback")
            return await self._fallback_search(query, kwargs)
        
        # Параметры поиска
        k = kwargs.get('k', 5)
        use_index = kwargs.get('use_index', True)
        
        logger.debug(f"Modern async поиск: query='{query}', k={k}, use_index={use_index}")
        
        try:
            start_time = time.time()
            
            # Проверка и построение индекса если необходимо
            if use_index and not self._index_built:
                await self.build_index()
            
            # Выполнение поиска
            if self.config.async_operations:
                results = await self.searcher.vector_search_async(query, k, use_index)
            else:
                # Синхронный поиск в отдельном потоке
                loop = asyncio.get_event_loop()
                results = await loop.run_in_executor(
                    None, self.searcher.vector_search_sync, query, k, use_index
                )
            
            # Обновление статистики
            search_time = time.time() - start_time
            self._performance_stats['search_count'] += 1
            self._performance_stats['total_search_time'] += search_time
            
            # Проверка попаданий в кэш
            if hasattr(self.searcher, 'get_performance_stats'):
                cache_stats = self.searcher.get_performance_stats()
                self._performance_stats['cache_hits'] += cache_stats.get('cache_hits', 0)
            
            logger.debug(f"Modern поиск завершен за {search_time:.3f}s, найдено {len(results)} результатов")
            
            return results
            
        except Exception as e:
            logger.error(f"Ошибка в modern поиске: {e}")
            return await self._fallback_search(query, kwargs)
    
    async def search_sync(self, query: str, **kwargs) -> List[EvidenceChunk]:
        """Синхронный поиск (обертка для совместимости)."""
        return await self.search_async(query, **kwargs)
    
    async def batch_search(self, queries: List[str], **kwargs) -> List[List[EvidenceChunk]]:
        """Пакетный поиск для множественных запросов.
        
        Args:
            queries: Список поисковых запросов
            **kwargs: Общие параметры для всех запросов
            
        Returns:
            Список результатов для каждого запроса
        """
        logger.info(f"Выполняю пакетный поиск для {len(queries)} запросов")
        
        # Создание задач для параллельного выполнения
        tasks = []
        for query in queries:
            task = self.search_async(query, **kwargs)
            tasks.append(task)
        
        # Выполнение всех поисков параллельно
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Обработка исключений
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Ошибка в пакетном поиске для запроса '{queries[i]}': {result}")
                processed_results.append([])
            else:
                processed_results.append(result)
        
        logger.info(f"Пакетный поиск завершен. Обработано {len(processed_results)} результатов")
        return processed_results
    
    async def _fallback_search(self, query: str, kwargs: Dict) -> List[EvidenceChunk]:
        """Fallback поиск при ошибках."""
        logger.warning("Использую fallback поиск для modern поиска")
        
        try:
            # Простая реализация fallback поиска
            k = kwargs.get('k', 5)
            
            if not os.path.exists(self.config.evidence_path):
                logger.error(f"Файл evidence не найден: {self.config.evidence_path}")
                return []
            
            # Загрузка данных и простой поиск
            results = []
            query_tokens = self._simple_tokenize(query.lower())
            
            with open(self.config.evidence_path, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        obj = json.loads(line.strip())
                        if obj.get('content') and obj.get('doc_id'):
                            content_tokens = self._simple_tokenize(obj['content'].lower())
                            
                            # Простое вычисление пересечения токенов
                            intersection = query_tokens.intersection(content_tokens)
                            if intersection:
                                score = len(intersection) / len(query_tokens.union(content_tokens))
                                
                                results.append(EvidenceChunk(
                                    doc_id=obj['doc_id'],
                                    chunk_id=int(obj.get('chunk_id', 0)),
                                    content=obj['content'],
                                    score=score,
                                    metadata={'fallback': True}
                                ))
                    except json.JSONDecodeError:
                        continue
            
            # Сортировка и ограничение результатов
            results.sort(key=lambda x: x.score, reverse=True)
            return results[:k]
            
        except Exception as e:
            logger.error(f"Fallback поиск также не удался: {e}")
            return []
    
    def _simple_tokenize(self, text: str) -> Set[str]:
        """Простая токенизация для fallback."""
        import re
        tokens = re.findall(r"\b\w+\b", text.lower())
        return set(token for token in tokens if len(token) > 2)
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Получение статистики производительности."""
        stats = self._performance_stats.copy()
        
        # Добавление статистики от поисковика
        if self.searcher and hasattr(self.searcher, 'get_performance_stats'):
            try:
                searcher_stats = self.searcher.get_performance_stats()
                stats.update(searcher_stats)
            except Exception as e:
                logger.warning(f"Не удалось получить статистику поисковика: {e}")
        
        # Вычисление среднего времени поиска
        if stats['search_count'] > 0:
            stats['avg_search_time_ms'] = (stats['total_search_time'] / stats['search_count']) * 1000
        
        return stats
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Получение статистики кэша."""
        if self.searcher and hasattr(self.searcher, 'get_performance_stats'):
            try:
                cache_stats = self.searcher.get_performance_stats()
                return {
                    'cache_hits': cache_stats.get('cache_hits', 0),
                    'cache_hit_rate': cache_stats.get('cache_hit_rate', 0),
                    'cache_size': cache_stats.get('cache_size', 'неизвестно')
                }
            except Exception as e:
                logger.warning(f"Не удалось получить статистику кэша: {e}")
        
        return {'cache_hits': 0, 'cache_hit_rate': 0, 'cache_size': 'неизвестно'}
    
    def clear_cache(self):
        """Очистка кэша."""
        if self.searcher and hasattr(self.searcher, 'clear_cache'):
            try:
                self.searcher.clear_cache()
                logger.info("Cache современного поиска очищен")
            except Exception as e:
                logger.warning(f"Не удалось очистить cache: {e}")
        
        # Сброс статистики cache hits
        self._performance_stats['cache_hits'] = 0
    
    def reindex(self):
        """Перестроение индекса."""
        logger.info("Начинаю перестроение индекса")
        self._index_built = False
        
        if self.searcher:
            try:
                # Очистка данных поисковика
                if hasattr(self.searcher, 'clear_cache'):
                    self.searcher.clear_cache()
                
                self._performance_stats['index_builds'] = 0
                logger.info("Индекс помечен для перестроения")
            except Exception as e:
                logger.error(f"Ошибка при подготовке к переиндексации: {e}")
    
    def get_index_status(self) -> Dict[str, Any]:
        """Получение статуса индекса."""
        return {
            'index_built': self._index_built,
            'searcher_available': self.searcher is not None,
            'enable_indexing': self.config.enable_indexing,
            'evidence_path': self.config.evidence_path,
            'evidence_exists': os.path.exists(self.config.evidence_path),
            'index_builds_count': self._performance_stats['index_builds']
        }
    
    def configure_performance(self, cache_size: int = None, max_workers: int = None):
        """Настройка параметров производительности."""
        if cache_size is not None:
            self.config.cache_size = cache_size
            logger.info(f"Размер кэша установлен: {cache_size}")
        
        if max_workers is not None:
            self.config.max_workers = max_workers
            logger.info(f"Максимальное количество workers: {max_workers}")
        
        # Перезагрузка поисковика с новыми параметрами
        if cache_size is not None or max_workers is not None:
            self._load_optimized_searcher()
    
    def __str__(self) -> str:
        index_status = self.get_index_status()
        return (f"ModernVectorSearch("
                f"index_built={index_status['index_built']}, "
                f"searches={self._performance_stats['search_count']}, "
                f"cache_hits={self._performance_stats['cache_hits']})")
    
    def __repr__(self) -> str:
        return self.__str__()