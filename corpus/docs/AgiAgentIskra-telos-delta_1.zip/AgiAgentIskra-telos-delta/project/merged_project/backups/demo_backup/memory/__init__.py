"""Интегрированная система памяти для объединения Version 1 и Version 2.

Поддерживает четыре режима работы:
- Legacy Mode: простая синхронная память (Version 1)
- Modern Mode: продвинутая асинхронная память (Version 2)
- Hybrid Mode: дублирование данных в обе системы
- Migration Mode: постепенная миграция данных
"""

from .integrated_memory import (
    IntegratedMemoryManager,
    MemoryMode,
    MemoryConfig,
    MemoryEvent,
    get_integrated_memory_manager
)

from .legacy_memory import LegacyMemoryManager
from .modern_memory import ModernMemoryManager
from .migration_tools import MigrationManager, DataSynchronizer

__all__ = [
    'IntegratedMemoryManager',
    'MemoryMode',
    'MemoryConfig', 
    'MemoryEvent',
    'LegacyMemoryManager',
    'ModernMemoryManager',
    'MigrationManager',
    'DataSynchronizer',
    'get_integrated_memory_manager'
]

__version__ = "2.0.0"