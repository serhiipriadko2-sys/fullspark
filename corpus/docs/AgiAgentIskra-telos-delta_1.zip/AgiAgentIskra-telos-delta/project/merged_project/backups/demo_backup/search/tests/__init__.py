"""Тесты для интегрированной поисковой системы.

Содержит тесты совместимости, производительности и функциональности
для всех компонентов поисковой системы.
"""

from .test_compatibility import *
from .test_performance import *

__all__ = [
    'TestIntegratedSearch',
    'TestLegacyAdapter', 
    'TestModernAdapter',
    'TestPerformanceConfig',
    'TestSearchResult',
    'TestSearchMetrics',
    'TestIntegration',
    'TestPerformance'
]