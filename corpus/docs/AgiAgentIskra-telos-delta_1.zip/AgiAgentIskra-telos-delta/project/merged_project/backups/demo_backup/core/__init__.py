"""Основной пакет интегрированной системы обработки ошибок Iskra.

Объединяет базовую обработку ошибок Version 1 с продвинутой системой Version 2.

Содержит:
- Иерархию исключений (core.exceptions)
- Обработчики ошибок (core.handlers) 
- Систему логирования (core.logging)
- Web API middleware (core.middleware)

Автор: Iskra Integration Team
Версия: 1.0
"""

# Export main components for easy importing
from . import exceptions
from . import handlers  
from . import logging
from . import middleware

# Version information
__version__ = "1.0.0"
__author__ = "Iskra Integration Team"

# Quick setup function
def setup_error_system(
    log_level: str = "INFO",
    log_file: str = "logs/iskra.log",
    enable_async_logging: bool = False
):
    """Быстрая настройка системы обработки ошибок.
    
    Args:
        log_level: Уровень логирования (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Путь к файлу логов
        enable_async_logging: Включить асинхронное логирование
        
    Returns:
        tuple: (ErrorHandlerManager, CentralizedLogger, IskraMiddlewareStack)
    """
    from .logging import setup_logging, CentralizedLogger
    from .handlers import ErrorHandlerManager
    from .middleware import setup_middleware_stack
    from .exceptions import BaseIskraException
    
    # Настраиваем логирование
    logger = setup_logging(
        log_level=log_level,
        log_file=log_file,
        enable_async=enable_async_logging
    )
    
    # Создаем менеджер обработчиков ошибок
    error_manager = ErrorHandlerManager(logger)
    
    return error_manager, logger, None  # Middleware stack создается в FastAPI app