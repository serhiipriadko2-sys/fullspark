#!/usr/bin/env python3
"""
Простой тест основных компонентов интегрированной поисковой системы.
"""

import sys
import os
import asyncio

# Добавляем путь к модулю search и его родительской директории
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

def test_basic_functionality():
    """Тест базовой функциональности."""
    print("Тестирование базовой функциональности...")
    
    # Тест прямого импорта модулей
    try:
        from search.performance_config import PerformanceConfig, SearchMode, PerformanceProfile
        from search.performance_config import create_fast_config, create_balanced_config
        from search.integrated_search import IntegratedSearch
        print("✓ Импорт модулей")
    except ImportError as e:
        print(f"❌ Ошибка импорта: {e}")
        return False
    
    # Тест создания конфигурации
    try:
        config = PerformanceConfig()
        assert config.default_mode == SearchMode.HYBRID
        assert config.default_k == 5
        print("✓ Создание конфигурации")
    except Exception as e:
        print(f"❌ Ошибка создания конфигурации: {e}")
        return False
    
    # Тест профилей производительности
    try:
        fast_config = create_fast_config()
        assert fast_config.performance_profile == PerformanceProfile.FASTEST
        print("✓ Профили производительности")
    except Exception as e:
        print(f"❌ Ошибка профилей: {e}")
        return False
    
    # Тест создания поисковой системы
    try:
        searcher = IntegratedSearch(config)
        assert searcher is not None
        assert hasattr(searcher, 'legacy_search')
        assert hasattr(searcher, 'modern_search')
        print("✓ Создание поисковой системы")
    except Exception as e:
        print(f"❌ Ошибка создания поисковой системы: {e}")
        return False
    
    print("Базовые тесты пройдены успешно!")
    return True

async def test_search_system():
    """Тест поисковой системы."""
    print("\\nТестирование поисковой системы...")
    
    try:
        from search.performance_config import create_balanced_config
        from search.integrated_search import IntegratedSearch
        
        config = create_balanced_config()
        
        async with IntegratedSearch(config) as searcher:
            # Тест поиска без данных (должен работать)
            results, metrics = await searcher.search("тестовый запрос")
            
            assert isinstance(results, list)
            assert isinstance(metrics.search_time_ms, (int, float))
            assert metrics.mode_used in [mode.value for mode in SearchMode]
            
            print(f"✓ Поиск работает (режим: {metrics.mode_used}, время: {metrics.search_time_ms:.2f}ms)")
        
        print("Тесты поисковой системы пройдены успешно!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка тестирования поиска: {e}")
        import traceback
        traceback.print_exc()
        return False

async def test_error_handling():
    """Тест обработки ошибок."""
    print("\\nТестирование обработки ошибок...")
    
    try:
        from search.performance_config import create_balanced_config
        from search.integrated_search import IntegratedSearch
        
        config = create_balanced_config()
        config.legacy_config.evidence_path = "nonexistent.jsonl"
        config.modern_config.evidence_path = "nonexistent.jsonl"
        
        async with IntegratedSearch(config) as searcher:
            # Поиск с несуществующими данными должен работать через fallback
            results, metrics = await searcher.search("тестовый запрос")
            
            assert isinstance(results, list)
            assert hasattr(metrics, 'mode_used')
            
            print(f"✓ Обработка ошибок работает (статус: {metrics.mode_used})")
        
        print("Тесты обработки ошибок пройдены успешно!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка тестирования обработки ошибок: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Основная функция тестирования."""
    print("ТЕСТИРОВАНИЕ ИНТЕГРИРОВАННОЙ ПОИСКОВОЙ СИСТЕМЫ")
    print("=" * 50)
    
    success = True
    
    try:
        # Базовые тесты
        if not test_basic_functionality():
            success = False
        
        # Асинхронные тесты
        if success:
            if not asyncio.run(test_search_system()):
                success = False
        
        if success:
            if not asyncio.run(test_error_handling()):
                success = False
        
        if success:
            print("\\n" + "=" * 50)
            print("ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО!")
            print("Интегрированная поисковая система работает корректно.")
            print("=" * 50)
        else:
            print("\\n❌ НЕКОТОРЫЕ ТЕСТЫ НЕ ПРОЙДЕНЫ")
        
        return 0 if success else 1
        
    except Exception as e:
        print(f"\\n❌ КРИТИЧЕСКАЯ ОШИБКА ТЕСТИРОВАНИЯ: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())