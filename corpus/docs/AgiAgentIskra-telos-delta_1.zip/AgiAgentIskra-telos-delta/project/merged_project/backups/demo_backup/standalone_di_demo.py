"""
Standalone DI система для проекта "Искра"

Упрощенная версия Dependency Injection системы без внешних зависимостей
"""

import logging
import threading
import time
from typing import Any, Dict, List, Optional, Type, Union, Callable, TypeVar
from abc import ABC, abstractmethod
from enum import Enum

T = TypeVar('T')

class ServiceLifetime(Enum):
    """Временные жизни сервисов"""
    TRANSIENT = "transient"      # Новый экземпляр каждый раз
    SCOPED = "scoped"            # Один экземпляр на область
    SINGLETON = "singleton"      # Один экземпляр на всю жизнь

class VersionCompatibility(Enum):
    """Уровни совместимости с версиями"""
    V1_ONLY = "v1_only"          # Только для Version 1
    V2_ONLY = "v2_only"          # Только для Version 2  
    HYBRID = "hybrid"            # Гибридный режим
    UNIVERSAL = "universal"      # Универсальный

class ServiceDescriptor:
    """Дескриптор сервиса для регистрации в контейнере"""
    
    def __init__(
        self,
        service_type: Type,
        implementation: Union[Type, Callable],
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None
    ):
        self.service_type = service_type
        self.implementation = implementation
        self.lifetime = lifetime
        self.config = config or {}
        self.dependencies = dependencies or []
        self.instance = None
        self.created_at = None
        self.access_count = 0
        self.lock = threading.RLock()

class SimpleDIContainer:
    """
    Упрощенный DI контейнер
    
    Без внешних зависимостей, для базового использования
    """
    
    def __init__(self):
        self._services: Dict[Type, ServiceDescriptor] = {}
        self._singletons: Dict[Type, Any] = {}
        self._metrics = {
            'registrations': 0,
            'resolutions': 0,
            'errors': 0
        }
        self.logger = logging.getLogger(__name__)
    
    def register(
        self,
        service_type: Type,
        implementation: Union[Type, Callable] = None,
        lifetime: ServiceLifetime = ServiceLifetime.TRANSIENT,
        config: Optional[Dict[str, Any]] = None,
        dependencies: Optional[List[Type]] = None
    ) -> 'SimpleDIContainer':
        """Регистрация сервиса"""
        if implementation is None:
            implementation = service_type
            
        descriptor = ServiceDescriptor(
            service_type=service_type,
            implementation=implementation,
            lifetime=lifetime,
            config=config or {},
            dependencies=dependencies or []
        )
        
        self._services[service_type] = descriptor
        self._metrics['registrations'] += 1
        return self
    
    def resolve(self, service_type: Type) -> Optional[Any]:
        """Получение сервиса"""
        descriptor = self._services.get(service_type)
        if not descriptor:
            return None
        
        if descriptor.lifetime == ServiceLifetime.SINGLETON:
            if descriptor.instance is None:
                descriptor.instance = self._create_instance(descriptor)
            return descriptor.instance
        else:
            return self._create_instance(descriptor)
    
    def _create_instance(self, descriptor: ServiceDescriptor) -> Any:
        """Создание экземпляра сервиса"""
        try:
            dependencies = []
            for dep_type in descriptor.dependencies:
                dep_instance = self.resolve(dep_type)
                dependencies.append(dep_instance)
            
            if dependencies:
                return descriptor.implementation(*dependencies)
            else:
                return descriptor.implementation()
        except Exception as e:
            self._metrics['errors'] += 1
            self.logger.error(f"Failed to create instance: {e}")
            raise
    
    def get_metrics(self) -> Dict[str, Any]:
        """Получение метрик"""
        return self._metrics.copy()

# Создание глобального контейнера
global_container = SimpleDIContainer()

class SimpleRegistry:
    """Упрощенный реестр сервисов"""
    
    def __init__(self, container: SimpleDIContainer):
        self.container = container
        self.services = {}
    
    def register_all(self):
        """Регистрация стандартных сервисов"""
        # Базовая регистрация для демонстрации
        pass
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика реестра"""
        return {
            'total_services': len(self.services),
            'container_metrics': self.container.get_metrics()
        }

# Примеры компонентов для демонстрации
class MemoryManager:
    """Legacy Version 1 Memory Manager"""
    _is_legacy = True
    
    def __init__(self):
        self.data = {}
        print("🔧 Initialized Legacy MemoryManager (Version 1)")
    
    def put(self, key, value):
        self.data[key] = value
        return f"Legacy put: {key}"
    
    def get(self, key):
        return self.data.get(key, "legacy_default")

class OptimizedMemoryManager:
    """Modern Version 2 Memory Manager"""
    _is_modern = True
    
    def __init__(self, batch_size=50, cache_size=1000):
        self.data = {}
        self.batch_size = batch_size
        self.cache_size = cache_size
        print(f"🚀 Initialized OptimizedMemoryManager (Version 2)")
        print(f"   Batch size: {batch_size}, Cache size: {cache_size}")
    
    def put(self, key, value):
        self.data[key] = value
        return f"Modern put: {key}"
    
    def get(self, key):
        return self.data.get(key, "modern_default")

class VectorSearch:
    """Legacy Version 1 Vector Search"""
    _is_legacy = True
    
    def __init__(self):
        self.vectors = []
        print("🔍 Initialized Legacy VectorSearch (Version 1)")
    
    def search(self, query):
        return [f"legacy_result_{i}" for i in range(3)]
    
    def add_vector(self, vector):
        self.vectors.append(vector)

class OptimizedVectorSearch:
    """Modern Version 2 Vector Search"""
    _is_modern = True
    
    def __init__(self, cache_enabled=True, async_enabled=True):
        self.vectors = []
        self.cache_enabled = cache_enabled
        self.async_enabled = async_enabled
        self.cache = {}
        print(f"⚡ Initialized OptimizedVectorSearch (Version 2)")
        print(f"   Cache: {cache_enabled}, Async: {async_enabled}")
    
    def search(self, query):
        if self.cache_enabled and query in self.cache:
            return self.cache[query]
        results = [f"optimized_result_{i}" for i in range(5)]
        if self.cache_enabled:
            self.cache[query] = results
        return results
    
    def add_vector(self, vector):
        self.vectors.append(vector)

# Функции для демонстрации
def demo_backward_compatibility():
    """Демонстрация backward compatibility с Version 1"""
    print("\n" + "="*60)
    print("🔄 ДЕМОНСТРАЦИЯ: Backward Compatibility (Version 1)")
    print("="*60)
    
    global_container._services.clear()
    global_container._singletons.clear()
    
    # Регистрация legacy сервисов
    global_container.register("MemoryManager", MemoryManager)
    global_container.register("VectorSearch", VectorSearch)
    
    # Получение legacy сервисов
    memory = global_container.resolve("MemoryManager")
    search = global_container.resolve("VectorSearch")
    
    print(f"\n📊 Результат:")
    print(f"Memory: {memory.put('test', 'legacy_value')}")
    print(f"Search: {search.search('test_query')}")
    print(f"Memory get: {memory.get('test')}")
    
    # Метрики
    metrics = global_container.get_metrics()
    print(f"\n📈 Метрики: {metrics['resolutions']} разрешений")

def demo_hybrid_mode():
    """Демонстрация гибридного режима"""
    print("\n" + "="*60)
    print("🔀 ДЕМОНСТРАЦИЯ: Hybrid Mode (Version 1 + Version 2)")
    print("="*60)
    
    global_container._services.clear()
    global_container._singletons.clear()
    
    # Регистрация как legacy, так и modern сервисов
    global_container.register("LegacyMemoryManager", MemoryManager)
    global_container.register("ModernMemoryManager", OptimizedMemoryManager, 
                            config={'batch_size': 100, 'cache_size': 2000})
    global_container.register("LegacyVectorSearch", VectorSearch)
    global_container.register("ModernVectorSearch", OptimizedVectorSearch,
                            config={'cache_enabled': True, 'async_enabled': False})
    
    print(f"\n📊 Подключенные сервисы:")
    for service_type in global_container._services.keys():
        descriptor = global_container._services[service_type]
        print(f"  {service_type}: {descriptor.lifetime.value}")
    
    # Тестирование сервисов
    legacy_memory = global_container.resolve("LegacyMemoryManager")
    modern_memory = global_container.resolve("ModernMemoryManager")
    
    print(f"\n🧪 Тестирование:")
    print(f"Legacy memory: {legacy_memory.put('hybrid_test', 'legacy_value')}")
    print(f"Modern memory: {modern_memory.put('hybrid_test', 'modern_value')}")
    
    # Метрики
    metrics = global_container.get_metrics()
    print(f"\n📈 Статистика:")
    print(f"Зарегистрировано сервисов: {metrics['registrations']}")
    print(f"Разрешений: {metrics['resolutions']}")

def demo_gradual_migration():
    """Демонстрация постепенной миграции"""
    print("\n" + "="*60)
    print("🚀 ДЕМОНСТРАЦИЯ: Gradual Migration (Version 1 → Version 2)")
    print("="*60)
    
    global_container._services.clear()
    global_container._singletons.clear()
    
    # Этап 1: Legacy компоненты
    print("\n📝 Этап 1: Legacy компоненты")
    global_container.register("MemoryService", MemoryManager)
    
    memory_service = global_container.resolve("MemoryService")
    print(f"Legacy сервис: {memory_service.put('migration_step1', 'legacy_value')}")
    
    # Этап 2: Добавление modern компонента
    print("\n📝 Этап 2: Добавление modern компонента")
    global_container.register("ModernMemoryService", OptimizedMemoryManager,
                            config={'batch_size': 75, 'cache_size': 1500})
    
    modern_service = global_container.resolve("ModernMemoryService")
    print(f"Modern сервис: {modern_service.put('migration_step2', 'modern_value')}")
    
    # Этап 3: Создание unified интерфейса
    print("\n📝 Этап 3: Unified интерфейс")
    
    class UnifiedMemoryManager:
        def __init__(self, legacy_service, modern_service, use_modern=False):
            self.legacy = legacy_service
            self.modern = modern_service
            self.use_modern = use_modern
        
        def put(self, key, value):
            if self.use_modern:
                return self.modern.put(key, value)
            else:
                return self.legacy.put(key, value)
        
        def get(self, key):
            if self.use_modern:
                return self.modern.get(key)
            else:
                return self.legacy.get(key)
    
    # Создание unified сервиса
    legacy_mem = global_container.resolve("MemoryService")
    modern_mem = global_container.resolve("ModernMemoryService")
    unified_service = UnifiedMemoryManager(legacy_mem, modern_mem, use_modern=False)
    
    print(f"Unified (legacy mode): {unified_service.put('unified_test', 'step3_value')}")
    
    # Переключение на modern
    unified_service_modern = UnifiedMemoryManager(legacy_mem, modern_mem, use_modern=True)
    print(f"Unified (modern mode): {unified_service_modern.put('unified_test', 'modern_value')}")

def demo_configuration():
    """Демонстрация конфигурации"""
    print("\n" + "="*60)
    print("⚙️  ДЕМОНСТРАЦИЯ: Configuration System")
    print("="*60)
    
    # Демонстрация различных конфигураций
    configs = [
        ("Development", {'batch_size': 10, 'cache_size': 100}),
        ("Production", {'batch_size': 1000, 'cache_size': 10000}),
        ("Testing", {'batch_size': 1, 'cache_size': 10})
    ]
    
    for env_name, config in configs:
        print(f"\n🔧 Конфигурация для {env_name}:")
        print(f"  Batch size: {config['batch_size']}")
        print(f"  Cache size: {config['cache_size']}")
        
        # Регистрация с конфигурацией
        global_container.register(f"MemoryService_{env_name}", OptimizedMemoryManager, 
                                config=config)
        
        service = global_container.resolve(f"MemoryService_{env_name}")
        print(f"  Сервис создан: {service.__class__.__name__}")

def demo_monitoring():
    """Демонстрация мониторинга"""
    print("\n" + "="*60)
    print("📊 ДЕМОНСТРАЦИЯ: Monitoring and Metrics")
    print("="*60)
    
    # Создание нагрузки
    global_container._services.clear()
    global_container._singletons.clear()
    
    global_container.register("MemoryA", MemoryManager)
    global_container.register("MemoryB", OptimizedMemoryManager)
    global_container.register("SearchA", VectorSearch)
    global_container.register("SearchB", OptimizedVectorSearch)
    
    # Генерация обращений
    for i in range(5):
        memory_a = global_container.resolve("MemoryA")
        memory_b = global_container.resolve("MemoryB")
        search_a = global_container.resolve("SearchA")
        search_b = global_container.resolve("SearchB")
    
    # Получение метрик
    print(f"\n📈 Метрики контейнера:")
    metrics = global_container.get_metrics()
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    
    print(f"\n📋 Зарегистрированные сервисы:")
    for service_type, descriptor in global_container._services.items():
        print(f"  {service_type}: {descriptor.lifetime.value}")

def main():
    """Главная функция демонстрации"""
    print("🚀 ДЕМОНСТРАЦИЯ STANDALONE DI СИСТЕМЫ")
    print("Проект 'Искра' - Упрощенная версия без зависимостей")
    
    try:
        # Настройка логирования
        logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
        
        # Запуск демонстраций
        demo_backward_compatibility()
        demo_hybrid_mode()
        demo_gradual_migration()
        demo_configuration()
        demo_monitoring()
        
        print("\n" + "="*60)
        print("✅ ВСЕ ДЕМОНСТРАЦИИ ЗАВЕРШЕНЫ УСПЕШНО")
        print("="*60)
        print("\n💡 Standalone DI система работает!")
        print("📚 Полная документация: core/di/README.md")
        print("🔧 Основные компоненты: di_container.py, service_registry.py")
        
    except Exception as e:
        print(f"\n❌ ОШИБКА В ДЕМОНСТРАЦИИ: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()