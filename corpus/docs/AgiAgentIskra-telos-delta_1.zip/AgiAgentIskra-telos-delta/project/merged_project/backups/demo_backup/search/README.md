# Интегрированная Поисковая Система Iskra

## Обзор

Интегрированная поисковая система объединяет возможности Version 1 (GraphRAG) и Version 2 (оптимизированный поиск) в единую высокопроизводительную систему поиска.

## Архитектура

### Основные компоненты

```
search/
├── integrated_search.py      # Главный модуль интегрированного поиска
├── legacy_adapter.py         # Адаптер для Version 1 (GraphRAG)
├── modern_adapter.py         # Адаптер для Version 2 (оптимизированный)
├── performance_config.py     # Конфигурация производительности
└── tests/                    # Тесты совместимости и производительности
    ├── test_compatibility.py
    ├── test_performance.py
    └── pytest.ini
```

### Режимы работы

1. **Legacy Mode** (Version 1)
   - Использует GraphRAG возможности
   - Сложность: O(n)
   - Поддержка анализа сущностей и связей
   - Гибридный поиск (vector + graph)

2. **Modern Mode** (Version 2)
   - Высокопроизводительный поиск с оптимизацией
   - Сложность: O(log n)
   - Инвертированные индексы
   - Кэширование с LRU

3. **Hybrid Mode**
   - Автоматический выбор алгоритма
   - Объединение результатов с весами
   - Оптимизация на основе характеристик запроса

4. **GraphRAG Mode**
   - Усиленный анализ графов знаний
   - Извлечение сущностей и связей
   - Обнаружение сообществ

## Быстрый старт

### Базовая инициализация

```python
from search import IntegratedSearch, create_balanced_config

# Создание конфигурации
config = create_balanced_config()

# Инициализация поисковой системы
async with IntegratedSearch(config) as searcher:
    # Поиск с автоматическим выбором режима
    results, metrics = await searcher.search("ваш запрос")
    
    print(f"Найдено результатов: {len(results)}")
    print(f"Режим поиска: {metrics.mode_used}")
    print(f"Время поиска: {metrics.search_time_ms:.2f}ms")
```

### Простые функции поиска

```python
from search import integrated_search, load_config

# Загрузка конфигурации
config = load_config()  # или load_config('path/to/config.json')

# Быстрый поиск
results, metrics = await integrated_search("запрос", config=config)
```

### Конфигурация для разных сценариев

```python
from search import (
    create_fast_config,      # Максимальная скорость
    create_balanced_config,  # Баланс скорости и качества
    create_quality_config,   # Максимальное качество
    create_graphrag_config   # Фокус на GraphRAG
)

# Быстрый поиск в реальном времени
fast_config = create_fast_config()
fast_config.default_mode = SearchMode.MODERN

# Качественный анализ
quality_config = create_quality_config()
quality_config.default_mode = SearchMode.GRAPHRAG
```

## Подробное использование

### Настройка конфигурации

```python
from search import PerformanceConfig, SearchMode

config = PerformanceConfig(
    default_mode=SearchMode.HYBRID,
    default_k=10,
    cache_size=1000,
    legacy_weight=0.6,
    modern_weight=0.4,
    enable_result_cache=True
)

# Настройка путей к данным
config.evidence_path = "path/to/evidence.jsonl"
config.legacy_config.evidence_path = config.evidence_path
config.modern_config.evidence_path = config.evidence_path
```

### Прямое использование адаптеров

```python
from search import LegacyVectorSearch, ModernVectorSearch

# Legacy поиск с GraphRAG
legacy_config = LegacySearchConfig(
    use_graph=True,
    use_vector=True,
    graph_weight=0.5,
    vector_weight=0.5
)
legacy_searcher = LegacyVectorSearch(legacy_config)

# Modern поиск
modern_config = ModernSearchConfig(
    cache_size=2000,
    enable_indexing=True
)
modern_searcher = ModernVectorSearch(modern_config)
```

### Пакетный поиск

```python
async with IntegratedSearch(config) as searcher:
    queries = ["запрос 1", "запрос 2", "запрос 3"]
    
    # Параллельный поиск
    results_lists = await modern_searcher.batch_search(queries)
    
    for i, results in enumerate(results_lists):
        print(f"Запрос {i+1}: {len(results)} результатов")
```

### Мониторинг производительности

```python
async with IntegratedSearch(config) as searcher:
    # Выполнение поисков
    for query in queries:
        await searcher.search(query)
    
    # Получение отчета о производительности
    report = searcher.get_performance_report()
    
    print(f"Всего поисков: {report['total_searches']}")
    print(f"Среднее время: {report['average_search_time_ms']:.2f}ms")
    print(f"Распределение режимов: {report['mode_distribution']}")
    print(f"Попадания в кэш: {report['cache_hit_rate']:.3f}")
```

## Конфигурация из файла

### Создание файла конфигурации

```python
import json
from search import PerformanceConfig

config = create_balanced_config()
config.save_to_file("search_config.json")
```

### Загрузка конфигурации

```python
from search import load_config

# Из файла
config = load_config("search_config.json")

# Из переменных окружения
config = load_config("env")

# По умолчанию
config = load_config()  # или load_config(None)
```

### Пример файла конфигурации

```json
{
  "default_mode": "hybrid",
  "default_k": 5,
  "evidence_path": "memory/evidence.jsonl",
  "max_workers": 4,
  "cache_size": 500,
  "legacy_weight": 0.6,
  "modern_weight": 0.4,
  "enable_result_cache": true,
  "cache_ttl_seconds": 300,
  "performance_profile": "balanced",
  "enable_async_operations": true,
  "max_concurrent_searches": 10,
  "debug_mode": false,
  "log_search_metrics": true
}
```

## Переменные окружения

```bash
# Режим поиска по умолчанию
export SEARCH_DEFAULT_MODE=hybrid

# Количество результатов
export SEARCH_DEFAULT_K=10

# Размер кэша
export SEARCH_CACHE_SIZE=1000

# Количество воркеров
export SEARCH_MAX_WORKERS=8

# Путь к файлу evidence
export SEARCH_EVIDENCE_PATH=/path/to/evidence.jsonl

# Режим отладки
export SEARCH_DEBUG_MODE=true

# Логирование метрик
export SEARCH_LOG_METRICS=true
```

## Тестирование

### Запуск всех тестов

```bash
cd merged_project/search/tests
pytest
```

### Запуск определенных тестов

```bash
# Тесты совместимости
pytest test_compatibility.py -v

# Тесты производительности
pytest test_performance.py -v -m "slow"

# Быстрые тесты
pytest -m "unit"
```

### Создание тестовых данных

```python
from search.tests.test_compatibility import create_test_evidence_file

# Создание файла с тестовыми данными
test_file = create_test_evidence_file(num_docs=50, chunks_per_doc=5)

# Использование в тестах
config.evidence_path = test_file
```

## API Reference

### IntegratedSearch

Основной класс интегрированного поиска.

#### Методы

- `search(query, **kwargs) -> (List[SearchResult], SearchMetrics)`: Основной поиск
- `build_indexes()`: Построение индексов
- `get_performance_report() -> Dict`: Отчет о производительности
- `clear_cache()`: Очистка кэша
- `close()`: Закрытие ресурсов

### SearchResult

Результат поиска с метаданными.

#### Атрибуты

- `doc_id`: Идентификатор документа
- `chunk_id`: Идентификатор чанка
- `content`: Текстовое содержимое
- `score`: Оценка релевантности
- `source`: Источник результата (legacy/modern/hybrid)
- `search_mode`: Использованный режим поиска
- `metadata`: Дополнительные метаданные

### SearchMetrics

Метрики выполнения поиска.

#### Атрибуты

- `search_time_ms`: Время поиска в миллисекундах
- `mode_used`: Использованный режим
- `results_count`: Количество результатов
- `cache_hit`: Попадание в кэш
- `index_used`: Использование индекса
- `additional_info`: Дополнительная информация

## Оптимизация производительности

### Профили производительности

1. **FASTEST**: Максимальная скорость
   - Modern Mode по умолчанию
   - Отключен GraphRAG
   - Большой кэш

2. **BALANCED**: Баланс
   - Hybrid Mode
   - Включены все функции
   - Средний кэш

3. **QUALITY**: Максимальное качество
   - GraphRAG Mode по умолчанию
   - Увеличенное k
   - Все анализы включены

4. **GRAPHRAG_FOCUS**: Фокус на GraphRAG
   - Приоритет GraphRAG
   - Увеличенные веса для графа
   - Ограниченный параллелизм

### Автоматическая оптимизация

```python
config = PerformanceConfig(
    auto_performance_tuning=True,
    performance_monitoring_interval=60
)
```

Система автоматически настраивает параметры на основе характеристик запроса.

## Устранение неполадок

### Частые проблемы

1. **Медленный поиск**
   - Проверьте профиль производительности
   - Увеличьте размер кэша
   - Используйте Modern Mode для простых запросов

2. **Высокое использование памяти**
   - Уменьшите размер кэша
   - Очищайте кэш периодически
   - Используйте Fast профиль

3. **Ошибки импорта**
   - Проверьте наличие исходных файлов Version 1/2
   - Убедитесь в корректности путей
   - Проверьте переменную PYTHONPATH

### Логирование

```python
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('search')
```

### Отладка

```python
config = PerformanceConfig(
    debug_mode=True,
    log_search_metrics=True,
    enable_performance_profiling=True
)
```

## Миграция данных

### Миграция между версиями

```python
from search import LegacyVectorSearch, ModernVectorSearch

# Загрузка данных из Version 1
legacy_searcher = LegacyVectorSearch(LegacySearchConfig())
legacy_stats = legacy_searcher.get_evidence_statistics()

# Индексация для Version 2
modern_searcher = ModernVectorSearch(ModernSearchConfig())
await modern_searcher.build_index()
```

### Совместимость данных

Формат данных остается совместимым между версиями:

```json
{
  "doc_id": "document.md",
  "chunk_id": 0,
  "content": "Текстовое содержимое"
}
```

## Производственное развертывание

### Рекомендации

1. **Производительность**
   - Используйте SSD для хранения evidence
   - Настройте размер кэша согласно доступной памяти
   - Мониторьте метрики производительности

2. **Масштабирование**
   - Настройте max_concurrent_searches
   - Используйте load balancing
   - Рассмотрите горизонтальное масштабирование

3. **Мониторинг**
   - Логируйте все поисковые запросы
   - Отслеживайте метрики производительности
   - Настройте алерты для аномалий

### Пример развертывания

```python
#!/usr/bin/env python3
import asyncio
from search import create_fast_config, IntegratedSearch

async def main():
    config = create_fast_config()
    config.evidence_path = "/production/data/evidence.jsonl"
    config.cache_size = 10000
    
    async with IntegratedSearch(config) as searcher:
        await searcher.build_indexes()
        
        # Запуск поискового сервера
        while True:
            query = await get_user_query()
            if query:
                results, metrics = await searcher.search(query)
                await display_results(results, metrics)

if __name__ == "__main__":
    asyncio.run(main())
```