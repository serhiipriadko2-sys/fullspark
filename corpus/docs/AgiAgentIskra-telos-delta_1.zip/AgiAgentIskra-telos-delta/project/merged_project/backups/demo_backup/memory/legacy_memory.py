"""Модуль совместимости с Version 1 (Legacy Memory).

Обеспечивает точную совместимость с простой синхронной системой памяти Version 1.
"""

import json
import os
import time
from dataclasses import dataclass, asdict
from typing import Optional, List, Dict, Any
import threading
from collections import defaultdict


@dataclass
class MemoryEvent:
    """Событие памяти для совместимости с Version 1."""
    t: float
    kind: str
    key: str
    value: dict
    meta: Optional[dict] = None


class LegacyMemoryManager:
    """Менеджер памяти, полностью совместимый с Version 1."""
    
    def __init__(self, root: str = "./memory", auto_flush: bool = True):
        """Инициализация Legacy Memory Manager.
        
        Args:
            root: Корневая директория для хранения файлов памяти
            auto_flush: Автоматическая запись данных при каждом put()
        """
        self.root = root
        self.auto_flush = auto_flush
        
        # Создание директории памяти
        os.makedirs(self.root, exist_ok=True)
        
        # Пути к файлам
        self.archive_path = os.path.join(self.root, "main_archive.jsonl")
        self.shadow_path = os.path.join(self.root, "main_shadow.jsonl")
        
        # Буферизация для оптимизации записи
        self._buffer = {
            "archive": [],
            "shadow": []
        }
        self._buffer_lock = threading.Lock()
        self._buffer_max_size = 100  # Размер буфера перед принудительной записью
        
        # Статистика
        self._stats = {
            "total_puts": 0,
            "archive_puts": 0,
            "shadow_puts": 0,
            "buffered_puts": 0,
            "flushed_operations": 0,
            "start_time": time.time()
        }
        self._stats_lock = threading.Lock()
        
        # Создание файлов если они не существуют
        self._ensure_files_exist()
    
    def _ensure_files_exist(self):
        """Создание файлов памяти если они не существуют."""
        for file_path in [self.archive_path, self.shadow_path]:
            if not os.path.exists(file_path):
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        pass  # Создаем пустой файл
                except Exception as e:
                    print(f"Ошибка создания файла {file_path}: {e}")
    
    def put(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение события в память.
        
        Args:
            kind: Тип события ('archive' или 'shadow')
            key: Ключ для события
            value: Данные события
            meta: Дополнительные метаданные
            
        Returns:
            MemoryEvent: Созданное событие памяти
        """
        # Создание события
        event = MemoryEvent(
            t=time.time(),
            kind=kind,
            key=key,
            value=value,
            meta=meta
        )
        
        # Обновление статистики
        with self._stats_lock:
            self._stats["total_puts"] += 1
            if kind == "archive":
                self._stats["archive_puts"] += 1
            else:
                self._stats["shadow_puts"] += 1
        
        if self.auto_flush:
            # Прямая запись в файл
            self._write_event_to_file(event)
        else:
            # Буферизация
            self._buffer_event(event)
        
        return event
    
    def _write_event_to_file(self, event: MemoryEvent):
        """Запись события в файл."""
        file_path = self.archive_path if event.kind == "archive" else self.shadow_path
        
        try:
            with open(file_path, "a", encoding="utf-8") as f:
                line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                f.write(line + "\n")
                f.flush()  # Принудительная запись на диск
        except Exception as e:
            print(f"Ошибка записи события в {file_path}: {e}")
            raise
    
    def _buffer_event(self, event: MemoryEvent):
        """Добавление события в буфер."""
        buffer_key = event.kind
        
        with self._buffer_lock:
            self._buffer[buffer_key].append(event)
            
            # Проверка размера буфера
            if len(self._buffer[buffer_key]) >= self._buffer_max_size:
                self._flush_buffer(buffer_key)
    
    def _flush_buffer(self, buffer_key: str):
        """Принудительная запись буфера на диск."""
        if not self._buffer[buffer_key]:
            return
        
        file_path = self.archive_path if buffer_key == "archive" else self.shadow_path
        
        try:
            # Группировка событий для эффективной записи
            lines = []
            for event in self._buffer[buffer_key]:
                line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                lines.append(line)
            
            # Атомарная запись
            data = '\n'.join(lines) + '\n'
            
            with open(file_path, "a", encoding="utf-8") as f:
                f.write(data)
                f.flush()
            
            # Очистка буфера
            self._buffer[buffer_key].clear()
            
            with self._stats_lock:
                self._stats["flushed_operations"] += 1
                
        except Exception as e:
            print(f"Ошибка записи буфера в {file_path}: {e}")
            raise
    
    def flush_all(self):
        """Принудительная запись всех буферов на диск."""
        with self._buffer_lock:
            for buffer_key in ["archive", "shadow"]:
                if self._buffer[buffer_key]:
                    self._flush_buffer(buffer_key)
    
    def get(self, kind: str, key: str = "", since: Optional[float] = None) -> List[MemoryEvent]:
        """Получение событий из памяти.
        
        Args:
            kind: Тип события ('archive' или 'shadow')
            key: Ключ для фильтрации (пустая строка - все ключи)
            since: Время для фильтрации по времени (события после этого времени)
            
        Returns:
            List[MemoryEvent]: Список найденных событий
        """
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        events = []
        
        # Проверка существования файла
        if not os.path.exists(file_path):
            return events
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        data = json.loads(line)
                        event = MemoryEvent(**data)
                        
                        # Фильтрация по ключу
                        if key and event.key != key:
                            continue
                        
                        # Фильтрация по времени
                        if since and event.t < since:
                            continue
                        
                        events.append(event)
                        
                    except (json.JSONDecodeError, KeyError, TypeError) as e:
                        # Пропуск поврежденных строк
                        continue
                        
        except Exception as e:
            print(f"Ошибка чтения файла {file_path}: {e}")
        
        # Сортировка по времени
        events.sort(key=lambda x: x.t, reverse=True)
        
        return events
    
    def get_recent(self, kind: str, hours: int = 24, key: str = "") -> List[MemoryEvent]:
        """Получение недавних событий за последние N часов.
        
        Args:
            kind: Тип события
            hours: Количество часов назад
            key: Ключ для фильтрации
            
        Returns:
            List[MemoryEvent]: Список недавних событий
        """
        since = time.time() - (hours * 3600)
        return self.get(kind, key, since)
    
    def get_by_key_pattern(self, kind: str, pattern: str) -> List[MemoryEvent]:
        """Получение событий по шаблону ключа.
        
        Args:
            kind: Тип события
            pattern: Шаблон для поиска в ключах
            
        Returns:
            List[MemoryEvent]: Список найденных событий
        """
        events = self.get(kind)
        filtered_events = []
        
        for event in events:
            if pattern in event.key:
                filtered_events.append(event)
        
        return filtered_events
    
    def search_events(self, kind: str = "", key: str = "", value_search: str = "", 
                     since: Optional[float] = None, limit: int = 100) -> List[MemoryEvent]:
        """Расширенный поиск событий.
        
        Args:
            kind: Тип события (пустая строка - все типы)
            key: Ключ для фильтрации
            value_search: Строка для поиска в значениях
            since: Время для фильтрации
            limit: Максимальное количество результатов
            
        Returns:
            List[MemoryEvent]: Список найденных событий
        """
        events = []
        
        # Определение типов для поиска
        kinds_to_search = [kind] if kind else ["archive", "shadow"]
        
        for k in kinds_to_search:
            kind_events = self.get(k, key, since)
            
            for event in kind_events:
                # Поиск в значениях
                if value_search:
                    value_str = json.dumps(event.value, ensure_ascii=False)
                    if value_search.lower() not in value_str.lower():
                        continue
                
                events.append(event)
                
                # Ограничение количества результатов
                if len(events) >= limit:
                    return events
        
        # Сортировка по времени (новые сначала)
        events.sort(key=lambda x: x.t, reverse=True)
        
        return events[:limit]
    
    def delete_events(self, kind: str, key: str = "", since: Optional[float] = None) -> int:
        """Удаление событий по критериям.
        
        Args:
            kind: Тип события
            key: Ключ для удаления (пустая строка - все ключи)
            since: Время для фильтрации (только события после этого времени)
            
        Returns:
            int: Количество удаленных событий
        """
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        
        if not os.path.exists(file_path):
            return 0
        
        # Сначала читаем все события
        all_events = []
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        data = json.loads(line)
                        event = MemoryEvent(**data)
                        all_events.append(event)
                    except (json.JSONDecodeError, KeyError, TypeError):
                        continue
        except Exception as e:
            print(f"Ошибка чтения файла {file_path}: {e}")
            return 0
        
        # Фильтрация событий для удаления
        events_to_keep = []
        events_deleted = 0
        
        for event in all_events:
            should_delete = True
            
            # Проверка типа
            if event.kind != kind:
                should_delete = False
            
            # Проверка ключа
            if key and event.key != key:
                should_delete = False
            
            # Проверка времени
            if since and event.t < since:
                should_delete = False
            
            if should_delete:
                events_deleted += 1
            else:
                events_to_keep.append(event)
        
        # Перезапись файла с оставшимися событиями
        if events_deleted > 0:
            try:
                with open(file_path, "w", encoding="utf-8") as f:
                    for event in events_to_keep:
                        line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                        f.write(line + "\n")
            except Exception as e:
                print(f"Ошибка перезаписи файла {file_path}: {e}")
                return 0
        
        return events_deleted
    
    def cleanup_old_events(self, days: int = 30) -> int:
        """Очистка старых событий.
        
        Args:
            days: Количество дней для хранения событий
            
        Returns:
            int: Количество удаленных событий
        """
        cutoff_time = time.time() - (days * 24 * 3600)
        total_deleted = 0
        
        # Удаление из обеих типов событий
        for kind in ["archive", "shadow"]:
            deleted = self.delete_events(kind, since=cutoff_time)
            total_deleted += deleted
        
        return total_deleted
    
    def get_file_stats(self) -> Dict[str, Any]:
        """Получение статистики файлов памяти."""
        stats = {}
        
        for kind, file_path in [("archive", self.archive_path), ("shadow", self.shadow_path)]:
            if os.path.exists(file_path):
                stat = os.stat(file_path)
                stats[kind] = {
                    "size_bytes": stat.st_size,
                    "size_mb": round(stat.st_size / (1024 * 1024), 2),
                    "modified": stat.st_mtime
                }
            else:
                stats[kind] = {"size_bytes": 0, "size_mb": 0, "modified": None}
        
        return stats
    
    def get_stats(self) -> Dict[str, Any]:
        """Получение статистики работы системы."""
        with self._stats_lock:
            stats = self._stats.copy()
        
        # Добавляем время работы
        stats["uptime_seconds"] = time.time() - stats["start_time"]
        del stats["start_time"]  # Удаляем время начала
        
        # Добавляем статистику файлов
        stats["files"] = self.get_file_stats()
        
        # Добавляем информацию о буфере
        with self._buffer_lock:
            stats["buffer"] = {
                "archive_buffered": len(self._buffer["archive"]),
                "shadow_buffered": len(self._buffer["shadow"]),
                "max_buffer_size": self._buffer_max_size,
                "buffering_enabled": not self.auto_flush
            }
        
        return stats
    
    def optimize_files(self):
        """Оптимизация файлов памяти (удаление дубликатов и сжатие)."""
        # Сначала сбрасываем буфер
        self.flush_all()
        
        # Оптимизация каждого файла
        for kind in ["archive", "shadow"]:
            self._optimize_file(kind)
    
    def _optimize_file(self, kind: str):
        """Оптимизация отдельного файла."""
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        
        if not os.path.exists(file_path):
            return
        
        # Читаем все события
        events = self.get(kind)
        
        # Удаляем дубликаты (по ключу и времени)
        unique_events = {}
        for event in events:
            unique_key = f"{event.key}:{event.t}"
            if unique_key not in unique_events:
                unique_events[unique_key] = event
        
        # Перезаписываем файл с уникальными событиями
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                for event in unique_events.values():
                    line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                    f.write(line + "\n")
        except Exception as e:
            print(f"Ошибка оптимизации файла {file_path}: {e}")
    
    def compact_files(self):
        """Компактификация файлов памяти."""
        self.optimize_files()
    
    def export_to_json(self, output_file: str, kind: str = "", since: Optional[float] = None):
        """Экспорт событий в JSON файл.
        
        Args:
            output_file: Путь к выходному файлу
            kind: Тип события (пустая строка - все типы)
            since: Время для фильтрации
        """
        events = []
        
        # Определение типов для экспорта
        kinds_to_export = [kind] if kind else ["archive", "shadow"]
        
        for k in kinds_to_export:
            kind_events = self.get(k, since=since)
            events.extend(kind_events)
        
        # Сортировка по времени
        events.sort(key=lambda x: x.t)
        
        # Экспорт в JSON
        try:
            export_data = {
                "export_time": time.time(),
                "total_events": len(events),
                "events": [event.to_dict() for event in events]
            }
            
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            print(f"Ошибка экспорта в {output_file}: {e}")
            raise
    
    def import_from_json(self, input_file: str, merge: bool = True):
        """Импорт событий из JSON файла.
        
        Args:
            input_file: Путь к входному файлу
            merge: Объединять с существующими событиями
        """
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            events_data = import_data.get("events", [])
            imported_count = 0
            
            for event_data in events_data:
                try:
                    event = MemoryEvent(**event_data)
                    self.put(event.kind, event.key, event.value, event.meta)
                    imported_count += 1
                except Exception as e:
                    print(f"Ошибка импорта события: {e}")
                    continue
            
            print(f"Импортировано {imported_count} событий из {input_file}")
            
        except Exception as e:
            print(f"Ошибка импорта из {input_file}: {e}")
            raise
    
    def close(self):
        """Закрытие системы и сброс буферов."""
        self.flush_all()
        print("Legacy Memory Manager закрыт")


# Функции совместимости для Version 1
def create_legacy_memory_manager(root: str = "./memory") -> LegacyMemoryManager:
    """Создание Legacy Memory Manager (для совместимости с Version 1)."""
    return LegacyMemoryManager(root=root)


def get_memory_manager_v1(root: str = "./memory") -> LegacyMemoryManager:
    """Получение Memory Manager версии 1 (для обратной совместимости)."""
    return LegacyMemoryManager(root=root)