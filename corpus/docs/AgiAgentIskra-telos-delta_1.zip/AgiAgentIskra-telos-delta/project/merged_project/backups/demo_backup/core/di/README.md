# Dependency Injection система для проекта "Искра"

**Версия:** 1.0  
**Дата создания:** 01.11.2025  
**Статус:** Интегрированная система для Version 1 + Version 2  

## 📋 Обзор системы

Интегрированная система Dependency Injection (DI) объединяет простоту Version 1 с гибкостью и архитектурными улучшениями Version 2. Система обеспечивает:

- ✅ **Полная обратная совместимость** с Version 1
- 🔄 **Постепенная миграция** к архитектуре Version 2
- 🧪 **Автоматическое тестирование** подключений
- ⚡ **Высокая производительность** и мониторинг
- 🔒 **Безопасность enterprise-grade**

## 🏗️ Архитектура системы

### Основные компоненты:

1. **DIContainer** - центральный контейнер управления зависимостями
2. **ServiceRegistry** - реестр сервисов для автоматического обнаружения
3. **DependencyConfig** - конфигурация зависимостей и настроек
4. **DependencyWiring** - автоматическое подключение компонентов

```
merged_project/core/di/
├── __init__.py                 # Экспорт основных компонентов
├── di_container.py            # Главный DI контейнер
├── service_registry.py        # Реестр сервисов
├── config_dependencies.py     # Конфигурация зависимостей
└── dependency_wiring.py       # Подключение зависимостей
```

## 🚀 Быстрый старт

### 1. Базовое использование

```python
from merged_project.core.di import container, registry, wiring

# Автоматическое подключение всех компонентов
results = wiring.auto_wire_all()

# Получение сервиса из контейнера
memory_service = container.resolve("UnifiedMemoryManager")
search_service = container.resolve("UnifiedVectorSearch")
```

### 2. Ручная регистрация сервиса

```python
from merged_project.core.di import container, ServiceLifetime

# Регистрация singleton сервиса
container.register_singleton(
    service_type=MemoryManager,
    implementation=OptimizedMemoryManager,
    config={'batch_size': 50, 'cache_size': 1000}
)

# Получение сервиса
memory_manager = container.resolve(MemoryManager)
```

### 3. Конфигурация для разных режимов

```python
from merged_project.core.di import DependencyConfig, VersionCompatibility

# Создание конфигурации
config = DependencyConfig()

# Настройка для совместимости с Version 1
config.config.version_compatibility = VersionCompatibility.BACKWARD_COMPATIBLE

# Настройка для гибридного режима
config.config.version_compatibility = VersionCompatibility.HYBRID

# Настройка для полного использования Version 2
config.config.version_compatibility = VersionCompatibility.V2_ONLY
```

## 🔧 Конфигурация

### Переменные окружения

| Переменная | Описание | По умолчанию |
|------------|----------|--------------|
| `DI_ENVIRONMENT` | Режим окружения | `development` |
| `DI_VERSION_COMPATIBILITY` | Режим совместимости | `hybrid` |
| `JWT_SECRET` | Секрет для JWT (production!) | `dev-secret` |
| `CORS_ORIGINS` | Разрешенные CORS origins | `*` |
| `MEMORY_HYBRID_MODE` | Гибридный режим памяти | `true` |
| `SEARCH_CACHE_ENABLED` | Кэширование поиска | `true` |

### Конфигурационный файл

```yaml
# config/di_config.yaml
environment: production
version_compatibility: hybrid

security:
  jwt_secret: "${JWT_SECRET}"
  cors_origins: ["https://yourdomain.com"]
  rate_limit_enabled: true
  enable_cors_validation: true

memory:
  modern_batch_size: 50
  modern_cache_size: 1000
  hybrid_mode: true

search:
  modern_cache_enabled: true
  hybrid_auto_select: true

api:
  async_handlers: true
  modular_routing: true
```

## 📚 Основные концепции

### Времена жизни сервисов

#### Transient (По умолчанию)
```python
# Новый экземпляр при каждом запросе
container.register_transient(EmailService)
```

#### Scoped
```python
# Один экземпляр на область (например, HTTP request)
container.register_scoped(AuthService)
```

#### Singleton
```python
# Один экземпляр на всю жизнь приложения
container.register_singleton(MemoryManager)
```

### Режимы совместимости

#### V1_ONLY (Version 1)
- Используются только legacy компоненты
- Полная совместимость с существующим кодом
- Ограниченные возможности

#### V2_ONLY (Version 2)
- Используются только modern компоненты
- Максимальная производительность и функциональность
- Требует обновления кода

#### HYBRID (По умолчанию)
- Автоматический выбор между legacy и modern
- Backward compatibility с graceful degradation
- Постепенная миграция

#### UNIVERSAL
- Универсальные компоненты, работающие в любом режиме

## 🔄 Миграция от Version 1 к Version 2

### Этап 1: Подготовка (Backward Compatible)

```python
# Старый код (Version 1)
class LegacyMemoryManager:
    def __init__(self):
        self.memory = MemoryManager()  # Прямое создание

# Новый код с DI
class ModernMemoryManager:
    def __init__(self, memory_service: MemoryService):
        self.memory_service = memory_service  # DI через сервис
```

### Этап 2: Гибридный режим

```python
# Одновременная поддержка обеих версий
container.register_singleton(
    service_type=MemoryService,
    implementation=UnifiedMemoryManager,  # Автоматически выбирает V1/V2
    config={'mode': 'hybrid'}
)
```

### Этап 3: Полный переход на Version 2

```python
# Только modern компоненты
container.register_singleton(
    service_type=MemoryService,
    implementation=OptimizedMemoryManager,
    config={'version': 'v2'}
)
```

## 🧪 Автоматическое тестирование

### Проверка подключений

```python
from merged_project.core.di import wiring

# Запуск автоматического тестирования
results = wiring.auto_wire_all()

# Анализ результатов
for name, result in results.items():
    if result.is_success():
        print(f"✅ {name}: {result.status.value}")
    else:
        print(f"❌ {name}: {result.error}")
```

### Юнит-тестирование компонентов

```python
import pytest
from merged_project.core.di import container

def test_memory_service_wiring():
    # Сброс контейнера для тестирования
    container.reset()
    
    # Регистрация тестовых сервисов
    container.register_singleton(MemoryService, MockMemoryManager)
    
    # Получение и тестирование
    memory_service = container.resolve(MemoryService)
    assert memory_service is not None
    assert isinstance(memory_service, MockMemoryManager)

def test_circular_dependency_detection():
    with pytest.raises(RuntimeError, match="Circular dependency"):
        # Попытка создать циклическую зависимость
        container.resolve(CircularDependencyService)
```

## 📊 Мониторинг и метрики

### Получение метрик

```python
# Метрики контейнера
container_metrics = container.get_metrics()
print(f"Регистраций: {container_metrics['registrations']}")
print(f"Разрешений: {container_metrics['resolutions']}")
print(f"Ошибок: {container_metrics['errors']}")

# Статус подключения
wiring_stats = wiring.get_wiring_status()
print(f"Успешно подключено: {wiring_stats['successfully_wired']}")
print(f"Legacy компоненты: {wiring_stats['legacy_components']}")
print(f"Modern компоненты: {wiring_stats['modern_components']}")
```

### Экспорт конфигурации

```python
# Сохранение конфигурации DI
config.save_to_file("config/di_config.yaml")

# Экспорт результатов подключения
wiring.export_wiring_config("logs/wiring_results.json")
```

## 🔒 Безопасность

### Автоматическое исправление уязвимостей Version 1

```python
# Version 1 (уязвимый код)
JWT_SECRET = "dev-secret"  # 🔴 Критическая уязвимость
CORS_ORIGINS = "*"         # 🔴 Небезопасный CORS

# Version 2 (исправленный код через DI)
config.security.jwt_secret = os.getenv('PRODUCTION_JWT_SECRET')
config.security.cors_origins = ['https://yourdomain.com']
```

### Rate Limiting и валидация

```python
# Автоматическое включение rate limiting в production
if config.environment == EnvironmentMode.PRODUCTION:
    container.register_scoped(RateLimiter, production_config)
    container.register_singleton(CORSManager, secure_config)
```

## 🐛 Отладка

### Включение подробного логирования

```python
import logging

# Настройка логирования для DI системы
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger('merged_project.core.di')
logger.setLevel(logging.DEBUG)
```

### Проверка состояния компонентов

```python
# Проверка регистрации сервиса
if container.is_registered(MemoryService):
    print("MemoryService зарегистрирован")

# Получение всех регистраций
registrations = container.get_all_registrations()
for reg in registrations:
    print(f"{reg['service_type']}: {reg['lifetime']} (доступов: {reg['access_count']})")

# Проверка статуса конкретного компонента
status = wiring.get_component_status("unified_memory")
print(f"Статус memory компонента: {status.value}")
```

### Очистка области видимости

```python
# Очистка scoped сервисов
container.clear_scope("http_request_123")

# Полный сброс контейнера (для тестирования)
container.reset()
wiring.reset_wiring()
```

## 📈 Производительность

### Рекомендации для оптимизации

1. **Singleton для тяжелых сервисов**
   ```python
   # Хорошо: тяжелые сервисы как singleton
   container.register_singleton(MemoryManager, OptimizedMemoryManager)
   container.register_singleton(SearchEngine, OptimizedVectorSearch)
   ```

2. **Scoped для контекстных сервисов**
   ```python
   # Хорошо: контекстные сервисы как scoped
   container.register_scoped(AuthService)
   container.register_scoped(RequestValidator)
   ```

3. **Transient для легких сервисов**
   ```python
   # Хорошо: легкие stateless сервисы как transient
   container.register_transient(EmailService)
   container.register_transient(Logger)
   ```

### Мониторинг производительности

```python
# Метрики доступа к сервисам
for reg in container.get_all_registrations():
    if reg['access_count'] > 1000:
        print(f"High usage: {reg['service_type']} accessed {reg['access_count']} times")
    
    if reg['lifetime'] == 'singleton' and reg['access_count'] == 0:
        print(f"Unused singleton: {reg['service_type']}")
```

## 🔄 Интеграция с существующим кодом

### Адаптация legacy компонентов

```python
# Version 1: Прямое создание зависимостей
class LegacyAPIHandler:
    def __init__(self):
        self.memory = MemoryManager()  # Прямое создание
        self.search = VectorSearch()   # Прямое создание

# Version 2: Адаптация для DI
class ModernAPIHandler:
    def __init__(self, memory_service=None, search_service=None):
        # Backward compatibility
        if memory_service is None:
            memory_service = MemoryManager()
        if search_service is None:
            search_service = VectorSearch()
            
        self.memory = memory_service
        self.search = search_service
```

### Gradual migration

```python
# Шаг 1: Обернуть в DI-совместимый интерфейс
@container.register_transient
class DILegacyMemoryManager:
    def __init__(self):
        self._legacy = MemoryManager()  # Оригинальный Version 1 код
    
    def put(self, key, value):
        return self._legacy.put(key, value)
    
    def get(self, key):
        return self._legacy.get(key)

# Шаг 2: Постепенно заменять на modern реализации
@container.register_transient  
class ModernMemoryManager:
    def __init__(self):
        self._optimized = OptimizedMemoryManager()  # Version 2 код
    
    def put(self, key, value):
        return self._optimized.put(key, value)
    
    def get(self, key):
        return self._optimized.get(key)
```

## 🆘 Troubleshooting

### Частые проблемы и решения

#### 1. Circular Dependency Error
```
RuntimeError: Circular dependency detected for MemoryService
```

**Решение:**
```python
# Избегайте циклических зависимостей
# Плохо:
class ServiceA:
    def __init__(self, service_b: ServiceB): pass

class ServiceB:
    def __init__(self, service_a: ServiceA): pass

# Хорошо: Используйте события или фасады
```

#### 2. Service Not Registered
```
Service not registered: MemoryManager
```

**Решение:**
```python
# Убедитесь, что сервис зарегистрирован
container.register_singleton(MemoryManager, OptimizedMemoryManager)

# Или используйте auto-discovery
registry.auto_discover_services()
```

#### 3. Implementation Not Found
```
ModuleNotFoundError: No module named 'optimized.memory'
```

**Решение:**
```python
# Проверьте пути в sys.path
import sys
sys.path.append('./path/to/optimized')

# Или используйте fallback implementations
wiring._attempt_fallback_wiring("memory")
```

## 📞 Поддержка

Для получения помощи по DI системе:

1. Проверьте логи с уровнем DEBUG
2. Используйте методы диагностики (`get_wiring_status()`, `get_metrics()`)
3. Обратитесь к документации troubleshooting
4. Создайте issue с результатами `export_wiring_config()`

## 📄 Лицензия

Система DI является частью проекта "Искра" и следует той же лицензии.