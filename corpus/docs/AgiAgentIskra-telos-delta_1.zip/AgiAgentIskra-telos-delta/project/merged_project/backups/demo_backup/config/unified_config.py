"""
Синхронизированная система конфигурации для интегрированной архитектуры Искра.

Объединяет настройки Version 1 и Version 2 с полной совместимостью,
обеспечивает единообразную работу всех компонентов системы.
"""

import os
import json
import secrets
import base64
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum
import logging

# Import configuration components
try:
    from .environment import EnvironmentManager
    from .validation import ConfigValidator
    from .compatibility import VersionCompatibility
    from .migration import ConfigMigrator
    from .defaults import DefaultSettings
except ImportError:
    # Fallback for direct execution or missing dependencies
    EnvironmentManager = None
    ConfigValidator = None
    VersionCompatibility = None
    ConfigMigrator = None
    DefaultSettings = None


class EnvironmentProfile(Enum):
    """Профили конфигурации для разных сред."""
    DEVELOPMENT = "development"
    PRODUCTION = "production"
    TESTING = "testing"
    STAGING = "staging"


@dataclass
class SecuritySettings:
    """Настройки безопасности."""
    # JWT настройки
    jwt_secret: str = ""
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 30
    jwt_refresh_token_expire_days: int = 7
    
    # CORS настройки
    cors_origins: List[str] = field(default_factory=lambda: ["http://localhost:3000"])
    cors_allow_credentials: bool = True
    cors_allow_methods: List[str] = field(default_factory=lambda: ["GET", "POST", "PUT", "DELETE", "OPTIONS"])
    cors_allow_headers: List[str] = field(default_factory=lambda: ["Authorization", "Content-Type", "X-Requested-With"])
    
    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_requests_per_minute: int = 100
    rate_limit_burst_size: int = 200
    
    # Security headers
    security_headers_enabled: bool = True
    strict_transport_security: bool = True
    content_security_policy: str = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"


@dataclass 
class MemorySettings:
    """Настройки системы памяти."""
    # Основные пути
    memory_root: str = "memory"
    evidence_path: str = "memory/evidence.jsonl"
    working_memory_path: str = "memory/working.jsonl"
    long_term_memory_path: str = "memory/long_term.jsonl"
    
    # Batch processing
    memory_batch_size: int = 50
    memory_flush_interval_seconds: float = 5.0
    memory_auto_flush: bool = True
    
    # Compression и storage
    memory_compression_enabled: bool = False
    memory_compression_algorithm: str = "gzip"
    memory_max_size_mb: int = 1024
    
    # Async operations
    memory_async_enabled: bool = True
    memory_concurrent_operations: int = 4


@dataclass
class SearchSettings:
    """Настройки поисковой системы."""
    # Основные настройки поиска
    default_search_k: int = 5
    max_search_results: int = 50
    search_timeout_seconds: float = 30.0
    
    # Кэширование
    search_cache_enabled: bool = True
    search_cache_size: int = 1000
    search_cache_ttl_seconds: int = 3600
    
    # Индексы
    vector_index_enabled: bool = True
    vector_index_refresh_interval: int = 300
    vector_index_auto_rebuild: bool = True
    
    # Similarity settings
    similarity_threshold: float = 0.7
    similarity_algorithm: str = "cosine"
    
    # Performance
    search_parallel_threads: int = 4
    search_batch_processing: bool = True


@dataclass
class APISettings:
    """Настройки API."""
    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000
    reload: bool = False
    workers: int = 1
    
    # API versioning
    api_version_prefix: str = "/v1"
    api_version_header: str = "X-API-Version"
    
    # Middleware
    middleware_enabled: bool = True
    cors_middleware_enabled: bool = True
    auth_middleware_enabled: bool = True
    logging_middleware_enabled: bool = True
    
    # Request limits
    request_size_limit_mb: int = 100
    request_timeout_seconds: int = 300
    
    # Documentation
    docs_enabled: bool = True
    docs_url: str = "/docs"
    redoc_url: str = "/redoc"


@dataclass
class PerformanceSettings:
    """Настройки производительности."""
    # Async settings
    async_pool_size: int = 4
    async_queue_size: int = 1000
    async_timeout_seconds: float = 30.0
    
    # Thread pools
    io_thread_pool_size: int = 10
    cpu_thread_pool_size: int = 4
    
    # Connection pools
    connection_pool_size: int = 10
    connection_pool_max_overflow: int = 20
    connection_pool_timeout: int = 30
    
    # Memory management
    memory_pool_enabled: bool = True
    garbage_collection_optimization: bool = True
    
    # Caching
    lru_cache_enabled: bool = True
    lru_cache_size: int = 1000
    redis_cache_enabled: bool = False


@dataclass
class LoggingSettings:
    """Настройки логирования."""
    # Level и format
    log_level: str = "INFO"
    log_format: str = "json"  # json, text, colored
    log_date_format: str = "%Y-%m-%d %H:%M:%S"
    
    # Outputs
    console_logging: bool = True
    file_logging: bool = False
    syslog_logging: bool = False
    
    # File logging
    log_file_path: str = "logs/app.log"
    log_file_max_size_mb: int = 100
    log_file_backup_count: int = 5
    
    # Performance
    async_logging: bool = True
    log_buffer_size: int = 1000
    log_flush_interval_seconds: float = 1.0
    
    # Structured logging
    structured_logging: bool = True
    include_trace_id: bool = True
    include_user_id: bool = False


@dataclass
class MonitoringSettings:
    """Настройки мониторинга и метрик."""
    # Metrics
    metrics_enabled: bool = True
    metrics_port: int = 9090
    metrics_path: str = "/metrics"
    
    # Health checks
    health_check_enabled: bool = True
    health_check_interval_seconds: int = 60
    health_check_timeout_seconds: float = 5.0
    
    # OpenTelemetry
    otel_enabled: bool = True
    otel_service_name: str = "iskra-api"
    otel_service_version: str = "1.0.0"
    
    # Alerts
    alerts_enabled: bool = False
    alert_webhook_url: str = ""
    alert_threshold_cpu_percent: float = 80.0
    alert_threshold_memory_percent: float = 85.0


@dataclass
class DatabaseSettings:
    """Настройки базы данных."""
    # Main database
    database_url: Optional[str] = None
    database_pool_size: int = 5
    database_max_overflow: int = 10
    database_timeout: int = 30
    
    # Connection settings
    database_echo: bool = False
    database_pool_recycle: int = 3600
    
    # Migration settings
    migration_enabled: bool = True
    migration_path: str = "migrations"


class UnifiedConfig:
    """Главный класс конфигурации, объединяющий все настройки."""
    
    def __init__(self, config_path: Optional[str] = None, profile: Optional[EnvironmentProfile] = None):
        """
        Инициализация конфигурации.
        
        Args:
            config_path: Путь к файлу конфигурации
            profile: Профиль окружения (dev/prod/test)
        """
        # Инициализация компонентов
        self.environment_manager = EnvironmentManager() if EnvironmentManager else None
        self.validator = ConfigValidator() if ConfigValidator else None
        self.compatibility = VersionCompatibility() if VersionCompatibility else None
        self.migrator = ConfigMigrator() if ConfigMigrator else None
        self.defaults = DefaultSettings() if DefaultSettings else None
        
        # Определение профиля
        self.profile = profile or self._detect_environment_profile()
        
        # Загрузка конфигурации
        self.config_data = self._load_configuration(config_path)
        
        # Создание настроек
        self.security = self._create_security_settings()
        self.memory = self._create_memory_settings()
        self.search = self._create_search_settings()
        self.api = self._create_api_settings()
        self.performance = self._create_performance_settings()
        self.logging = self._create_logging_settings()
        self.monitoring = self._create_monitoring_settings()
        self.database = self._create_database_settings()
        
        # Валидация конфигурации
        self._validate_configuration()
        
        # Финализация настроек
        self._finalize_configuration()
    
    def _detect_environment_profile(self) -> EnvironmentProfile:
        """Автоматическое определение профиля окружения."""
        env_var = os.getenv("ENVIRONMENT_PROFILE", "").lower()
        
        if env_var in ["prod", "production"]:
            return EnvironmentProfile.PRODUCTION
        elif env_var in ["test", "testing"]:
            return EnvironmentProfile.TESTING
        elif env_var in ["stage", "staging"]:
            return EnvironmentProfile.STAGING
        else:
            return EnvironmentProfile.DEVELOPMENT
    
    def _load_configuration(self, config_path: Optional[str]) -> Dict[str, Any]:
        """Загрузка конфигурации из файлов и окружения."""
        config_data = {}
        
        # 1. Загрузка значений по умолчанию
        config_data.update(self.defaults.get_defaults())
        
        # 2. Загрузка из файла конфигурации
        if config_path and Path(config_path).exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    file_config = json.load(f)
                config_data.update(file_config)
            except Exception as e:
                logging.warning(f"Ошибка загрузки файла конфигурации {config_path}: {e}")
        
        # 3. Загрузка из переменных окружения
        if self.environment_manager:
            env_config = self.environment_manager.load_from_environment()
            config_data.update(env_config)
        
        # 4. Применение профиля
        self._apply_profile_settings(config_data)
        
        # 5. Миграция из старых версий
        if self.migrator:
            config_data = self.migrator.migrate_config(config_data)
        
        return config_data
    
    def _apply_profile_settings(self, config_data: Dict[str, Any]) -> None:
        """Применение настроек конкретного профиля."""
        profile_overrides = {
            EnvironmentProfile.DEVELOPMENT: {
                "DEBUG": True,
                "LOG_LEVEL": "DEBUG",
                "CONSOLE_LOGGING": True,
                "DOCS_ENABLED": True,
                "METRICS_ENABLED": True,
                "RATE_LIMIT_ENABLED": False,
            },
            EnvironmentProfile.PRODUCTION: {
                "DEBUG": False,
                "LOG_LEVEL": "WARNING",
                "SECURITY_HEADERS_ENABLED": True,
                "RATE_LIMIT_ENABLED": True,
                "MEMORY_COMPRESSION_ENABLED": True,
                "TELEMETRY_ENABLED": True,
            },
            EnvironmentProfile.TESTING: {
                "DEBUG": False,
                "LOG_LEVEL": "ERROR",
                "DATABASE_ECHO": False,
                "ASYNC_LOGGING": False,
                "METRICS_ENABLED": False,
            },
            EnvironmentProfile.STAGING: {
                "DEBUG": True,
                "LOG_LEVEL": "INFO",
                "SECURITY_HEADERS_ENABLED": True,
                "METRICS_ENABLED": True,
            }
        }
        
        overrides = profile_overrides.get(self.profile, {})
        config_data.update(overrides)
    
    def _create_security_settings(self) -> SecuritySettings:
        """Создание настроек безопасности."""
        return SecuritySettings(
            jwt_secret=self._get_jwt_secret(),
            jwt_algorithm=self.config_data.get("JWT_ALGORITHM", "HS256"),
            jwt_access_token_expire_minutes=self.config_data.get("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", 30),
            jwt_refresh_token_expire_days=self.config_data.get("JWT_REFRESH_TOKEN_EXPIRE_DAYS", 7),
            
            cors_origins=self._parse_cors_origins(),
            cors_allow_credentials=self.config_data.get("CORS_ALLOW_CREDENTIALS", True),
            cors_allow_methods=self.config_data.get("CORS_ALLOW_METHODS", ["GET", "POST", "PUT", "DELETE"]),
            cors_allow_headers=self.config_data.get("CORS_ALLOW_HEADERS", ["Authorization", "Content-Type"]),
            
            rate_limit_enabled=self.config_data.get("RATE_LIMIT_ENABLED", True),
            rate_limit_requests_per_minute=self.config_data.get("RATE_LIMIT_REQUESTS", 100),
            rate_limit_burst_size=self.config_data.get("RATE_LIMIT_BURST", 200),
            
            security_headers_enabled=self.config_data.get("SECURITY_HEADERS_ENABLED", True),
            strict_transport_security=self.config_data.get("STRICT_TRANSPORT_SECURITY", True),
            content_security_policy=self.config_data.get("CONTENT_SECURITY_POLICY", "default-src 'self'"),
        )
    
    def _get_jwt_secret(self) -> str:
        """Получение JWT секрета с автоматической генерацией."""
        secret = self.config_data.get("JWT_SECRET", "")
        if not secret or len(secret) < 32:
            secret = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8')
            logging.info("Автоматически сгенерирован JWT секрет")
        return secret
    
    def _parse_cors_origins(self) -> List[str]:
        """Парсинг CORS источников."""
        origins_str = self.config_data.get("CORS_ORIGINS", "http://localhost:3000")
        if isinstance(origins_str, str):
            return [origin.strip() for origin in origins_str.split(",") if origin.strip()]
        return origins_str if isinstance(origins_str, list) else ["http://localhost:3000"]
    
    def _create_memory_settings(self) -> MemorySettings:
        """Создание настроек памяти."""
        return MemorySettings(
            memory_root=self.config_data.get("MEMORY_ROOT", "memory"),
            evidence_path=self.config_data.get("EVIDENCE_PATH", "memory/evidence.jsonl"),
            working_memory_path=self.config_data.get("WORKING_MEMORY_PATH", "memory/working.jsonl"),
            long_term_memory_path=self.config_data.get("LONG_TERM_MEMORY_PATH", "memory/long_term.jsonl"),
            
            memory_batch_size=self.config_data.get("MEMORY_BATCH_SIZE", 50),
            memory_flush_interval_seconds=self.config_data.get("MEMORY_FLUSH_INTERVAL", 5.0),
            memory_auto_flush=self.config_data.get("MEMORY_AUTO_FLUSH", True),
            
            memory_compression_enabled=self.config_data.get("MEMORY_COMPRESSION", False),
            memory_compression_algorithm=self.config_data.get("MEMORY_COMPRESSION_ALGORITHM", "gzip"),
            memory_max_size_mb=self.config_data.get("MEMORY_MAX_SIZE_MB", 1024),
            
            memory_async_enabled=self.config_data.get("MEMORY_ASYNC", True),
            memory_concurrent_operations=self.config_data.get("MEMORY_CONCURRENT_OPS", 4),
        )
    
    def _create_search_settings(self) -> SearchSettings:
        """Создание настроек поиска."""
        return SearchSettings(
            default_search_k=self.config_data.get("DEFAULT_SEARCH_K", 5),
            max_search_results=self.config_data.get("MAX_SEARCH_RESULTS", 50),
            search_timeout_seconds=self.config_data.get("SEARCH_TIMEOUT", 30.0),
            
            search_cache_enabled=self.config_data.get("SEARCH_CACHE_ENABLED", True),
            search_cache_size=self.config_data.get("SEARCH_CACHE_SIZE", 1000),
            search_cache_ttl_seconds=self.config_data.get("SEARCH_CACHE_TTL", 3600),
            
            vector_index_enabled=self.config_data.get("VECTOR_INDEX_ENABLED", True),
            vector_index_refresh_interval=self.config_data.get("VECTOR_INDEX_REFRESH", 300),
            vector_index_auto_rebuild=self.config_data.get("VECTOR_INDEX_AUTO_REBUILD", True),
            
            similarity_threshold=self.config_data.get("SIMILARITY_THRESHOLD", 0.7),
            similarity_algorithm=self.config_data.get("SIMILARITY_ALGORITHM", "cosine"),
            
            search_parallel_threads=self.config_data.get("SEARCH_PARALLEL_THREADS", 4),
            search_batch_processing=self.config_data.get("SEARCH_BATCH_PROCESSING", True),
        )
    
    def _create_api_settings(self) -> APISettings:
        """Создание настроек API."""
        return APISettings(
            host=self.config_data.get("HOST", "0.0.0.0"),
            port=self.config_data.get("PORT", 8000),
            reload=self.config_data.get("AUTO_RELOAD", False),
            workers=self.config_data.get("WORKERS", 1),
            
            api_version_prefix=self.config_data.get("API_VERSION_PREFIX", "/v1"),
            api_version_header=self.config_data.get("API_VERSION_HEADER", "X-API-Version"),
            
            middleware_enabled=self.config_data.get("MIDDLEWARE_ENABLED", True),
            cors_middleware_enabled=self.config_data.get("CORS_MIDDLEWARE_ENABLED", True),
            auth_middleware_enabled=self.config_data.get("AUTH_MIDDLEWARE_ENABLED", True),
            logging_middleware_enabled=self.config_data.get("LOGGING_MIDDLEWARE_ENABLED", True),
            
            request_size_limit_mb=self.config_data.get("REQUEST_SIZE_LIMIT_MB", 100),
            request_timeout_seconds=self.config_data.get("REQUEST_TIMEOUT", 300),
            
            docs_enabled=self.config_data.get("DOCS_ENABLED", True),
            docs_url=self.config_data.get("DOCS_URL", "/docs"),
            redoc_url=self.config_data.get("REDOC_URL", "/redoc"),
        )
    
    def _create_performance_settings(self) -> PerformanceSettings:
        """Создание настроек производительности."""
        return PerformanceSettings(
            async_pool_size=self.config_data.get("ASYNC_POOL_SIZE", 4),
            async_queue_size=self.config_data.get("ASYNC_QUEUE_SIZE", 1000),
            async_timeout_seconds=self.config_data.get("ASYNC_TIMEOUT", 30.0),
            
            io_thread_pool_size=self.config_data.get("IO_THREAD_POOL_SIZE", 10),
            cpu_thread_pool_size=self.config_data.get("CPU_THREAD_POOL_SIZE", 4),
            
            connection_pool_size=self.config_data.get("CONNECTION_POOL_SIZE", 10),
            connection_pool_max_overflow=self.config_data.get("CONNECTION_POOL_MAX_OVERFLOW", 20),
            connection_pool_timeout=self.config_data.get("CONNECTION_POOL_TIMEOUT", 30),
            
            memory_pool_enabled=self.config_data.get("MEMORY_POOL_ENABLED", True),
            garbage_collection_optimization=self.config_data.get("GC_OPTIMIZATION", True),
            
            lru_cache_enabled=self.config_data.get("LRU_CACHE_ENABLED", True),
            lru_cache_size=self.config_data.get("LRU_CACHE_SIZE", 1000),
            redis_cache_enabled=self.config_data.get("REDIS_CACHE_ENABLED", False),
        )
    
    def _create_logging_settings(self) -> LoggingSettings:
        """Создание настроек логирования."""
        return LoggingSettings(
            log_level=self.config_data.get("LOG_LEVEL", "INFO"),
            log_format=self.config_data.get("LOG_FORMAT", "json"),
            log_date_format=self.config_data.get("LOG_DATE_FORMAT", "%Y-%m-%d %H:%M:%S"),
            
            console_logging=self.config_data.get("CONSOLE_LOGGING", True),
            file_logging=self.config_data.get("FILE_LOGGING", False),
            syslog_logging=self.config_data.get("SYSLOG_LOGGING", False),
            
            log_file_path=self.config_data.get("LOG_FILE_PATH", "logs/app.log"),
            log_file_max_size_mb=self.config_data.get("LOG_FILE_MAX_SIZE_MB", 100),
            log_file_backup_count=self.config_data.get("LOG_FILE_BACKUP_COUNT", 5),
            
            async_logging=self.config_data.get("ASYNC_LOGGING", True),
            log_buffer_size=self.config_data.get("LOG_BUFFER_SIZE", 1000),
            log_flush_interval_seconds=self.config_data.get("LOG_FLUSH_INTERVAL", 1.0),
            
            structured_logging=self.config_data.get("STRUCTURED_LOGGING", True),
            include_trace_id=self.config_data.get("INCLUDE_TRACE_ID", True),
            include_user_id=self.config_data.get("INCLUDE_USER_ID", False),
        )
    
    def _create_monitoring_settings(self) -> MonitoringSettings:
        """Создание настроек мониторинга."""
        return MonitoringSettings(
            metrics_enabled=self.config_data.get("METRICS_ENABLED", True),
            metrics_port=self.config_data.get("METRICS_PORT", 9090),
            metrics_path=self.config_data.get("METRICS_PATH", "/metrics"),
            
            health_check_enabled=self.config_data.get("HEALTH_CHECK_ENABLED", True),
            health_check_interval_seconds=self.config_data.get("HEALTH_CHECK_INTERVAL", 60),
            health_check_timeout_seconds=self.config_data.get("HEALTH_CHECK_TIMEOUT", 5.0),
            
            otel_enabled=self.config_data.get("OTEL_ENABLED", True),
            otel_service_name=self.config_data.get("OTEL_SERVICE_NAME", "iskra-api"),
            otel_service_version=self.config_data.get("OTEL_SERVICE_VERSION", "1.0.0"),
            
            alerts_enabled=self.config_data.get("ALERTS_ENABLED", False),
            alert_webhook_url=self.config_data.get("ALERT_WEBHOOK_URL", ""),
            alert_threshold_cpu_percent=self.config_data.get("ALERT_CPU_THRESHOLD", 80.0),
            alert_threshold_memory_percent=self.config_data.get("ALERT_MEMORY_THRESHOLD", 85.0),
        )
    
    def _create_database_settings(self) -> DatabaseSettings:
        """Создание настроек базы данных."""
        return DatabaseSettings(
            database_url=self.config_data.get("DATABASE_URL"),
            database_pool_size=self.config_data.get("DATABASE_POOL_SIZE", 5),
            database_max_overflow=self.config_data.get("DATABASE_MAX_OVERFLOW", 10),
            database_timeout=self.config_data.get("DATABASE_TIMEOUT", 30),
            
            database_echo=self.config_data.get("DATABASE_ECHO", False),
            database_pool_recycle=self.config_data.get("DATABASE_POOL_RECYCLE", 3600),
            
            migration_enabled=self.config_data.get("MIGRATION_ENABLED", True),
            migration_path=self.config_data.get("MIGRATION_PATH", "migrations"),
        )
    
    def _validate_configuration(self) -> None:
        """Валидация всей конфигурации."""
        try:
            self.validator.validate_all_settings(self)
            logging.info("Валидация конфигурации прошла успешно")
        except Exception as e:
            logging.error(f"Ошибка валидации конфигурации: {e}")
            raise
    
    def _finalize_configuration(self) -> None:
        """Финализация конфигурации после загрузки."""
        # Создание необходимых директорий
        self._create_directories()
        
        # Настройка логирования
        self._setup_logging()
        
        # Применение настроек совместимости
        if self.compatibility:
            self.compatibility.apply_compatibility_settings(self)
        
        logging.info(f"Конфигурация инициализирована для профиля: {self.profile.value}")
    
    def _create_directories(self) -> None:
        """Создание необходимых директорий."""
        directories = [
            self.memory.memory_root,
            os.path.dirname(self.memory.evidence_path),
            os.path.dirname(self.logging.log_file_path),
            "logs",
            "temp",
        ]
        
        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True)
    
    def _setup_logging(self) -> None:
        """Настройка системы логирования."""
        import logging.config
        
        if self.logging.file_logging:
            # Создание директории для логов
            log_dir = Path(self.logging.log_file_path).parent
            log_dir.mkdir(parents=True, exist_ok=True)
        
        # Базовая настройка логирования
        logging.basicConfig(
            level=getattr(logging, self.logging.log_level),
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
    
    def reload(self) -> None:
        """Перезагрузка конфигурации."""
        logging.info("Перезагрузка конфигурации")
        self.__init__(profile=self.profile)
    
    def export_to_env_file(self, filepath: str = ".env") -> None:
        """Экспорт конфигурации в .env файл."""
        if not self.environment_manager:
            raise RuntimeError("EnvironmentManager не инициализирован")
        
        env_vars = self.environment_manager.config_to_env_vars(self)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(f"# Сгенерировано автоматически {self.__class__.__name__}\n")
            f.write(f"# Профиль: {self.profile.value}\n\n")
            
            for key, value in env_vars.items():
                if isinstance(value, str):
                    f.write(f'{key}="{value}"\n')
                else:
                    f.write(f'{key}={value}\n')
        
        logging.info(f"Конфигурация экспортирована в {filepath}")
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Получение сводки конфигурации."""
        return {
            "profile": self.profile.value,
            "version": "1.0.0",
            "security": {
                "jwt_algorithm": self.security.jwt_algorithm,
                "cors_origins_count": len(self.security.cors_origins),
                "rate_limiting": self.security.rate_limit_enabled,
            },
            "api": {
                "host": self.api.host,
                "port": self.api.port,
                "docs_enabled": self.api.docs_enabled,
            },
            "memory": {
                "root": self.memory.memory_root,
                "batch_size": self.memory.memory_batch_size,
                "compression": self.memory.memory_compression_enabled,
            },
            "logging": {
                "level": self.logging.log_level,
                "format": self.logging.log_format,
                "file_logging": self.logging.file_logging,
            },
            "monitoring": {
                "metrics_enabled": self.monitoring.metrics_enabled,
                "health_checks": self.monitoring.health_check_enabled,
                "otel_enabled": self.monitoring.otel_enabled,
            }
        }
    
    def is_production_mode(self) -> bool:
        """Проверка режима продакшена."""
        return self.profile == EnvironmentProfile.PRODUCTION
    
    def is_development_mode(self) -> bool:
        """Проверка режима разработки."""
        return self.profile == EnvironmentProfile.DEVELOPMENT
    
    def is_testing_mode(self) -> bool:
        """Проверка режима тестирования."""
        return self.profile == EnvironmentProfile.TESTING


# Глобальный экземпляр конфигурации
_config_instance: Optional[UnifiedConfig] = None


def get_config() -> UnifiedConfig:
    """Получение глобального экземпляра конфигурации."""
    global _config_instance
    if _config_instance is None:
        _config_instance = UnifiedConfig()
    return _config_instance


def init_config(config_path: Optional[str] = None, profile: Optional[EnvironmentProfile] = None) -> UnifiedConfig:
    """Инициализация конфигурации."""
    global _config_instance
    _config_instance = UnifiedConfig(config_path=config_path, profile=profile)
    return _config_instance


def reload_config() -> UnifiedConfig:
    """Перезагрузка конфигурации."""
    global _config_instance
    if _config_instance:
        _config_instance.reload()
    return _config_instance