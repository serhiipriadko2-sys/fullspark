"""Модуль улучшенной памяти Version 2.

Обеспечивает высокопроизводительную асинхронную систему памяти с:
- Асинхронными I/O операциями
- Batch обработкой для снижения накладных расходов
- Connection pooling для файловых операций
- Автоматическим фоновым сбросом
- Управлением памятью и очисткой
- Поддержкой сжатого хранения
"""

import asyncio
import json
import os
import time
import threading
from collections import deque
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Any, Callable, Union
from concurrent.futures import ThreadPoolExecutor
import gzip
import pickle
from datetime import datetime, timedelta


@dataclass
class MemoryEvent:
    """Событие памяти с расширенной функциональностью."""
    t: float
    kind: str
    key: str
    value: dict
    meta: Optional[dict] = None
    
    def to_dict(self) -> dict:
        """Конвертация в словарь для сериализации."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MemoryEvent':
        """Создание из словаря."""
        return cls(**data)


class AsyncEventBuffer:
    """Асинхронный буфер событий с batch обработкой и сжатием."""
    
    def __init__(self, max_size: int = 1000, batch_size: int = 50, 
                 flush_interval: float = 5.0, compress: bool = False):
        self.max_size = max_size
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.compress = compress
        
        self._buffer: deque = deque()
        self._lock = asyncio.Lock()
        self._flush_event = asyncio.Event()
        self._background_task: Optional[asyncio.Task] = None
        self._last_flush = time.time()
        
        # Статистика
        self.events_written = 0
        self.batches_flushed = 0
        self.total_bytes_written = 0
        self.compression_ratio = 0.0
    
    async def add_event(self, event: MemoryEvent):
        """Добавление события в буфер."""
        async with self._lock:
            self._buffer.append(event)
            
            # Автосброс если буфер полон
            if len(self._buffer) >= self.batch_size:
                asyncio.create_task(self.flush())
            elif self._background_task is None:
                self._start_background_flush()
    
    def _start_background_flush(self):
        """Запуск фоновой задачи сброса."""
        if self._background_task is None or self._background_task.done():
            self._background_task = asyncio.create_task(self._background_flush_loop())
    
    async def _background_flush_loop(self):
        """Фоновая задача периодического сброса."""
        while True:
            try:
                await asyncio.sleep(self.flush_interval)
                
                async with self._lock:
                    should_flush = (len(self._buffer) > 0 and 
                                  time.time() - self._last_flush >= self.flush_interval)
                
                if should_flush:
                    await self.flush()
                
                # Выход если буфер пуст и события не добавляются
                async with self._lock:
                    if len(self._buffer) == 0:
                        self._background_task = None
                        break
                        
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Ошибка фонового сброса: {e}")
                await asyncio.sleep(1)
    
    async def flush(self, file_path: str = None):
        """Сброс буфера в файл."""
        async with self._lock:
            if not self._buffer:
                return
            
            events_to_flush = list(self._buffer)
            self._buffer.clear()
            self._last_flush = time.time()
        
        if not events_to_flush:
            return
        
        if file_path is None:
            return  # Вызывающий должен предоставить путь к файлу
        
        # Запись событий в файл
        try:
            await self._write_events_to_file(events_to_flush, file_path)
            self.batches_flushed += 1
            self.events_written += len(events_to_flush)
        except Exception as e:
            print(f"Ошибка записи событий в {file_path}: {e}")
            # Повторное добавление событий в буфер при ошибке
            async with self._lock:
                self._buffer.extendleft(reversed(events_to_flush))
            raise
    
    async def _write_events_to_file(self, events: List[MemoryEvent], file_path: str):
        """Запись событий в файл с опциональным сжатием."""
        # Создание директории если нужно
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        if self.compress:
            file_path = f"{file_path}.gz"
        
        # Сериализация событий
        lines = []
        original_size = 0
        
        for event in events:
            line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
            lines.append(line)
            original_size += len(line.encode('utf-8'))
        
        data = '\n'.join(lines) + '\n'
        
        if self.compress:
            async with aiofiles.open(file_path, 'ab') as f:
                compressed_data = gzip.compress(data.encode('utf-8'))
                compressed_size = len(compressed_data)
                await f.write(compressed_data)
                
                # Обновление статистики сжатия
                if original_size > 0:
                    self.compression_ratio = 1.0 - (compressed_size / original_size)
        else:
            async with aiofiles.open(file_path, 'a', encoding='utf-8') as f:
                await f.write(data)
        
        self.total_bytes_written += len(data.encode('utf-8'))
    
    async def force_flush(self):
        """Принудительный сброс всех ожидающих событий."""
        async with self._lock:
            if not self._buffer:
                return
            
            events_to_flush = list(self._buffer)
            self._buffer.clear()
        
        # Этот метод должен вызываться MemoryManager с правильными путями к файлам
    
    def get_stats(self) -> Dict:
        """Получение статистики буфера."""
        buffer_size = len(self._buffer)
        
        return {
            "buffer_size": buffer_size,
            "events_written": self.events_written,
            "batches_flushed": self.batches_flushed,
            "total_bytes_written": self.total_bytes_written,
            "compression_enabled": self.compress,
            "compression_ratio": self.compression_ratio,
            "max_buffer_size": self.max_size,
            "batch_size": self.batch_size,
            "flush_interval": self.flush_interval
        }


class FileConnectionPool:
    """Пул соединений для файловых операций."""
    
    def __init__(self, pool_size: int = 10):
        self.pool_size = pool_size
        self._available: asyncio.Queue = asyncio.Queue(maxsize=pool_size)
        self._in_use: Set = set()
        
        # Инициализация пула
        for _ in range(pool_size):
            self._available.put_nowait({"in_use": False})
    
    async def get_connection(self) -> Dict:
        """Получение соединения из пула."""
        conn = await self._available.get()
        conn["in_use"] = True
        self._in_use.add(id(conn))
        return conn
    
    async def return_connection(self, conn: Dict):
        """Возврат соединения в пул."""
        conn_id = id(conn)
        if conn_id in self._in_use:
            self._in_use.remove(conn_id)
            conn["in_use"] = False
            await self._available.put(conn)
    
    async def get_pool_stats(self) -> Dict:
        """Получение статистики пула."""
        return {
            "pool_size": self.pool_size,
            "available": self._available.qsize(),
            "in_use": len(self._in_use),
            "utilization": len(self._in_use) / self.pool_size
        }


class ModernMemoryManager:
    """Высокопроизводительный асинхронный менеджер памяти с батчингом и пулингом."""
    
    def __init__(self, root: str = "./memory", 
                 batch_size: int = 50,
                 flush_interval: float = 5.0,
                 max_workers: int = 4,
                 compress: bool = False,
                 max_buffer_size: int = 1000):
        self.root = Path(root)
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.max_workers = max_workers
        self.compress = compress
        self.max_buffer_size = max_buffer_size
        
        # Создание директорий
        self.root.mkdir(parents=True, exist_ok=True)
        self.archive_path = self.root / "main_archive.jsonl"
        self.shadow_path = self.root / "main_shadow.jsonl"
        
        # Асинхронные компоненты
        self._archive_buffer = AsyncEventBuffer(
            max_size=max_buffer_size,
            batch_size=batch_size,
            flush_interval=flush_interval,
            compress=compress
        )
        self._shadow_buffer = AsyncEventBuffer(
            max_size=max_buffer_size,
            batch_size=batch_size,
            flush_interval=flush_interval,
            compress=compress
        )
        self._file_pool = FileConnectionPool()
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        
        # Очистка и управление событиями
        self._cleanup_task: Optional[asyncio.Task] = None
        self._start_cleanup_task()
        
        # Статистика
        self.events_stored = 0
        self.total_storage_time = 0.0
        self.avg_storage_time = 0.0
        self._stats_lock = threading.Lock()
    
    def _start_cleanup_task(self):
        """Запуск фоновой задачи очистки."""
        if self._cleanup_task is None or self._cleanup_task.done():
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
    
    async def _cleanup_loop(self):
        """Фоновая задача очистки старых событий."""
        while True:
            try:
                await asyncio.sleep(3600)  # Запуск каждый час
                await self._cleanup_old_events()
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Ошибка очистки: {e}")
    
    async def _cleanup_old_events(self):
        """Очистка старых событий."""
        try:
            cutoff_time = time.time() - (30 * 24 * 3600)  # 30 дней назад
            
            for file_path in [self.archive_path, self.shadow_path]:
                if file_path.exists():
                    # Удаление старых событий
                    await self._remove_old_events_from_file(file_path, cutoff_time)
                    
        except Exception as e:
            print(f"Ошибка во время очистки: {e}")
    
    async def _remove_old_events_from_file(self, file_path: Path, cutoff_time: float):
        """Удаление старых событий из файла."""
        temp_file = file_path.with_suffix('.tmp')
        
        try:
            # Чтение и фильтрация событий
            events_to_keep = []
            
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                async for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        data = json.loads(line)
                        event = MemoryEvent.from_dict(data)
                        
                        if event.t >= cutoff_time:
                            events_to_keep.append(event)
                    except (json.JSONDecodeError, KeyError):
                        continue
            
            # Запись оставшихся событий во временный файл
            if events_to_keep:
                lines = []
                for event in events_to_keep:
                    line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                    lines.append(line)
                
                data = '\n'.join(lines) + '\n'
                
                async with aiofiles.open(temp_file, 'w', encoding='utf-8') as f:
                    await f.write(data)
                
                # Атомарная замена файла
                temp_file.replace(file_path)
            else:
                # Если нет событий для сохранения, удаляем файл
                file_path.unlink()
            
        except Exception as e:
            print(f"Ошибка удаления старых событий из {file_path}: {e}")
            if temp_file.exists():
                temp_file.unlink()
    
    async def put_async(self, kind: str, key: str, value: dict, 
                       meta: dict = None) -> MemoryEvent:
        """Асинхронное сохранение события с батчингом."""
        start_time = time.time()
        
        ev = MemoryEvent(
            t=time.time(),
            kind=kind,
            key=key,
            value=value,
            meta=meta
        )
        
        # Выбор подходящего буфера
        buffer = self._archive_buffer if kind == "archive" else self._shadow_buffer
        await buffer.add_event(ev)
        
        # Принудительный сброс если буфер становится большим
        async with buffer._lock:
            if len(buffer._buffer) >= buffer.max_size:
                # Принудительный сброс в фоне
                file_path = str(self.archive_path) if kind == "archive" else str(self.shadow_path)
                asyncio.create_task(buffer.flush(file_path))
        
        self._update_storage_stats(start_time)
        
        return ev
    
    def _update_storage_stats(self, start_time: float):
        """Обновление статистики хранения."""
        storage_time = time.time() - start_time
        
        with self._stats_lock:
            self.events_stored += 1
            self.total_storage_time += storage_time
            
            if self.events_stored > 0:
                self.avg_storage_time = self.total_storage_time / self.events_stored
    
    def put_sync(self, kind: str, key: str, value: dict, 
                meta: dict = None) -> MemoryEvent:
        """Синхронная обертка для обратной совместимости."""
        return asyncio.run(self.put_async(kind, key, value, meta))
    
    async def put(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Синхронный интерфейс для put (совместимость)."""
        return await self.put_async(kind, key, value, meta)
    
    async def get_async(self, kind: str, key: str = "", 
                       since: Optional[float] = None) -> List[MemoryEvent]:
        """Асинхронное получение событий с опциональным фильтром по времени."""
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        events = []
        
        if not file_path.exists():
            return events
        
        try:
            # Использование пула потоков для файлового I/O
            loop = asyncio.get_event_loop()
            events = await loop.run_in_executor(
                self._executor,
                self._read_events_from_file,
                str(file_path),
                key,
                since
            )
        except Exception as e:
            print(f"Ошибка чтения событий: {e}")
        
        return events
    
    def _read_events_from_file(self, file_path: str, key: str, 
                              since: Optional[float] = None) -> List[MemoryEvent]:
        """Чтение событий из файла (блокирующая операция)."""
        events = []
        
        try:
            # Определение открывающей функции и режима
            if file_path.endswith('.gz'):
                import gzip
                opener = gzip.open
                mode = 'rt'
            else:
                opener = open
                mode = 'r'
            
            with opener(file_path, mode, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        data = json.loads(line)
                        ev = MemoryEvent.from_dict(data)
                        
                        # Фильтрация по ключу и времени
                        if not key or ev.key == key:
                            if since is None or ev.t >= since:
                                events.append(ev)
                    except (json.JSONDecodeError, KeyError):
                        continue
                        
        except Exception as e:
            print(f"Ошибка чтения файла {file_path}: {e}")
        
        return events
    
    def get_sync(self, kind: str, key: str = "", 
                since: Optional[float] = None) -> List[MemoryEvent]:
        """Синхронная обертка для обратной совместимости."""
        return asyncio.run(self.get_async(kind, key, since))
    
    def get(self, kind: str, key: str = "", since: Optional[float] = None) -> List[MemoryEvent]:
        """Синхронный интерфейс для get (совместимость)."""
        return self.get_sync(kind, key, since)
    
    async def get_batch(self, kinds: List[str], key: str = "", 
                       since: Optional[float] = None) -> Dict[str, List[MemoryEvent]]:
        """Batch получение событий из нескольких типов."""
        tasks = []
        for kind in kinds:
            task = self.get_async(kind, key, since)
            tasks.append((kind, task))
        
        results = {}
        for kind, task in tasks:
            try:
                results[kind] = await task
            except Exception as e:
                print(f"Ошибка получения событий типа {kind}: {e}")
                results[kind] = []
        
        return results
    
    async def flush_all(self):
        """Сброс всех ожидающих событий."""
        # Сброс обоих буферов
        archive_path = str(self.archive_path)
        shadow_path = str(self.shadow_path)
        
        await asyncio.gather(
            self._archive_buffer.flush(archive_path),
            self._shadow_buffer.flush(shadow_path),
            return_exceptions=True
        )
    
    async def close(self):
        """Закрытие менеджера памяти и очистка ресурсов."""
        # Отмена задачи очистки
        if self._cleanup_task:
            self._cleanup_task.cancel()
        
        # Сброс всех ожидающих событий
        await self.flush_all()
        
        # Завершение исполнителя
        self._executor.shutdown(wait=True)
        
        print("Modern Memory Manager закрыт")
    
    def get_stats(self) -> Dict:
        """Получение статистики менеджера памяти."""
        return {
            "events_stored": self.events_stored,
            "avg_storage_time_ms": self.avg_storage_time * 1000,
            "total_storage_time_ms": self.total_storage_time * 1000,
            "archive_buffer": self._archive_buffer.get_stats(),
            "shadow_buffer": self._shadow_buffer.get_stats(),
            "file_pool": asyncio.run(self._file_pool.get_pool_stats()),
            "compress_enabled": self.compress,
            "batch_size": self.batch_size,
            "flush_interval": self.flush_interval,
            "max_workers": self.max_workers,
            "max_buffer_size": self.max_buffer_size
        }
    
    async def get_recent_events(self, kind: str, hours: int = 24, key: str = "") -> List[MemoryEvent]:
        """Получение недавних событий за последние N часов."""
        since = time.time() - (hours * 3600)
        return await self.get_async(kind, key, since)
    
    async def search_events(self, kind: str = "", key_pattern: str = "", 
                           value_pattern: str = "", since: Optional[float] = None,
                           limit: int = 100) -> List[MemoryEvent]:
        """Поиск событий по паттернам."""
        if kind:
            kinds = [kind]
        else:
            kinds = ["archive", "shadow"]
        
        all_events = []
        
        for k in kinds:
            events = await self.get_async(k)
            
            for event in events:
                # Фильтрация по времени
                if since and event.t < since:
                    continue
                
                # Фильтрация по паттерну ключа
                if key_pattern and key_pattern not in event.key:
                    continue
                
                # Фильтрация по паттерну значения
                if value_pattern:
                    value_str = json.dumps(event.value, ensure_ascii=False)
                    if value_pattern not in value_str:
                        continue
                
                all_events.append(event)
                
                if len(all_events) >= limit:
                    break
            
            if len(all_events) >= limit:
                break
        
        # Сортировка по времени (новые сначала)
        all_events.sort(key=lambda x: x.t, reverse=True)
        
        return all_events[:limit]
    
    async def delete_events(self, kind: str, key: str = "", since: Optional[float] = None) -> int:
        """Удаление событий по критериям."""
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        
        if not file_path.exists():
            return 0
        
        # Сначала сбрасываем буфер
        buffer = self._archive_buffer if kind == "archive" else self._shadow_buffer
        await buffer.flush(str(file_path))
        
        # Чтение всех событий
        all_events = self._read_events_from_file(str(file_path), "", None)
        
        # Фильтрация событий для удаления
        events_to_keep = []
        events_deleted = 0
        
        for event in all_events:
            should_delete = True
            
            # Проверка типа
            if event.kind != kind:
                should_delete = False
            
            # Проверка ключа
            if key and event.key != key:
                should_delete = False
            
            # Проверка времени
            if since and event.t < since:
                should_delete = False
            
            if should_delete:
                events_deleted += 1
            else:
                events_to_keep.append(event)
        
        # Перезапись файла с оставшимися событиями
        if events_deleted > 0:
            temp_file = file_path.with_suffix('.tmp')
            
            try:
                if events_to_keep:
                    lines = []
                    for event in events_to_keep:
                        line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                        lines.append(line)
                    
                    data = '\n'.join(lines) + '\n'
                    
                    async with aiofiles.open(temp_file, 'w', encoding='utf-8') as f:
                        await f.write(data)
                else:
                    # Если нет событий для сохранения, удаляем файл
                    file_path.unlink()
                    return events_deleted
                
                # Атомарная замена файла
                temp_file.replace(file_path)
                
            except Exception as e:
                print(f"Ошибка перезаписи файла {file_path}: {e}")
                return 0
        
        return events_deleted
    
    async def optimize_storage(self):
        """Оптимизация хранилища (удаление дубликатов и сжатие)."""
        # Сброс всех буферов
        await self.flush_all()
        
        # Оптимизация каждого файла
        for kind in ["archive", "shadow"]:
            await self._optimize_file(kind)
    
    async def _optimize_file(self, kind: str):
        """Оптимизация отдельного файла."""
        file_path = self.archive_path if kind == "archive" else self.shadow_path
        
        if not file_path.exists():
            return
        
        # Чтение всех событий
        all_events = self._read_events_from_file(str(file_path), "", None)
        
        # Удаление дубликатов (по ключу и времени)
        unique_events = {}
        for event in all_events:
            unique_key = f"{event.key}:{event.t}"
            if unique_key not in unique_events:
                unique_events[unique_key] = event
        
        # Перезапись файла с уникальными событиями
        temp_file = file_path.with_suffix('.tmp')
        
        try:
            lines = []
            for event in unique_events.values():
                line = json.dumps(event.to_dict(), ensure_ascii=False, separators=(',', ':'))
                lines.append(line)
            
            data = '\n'.join(lines) + '\n'
            
            async with aiofiles.open(temp_file, 'w', encoding='utf-8') as f:
                await f.write(data)
            
            # Атомарная замена файла
            temp_file.replace(file_path)
            
        except Exception as e:
            print(f"Ошибка оптимизации файла {file_path}: {e}")
            if temp_file.exists():
                temp_file.unlink()
    
    async def export_events(self, output_file: str, kind: str = "", since: Optional[float] = None):
        """Экспорт событий в JSON файл."""
        events = []
        
        # Определение типов для экспорта
        kinds_to_export = [kind] if kind else ["archive", "shadow"]
        
        for k in kinds_to_export:
            kind_events = await self.get_async(k, since=since)
            events.extend(kind_events)
        
        # Сортировка по времени
        events.sort(key=lambda x: x.t)
        
        # Экспорт в JSON
        try:
            export_data = {
                "export_time": time.time(),
                "total_events": len(events),
                "events": [event.to_dict() for event in events]
            }
            
            async with aiofiles.open(output_file, 'w', encoding='utf-8') as f:
                await f.write(json.dumps(export_data, ensure_ascii=False, indent=2))
                
        except Exception as e:
            print(f"Ошибка экспорта в {output_file}: {e}")
            raise
    
    async def import_events(self, input_file: str):
        """Импорт событий из JSON файла."""
        try:
            async with aiofiles.open(input_file, 'r', encoding='utf-8') as f:
                import_data = json.loads(await f.read())
            
            events_data = import_data.get("events", [])
            imported_count = 0
            
            for event_data in events_data:
                try:
                    event = MemoryEvent(**event_data)
                    await self.put_async(event.kind, event.key, event.value, event.meta)
                    imported_count += 1
                except Exception as e:
                    print(f"Ошибка импорта события: {e}")
                    continue
            
            print(f"Импортировано {imported_count} событий из {input_file}")
            
        except Exception as e:
            print(f"Ошибка импорта из {input_file}: {e}")
            raise


# Функции для создания менеджеров
def create_modern_memory_manager(root: str = "./memory", **kwargs) -> ModernMemoryManager:
    """Создание Modern Memory Manager."""
    return ModernMemoryManager(root=root, **kwargs)


# Глобальный экземпляр для оптимизации
_global_modern_memory = None

def get_modern_memory_manager(root: str = "./memory", **kwargs) -> ModernMemoryManager:
    """Получение глобального экземпляра Modern Memory Manager."""
    global _global_modern_memory
    if _global_modern_memory is None:
        _global_modern_memory = ModernMemoryManager(root, **kwargs)
    return _global_modern_memory


# Обратная совместимость
class MemoryManager(ModernMemoryManager):
    """Менеджер памяти с обратной совместимостью."""
    
    def __init__(self, root: str = "./memory"):
        # Инициализация с оптимизированными настройками, но синхронным интерфейсом
        super().__init__(
            root=root,
            batch_size=20,  # Меньшие батчи для синхронного интерфейса
            flush_interval=2.0,
            compress=False
        )
    
    def put(self, kind: str, key: str, value: dict, meta: dict = None):
        """Синхронная запись (обратная совместимость)."""
        return self.put_sync(kind, key, value, meta)


def create_memory_manager_v2(root: str = "./memory") -> MemoryManager:
    """Создание Memory Manager версии 2 (для обратной совместимости)."""
    return MemoryManager(root=root)