"""
Примеры использования интегрированной DI системы

Демонстрация различных сценариев использования:
- Backward compatibility с Version 1
- Гибридный режим
- Постепенная миграция к Version 2
"""

import sys
import os
from pathlib import Path

# Добавляем путь к проекту
sys.path.append(str(Path(__file__).parent.parent))

from core.di import (
    container, registry, wiring, 
    DIContainer, ServiceLifetime, VersionCompatibility,
    DependencyConfig, WireMode
)

# Примеры mock классов для демонстрации
class MemoryManager:
    """Legacy Version 1 Memory Manager"""
    _is_legacy = True
    
    def __init__(self):
        self.data = {}
        print("🔧 Initialized Legacy MemoryManager (Version 1)")
    
    def put(self, key, value):
        self.data[key] = value
        return f"Legacy put: {key}"
    
    def get(self, key):
        return self.data.get(key, "legacy_default")

class OptimizedMemoryManager:
    """Modern Version 2 Memory Manager"""
    _is_modern = True
    
    def __init__(self, batch_size=50, cache_size=1000):
        self.data = {}
        self.batch_size = batch_size
        self.cache_size = cache_size
        print(f"🚀 Initialized OptimizedMemoryManager (Version 2)")
        print(f"   Batch size: {batch_size}, Cache size: {cache_size}")
    
    def put(self, key, value):
        self.data[key] = value
        return f"Modern put: {key}"
    
    def get(self, key):
        return self.data.get(key, "modern_default")

class VectorSearch:
    """Legacy Version 1 Vector Search"""
    _is_legacy = True
    
    def __init__(self):
        self.vectors = []
        print("🔍 Initialized Legacy VectorSearch (Version 1)")
    
    def search(self, query):
        return [f"legacy_result_{i}" for i in range(3)]
    
    def add_vector(self, vector):
        self.vectors.append(vector)

class OptimizedVectorSearch:
    """Modern Version 2 Vector Search"""
    _is_modern = True
    
    def __init__(self, cache_enabled=True, async_enabled=True):
        self.vectors = []
        self.cache_enabled = cache_enabled
        self.async_enabled = async_enabled
        self.cache = {}
        print(f"⚡ Initialized OptimizedVectorSearch (Version 2)")
        print(f"   Cache: {cache_enabled}, Async: {async_enabled}")
    
    def search(self, query):
        # Modern search with caching
        if self.cache_enabled and query in self.cache:
            return self.cache[query]
        results = [f"optimized_result_{i}" for i in range(5)]
        if self.cache_enabled:
            self.cache[query] = results
        return results
    
    def add_vector(self, vector):
        self.vectors.append(vector)

# Демонстрация различных сценариев
def demo_backward_compatibility():
    """Демонстрация backward compatibility с Version 1"""
    print("\n" + "="*60)
    print("🔄 ДЕМОНСТРАЦИЯ: Backward Compatibility (Version 1)")
    print("="*60)
    
    # Сброс контейнера
    container.reset()
    wiring.reset_wiring()
    
    # Регистрация legacy сервисов
    container.register_singleton("MemoryManager", MemoryManager)
    container.register_singleton("VectorSearch", VectorSearch)
    
    # Получение legacy сервисов
    memory = container.resolve("MemoryManager")
    search = container.resolve("VectorSearch")
    
    print(f"\n📊 Результат:")
    print(f"Memory: {memory.put('test', 'legacy_value')}")
    print(f"Search: {search.search('test_query')}")
    print(f"Memory get: {memory.get('test')}")
    
    # Метрики
    metrics = container.get_metrics()
    print(f"\n📈 Метрики: {metrics['resolutions']} разрешений")

def demo_hybrid_mode():
    """Демонстрация гибридного режима"""
    print("\n" + "="*60)
    print("🔀 ДЕМОНСТРАЦИЯ: Hybrid Mode (Version 1 + Version 2)")
    print("="*60)
    
    # Сброс контейнера
    container.reset()
    wiring.reset_wiring()
    
    # Настройка для гибридного режима
    config = DependencyConfig()
    config.config.version_compatibility = VersionCompatibility.HYBRID
    
    # Регистрация как legacy, так и modern сервисов
    container.register_singleton("LegacyMemoryManager", MemoryManager)
    container.register_singleton("ModernMemoryManager", OptimizedMemoryManager, 
                               config={'batch_size': 100, 'cache_size': 2000})
    container.register_singleton("LegacyVectorSearch", VectorSearch)
    container.register_singleton("ModernVectorSearch", OptimizedVectorSearch,
                               config={'cache_enabled': True, 'async_enabled': False})
    
    # Автоматическое подключение
    results = wiring.auto_wire_all(WireMode.HYBRID)
    
    print(f"\n📊 Результаты подключения:")
    for name, result in results.items():
        status_icon = "✅" if result.is_success() else "❌"
        print(f"{status_icon} {name}: {result.status.value}")
        if result.warnings:
            print(f"   ⚠️  Warnings: {result.warnings}")
    
    # Тестирование сервисов
    legacy_memory = container.resolve("LegacyMemoryManager")
    modern_memory = container.resolve("ModernMemoryManager")
    
    print(f"\n🧪 Тестирование:")
    print(f"Legacy memory: {legacy_memory.put('hybrid_test', 'legacy_value')}")
    print(f"Modern memory: {modern_memory.put('hybrid_test', 'modern_value')}")
    
    # Метрики
    wiring_stats = wiring.get_wiring_status()
    print(f"\n📈 Статистика подключения:")
    print(f"Успешно подключено: {wiring_stats['successfully_wired']}/{wiring_stats['total_components']}")
    print(f"Legacy компоненты: {wiring_stats['legacy_components']}")
    print(f"Modern компоненты: {wiring_stats['modern_components']}")

def demo_gradual_migration():
    """Демонстрация постепенной миграции"""
    print("\n" + "="*60)
    print("🚀 ДЕМОНСТРАЦИЯ: Gradual Migration (Version 1 → Version 2)")
    print("="*60)
    
    # Этап 1: Обертывание legacy в DI-совместимый интерфейс
    print("\n📝 Этап 1: Обертывание legacy компонентов")
    container.reset()
    
    class DILegacyMemoryManager:
        def __init__(self):
            self._legacy = MemoryManager()
        
        def put(self, key, value):
            return self._legacy.put(key, value)
        
        def get(self, key):
            return self._legacy.get(key)
    
    container.register_singleton("MemoryService", DILegacyMemoryManager)
    
    memory_service = container.resolve("MemoryService")
    print(f"Обернутый legacy: {memory_service.put('migration_step1', 'wrapped_legacy')}")
    
    # Этап 2: Добавление modern компонента рядом
    print("\n📝 Этап 2: Добавление modern компонента")
    container.register_singleton("ModernMemoryService", OptimizedMemoryManager,
                               config={'batch_size': 75, 'cache_size': 1500})
    
    # Создание унифицированного интерфейса
    class UnifiedMemoryManager:
        def __init__(self, legacy_service, modern_service, use_modern=False):
            self.legacy = legacy_service
            self.modern = modern_service
            self.use_modern = use_modern
        
        def put(self, key, value):
            if self.use_modern:
                return self.modern.put(key, value)
            else:
                return self.legacy.put(key, value)
        
        def get(self, key):
            if self.use_modern:
                return self.modern.get(key)
            else:
                return self.legacy.get(key)
    
    # Регистрация унифицированного сервиса
    container.register_singleton("UnifiedMemoryService", UnifiedMemoryManager,
                               dependencies=["MemoryService", "ModernMemoryService"],
                               config={'use_modern': False})  # Начнем с legacy
    
    unified_service = container.resolve("UnifiedMemoryService")
    print(f"Unified (legacy mode): {unified_service.put('unified_test', 'step2_value')}")
    
    # Этап 3: Переключение на modern
    print("\n📝 Этап 3: Переключение на modern")
    container._services["UnifiedMemoryService"].config['use_modern'] = True
    
    unified_service_modern = container.resolve("UnifiedMemoryService")
    print(f"Unified (modern mode): {unified_service_modern.put('unified_test', 'step3_value')}")
    print(f"Legacy get: {unified_service.get('unified_test')}")  # Данные остались в legacy
    print(f"Modern get: {unified_service_modern.get('unified_test')}")  # Modern storage

def demo_configuration():
    """Демонстрация системы конфигурации"""
    print("\n" + "="*60)
    print("⚙️  ДЕМОНСТРАЦИЯ: Configuration System")
    print("="*60)
    
    # Создание конфигурации
    config = DependencyConfig()
    
    print(f"\n📋 Текущая конфигурация:")
    summary = config.get_config_summary()
    for key, value in summary.items():
        print(f"  {key}: {value}")
    
    # Демонстрация различных режимов
    modes = [
        VersionCompatibility.V1_ONLY,
        VersionCompatibility.HYBRID,
        VersionCompatibility.V2_ONLY
    ]
    
    for mode in modes:
        print(f"\n🔧 Режим: {mode.value}")
        config.config.version_compatibility = mode
        
        # Настройки для разных категорий
        memory_config = config.get_memory_config()
        search_config = config.get_search_config()
        security_config = config.get_security_config()
        
        print(f"  Memory hybrid: {memory_config.hybrid_mode}")
        print(f"  Search cache: {search_config.modern_cache_enabled}")
        print(f"  JWT configured: {security_config.jwt_secret != 'dev-secret'}")

def demo_monitoring():
    """Демонстрация мониторинга и метрик"""
    print("\n" + "="*60)
    print("📊 ДЕМОНСТРАЦИЯ: Monitoring and Metrics")
    print("="*60)
    
    # Создание нагрузки на контейнер
    container.reset()
    
    # Регистрация сервисов
    container.register_singleton("MemoryA", MemoryManager)
    container.register_singleton("MemoryB", OptimizedMemoryManager)
    container.register_transient("SearchA", VectorSearch)
    container.register_scoped("AuthService", type("AuthService", (), {}))
    
    # Генерация обращений
    for i in range(10):
        memory_a = container.resolve("MemoryA")
        memory_b = container.resolve("MemoryB")
        search_a = container.resolve("SearchA")
    
    # Получение метрик
    print(f"\n📈 Метрики контейнера:")
    metrics = container.get_metrics()
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    
    # Статистика регистраций
    print(f"\n📋 Зарегистрированные сервисы:")
    registrations = container.get_all_registrations()
    for reg in registrations:
        print(f"  {reg['service_type']}: {reg['lifetime']} ({reg['access_count']} доступов)")
    
    # Реестр сервисов
    print(f"\n🏢 Статистика реестра:")
    registry_stats = registry.get_registry_stats()
    for key, value in registry_stats.items():
        print(f"  {key}: {value}")

def demo_error_handling():
    """Демонстрация обработки ошибок"""
    print("\n" + "="*60)
    print("🛡️  ДЕМОНСТРАЦИЯ: Error Handling")
    print("="*60)
    
    container.reset()
    
    # 1. Попытка разрешения незарегистрированного сервиса
    print("\n❌ Тест 1: Незарегистрированный сервис")
    try:
        unknown_service = container.resolve("UnknownService")
        print(f"Получен: {unknown_service}")
    except Exception as e:
        print(f"Ошибка: {e}")
    
    # 2. Циклическая зависимость
    print("\n🔄 Тест 2: Циклическая зависимость")
    
    class ServiceA:
        def __init__(self, service_b): pass
    
    class ServiceB:
        def __init__(self, service_a): pass
    
    try:
        container.register_singleton("ServiceA", ServiceA, dependencies=["ServiceB"])
        container.register_singleton("ServiceB", ServiceB, dependencies=["ServiceA"])
        
        service_a = container.resolve("ServiceA")
    except Exception as e:
        print(f"Циклическая зависимость обнаружена: {e}")
    
    # 3. Graceful degradation
    print("\n🛡️  Тест 3: Graceful degradation")
    
    # Регистрация только части сервисов
    container.register_singleton("WorkingService", MemoryManager)
    # ServiceB не зарегистрирован
    
    try:
        # Попытка получить сервис с отсутствующими зависимостями
        working = container.resolve("ServiceA")
        print(f"Получен рабочий сервис: {working}")
    except Exception as e:
        print(f"Ошибка graceful degradation: {e}")
    
    # 4. Fallback wiring
    print("\n🔄 Тест 4: Fallback wiring")
    
    wiring.reset_wiring()
    
    # Попытка автообнаружения с отсутствующими модулями
    try:
        results = wiring.auto_wire_all(WireMode.AUTO)
        print(f"Автоподключение завершено: {len(results)} результатов")
        
        for name, result in results.items():
            if result.is_success():
                print(f"✅ {name}: {result.status.value}")
            else:
                print(f"❌ {name}: {result.error}")
                
    except Exception as e:
        print(f"Ошибка автоподключения: {e}")

def main():
    """Главная функция демонстрации"""
    print("🚀 ДЕМОНСТРАЦИЯ ИНТЕГРИРОВАННОЙ DI СИСТЕМЫ")
    print("Проект 'Искра' - Объединение Version 1 + Version 2")
    
    try:
        # Запуск всех демонстраций
        demo_backward_compatibility()
        demo_hybrid_mode()
        demo_gradual_migration()
        demo_configuration()
        demo_monitoring()
        demo_error_handling()
        
        print("\n" + "="*60)
        print("✅ ВСЕ ДЕМОНСТРАЦИИ ЗАВЕРШЕНЫ УСПЕШНО")
        print("="*60)
        print("\n💡 Система готова к интеграции!")
        print("📚 Подробная документация: merged_project/core/di/README.md")
        
    except Exception as e:
        print(f"\n❌ ОШИБКА В ДЕМОНСТРАЦИИ: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()