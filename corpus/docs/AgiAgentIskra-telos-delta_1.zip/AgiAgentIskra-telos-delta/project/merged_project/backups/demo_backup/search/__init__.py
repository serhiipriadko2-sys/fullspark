"""Интегрированная поисковая система Iskra.

Объединяет возможности Version 1 (GraphRAG) и Version 2 (оптимизированный поиск)
в единую высокопроизводительную систему поиска.

Основные возможности:
- Legacy Mode: поиск с GraphRAG из Version 1 (O(n))
- Modern Mode: оптимизированный поиск из Version 2 (O(log n))
- Hybrid Mode: автоматический выбор алгоритма
- GraphRAG Mode: расширенный анализ с графом знаний
- Асинхронные и синхронные операции
- Конфигурируемая производительность
- Кэширование и мониторинг метрик
"""

from .integrated_search import (
    IntegratedSearch,
    SearchResult,
    SearchMetrics,
    integrated_search,
    create_integrated_search
)

from .legacy_adapter import (
    LegacyVectorSearch,
    LegacySearchConfig,
    EvidenceChunk as LegacyEvidenceChunk
)

from .modern_adapter import (
    ModernVectorSearch,
    ModernSearchConfig,
    EvidenceChunk as ModernEvidenceChunk
)

from .performance_config import (
    PerformanceConfig,
    SearchMode,
    PerformanceProfile,
    LegacySearchParams,
    ModernSearchParams,
    create_fast_config,
    create_balanced_config,
    create_quality_config,
    create_graphrag_config,
    load_config
)

__version__ = "1.0.0"
__author__ = "Iskra Search Integration Team"

# Экспорт основных классов и функций
__all__ = [
    # Основные классы
    'IntegratedSearch',
    'LegacyVectorSearch', 
    'ModernVectorSearch',
    'PerformanceConfig',
    
    # Результаты поиска
    'SearchResult',
    'SearchMetrics',
    
    # Конфигурация
    'SearchMode',
    'PerformanceProfile',
    'LegacySearchConfig',
    'LegacySearchParams',
    'ModernSearchConfig', 
    'ModernSearchParams',
    
    # Утилиты
    'create_fast_config',
    'create_balanced_config',
    'create_quality_config', 
    'create_graphrag_config',
    'load_config',
    'integrated_search',
    'create_integrated_search'
]

# Версии совместимости
VERSION_INFO = {
    'major': 1,
    'minor': 0,
    'patch': 0,
    'release_type': 'stable'
}

def get_version_info():
    """Получение информации о версии."""
    return VERSION_INFO.copy()

def check_compatibility():
    """Проверка совместимости с исходными системами."""
    compatibility_report = {
        'version1_support': False,
        'version2_support': False,
        'legacy_adapter_available': False,
        'modern_adapter_available': False,
        'issues': []
    }
    
    try:
        # Проверка Version 1
        import sys
        import os
        v1_path = os.path.join(os.path.dirname(__file__), '..', '..', 
                              'user_input_files', 'extracted_v1', 'iskra_project')
        if os.path.exists(v1_path):
            sys.path.append(v1_path)
            try:
                from iskra_project.lib.vector_search import hybrid_search
                compatibility_report['version1_support'] = True
                compatibility_report['legacy_adapter_available'] = True
            except ImportError as e:
                compatibility_report['issues'].append(f"Version 1 import error: {e}")
        
        # Проверка Version 2  
        v2_path = os.path.join(os.path.dirname(__file__), '..', '..',
                              'user_input_files', 'extracted_v2', 'code', 'optimized')
        if os.path.exists(v2_path):
            sys.path.append(v2_path)
            try:
                from vector_search import OptimizedVectorSearcher
                compatibility_report['version2_support'] = True
                compatibility_report['modern_adapter_available'] = True
            except ImportError as e:
                compatibility_report['issues'].append(f"Version 2 import error: {e}")
                
    except Exception as e:
        compatibility_report['issues'].append(f"Compatibility check error: {e}")
    
    return compatibility_report

# Инициализация при импорте модуля
try:
    _compat_report = check_compatibility()
    if _compat_report['issues']:
        import logging
        logger = logging.getLogger(__name__)
        for issue in _compat_report['issues']:
            logger.warning(f"Compatibility issue: {issue}")
except Exception as e:
    import logging
    logger = logging.getLogger(__name__)
    logger.error(f"Error during module initialization: {e}")