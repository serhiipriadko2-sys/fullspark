"""
Модели данных для интегрированной архитектуры проекта Искра.

Объединяет модели Version 1 (для обратной совместимости) и Version 2 (для новых возможностей).
"""

from typing import List, Optional, Dict, Any, Union
from pydantic import BaseModel, Field, validator
from datetime import datetime


# ================== MODELS VERSION 1 (Backward Compatibility) ==================

class Token(BaseModel):
    """Модель токена аутентификации."""
    access_token: str = Field(..., description="JWT токен доступа")
    token_type: str = Field(default="bearer", description="Тип токена")


class LoginRequest(BaseModel):
    """Модель запроса аутентификации."""
    username: str = Field(..., min_length=1, max_length=100, description="Имя пользователя")
    password: str = Field(..., min_length=8, max_length=255, description="Пароль")
    
    @validator('username')
    def validate_username(cls, v):
        v = v.strip()
        if any(char in v for char in ['<', '>', '&', '"', "'", '(', ')', ';']):
            raise ValueError('Username contains invalid characters')
        return v
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        return v


class SearchRequest(BaseModel):
    """Модель запроса поиска (Version 1 совместимость)."""
    query: str = Field(..., min_length=1, max_length=1000, description="Поисковый запрос")
    k: int = Field(default=5, ge=1, le=50, description="Количество результатов")
    
    @validator('query')
    def validate_query(cls, v):
        v = v.strip()
        if not v:
            raise ValueError('Query cannot be empty')
        return v


class Chunk(BaseModel):
    """Модель чанка доказательства."""
    doc_id: str = Field(..., description="Идентификатор документа")
    score: float = Field(..., ge=0.0, le=1.0, description="Оценка релевантности")
    content: str = Field(..., description="Содержимое чанка")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Дополнительные метаданные")


class SearchResponse(BaseModel):
    """Модель ответа на поиск (Version 1 совместимость)."""
    query: str = Field(..., description="Обработанный запрос")
    chunks: List[Chunk] = Field(..., description="Найденные чанки")
    latency_ms: float = Field(..., description="Время выполнения в миллисекундах")


class ChatRequest(BaseModel):
    """Модель запроса чата (Version 1 совместимость)."""
    message: str = Field(..., min_length=1, max_length=5000, description="Сообщение пользователя")
    topk: int = Field(default=4, ge=1, le=20, description="Количество источников для контекста")
    
    @validator('message')
    def validate_message(cls, v):
        v = v.strip()
        if not v:
            raise ValueError('Message cannot be empty')
        return v


class ChatResponse(BaseModel):
    """Модель ответа чата (Version 1 совместимость)."""
    reply: str = Field(..., description="Ответ системы")
    citations: List[Chunk] = Field(default_factory=list, description="Цитируемые источники")
    cd_index: Optional[float] = Field(default=None, description="Индекс CD")


# ================== MODELS VERSION 2 (Enhanced) ==================

class EnhancedSearchRequest(BaseModel):
    """Улучшенная модель запроса поиска."""
    query: str = Field(..., min_length=1, max_length=2000, description="Поисковый запрос")
    k: int = Field(default=10, ge=1, le=100, description="Количество результатов")
    use_cache: bool = Field(default=True, description="Использовать кэш")
    include_metadata: bool = Field(default=True, description="Включить метаданные")
    filters: Optional[Dict[str, Any]] = Field(default=None, description="Фильтры поиска")
    
    @validator('query')
    def validate_enhanced_query(cls, v):
        v = v.strip()
        if not v:
            raise ValueError('Query cannot be empty')
        return v


class EnhancedChunk(BaseModel):
    """Улучшенная модель чанка с расширенными метаданными."""
    doc_id: str = Field(..., description="Идентификатор документа")
    score: float = Field(..., ge=0.0, le=1.0, description="Оценка релевантности")
    content: str = Field(..., description="Содержимое чанка")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Метаданные")
    source_path: Optional[str] = Field(default=None, description="Путь к источнику")
    chunk_index: Optional[int] = Field(default=None, description="Индекс чанка в документе")
    created_at: Optional[datetime] = Field(default=None, description="Время создания")
    tags: List[str] = Field(default_factory=list, description="Теги")


class EnhancedSearchResponse(BaseModel):
    """Улучшенный ответ на поиск."""
    query: str = Field(..., description="Обработанный запрос")
    chunks: List[EnhancedChunk] = Field(..., description="Найденные чанки")
    latency_ms: float = Field(..., description="Время выполнения")
    total_found: int = Field(..., description="Общее количество найденных")
    search_id: str = Field(..., description="Уникальный идентификатор поиска")
    cache_hit: bool = Field(default=False, description="Результат взят из кэша")
    enhanced: bool = Field(default=True, description="Улучшенный поиск")


class EnhancedChatRequest(BaseModel):
    """Улучшенная модель запроса чата."""
    message: str = Field(..., min_length=1, max_length=10000, description="Сообщение пользователя")
    topk: int = Field(default=8, ge=1, le=50, description="Количество источников")
    context_window: int = Field(default=2000, ge=500, max_length=5000, description="Размер контекстного окна")
    include_reasoning: bool = Field(default=True, description="Включить процесс рассуждения")
    memory_enabled: bool = Field(default=True, description="Использовать память диалога")
    
    @validator('message')
    def validate_enhanced_message(cls, v):
        v = v.strip()
        if not v:
            raise ValueError('Message cannot be empty')
        return v


class EnhancedChatResponse(BaseModel):
    """Улучшенный ответ чата."""
    reply: str = Field(..., description="Ответ системы")
    citations: List[EnhancedChunk] = Field(default_factory=list, description="Цитируемые источники")
    reasoning: Optional[str] = Field(default=None, description="Процесс рассуждения")
    memory_used: bool = Field(default=False, description="Использована память")
    chat_id: str = Field(..., description="Уникальный идентификатор чата")
    version: str = Field(default="2.0", description="Версия чат системы")
    enhanced: bool = Field(default=True, description="Улучшенный чат")


# ================== SYSTEM MODELS ==================

class HealthStatus(BaseModel):
    """Модель статуса системы."""
    status: str = Field(..., description="Статус системы")
    timestamp: float = Field(..., description="Временная метка")
    version: str = Field(..., description="Версия системы")
    uptime_seconds: float = Field(default=0.0, description="Время работы в секундах")
    services: Dict[str, Any] = Field(default_factory=dict, description="Статус сервисов")


class VersionInfo(BaseModel):
    """Модель информации о версии."""
    name: str = Field(..., description="Название системы")
    version: str = Field(..., description="Версия")
    compatibility: str = Field(..., description="Информация о совместимости")
    components: Dict[str, Any] = Field(default_factory=dict, description="Компоненты системы")
    cd_index: Optional[float] = Field(default=None, description="CD индекс")
    enhanced_features: List[str] = Field(default_factory=list, description="Улучшенные возможности")
    architecture: Optional[str] = Field(default=None, description="Архитектура")


class ErrorResponse(BaseModel):
    """Модель ответа об ошибке."""
    error: Dict[str, Any] = Field(..., description="Информация об ошибке")
    
    class Config:
        schema_extra = {
            "example": {
                "error": {
                    "message": "Validation failed",
                    "code": "VALIDATION_ERROR",
                    "details": {"field": "query", "reason": "empty"}
                }
            }
        }


# ================== MEMORY MODELS ==================

class MemoryEvent(BaseModel):
    """Модель события памяти."""
    t: float = Field(..., description="Временная метка")
    kind: str = Field(..., description="Тип события")
    key: str = Field(..., description="Ключ события")
    value: Dict[str, Any] = Field(..., description="Значение события")
    meta: Optional[Dict[str, Any]] = Field(default=None, description="Метаданные")


class MemoryStats(BaseModel):
    """Модель статистики памяти."""
    buffer_size: int = Field(..., description="Размер буфера")
    batch_size: int = Field(..., description="Размер батча")
    last_flush: float = Field(..., description="Время последнего сброса")
    compression_enabled: bool = Field(..., description="Включено сжатие")
    async_mode: bool = Field(..., description="Асинхронный режим")


# ================== ANALYTICS MODELS ==================

class SearchStats(BaseModel):
    """Модель статистики поиска."""
    total_searches: int = Field(..., description="Общее количество поисков")
    cache_hits: int = Field(..., description="Попадания в кэш")
    average_latency_ms: float = Field(..., description="Средняя латентность")
    cache_enabled: bool = Field(..., description="Кэш включен")
    cache_size: int = Field(..., description="Размер кэша")


class ChatStats(BaseModel):
    """Модель статистики чата."""
    total_chats: int = Field(..., description="Общее количество чатов")
    average_response_time_ms: float = Field(..., description="Среднее время ответа")
    citations_used: int = Field(..., description="Использованные цитаты")
    average_citations_per_chat: float = Field(..., description="Среднее количество цитат на чат")


# ================== UTILITY MODELS ==================

class APICompatibility(BaseModel):
    """Модель информации о совместимости API."""
    v1_legacy: bool = Field(default=True, description="Поддержка Version 1")
    v2_modern: bool = Field(default=True, description="Поддержка Version 2")
    migration_mode: str = Field(default="hybrid", description="Режим миграции")
    backward_compatibility: bool = Field(default=True, description="Обратная совместимость")


class SystemInfo(BaseModel):
    """Общая информация о системе."""
    message: str = Field(..., description="Приветственное сообщение")
    version: str = Field(..., description="Версия")
    compatibility: str = Field(..., description="Информация о совместимости")
    docs: str = Field(..., description="Ссылка на документацию")
    health: str = Field(..., description="Ссылка на проверку здоровья")
    api_versions: APICompatibility = Field(..., description="Поддерживаемые версии API")