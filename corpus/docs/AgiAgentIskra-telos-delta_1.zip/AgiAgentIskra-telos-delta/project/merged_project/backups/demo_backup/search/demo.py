#!/usr/bin/env python3
"""
Демонстрация интегрированной поисковой системы Iskra.

Показывает возможности всех режимов поиска,
конфигурации производительности и мониторинг.
"""

import asyncio
import json
import os
import sys
import tempfile
import time
from typing import Dict, List, Any

# Добавление пути к модулю  
sys.path.insert(0, os.path.dirname(__file__))

from search import (
    IntegratedSearch, 
    PerformanceConfig, 
    SearchMode,
    create_fast_config, 
    create_balanced_config,
    create_quality_config,
    create_graphrag_config,
    load_config
)

def create_demo_evidence_file() -> str:
    """Создание демонстрационного файла с данными."""
    demo_data = [
        {
            "doc_id": "ai_systems.md",
            "chunk_id": 0,
            "content": "Искусственный интеллект - это область компьютерных наук, которая создает системы, способные выполнять задачи, обычно требующие человеческого интеллекта."
        },
        {
            "doc_id": "ai_systems.md", 
            "chunk_id": 1,
            "content": "Машинное обучение - это подраздел искусственного интеллекта, который позволяет компьютерам учиться и принимать решения на основе данных."
        },
        {
            "doc_id": "search_algorithms.md",
            "chunk_id": 0,
            "content": "Поисковые алгоритмы используются для нахождения информации в больших наборах данных. Эффективность алгоритма определяется его временной сложностью."
        },
        {
            "doc_id": "search_algorithms.md",
            "chunk_id": 1, 
            "content": "O(log n) сложность означает, что время выполнения растет логарифмически относительно размера входных данных, что очень эффективно."
        },
        {
            "doc_id": "graph_databases.md",
            "chunk_id": 0,
            "content": "Графовые базы данных используют структуры графов для представления и хранения данных, что позволяет эффективно анализировать связи между объектами."
        },
        {
            "doc_id": "graph_databases.md",
            "chunk_id": 1,
            "content": "GraphRAG - это подход, который комбинирует возможности поиска по векторам с анализом графов для более глубокого понимания контекста."
        },
        {
            "doc_id": "performance_optimization.md",
            "chunk_id": 0,
            "content": "Оптимизация производительности включает в себя кэширование, индексацию и другие техники для ускорения выполнения операций."
        },
        {
            "doc_id": "performance_optimization.md",
            "chunk_id": 1,
            "content": "LRU кэш (Least Recently Used) - это алгоритм кэширования, который удаляет наименее недавно использованные элементы при заполнении кэша."
        }
    ]
    
    # Создание временного файла
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl', delete=False)
    for item in demo_data:
        temp_file.write(json.dumps(item, ensure_ascii=False) + '\\n')
    temp_file.close()
    
    return temp_file.name

async def demo_basic_search():
    """Демонстрация базового поиска."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ БАЗОВОГО ПОИСКА")
    print("="*60)
    
    evidence_file = create_demo_evidence_file()
    
    try:
        # Создание конфигурации
        config = create_balanced_config()
        config.legacy_config.evidence_path = evidence_file
        config.modern_config.evidence_path = evidence_file
        
        async with IntegratedSearch(config) as searcher:
            queries = [
                "искусственный интеллект",
                "поисковые алгоритмы", 
                "оптимизация производительности",
                "графовые базы данных"
            ]
            
            print("\\nВыполнение поисковых запросов...")
            for query in queries:
                print(f"\\nЗапрос: '{query}'")
                
                results, metrics = await searcher.search(query, k=3)
                
                print(f"  Найдено результатов: {len(results)}")
                print(f"  Режим поиска: {metrics.mode_used}")
                print(f"  Время выполнения: {metrics.search_time_ms:.2f}ms")
                
                for i, result in enumerate(results, 1):
                    print(f"  {i}. [{result.doc_id}] {result.content[:80]}...")
                    print(f"     Оценка: {result.score:.3f}")
        
        print("\\n✓ Базовый поиск завершен")
        
    finally:
        os.unlink(evidence_file)

async def demo_search_modes():
    """Демонстрация различных режимов поиска."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ РЕЖИМОВ ПОИСКА")
    print("="*60)
    
    evidence_file = create_demo_evidence_file()
    
    try:
        config = create_balanced_config()
        config.legacy_config.evidence_path = evidence_file
        config.modern_config.evidence_path = evidence_file
        
        test_query = "оптимизация алгоритмов"
        
        async with IntegratedSearch(config) as searcher:
            modes = [SearchMode.LEGACY, SearchMode.MODERN, SearchMode.HYBRID, SearchMode.GRAPHRAG]
            
            print(f"\\nТестовый запрос: '{test_query}'")
            print("Результаты по режимам:")
            
            for mode in modes:
                print(f"\\n--- {mode.value.upper()} MODE ---")
                
                results, metrics = await searcher.search(test_query, mode=mode.value, k=3)
                
                print(f"Время: {metrics.search_time_ms:.2f}ms")
                print(f"Результатов: {len(results)}")
                
                for i, result in enumerate(results, 1):
                    print(f"  {i}. {result.content[:60]}... (score: {result.score:.3f})")
        
        print("\\n✓ Демонстрация режимов завершена")
        
    finally:
        os.unlink(evidence_file)

async def demo_performance_modes():
    """Демонстрация профилей производительности."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ ПРОФИЛЕЙ ПРОИЗВОДИТЕЛЬНОСТИ")
    print("="*60)
    
    evidence_file = create_demo_evidence_file()
    
    try:
        profiles = {
            "FASTEST": create_fast_config(),
            "BALANCED": create_balanced_config(), 
            "QUALITY": create_quality_config(),
            "GRAPHRAG": create_graphrag_config()
        }
        
        test_query = "машинное обучение алгоритмы"
        
        print(f"\\nТестовый запрос: '{test_query}'")
        print("Сравнение профилей производительности:")
        
        for profile_name, config in profiles.items():
            config.legacy_config.evidence_path = evidence_file
            config.modern_config.evidence_path = evidence_file
            
            print(f"\\n--- {profile_name} PROFILE ---")
            
            async with IntegratedSearch(config) as searcher:
                start_time = time.time()
                results, metrics = await searcher.search(test_query, k=5)
                end_time = time.time()
                
                total_time = (end_time - start_time) * 1000
                
                print(f"Всего времени: {total_time:.2f}ms")
                print(f"Внутренние метрики: {metrics.search_time_ms:.2f}ms")
                print(f"Режим: {metrics.mode_used}")
                print(f"Результатов: {len(results)}")
                print(f"Кэш hit: {metrics.cache_hit}")
                
                # Показываем некоторые результаты
                for i, result in enumerate(results[:2], 1):
                    print(f"  {i}. [{result.doc_id}] {result.content[:50]}...")
        
        print("\\n✓ Демонстрация профилей завершена")
        
    finally:
        os.unlink(evidence_file)

async def demo_cache_performance():
    """Демонстрация эффективности кэширования."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ ЭФФЕКТИВНОСТИ КЭШИРОВАНИЯ")
    print("="*60)
    
    evidence_file = create_demo_evidence_file()
    
    try:
        config = create_balanced_config()
        config.legacy_config.evidence_path = evidence_file
        config.modern_config.evidence_path = evidence_file
        config.cache_size = 20  # Небольшой кэш для демонстрации
        
        test_query = "искусственный интеллект"
        
        async with IntegratedSearch(config) as searcher:
            print("\\nТест кэширования:")
            print(f"Запрос: '{test_query}'")
            
            # Первый поиск (без кэша)
            print("\\n1. Первый поиск (без кэша):")
            start_time = time.time()
            results1, metrics1 = await searcher.search(test_query)
            first_time = time.time() - start_time
            
            print(f"   Время выполнения: {first_time*1000:.2f}ms")
            print(f"   Кэш hit: {metrics1.cache_hit}")
            print(f"   Результатов: {len(results1)}")
            
            # Второй поиск (с кэшем)
            print("\\n2. Второй поиск (с кэшем):")
            start_time = time.time()
            results2, metrics2 = await searcher.search(test_query)
            second_time = time.time() - start_time
            
            print(f"   Время выполнения: {second_time*1000:.2f}ms")
            print(f"   Кэш hit: {metrics2.cache_hit}")
            print(f"   Результатов: {len(results2)}")
            
            # Сравнение
            if second_time > 0:
                speedup = first_time / second_time
                print(f"\\nУскорение от кэширования: {speedup:.2f}x")
            
            # Проверка консистентности
            if len(results1) == len(results2):
                print("✓ Результаты идентичны")
            else:
                print("⚠ Различное количество результатов")
        
        print("\\n✓ Демонстрация кэширования завершена")
        
    finally:
        os.unlink(evidence_file)

async def demo_performance_monitoring():
    """Демонстрация мониторинга производительности."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ МОНИТОРИНГА ПРОИЗВОДИТЕЛЬНОСТИ")
    print("="*60)
    
    evidence_file = create_demo_evidence_file()
    
    try:
        config = create_balanced_config()
        config.legacy_config.evidence_path = evidence_file
        config.modern_config.evidence_path = evidence_file
        
        async with IntegratedSearch(config) as searcher:
            print("\\nВыполнение серии поисков для сбора метрик...")
            
            queries = [
                "искусственный интеллект",
                "поисковые алгоритмы",
                "оптимизация",
                "графовые структуры", 
                "машинное обучение",
                "алгоритмы поиска"
            ]
            
            # Выполнение поисков
            for i, query in enumerate(queries, 1):
                results, metrics = await searcher.search(query, k=3)
                print(f"{i}. '{query}' -> {len(results)} результатов ({metrics.search_time_ms:.2f}ms)")
            
            # Получение отчета
            print("\\n" + "-"*40)
            print("ОТЧЕТ О ПРОИЗВОДИТЕЛЬНОСТИ")
            print("-"*40)
            
            report = searcher.get_performance_report()
            
            print(f"Всего поисков: {report['total_searches']}")
            print(f"Среднее время: {report['average_search_time_ms']:.2f}ms")
            print(f"Попадания в кэш: {report['cache_hit_rate']:.3f}")
            print(f"Размер кэша: {report['cache_size']}")
            
            print("\\nРаспределение режимов:")
            for mode, count in report['mode_distribution'].items():
                percentage = (count / report['total_searches']) * 100
                print(f"  {mode}: {count} ({percentage:.1f}%)")
            
            print("\\nДетали последних поисков:")
            for i, metrics in enumerate(report['recent_metrics'][-3:], 1):
                print(f"  {i}. {metrics.mode_used}: {metrics.search_time_ms:.2f}ms, {metrics.results_count} рез.")
        
        print("\\n✓ Демонстрация мониторинга завершена")
        
    finally:
        os.unlink(evidence_file)

async def demo_error_handling():
    """Демонстрация обработки ошибок."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ ОБРАБОТКИ ОШИБОК")
    print("="*60)
    
    # Используем несуществующий файл для демонстрации fallback
    config = create_balanced_config()
    config.legacy_config.evidence_path = "nonexistent_evidence.jsonl"
    config.modern_config.evidence_path = "nonexistent_evidence.jsonl"
    
    async with IntegratedSearch(config) as searcher:
        print("\\nТестирование обработки ошибок:")
        print("Используется несуществующий файл evidence...")
        
        test_queries = [
            "тестовый запрос",
            "поиск без данных",
            "fallback проверка"
        ]
        
        for query in test_queries:
            print(f"\\nЗапрос: '{query}'")
            
            try:
                results, metrics = await searcher.search(query)
                
                print(f"  Статус: Успешно обработан")
                print(f"  Режим: {metrics.mode_used}")
                print(f"  Результатов: {len(results)}")
                print(f"  Время: {metrics.search_time_ms:.2f}ms")
                
                if metrics.additional_info:
                    print(f"  Дополнительно: {metrics.additional_info}")
                    
            except Exception as e:
                print(f"  Статус: Ошибка - {e}")
        
        print("\\n✓ Демонстрация обработки ошибок завершена")

async def demo_configuration():
    """Демонстрация различных конфигураций."""
    print("\\n" + "="*60)
    print("ДЕМОНСТРАЦИЯ КОНФИГУРАЦИЙ")
    print("="*60)
    
    # Создание пользовательской конфигурации
    print("\\n1. Создание пользовательской конфигурации:")
    
    custom_config = PerformanceConfig(
        default_mode=SearchMode.HYBRID,
        default_k=8,
        cache_size=100,
        legacy_weight=0.7,
        modern_weight=0.3,
        enable_result_cache=True,
        max_concurrent_searches=5
    )
    
    print(f"   Режим: {custom_config.default_mode.value}")
    print(f"   K: {custom_config.default_k}")
    print(f"   Кэш: {custom_config.cache_size}")
    print(f"   Веса: legacy={custom_config.legacy_weight}, modern={custom_config.modern_weight}")
    
    # Сохранение в файл
    config_file = "demo_config.json"
    custom_config.save_to_file(config_file)
    print(f"\\n2. Конфигурация сохранена в файл: {config_file}")
    
    # Загрузка из файла
    loaded_config = PerformanceConfig.from_file(config_file)
    print(f"\\n3. Конфигурация загружена из файла:")
    print(f"   Режим: {loaded_config.default_mode.value}")
    print(f"   K: {loaded_config.default_k}")
    
    # Оптимизация для типа запроса
    print("\\n4. Оптимизация для типов запросов:")
    
    query_types = [
        "что такое машинное обучение?",
        "найти алгоритмы поиска",
        "ai ml",
        "как связаны между собой искусственный интеллект и машинное обучение"
    ]
    
    for query in query_types:
        optimizations = custom_config.optimize_for_query_type(query)
        print(f"   '{query[:40]}...'")
        for key, value in optimizations.items():
            print(f"     {key}: {value}")
    
    # Очистка
    os.unlink(config_file)
    print("\\n✓ Демонстрация конфигураций завершена")

async def main():
    """Основная функция демонстрации."""
    print("ИНТЕГРИРОВАННАЯ ПОИСКОВАЯ СИСТЕМА ISKRA")
    print("Демонстрация возможностей и функций")
    print("="*60)
    
    try:
        await demo_basic_search()
        await demo_search_modes()
        await demo_performance_modes()
        await demo_cache_performance()
        await demo_performance_monitoring()
        await demo_error_handling()
        await demo_configuration()
        
        print("\\n" + "="*60)
        print("ДЕМОНСТРАЦИЯ ЗАВЕРШЕНА УСПЕШНО!")
        print("Все функции интегрированной поисковой системы работают корректно.")
        print("="*60)
        
    except Exception as e:
        print(f"\\n❌ Ошибка во время демонстрации: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Запуск демонстрации
    asyncio.run(main())