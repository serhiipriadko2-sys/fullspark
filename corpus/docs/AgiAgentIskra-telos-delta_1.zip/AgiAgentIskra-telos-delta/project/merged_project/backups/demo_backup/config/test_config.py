#!/usr/bin/env python3
"""
Тест синхронизированной системы конфигурации.

Простой тест для проверки работоспособности всех компонентов
системы конфигурации без внешних зависимостей.
"""

import sys
import os
from pathlib import Path

# Добавляем путь к модулю
sys.path.insert(0, str(Path(__file__).parent))

def test_basic_imports():
    """Тест базового импорта модулей."""
    print("🔧 Тестирование базового импорта...")
    
    try:
        from config.unified_config import UnifiedConfig, EnvironmentProfile
        from config.environment import EnvironmentManager
        from config.compatibility import VersionCompatibility
        from config.migration import ConfigMigrator
        from config.validation import ConfigValidator
        from config.defaults import DefaultSettings
        print("✅ Все модули успешно импортированы")
        return True
    except Exception as e:
        print(f"❌ Ошибка импорта: {e}")
        return False


def test_basic_config_creation():
    """Тест создания базовой конфигурации."""
    print("\n🔧 Тестирование создания конфигурации...")
    
    try:
        from config.unified_config import UnifiedConfig, EnvironmentProfile
        
        # Создание конфигурации без внешних компонентов
        config = UnifiedConfig()
        print("✅ Конфигурация создана")
        
        # Проверка основных настроек
        print(f"   Профиль: {config.profile.value}")
        print(f"   Хост: {config.api.host}")
        print(f"   Порт: {config.api.port}")
        print(f"   JWT алгоритм: {config.security.jwt_algorithm}")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка создания конфигурации: {e}")
        return False


def test_dataclasses():
    """Тест работы с настройками через dataclass."""
    print("\n🔧 Тестирование dataclass настроек...")
    
    try:
        from config.unified_config import SecuritySettings, MemorySettings
        
        # Создание настроек безопасности
        security = SecuritySettings(
            jwt_secret="test-secret-12345678901234567890",
            jwt_algorithm="HS256",
            cors_origins=["http://localhost:3000"]
        )
        
        print("✅ Настройки безопасности созданы")
        print(f"   JWT алгоритм: {security.jwt_algorithm}")
        print(f"   CORS источники: {len(security.cors_origins)}")
        
        # Создание настроек памяти
        memory = MemorySettings(
            memory_root="test_memory",
            memory_batch_size=25
        )
        
        print("✅ Настройки памяти созданы")
        print(f"   Корневая директория: {memory.memory_root}")
        print(f"   Размер батча: {memory.memory_batch_size}")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка создания настроек: {e}")
        return False


def test_environment_manager():
    """Тест менеджера переменных окружения."""
    print("\n🔧 Тестирование менеджера окружения...")
    
    try:
        from config.environment import EnvironmentManager
        
        # Установка тестовых переменных
        os.environ["JWT_SECRET"] = "test-secret-for-environment"
        os.environ["CORS_ORIGINS"] = "https://example.com,https://test.com"
        
        env_manager = EnvironmentManager()
        
        # Проверка получения информации о переменной
        jwt_info = env_manager.get_variable_info("JWT_SECRET")
        print("✅ Информация о переменной получена")
        print(f"   JWT_SECRET: {jwt_info.description}")
        
        # Проверка списка переменных
        all_vars = env_manager.list_variables()
        print(f"✅ Список переменных получен: {len(all_vars)} переменных")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования окружения: {e}")
        return False


def test_profiles():
    """Тест работы с профилями."""
    print("\n🔧 Тестирование профилей...")
    
    try:
        from config.unified_config import EnvironmentProfile, UnifiedConfig
        
        profiles = [
            EnvironmentProfile.DEVELOPMENT,
            EnvironmentProfile.PRODUCTION,
            EnvironmentProfile.TESTING
        ]
        
        print("✅ Профили определены")
        
        for profile in profiles:
            config = UnifiedConfig(profile=profile)
            print(f"   {profile.value}: {config.profile.value}")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования профилей: {e}")
        return False


def test_simple_validation():
    """Простой тест валидации."""
    print("\n🔧 Тестирование валидации...")
    
    try:
        from config.unified_config import SecuritySettings
        
        # Создание настроек с разными значениями
        good_security = SecuritySettings(
            jwt_secret="very-long-and-secure-secret-key-123456789",
            jwt_algorithm="HS256"
        )
        
        print("✅ Настройки с корректными значениями созданы")
        
        # Проверка базовых атрибутов
        assert hasattr(good_security, 'jwt_secret')
        assert hasattr(good_security, 'jwt_algorithm')
        assert good_security.jwt_algorithm == "HS256"
        
        print("✅ Все атрибуты присутствуют")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования валидации: {e}")
        return False


def test_config_summary():
    """Тест получения сводки конфигурации."""
    print("\n🔧 Тестирование сводки конфигурации...")
    
    try:
        from config.unified_config import UnifiedConfig
        
        config = UnifiedConfig()
        
        # Проверка наличия метода
        assert hasattr(config, 'get_config_summary')
        
        # Получение сводки (без внешних компонентов)
        summary = config.get_config_summary()
        
        print("✅ Сводка конфигурации получена")
        print(f"   Профиль: {summary.get('profile', 'N/A')}")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка тестирования сводки: {e}")
        return False


def test_import_fallback():
    """Тест резервного режима при ошибках импорта."""
    print("\n🔧 Тестирование резервного режима...")
    
    try:
        # Попытка импорта с потенциальными ошибками
        from config.unified_config import EnvironmentManager, ConfigValidator
        
        # Проверка, что импорты работают в резервном режиме
        if EnvironmentManager is None:
            print("✅ Резервный режим: EnvironmentManager = None")
        if ConfigValidator is None:
            print("✅ Резервный режим: ConfigValidator = None")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка резервного режима: {e}")
        return False


def main():
    """Главная функция тестирования."""
    print("🚀 ТЕСТИРОВАНИЕ СИНХРОНИЗИРОВАННОЙ СИСТЕМЫ КОНФИГУРАЦИИ")
    print("=" * 60)
    
    tests = [
        ("Базовый импорт", test_basic_imports),
        ("Создание конфигурации", test_basic_config_creation),
        ("Dataclass настройки", test_dataclasses),
        ("Менеджер окружения", test_environment_manager),
        ("Профили", test_profiles),
        ("Валидация", test_simple_validation),
        ("Сводка конфигурации", test_config_summary),
        ("Резервный режим", test_import_fallback),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"❌ Критическая ошибка в тесте '{test_name}': {e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ")
    print("=" * 60)
    print(f"✅ Пройдено: {passed}")
    print(f"❌ Провалено: {failed}")
    print(f"📈 Процент успеха: {(passed / (passed + failed)) * 100:.1f}%")
    
    if failed == 0:
        print("\n🎉 Все тесты пройдены успешно!")
    else:
        print(f"\n⚠️  {failed} тестов провалено")
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)