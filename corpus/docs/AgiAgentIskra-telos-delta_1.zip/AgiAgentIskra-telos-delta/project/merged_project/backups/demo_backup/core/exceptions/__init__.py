"""Пакет исключений интегрированной системы обработки ошибок.

Объединяет базовую обработку ошибок Version 1 с продвинутой системой Version 2.

Автор: Iskra Integration Team
Версия: 1.0
"""

from .exception_hierarchy import (
    # Enums
    ErrorLevel,
    ErrorType,
    ErrorScope,
    
    # Base Exception
    BaseIskraException,
    
    # Version 1 Compatibility
    IskraException,
    
    # HTTP Level Exceptions
    HttpLevelException,
    AuthenticationException,
    AuthorizationException,
    NotFoundException,
    ValidationException,
    
    # Service Level Exceptions
    ServiceLevelException,
    BusinessLogicException,
    ConfigurationException,
    
    # Repository Level Exceptions
    RepositoryLevelException,
    DatabaseException,
    SearchException,
    VectorSearchException,
    
    # Infrastructure Level Exceptions
    InfrastructureLevelException,
    ExternalServiceException,
    SystemException,
    
    # Decorators
    error_handler,
    handle_iskra_exceptions,
    
    # Utilities
    is_iskra_exception,
    get_exception_info,
    create_exception_from_error,
)

__all__ = [
    # Enums
    "ErrorLevel",
    "ErrorType", 
    "ErrorScope",
    
    # Base Exception
    "BaseIskraException",
    
    # Version 1 Compatibility
    "IskraException",
    
    # HTTP Level Exceptions
    "HttpLevelException",
    "AuthenticationException",
    "AuthorizationException",
    "NotFoundException",
    "ValidationException",
    
    # Service Level Exceptions
    "ServiceLevelException",
    "BusinessLogicException",
    "ConfigurationException",
    
    # Repository Level Exceptions
    "RepositoryLevelException",
    "DatabaseException",
    "SearchException",
    "VectorSearchException",
    
    # Infrastructure Level Exceptions
    "InfrastructureLevelException",
    "ExternalServiceException",
    "SystemException",
    
    # Decorators
    "error_handler",
    "handle_iskra_exceptions",
    
    # Utilities
    "is_iskra_exception",
    "get_exception_info",
    "create_exception_from_error",
]

# Aliases for Version 1 compatibility
ISKRA_EXCEPTION = BaseIskraException
HTTP_EXCEPTION = HttpLevelException