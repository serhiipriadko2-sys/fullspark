"""
Модуль совместимости для синхронизированной конфигурации.

Обеспечивает совместимость с Version 1 и Version 2, автоматическую
миграцию устаревших настроек и адаптацию под разные версии API.
"""

import os
import logging
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass
from enum import Enum
import warnings
import re


class CompatibilityMode(Enum):
    """Режимы совместимости."""
    VERSION_1_ONLY = "v1_only"  # Только Version 1
    VERSION_2_ONLY = "v2_only"  # Только Version 2
    HYBRID = "hybrid"           # Гибридный режим
    UNIFIED = "unified"         # Полностью объединенная конфигурация


@dataclass
class CompatibilityMapping:
    """Сопоставление настроек между версиями."""
    version_1_key: str
    version_2_key: str
    unified_key: str
    conversion_func: Optional[callable] = None
    deprecation_warning: Optional[str] = None


class VersionCompatibility:
    """Менеджер совместимости версий."""
    
    # Сопоставления настроек между версиями
    COMPATIBILITY_MAPPINGS = {
        # === JWT НАСТРОЙКИ ===
        "JWT_SECRET": CompatibilityMapping(
            "JWT_SECRET", "JWT_SECRET", "security.jwt_secret"
        ),
        "JWT_ALGORITHM": CompatibilityMapping(
            "JWT_ALGORITHM", "JWT_ALGORITHM", "security.jwt_algorithm"
        ),
        "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": CompatibilityMapping(
            "JWT_EXPIRE_MINUTES", "JWT_ACCESS_TOKEN_EXPIRE_MINUTES", 
            "security.jwt_access_token_expire_minutes"
        ),
        
        # === CORS НАСТРОЙКИ ===
        "CORS_ORIGINS": CompatibilityMapping(
            "CORS_ORIGINS", "CORS_ORIGINS", "security.cors_origins",
            deprecation_warning="Переименовано в CORS_ALLOW_ORIGINS"
        ),
        "CORS_ALLOW_ORIGINS": CompatibilityMapping(
            "CORS_ORIGINS", "CORS_ORIGINS", "security.cors_origins"
        ),
        "CORS_ALLOW_CREDENTIALS": CompatibilityMapping(
            None, "CORS_ALLOW_CREDENTIALS", "security.cors_allow_credentials"
        ),
        
        # === ПОИСК ===
        "EVIDENCE_PATH": CompatibilityMapping(
            "EVIDENCE_PATH", "EVIDENCE_PATH", "memory.evidence_path"
        ),
        "MAX_SEARCH_RESULTS": CompatibilityMapping(
            "MAX_SEARCH_RESULTS", "MAX_SEARCH_RESULTS", "search.max_search_results"
        ),
        "DEFAULT_SEARCH_K": CompatibilityMapping(
            "DEFAULT_SEARCH_K", "DEFAULT_SEARCH_K", "search.default_search_k"
        ),
        
        # === ПАМЯТЬ ===
        "MEMORY_ROOT": CompatibilityMapping(
            None, "MEMORY_ROOT", "memory.memory_root"
        ),
        "MEMORY_BATCH_SIZE": CompatibilityMapping(
            None, "MEMORY_BATCH_SIZE", "memory.memory_batch_size"
        ),
        "MEMORY_FLUSH_INTERVAL": CompatibilityMapping(
            None, "MEMORY_FLUSH_INTERVAL", "memory.memory_flush_interval_seconds"
        ),
        "MEMORY_COMPRESSION": CompatibilityMapping(
            None, "MEMORY_COMPRESSION", "memory.memory_compression_enabled"
        ),
        
        # === ЛОГИРОВАНИЕ ===
        "LOG_LEVEL": CompatibilityMapping(
            "LOG_LEVEL", "LOG_LEVEL", "logging.log_level"
        ),
        
        # === CACHE ===
        "LRU_CACHE_SIZE": CompatibilityMapping(
            None, "LRU_CACHE_SIZE", "performance.lru_cache_size"
        ),
        
        # === МЕТРИКИ ===
        "OTEL_ENABLED": CompatibilityMapping(
            "OTEL_ENABLED", "OTEL_ENABLED", "monitoring.otel_enabled"
        ),
        "OTEL_SERVICE_NAME": CompatibilityMapping(
            None, "OTEL_SERVICE_NAME", "monitoring.otel_service_name"
        ),
        
        # === ФАЙЛОВЫЕ ПУТИ ===
        "MANIFEST_PATH": CompatibilityMapping(
            "MANIFEST_PATH", "MANIFEST_PATH", "legacy.manifest_path"
        ),
        "CANON_INDEX_PATH": CompatibilityMapping(
            "CANON_INDEX_PATH", "CANON_INDEX_PATH", "legacy.canon_index_path"
        ),
        
        # === ПРОИЗВОДИТЕЛЬНОСТЬ ===
        "ASYNC_POOL_SIZE": CompatibilityMapping(
            None, "ASYNC_POOL_SIZE", "performance.async_pool_size"
        ),
        "CONNECTION_POOL_SIZE": CompatibilityMapping(
            None, "CONNECTION_POOL_SIZE", "performance.connection_pool_size"
        ),
        
        # === МОНИТОРИНГ ===
        "METRICS_ENABLED": CompatibilityMapping(
            None, "METRICS_ENABLED", "monitoring.metrics_enabled"
        ),
        "HEALTH_CHECK_INTERVAL": CompatibilityMapping(
            None, "HEALTH_CHECK_INTERVAL", "monitoring.health_check_interval_seconds"
        ),
        
        # === БЕЗОПАСНОСТЬ ===
        "RATE_LIMIT_ENABLED": CompatibilityMapping(
            None, "RATE_LIMIT_ENABLED", "security.rate_limit_enabled"
        ),
        "RATE_LIMIT_REQUESTS": CompatibilityMapping(
            None, "RATE_LIMIT_REQUESTS", "security.rate_limit_requests_per_minute"
        ),
    }
    
    # Устаревшие настройки с рекомендациями по миграции
    DEPRECATED_SETTINGS = {
        "JWT_EXPIRE_MINUTES": {
            "replacement": "JWT_ACCESS_TOKEN_EXPIRE_MINUTES",
            "migration_message": "Переименовано для большей ясности"
        },
        "CORS_ORIGINS_ALIAS": {
            "replacement": "CORS_ALLOW_ORIGINS", 
            "migration_message": "Унифицировано название переменной"
        },
        "SEARCH_CACHE_SIZE": {
            "replacement": "LRU_CACHE_SIZE",
            "migration_message": "Унифицировано с другими cache настройками"
        },
        "TELEMETRY_ENABLED": {
            "replacement": "OTEL_ENABLED",
            "migration_message": "Переименовано для соответствия OpenTelemetry"
        },
        "MEMORY_POOL_ENABLED": {
            "replacement": "MEMORY_ASYNC",
            "migration_message": "Уточнена семантика настройки"
        }
    }
    
    def __init__(self):
        """Инициализация менеджера совместимости."""
        self.compatibility_mode = CompatibilityMode.UNIFIED
        self.detected_version = None
        self.migration_warnings = []
    
    def detect_version_from_config(self, config_data: Dict[str, Any]) -> CompatibilityMode:
        """
        Определение версии конфигурации.
        
        Args:
            config_data: Данные конфигурации
            
        Returns:
            Обнаруженный режим совместимости
        """
        v1_indicators = []
        v2_indicators = []
        
        # Индикаторы Version 1
        v1_keys = ["JWT_SECRET", "CORS_ORIGINS", "EVIDENCE_PATH", "LOG_LEVEL"]
        for key in v1_keys:
            if key in config_data:
                v1_indicators.append(key)
        
        # Индикаторы Version 2
        v2_keys = [
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "MEMORY_ROOT", "MEMORY_BATCH_SIZE",
            "OTEL_SERVICE_NAME", "ASYNC_POOL_SIZE", "METRICS_ENABLED"
        ]
        for key in v2_keys:
            if key in config_data:
                v2_indicators.append(key)
        
        # Определение режима
        if len(v2_indicators) > len(v1_indicators) * 2:
            self.compatibility_mode = CompatibilityMode.VERSION_2_ONLY
            self.detected_version = "2.x"
        elif len(v1_indicators) > len(v2_indicators) * 2:
            self.compatibility_mode = CompatibilityMode.VERSION_1_ONLY
            self.detected_version = "1.x"
        elif v1_indicators and v2_indicators:
            self.compatibility_mode = CompatibilityMode.HYBRID
            self.detected_version = "hybrid"
        else:
            self.compatibility_mode = CompatibilityMode.UNIFIED
            self.detected_version = "unified"
        
        logging.info(f"Обнаружен режим совместимости: {self.compatibility_mode.value}")
        return self.compatibility_mode
    
    def migrate_config(self, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Миграция конфигурации с обеспечением совместимости.
        
        Args:
            config_data: Исходные данные конфигурации
            
        Returns:
            Мигрированные данные конфигурации
        """
        migrated_data = config_data.copy()
        
        # Определение версии
        self.detect_version_from_config(config_data)
        
        # Миграция устаревших настроек
        self._migrate_deprecated_settings(migrated_data)
        
        # Применение совместимости
        if self.compatibility_mode in [CompatibilityMode.VERSION_1_ONLY, CompatibilityMode.HYBRID]:
            self._apply_v1_compatibility(migrated_data)
        
        if self.compatibility_mode in [CompatibilityMode.VERSION_2_ONLY, CompatibilityMode.HYBRID]:
            self._apply_v2_compatibility(migrated_data)
        
        # Применение унифицированных настроек
        self._apply_unified_settings(migrated_data)
        
        # Предупреждения о миграции
        if self.migration_warnings:
            logging.warning("Предупреждения миграции конфигурации:")
            for warning in self.migration_warnings:
                logging.warning(f"  - {warning}")
        
        return migrated_data
    
    def _migrate_deprecated_settings(self, config_data: Dict[str, Any]) -> None:
        """Миграция устаревших настроек."""
        for deprecated_key, migration_info in self.DEPRECATED_SETTINGS.items():
            if deprecated_key in config_data:
                old_value = config_data.pop(deprecated_key)
                new_key = migration_info["replacement"]
                
                # Миграция значения
                if new_key not in config_data:
                    config_data[new_key] = old_value
                    
                    warning_msg = (
                        f"Устаревшая настройка '{deprecated_key}' перенесена в '{new_key}'. "
                        f"{migration_info['migration_message']}"
                    )
                    self.migration_warnings.append(warning_msg)
                    warnings.warn(warning_msg, DeprecationWarning, stacklevel=2)
    
    def _apply_v1_compatibility(self, config_data: Dict[str, Any]) -> None:
        """Применение совместимости с Version 1."""
        
        # JWT_EXPIRE_MINUTES -> JWT_ACCESS_TOKEN_EXPIRE_MINUTES
        if "JWT_EXPIRE_MINUTES" in config_data and "JWT_ACCESS_TOKEN_EXPIRE_MINUTES" not in config_data:
            config_data["JWT_ACCESS_TOKEN_EXPIRE_MINUTES"] = config_data["JWT_EXPIRE_MINUTES"]
            self.migration_warnings.append(
                "JWT_EXPIRE_MINUTES переименовано в JWT_ACCESS_TOKEN_EXPIRE_MINUTES"
            )
        
        # Обеспечение совместимости CORS
        if "CORS_ORIGINS" in config_data and "CORS_ALLOW_ORIGINS" not in config_data:
            config_data["CORS_ALLOW_ORIGINS"] = config_data["CORS_ORIGINS"]
        
        # Безопасные значения по умолчанию для Version 1
        if "CORS_ALLOW_CREDENTIALS" not in config_data:
            config_data["CORS_ALLOW_CREDENTIALS"] = True
        
        if "RATE_LIMIT_ENABLED" not in config_data:
            config_data["RATE_LIMIT_ENABLED"] = False  # Отключено в V1
        
        # Безопасные headers для Version 1
        if "SECURITY_HEADERS_ENABLED" not in config_data:
            config_data["SECURITY_HEADERS_ENABLED"] = True
    
    def _apply_v2_compatibility(self, config_data: Dict[str, Any]) -> None:
        """Применение совместимости с Version 2."""
        
        # Обеспечение всех настроек Version 2
        v2_defaults = {
            "MEMORY_ROOT": "memory",
            "MEMORY_BATCH_SIZE": 50,
            "MEMORY_FLUSH_INTERVAL": 5.0,
            "MEMORY_ASYNC": True,
            "OTEL_SERVICE_NAME": "iskra-api",
            "ASYNC_POOL_SIZE": 4,
            "CONNECTION_POOL_SIZE": 10,
            "METRICS_ENABLED": True,
            "HEALTH_CHECK_ENABLED": True,
            "RATE_LIMIT_ENABLED": True,
        }
        
        for key, default_value in v2_defaults.items():
            if key not in config_data:
                config_data[key] = default_value
    
    def _apply_unified_settings(self, config_data: Dict[str, Any]) -> None:
        """Применение унифицированных настроек."""
        
        # Адаптивные настройки на основе профиля
        profile = os.getenv("ENVIRONMENT_PROFILE", "development")
        
        if profile == "production":
            # Более строгие настройки для продакшена
            if "SECURITY_HEADERS_ENABLED" not in config_data:
                config_data["SECURITY_HEADERS_ENABLED"] = True
            if "RATE_LIMIT_ENABLED" not in config_data:
                config_data["RATE_LIMIT_ENABLED"] = True
            if "MEMORY_COMPRESSION" not in config_data:
                config_data["MEMORY_COMPRESSION"] = True
        
        elif profile == "development":
            # Более мягкие настройки для разработки
            if "RATE_LIMIT_ENABLED" not in config_data:
                config_data["RATE_LIMIT_ENABLED"] = False
            if "DOCS_ENABLED" not in config_data:
                config_data["DOCS_ENABLED"] = True
        
        # Автоматическая генерация секретов если не заданы
        if not config_data.get("JWT_SECRET"):
            import secrets
            import base64
            config_data["JWT_SECRET"] = base64.urlsafe_b64encode(
                secrets.token_bytes(32)
            ).decode('utf-8')
            self.migration_warnings.append(
                "JWT_SECRET сгенерирован автоматически для безопасности"
            )
    
    def apply_compatibility_settings(self, config) -> None:
        """
        Применение настроек совместимости к объекту конфигурации.
        
        Args:
            config: Объект конфигурации
        """
        
        # Добавление legacy атрибутов для обратной совместимости
        if hasattr(config, 'security'):
            # Legacy атрибуты для Version 1
            config.JWT_SECRET = config.security.jwt_secret
            config.JWT_ALGORITHM = config.security.jwt_algorithm
            config.CORS_ORIGINS = config.security.cors_origins
            
            # Совместимость с изменениями названий
            config.CORS_ALLOW_ORIGINS = config.security.cors_origins
            config.CORS_ALLOW_CREDENTIALS = config.security.cors_allow_credentials
        
        if hasattr(config, 'api'):
            # Legacy атрибуты для Version 1
            config.HOST = config.api.host
            config.PORT = config.api.port
            config.DEBUG = getattr(config, 'DEBUG', False)
        
        if hasattr(config, 'memory'):
            # Legacy атрибуты для Version 2
            config.MEMORY_ROOT = config.memory.memory_root
            config.MEMORY_BATCH_SIZE = config.memory.memory_batch_size
            config.EVIDENCE_PATH = config.memory.evidence_path
        
        if hasattr(config, 'logging'):
            # Legacy атрибуты для обеих версий
            config.LOG_LEVEL = config.logging.log_level
        
        if hasattr(config, 'monitoring'):
            # Legacy атрибуты для Version 2
            config.OTEL_ENABLED = config.monitoring.otel_enabled
            config.OTEL_SERVICE_NAME = config.monitoring.otel_service_name
            config.METRICS_ENABLED = config.monitoring.metrics_enabled
        
        # Добавляем legacy пути если они есть
        if hasattr(config, 'legacy'):
            config.MANIFEST_PATH = config.legacy.get('manifest_path', 'manifest/cd_index_baseline.json')
            config.CANON_INDEX_PATH = config.legacy.get('canon_index_path', 'docs/CANON/INDEX.md')
        
        logging.info(f"Применены настройки совместимости для режима: {self.compatibility_mode.value}")
    
    def get_compatibility_mapping(self, key: str) -> Optional[CompatibilityMapping]:
        """Получение сопоставления для ключа."""
        return self.COMPATIBILITY_MAPPINGS.get(key)
    
    def list_deprecated_settings(self) -> List[Dict[str, str]]:
        """Получение списка устаревших настроек."""
        return [
            {
                "deprecated_key": key,
                "replacement": info["replacement"],
                "message": info["migration_message"]
            }
            for key, info in self.DEPRECATED_SETTINGS.items()
        ]
    
    def generate_compatibility_report(self, config_data: Dict[str, Any]) -> Dict[str, Any]:
        """Генерация отчета о совместимости конфигурации."""
        
        detected_mode = self.detect_version_from_config(config_data)
        
        # Анализ используемых настроек
        used_v1_settings = []
        used_v2_settings = []
        used_unified_settings = []
        deprecated_usage = []
        
        for key, value in config_data.items():
            if key in self.COMPATIBILITY_MAPPINGS:
                mapping = self.COMPATIBILITY_MAPPINGS[key]
                if mapping.version_1_key == key:
                    used_v1_settings.append(key)
                elif mapping.version_2_key == key:
                    used_v2_settings.append(key)
                else:
                    used_unified_settings.append(key)
            
            if key in self.DEPRECATED_SETTINGS:
                deprecated_usage.append(key)
        
        # Рекомендации по миграции
        migration_recommendations = []
        
        if detected_mode == CompatibilityMode.VERSION_1_ONLY:
            migration_recommendations.append(
                "Рекомендуется миграция на Version 2 для получения новых возможностей"
            )
        
        if detected_mode == CompatibilityMode.VERSION_2_ONLY:
            migration_recommendations.append(
                "Сохранить совместимость с Version 1 для существующих интеграций"
            )
        
        if deprecated_usage:
            migration_recommendations.append(
                f"Найдены устаревшие настройки: {', '.join(deprecated_usage)}"
            )
        
        return {
            "detected_mode": detected_mode.value,
            "version": self.detected_version,
            "used_settings": {
                "version_1": used_v1_settings,
                "version_2": used_v2_settings,
                "unified": used_unified_settings
            },
            "deprecated_usage": deprecated_usage,
            "migration_warnings": self.migration_warnings,
            "recommendations": migration_recommendations,
            "is_fully_compatible": len(deprecated_usage) == 0
        }
    
    def create_migration_script(self, output_path: str = "config_migration.py") -> None:
        """Создание скрипта миграции конфигурации."""
        
        script_content = f'''#!/usr/bin/env python3
"""
Скрипт автоматической миграции конфигурации Version 1 -> Version 2.

Автоматически обновляет .env файлы и конфигурационные файлы
для обеспечения совместимости с новой архитектурой.
"""

import os
import re
from pathlib import Path

def migrate_env_file(input_path: str = ".env", output_path: str = ".env.migrated"):
    """Миграция .env файла."""
    
    # Сопоставления для миграции
    migrations = {{
        "JWT_EXPIRE_MINUTES": "JWT_ACCESS_TOKEN_EXPIRE_MINUTES",
        "CORS_ORIGINS": "CORS_ALLOW_ORIGINS",
        "SEARCH_CACHE_SIZE": "LRU_CACHE_SIZE",
        "TELEMETRY_ENABLED": "OTEL_ENABLED",
    }}
    
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Применение миграций
        for old_key, new_key in migrations.items():
            pattern = rf'^{re.escape(old_key)}=(.+)$'
            replacement = f'{{new_key}}=\\1'
            content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
        
        # Добавление новых настроек Version 2
        new_settings = '''
        
        # Добавляем настройки Version 2
        v2_settings = [
            "MEMORY_ROOT=memory",
            "MEMORY_BATCH_SIZE=50", 
            "MEMORY_FLUSH_INTERVAL=5.0",
            "OTEL_SERVICE_NAME=iskra-api",
            "ASYNC_POOL_SIZE=4",
            "METRICS_ENABLED=true"
        ]
        
        for setting in v2_settings:
            script_content += f'\n        "{setting}",'
        
        script_content += '''
        ]
        
        # Проверяем, что новая настройка уже не существует
        for setting in new_settings:
            key = setting.split('=')[0]
            if not re.search(rf'^{re.escape(key)}=', content, re.MULTILINE):
                content += f"\\n{setting}"
        
        # Сохранение мигрированного файла
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# Мигрированная конфигурация\\n")
            f.write("# Автоматически создано VersionCompatibility\\n\\n")
            f.write(content)
        
        print(f"Миграция завершена: {{output_path}}")
        return True
        
    except Exception as e:
        print(f"Ошибка миграции: {{e}}")
        return False

if __name__ == "__main__":
    migrate_env_file()
'''
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        # Делаем файл исполняемым
        os.chmod(output_path, 0o755)
        
        logging.info(f"Скрипт миграции создан: {output_path}")