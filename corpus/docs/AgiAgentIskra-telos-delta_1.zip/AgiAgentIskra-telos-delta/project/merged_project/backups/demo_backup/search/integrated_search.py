"""Интегрированная поисковая система объединяющая возможности Version 1 и Version 2.

Этот модуль объединяет:
1. GraphRAG возможности из Version 1 
2. O(log n) оптимизацию из Version 2
3. Поддержку синхронных и асинхронных операций
4. Конфигурируемую производительность

Режимы поиска:
- Legacy Mode: использует Version 1 (O(n)) с GraphRAG
- Modern Mode: использует Version 2 (O(log n)) оптимизацию
- Hybrid Mode: автоматический выбор алгоритма
- GraphRAG Mode: с расширенными возможностями анализа
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Any, Union, Tuple
from concurrent.futures import ThreadPoolExecutor
import json

from .legacy_adapter import LegacyVectorSearch
from .modern_adapter import ModernVectorSearch
from .performance_config import SearchMode, PerformanceConfig

logger = logging.getLogger(__name__)

@dataclass
class SearchResult:
    """Результат поиска с метаданными."""
    doc_id: str
    chunk_id: int
    content: str
    score: float
    source: str
    search_mode: str
    search_time_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SearchMetrics:
    """Метрики производительности поиска."""
    search_time_ms: float
    mode_used: str
    results_count: int
    cache_hit: bool = False
    index_used: bool = False
    additional_info: Dict[str, Any] = field(default_factory=dict)

class IntegratedSearch:
    """Основной класс интегрированной поисковой системы.
    
    Обеспечивает единый интерфейс для различных режимов поиска
    с автоматическим выбором оптимального алгоритма.
    """
    
    def __init__(self, config: PerformanceConfig):
        """Инициализация интегрированного поиска.
        
        Args:
            config: Конфигурация производительности и режимов поиска
        """
        self.config = config
        self.legacy_search = LegacyVectorSearch(config.legacy_config)
        self.modern_search = ModernVectorSearch(config.modern_config)
        
        # Метрики производительности
        self.metrics_history: List[SearchMetrics] = []
        self.search_count = 0
        self.cache: Dict[str, Tuple[List[SearchResult], SearchMetrics]] = {}
        
        # Пул потоков для синхронных операций
        self.thread_pool = ThreadPoolExecutor(max_workers=config.max_workers)
        
        logger.info(f"Интегрированная поисковая система инициализирована в режиме: {config.default_mode}")
    
    async def search(self, query: str, **kwargs) -> Tuple[List[SearchResult], SearchMetrics]:
        """Основной метод поиска с автоматическим выбором режима.
        
        Args:
            query: Поисковый запрос
            **kwargs: Дополнительные параметры поиска
            
        Returns:
            Кортеж (результаты, метрики)
        """
        start_time = time.time()
        self.search_count += 1
        
        # Проверка кэша
        cache_key = self._generate_cache_key(query, kwargs)
        cached_result = self._get_cached_result(cache_key)
        if cached_result:
            logger.debug("Результат получен из кэша")
            return cached_result
        
        # Определение режима поиска
        search_mode = self._determine_search_mode(query, kwargs)
        
        try:
            if search_mode == SearchMode.LEGACY:
                results, mode_metrics = await self._legacy_search(query, **kwargs)
            elif search_mode == SearchMode.MODERN:
                results, mode_metrics = await self._modern_search(query, **kwargs)
            elif search_mode == SearchMode.GRAPHRAG:
                results, mode_metrics = await self._graphrag_search(query, **kwargs)
            else:  # HYBRID
                results, mode_metrics = await self._hybrid_search(query, **kwargs)
            
            # Создание метрик
            search_time = (time.time() - start_time) * 1000
            metrics = SearchMetrics(
                search_time_ms=search_time,
                mode_used=search_mode.value,
                results_count=len(results),
                index_used=search_mode in [SearchMode.MODERN, SearchMode.HYBRID],
                additional_info=mode_metrics
            )
            
            # Кэширование результата
            self._cache_result(cache_key, results, metrics)
            
            # Сохранение метрик
            self.metrics_history.append(metrics)
            if len(self.metrics_history) > self.config.metrics_history_size:
                self.metrics_history.pop(0)
            
            return results, metrics
            
        except Exception as e:
            logger.error(f"Ошибка поиска в режиме {search_mode}: {e}")
            # Fallback к базовому поиску
            return await self._fallback_search(query, str(e))
    
    def _determine_search_mode(self, query: str, kwargs: Dict) -> SearchMode:
        """Определяет оптимальный режим поиска на основе запроса и конфигурации.
        
        Args:
            query: Поисковый запрос
            kwargs: Дополнительные параметры
            
        Returns:
            Оптимальный режим поиска
        """
        # Явное указание режима
        if 'mode' in kwargs:
            try:
                return SearchMode(kwargs['mode'])
            except ValueError:
                logger.warning(f"Неизвестный режим поиска: {kwargs['mode']}")
        
        # Режим по умолчанию из конфигурации
        default_mode = self.config.default_mode
        
        # Автоматический выбор на основе характеристик запроса
        if default_mode == SearchMode.HYBRID:
            return self._auto_select_mode(query)
        
        return default_mode
    
    def _auto_select_mode(self, query: str) -> SearchMode:
        """Автоматический выбор режима на основе характеристик запроса.
        
        Args:
            query: Поисковый запрос
            
        Returns:
            Выбранный режим поиска
        """
        query_length = len(query.split())
        query_complexity = len(set(query.lower().split()))
        
        # Простые запросы - современный режим
        if query_length <= 3 and query_complexity <= 3:
            return SearchMode.MODERN
        
        # Сложные запросы с GraphRAG
        if query_length >= 10 or any(word in query.lower() for word in 
                                   ['отношение', 'связь', 'как связаны', 'объясни', 'анализ']):
            return SearchMode.GRAPHRAG
        
        # Средние запросы - гибридный режим
        return SearchMode.HYBRID
    
    async def _legacy_search(self, query: str, **kwargs) -> Tuple[List[SearchResult], Dict]:
        """Поиск в legacy режиме (Version 1)."""
        start_time = time.time()
        
        # Параметры для legacy поиска
        legacy_kwargs = {
            'k': kwargs.get('k', self.config.default_k),
            'use_graph': kwargs.get('use_graph', True),
            'use_vector': kwargs.get('use_vector', True),
            'evidence_path': kwargs.get('evidence_path', self.config.evidence_path)
        }
        
        results = await self.legacy_search.search(query, **legacy_kwargs)
        
        # Преобразование в SearchResult
        search_results = []
        for result in results:
            search_results.append(SearchResult(
                doc_id=result.doc_id,
                chunk_id=result.chunk_id,
                content=result.content,
                score=result.score,
                source=result.source,
                search_mode=SearchMode.LEGACY.value,
                metadata=result.metadata or {}
            ))
        
        mode_metrics = {
            'graph_used': legacy_kwargs['use_graph'],
            'vector_used': legacy_kwargs['use_vector'],
            'search_time_ms': (time.time() - start_time) * 1000
        }
        
        return search_results, mode_metrics
    
    async def _modern_search(self, query: str, **kwargs) -> Tuple[List[SearchResult], Dict]:
        """Поиск в современном режиме (Version 2)."""
        start_time = time.time()
        
        # Параметры для современного поиска
        modern_kwargs = {
            'k': kwargs.get('k', self.config.default_k),
            'use_index': kwargs.get('use_index', True),
            'evidence_path': kwargs.get('evidence_path', self.config.evidence_path)
        }
        
        results = await self.modern_search.search_async(query, **modern_kwargs)
        
        # Преобразование в SearchResult
        search_results = []
        for result in results:
            search_results.append(SearchResult(
                doc_id=result.doc_id,
                chunk_id=result.chunk_id,
                content=result.content,
                score=result.score,
                source='modern',
                search_mode=SearchMode.MODERN.value,
                metadata={'async_search': True}
            ))
        
        mode_metrics = {
            'index_used': modern_kwargs['use_index'],
            'cache_hits': self.modern_search.get_cache_stats().get('hits', 0),
            'search_time_ms': (time.time() - start_time) * 1000
        }
        
        return search_results, mode_metrics
    
    async def _graphrag_search(self, query: str, **kwargs) -> Tuple[List[SearchResult], Dict]:
        """Поиск в режиме GraphRAG."""
        start_time = time.time()
        
        # GraphRAG поиск через legacy адаптер с принудительным включением graph
        graph_kwargs = {
            'k': kwargs.get('k', self.config.default_k),
            'use_graph': True,
            'use_vector': kwargs.get('use_vector', True),
            'evidence_path': kwargs.get('evidence_path', self.config.evidence_path)
        }
        
        results = await self.legacy_search.search(query, **graph_kwargs)
        
        # Преобразование в SearchResult с метаданными GraphRAG
        search_results = []
        for result in results:
            metadata = result.metadata or {}
            metadata.update({
                'graphrag_mode': True,
                'entity_analysis': metadata.get('entities', []),
                'relationship_analysis': metadata.get('relationships', [])
            })
            
            search_results.append(SearchResult(
                doc_id=result.doc_id,
                chunk_id=result.chunk_id,
                content=result.content,
                score=result.score,
                source=result.source,
                search_mode=SearchMode.GRAPHRAG.value,
                metadata=metadata
            ))
        
        mode_metrics = {
            'graph_used': True,
            'entity_count': len(metadata.get('entities', [])),
            'relationship_count': len(metadata.get('relationships', [])),
            'search_time_ms': (time.time() - start_time) * 1000
        }
        
        return search_results, mode_metrics
    
    async def _hybrid_search(self, query: str, **kwargs) -> Tuple[List[SearchResult], Dict]:
        """Гибридный поиск, объединяющий оба подхода."""
        start_time = time.time()
        k = kwargs.get('k', self.config.default_k)
        
        # Параллельный запуск обоих поисков
        legacy_task = self._legacy_search(query, **{**kwargs, 'k': k // 2})
        modern_task = self._modern_search(query, **{**kwargs, 'k': k // 2})
        
        legacy_results, legacy_metrics = await legacy_task
        modern_results, modern_metrics = await modern_task
        
        # Объединение и ранжирование результатов
        all_results = legacy_results + modern_results
        all_results.sort(key=lambda x: x.score, reverse=True)
        
        # Применение весов и финальное ранжирование
        weighted_results = []
        for result in all_results[:k]:
            if result.source == 'legacy':
                result.score *= self.config.legacy_weight
            elif result.source == 'modern':
                result.score *= self.config.modern_weight
            
            result.search_mode = SearchMode.HYBRID.value
            weighted_results.append(result)
        
        mode_metrics = {
            'legacy_results': len(legacy_results),
            'modern_results': len(modern_results),
            'legacy_time_ms': legacy_metrics['search_time_ms'],
            'modern_time_ms': modern_metrics['search_time_ms'],
            'total_search_time_ms': (time.time() - start_time) * 1000
        }
        
        return weighted_results, mode_metrics
    
    async def _fallback_search(self, query: str, error_msg: str) -> Tuple[List[SearchResult], SearchMetrics]:
        """Поиск при ошибках с fallback логикой."""
        logger.warning(f"Используется fallback поиск: {error_msg}")
        
        try:
            # Попытка современного поиска
            results, _ = await self.modern_search.search_async(query, k=self.config.default_k)
            
            search_results = []
            for result in results:
                search_results.append(SearchResult(
                    doc_id=result.doc_id,
                    chunk_id=result.chunk_id,
                    content=result.content,
                    score=result.score * 0.8,  # Понижение оценки для fallback
                    source='fallback',
                    search_mode='fallback',
                    metadata={'fallback_reason': error_msg}
                ))
            
            metrics = SearchMetrics(
                search_time_ms=0,
                mode_used='fallback',
                results_count=len(search_results),
                additional_info={'error': error_msg}
            )
            
            return search_results, metrics
            
        except Exception as e:
            logger.error(f"Fallback поиск также не удался: {e}")
            return [], SearchMetrics(
                search_time_ms=0,
                mode_used='error',
                results_count=0,
                additional_info={'final_error': str(e)}
            )
    
    def _generate_cache_key(self, query: str, kwargs: Dict) -> str:
        """Генерация ключа кэша."""
        # Простая хэш-функция для кэша
        cache_str = f"{query}:{json.dumps(kwargs, sort_keys=True)}"
        return str(hash(cache_str))
    
    def _get_cached_result(self, cache_key: str) -> Optional[Tuple[List[SearchResult], SearchMetrics]]:
        """Получение результата из кэша."""
        if cache_key in self.cache:
            result, metrics = self.cache[cache_key]
            # Обновление метрик кэша
            metrics.cache_hit = True
            return result, metrics
        return None
    
    def _cache_result(self, cache_key: str, results: List[SearchResult], metrics: SearchMetrics):
        """Кэширование результата."""
        if len(self.cache) >= self.config.cache_size:
            # Удаление oldest элемента
            oldest_key = next(iter(self.cache))
            del self.cache[oldest_key]
        
        self.cache[cache_key] = (results, metrics)
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Получение отчета о производительности."""
        if not self.metrics_history:
            return {"message": "Нет данных о производительности"}
        
        total_searches = len(self.metrics_history)
        avg_time = sum(m.search_time_ms for m in self.metrics_history) / total_searches
        mode_distribution = {}
        
        for metrics in self.metrics_history:
            mode = metrics.mode_used
            mode_distribution[mode] = mode_distribution.get(mode, 0) + 1
        
        cache_hit_rate = sum(1 for m in self.metrics_history if m.cache_hit) / total_searches
        
        return {
            "total_searches": total_searches,
            "average_search_time_ms": round(avg_time, 2),
            "mode_distribution": mode_distribution,
            "cache_hit_rate": round(cache_hit_rate, 3),
            "cache_size": len(self.cache),
            "recent_metrics": self.metrics_history[-10:]  # Последние 10 поисков
        }
    
    def clear_cache(self):
        """Очистка кэша."""
        self.cache.clear()
        logger.info("Кэш поисковой системы очищен")
    
    def clear_performance_history(self):
        """Очистка истории производительности."""
        self.metrics_history.clear()
        logger.info("История производительности очищена")
    
    async def build_indexes(self):
        """Построение индексов для современного поиска."""
        await self.modern_search.build_index()
        logger.info("Индексы построены")
    
    def close(self):
        """Закрытие ресурсов."""
        self.thread_pool.shutdown(wait=True)
        logger.info("Ресурсы поисковой системы освобождены")
    
    async def __aenter__(self):
        """Асинхронный вход в контекст."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Асинхронный выход из контекста."""
        self.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

# Функции-помощники для совместимости
async def integrated_search(query: str, config: PerformanceConfig = None, **kwargs) -> Tuple[List[SearchResult], SearchMetrics]:
    """Упрощенная функция интегрированного поиска."""
    if config is None:
        config = PerformanceConfig()
    
    async with IntegratedSearch(config) as searcher:
        return await searcher.search(query, **kwargs)

def create_integrated_search(config: PerformanceConfig = None) -> IntegratedSearch:
    """Создание экземпляра интегрированного поиска."""
    if config is None:
        config = PerformanceConfig()
    return IntegratedSearch(config)