"""
Значения по умолчанию для синхронизированной конфигурации.

Предоставляет безопасные значения по умолчанию для всех настроек
с учетом различных профилей окружения и требований совместимости.
"""

import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum
from pathlib import Path


class DefaultProfile(Enum):
    """Профили значений по умолчанию."""
    MINIMAL = "minimal"           # Минимальные настройки
    DEVELOPMENT = "development"   # Разработка
    PRODUCTION = "production"     # Продакшен
    TESTING = "testing"           # Тестирование
    SECURITY = "security"         # Максимальная безопасность
    PERFORMANCE = "performance"   # Максимальная производительность


@dataclass
class DefaultSettings:
    """Класс значений по умолчанию."""
    
    def get_defaults(self, profile: Optional[DefaultProfile] = None) -> Dict[str, Any]:
        """
        Получение значений по умолчанию для профиля.
        
        Args:
            profile: Профиль настроек
            
        Returns:
            Словарь с настройками по умолчанию
        """
        if profile is None:
            profile = self._detect_profile()
        
        # Базовая конфигурация
        defaults = self._get_base_defaults()
        
        # Профильно-специфичные настройки
        profile_defaults = self._get_profile_defaults(profile)
        defaults.update(profile_defaults)
        
        return defaults
    
    def _detect_profile(self) -> DefaultProfile:
        """Автоматическое определение профиля."""
        env_profile = os.getenv("ENVIRONMENT_PROFILE", "").lower()
        
        if env_profile in ["prod", "production"]:
            return DefaultProfile.PRODUCTION
        elif env_profile in ["test", "testing"]:
            return DefaultProfile.TESTING
        elif env_profile in ["dev", "development"]:
            return DefaultProfile.DEVELOPMENT
        else:
            return DefaultProfile.DEVELOPMENT
    
    def _get_base_defaults(self) -> Dict[str, Any]:
        """Базовая конфигурация по умолчанию."""
        return {
            # === ОСНОВНЫЕ НАСТРОЙКИ ПРИЛОЖЕНИЯ ===
            "APP_NAME": "Iskra API",
            "APP_VERSION": "1.0.0",
            "DEBUG": False,
            "ENVIRONMENT_PROFILE": "development",
            
            # === СЕТЕВЫЕ НАСТРОЙКИ ===
            "HOST": "0.0.0.0",
            "PORT": 8000,
            
            # === CORS НАСТРОЙКИ ===
            "CORS_ORIGINS": "http://localhost:3000",
            "CORS_ALLOW_CREDENTIALS": True,
            "CORS_ALLOW_METHODS": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "CORS_ALLOW_HEADERS": ["Authorization", "Content-Type", "X-Requested-With"],
            
            # === JWT НАСТРОЙКИ ===
            "JWT_SECRET": "",  # Будет сгенерирован автоматически
            "JWT_ALGORITHM": "HS256",
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": 30,
            "JWT_REFRESH_TOKEN_EXPIRE_DAYS": 7,
            
            # === RATE LIMITING ===
            "RATE_LIMIT_ENABLED": True,
            "RATE_LIMIT_REQUESTS": 100,
            "RATE_LIMIT_BURST": 200,
            
            # === БЕЗОПАСНОСТЬ ===
            "SECURITY_HEADERS_ENABLED": True,
            "STRICT_TRANSPORT_SECURITY": True,
            "CONTENT_SECURITY_POLICY": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'",
            
            # === НАСТРОЙКИ ПАМЯТИ ===
            "MEMORY_ROOT": "memory",
            "EVIDENCE_PATH": "memory/evidence.jsonl",
            "WORKING_MEMORY_PATH": "memory/working.jsonl",
            "LONG_TERM_MEMORY_PATH": "memory/long_term.jsonl",
            "MEMORY_BATCH_SIZE": 50,
            "MEMORY_FLUSH_INTERVAL": 5.0,
            "MEMORY_AUTO_FLUSH": True,
            "MEMORY_COMPRESSION": False,
            "MEMORY_COMPRESSION_ALGORITHM": "gzip",
            "MEMORY_MAX_SIZE_MB": 1024,
            "MEMORY_ASYNC": True,
            "MEMORY_CONCURRENT_OPS": 4,
            
            # === НАСТРОЙКИ ПОИСКА ===
            "DEFAULT_SEARCH_K": 5,
            "MAX_SEARCH_RESULTS": 50,
            "SEARCH_TIMEOUT": 30.0,
            "SEARCH_CACHE_ENABLED": True,
            "SEARCH_CACHE_SIZE": 1000,
            "SEARCH_CACHE_TTL": 3600,
            "VECTOR_INDEX_ENABLED": True,
            "VECTOR_INDEX_REFRESH": 300,
            "VECTOR_INDEX_AUTO_REBUILD": True,
            "SIMILARITY_THRESHOLD": 0.7,
            "SIMILARITY_ALGORITHM": "cosine",
            "SEARCH_PARALLEL_THREADS": 4,
            "SEARCH_BATCH_PROCESSING": True,
            
            # === API НАСТРОЙКИ ===
            "API_VERSION_PREFIX": "/v1",
            "API_VERSION_HEADER": "X-API-Version",
            "MIDDLEWARE_ENABLED": True,
            "CORS_MIDDLEWARE_ENABLED": True,
            "AUTH_MIDDLEWARE_ENABLED": True,
            "LOGGING_MIDDLEWARE_ENABLED": True,
            "REQUEST_SIZE_LIMIT_MB": 100,
            "REQUEST_TIMEOUT": 300,
            "DOCS_ENABLED": True,
            "DOCS_URL": "/docs",
            "REDOC_URL": "/redoc",
            "AUTO_RELOAD": False,
            "WORKERS": 1,
            
            # === ПРОИЗВОДИТЕЛЬНОСТЬ ===
            "ASYNC_POOL_SIZE": 4,
            "ASYNC_QUEUE_SIZE": 1000,
            "ASYNC_TIMEOUT": 30.0,
            "IO_THREAD_POOL_SIZE": 10,
            "CPU_THREAD_POOL_SIZE": 4,
            "CONNECTION_POOL_SIZE": 10,
            "CONNECTION_POOL_MAX_OVERFLOW": 20,
            "CONNECTION_POOL_TIMEOUT": 30,
            "MEMORY_POOL_ENABLED": True,
            "GC_OPTIMIZATION": True,
            "LRU_CACHE_ENABLED": True,
            "LRU_CACHE_SIZE": 1000,
            "REDIS_CACHE_ENABLED": False,
            
            # === ЛОГИРОВАНИЕ ===
            "LOG_LEVEL": "INFO",
            "LOG_FORMAT": "json",
            "LOG_DATE_FORMAT": "%Y-%m-%d %H:%M:%S",
            "CONSOLE_LOGGING": True,
            "FILE_LOGGING": False,
            "SYSLOG_LOGGING": False,
            "LOG_FILE_PATH": "logs/app.log",
            "LOG_FILE_MAX_SIZE_MB": 100,
            "LOG_FILE_BACKUP_COUNT": 5,
            "ASYNC_LOGGING": True,
            "LOG_BUFFER_SIZE": 1000,
            "LOG_FLUSH_INTERVAL": 1.0,
            "STRUCTURED_LOGGING": True,
            "INCLUDE_TRACE_ID": True,
            "INCLUDE_USER_ID": False,
            
            # === МОНИТОРИНГ ===
            "METRICS_ENABLED": True,
            "METRICS_PORT": 9090,
            "METRICS_PATH": "/metrics",
            "HEALTH_CHECK_ENABLED": True,
            "HEALTH_CHECK_INTERVAL": 60,
            "HEALTH_CHECK_TIMEOUT": 5.0,
            "OTEL_ENABLED": True,
            "OTEL_SERVICE_NAME": "iskra-api",
            "OTEL_SERVICE_VERSION": "1.0.0",
            "ALERTS_ENABLED": False,
            "ALERT_WEBHOOK_URL": "",
            "ALERT_CPU_THRESHOLD": 80.0,
            "ALERT_MEMORY_THRESHOLD": 85.0,
            
            # === БАЗА ДАННЫХ ===
            "DATABASE_URL": None,
            "DATABASE_POOL_SIZE": 5,
            "DATABASE_MAX_OVERFLOW": 10,
            "DATABASE_TIMEOUT": 30,
            "DATABASE_ECHO": False,
            "DATABASE_POOL_RECYCLE": 3600,
            "MIGRATION_ENABLED": True,
            "MIGRATION_PATH": "migrations",
        }
    
    def _get_profile_defaults(self, profile: DefaultProfile) -> Dict[str, Any]:
        """Получение профильно-специфичных настроек."""
        profile_map = {
            DefaultProfile.DEVELOPMENT: self._get_development_defaults(),
            DefaultProfile.PRODUCTION: self._get_production_defaults(),
            DefaultProfile.TESTING: self._get_testing_defaults(),
            DefaultProfile.SECURITY: self._get_security_defaults(),
            DefaultProfile.PERFORMANCE: self._get_performance_defaults(),
            DefaultProfile.MINIMAL: self._get_minimal_defaults(),
        }
        
        return profile_map.get(profile, {})
    
    def _get_development_defaults(self) -> Dict[str, Any]:
        """Настройки для разработки."""
        return {
            "DEBUG": True,
            "LOG_LEVEL": "DEBUG",
            "LOG_FORMAT": "colored",
            "CONSOLE_LOGGING": True,
            "FILE_LOGGING": False,
            "DOCS_ENABLED": True,
            "AUTO_RELOAD": True,
            "RATE_LIMIT_ENABLED": False,
            "SECURITY_HEADERS_ENABLED": False,
            "METRICS_ENABLED": True,
            "OTEL_ENABLED": True,
            "DATABASE_ECHO": True,
            "MEMORY_COMPRESSION": False,
            "SEARCH_CACHE_ENABLED": False,
        }
    
    def _get_production_defaults(self) -> Dict[str, Any]:
        """Настройки для продакшена."""
        return {
            "DEBUG": False,
            "LOG_LEVEL": "WARNING",
            "LOG_FORMAT": "json",
            "CONSOLE_LOGGING": False,
            "FILE_LOGGING": True,
            "LOG_FILE_PATH": "/var/log/iskra/app.log",
            "DOCS_ENABLED": False,
            "AUTO_RELOAD": False,
            "WORKERS": 4,
            "RATE_LIMIT_ENABLED": True,
            "RATE_LIMIT_REQUESTS": 50,
            "SECURITY_HEADERS_ENABLED": True,
            "STRICT_TRANSPORT_SECURITY": True,
            "MEMORY_COMPRESSION": True,
            "MEMORY_MAX_SIZE_MB": 2048,
            "SEARCH_CACHE_ENABLED": True,
            "SEARCH_CACHE_SIZE": 5000,
            "METRICS_ENABLED": True,
            "OTEL_ENABLED": True,
            "ALERTS_ENABLED": True,
            "DATABASE_ECHO": False,
            "ASYNC_LOGGING": True,
            "STRUCTURED_LOGGING": True,
            "INCLUDE_TRACE_ID": True,
            "INCLUDE_USER_ID": False,
        }
    
    def _get_testing_defaults(self) -> Dict[str, Any]:
        """Настройки для тестирования."""
        return {
            "DEBUG": False,
            "LOG_LEVEL": "ERROR",
            "LOG_FORMAT": "text",
            "CONSOLE_LOGGING": True,
            "FILE_LOGGING": False,
            "DOCS_ENABLED": False,
            "AUTO_RELOAD": False,
            "WORKERS": 1,
            "RATE_LIMIT_ENABLED": False,
            "SECURITY_HEADERS_ENABLED": False,
            "METRICS_ENABLED": False,
            "OTEL_ENABLED": False,
            "ALERTS_ENABLED": False,
            "DATABASE_ECHO": False,
            "ASYNC_LOGGING": False,
            "MEMORY_ASYNC": False,
            "MEMORY_COMPRESSION": False,
            "SEARCH_CACHE_ENABLED": False,
        }
    
    def _get_security_defaults(self) -> Dict[str, Any]:
        """Настройки для максимальной безопасности."""
        return {
            "DEBUG": False,
            "LOG_LEVEL": "INFO",
            "LOG_FORMAT": "json",
            "CONSOLE_LOGGING": False,
            "FILE_LOGGING": True,
            "LOG_FILE_PATH": "/var/log/iskra/secure.log",
            "DOCS_ENABLED": False,
            "AUTO_RELOAD": False,
            "WORKERS": 1,
            "RATE_LIMIT_ENABLED": True,
            "RATE_LIMIT_REQUESTS": 20,
            "RATE_LIMIT_BURST": 50,
            "SECURITY_HEADERS_ENABLED": True,
            "STRICT_TRANSPORT_SECURITY": True,
            "CONTENT_SECURITY_POLICY": "default-src 'none'; script-src 'none'; style-src 'none'",
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": 15,
            "JWT_REFRESH_TOKEN_EXPIRE_DAYS": 1,
            "MEMORY_COMPRESSION": True,
            "MEMORY_ASYNC": True,
            "SEARCH_CACHE_ENABLED": False,
            "METRICS_ENABLED": True,
            "OTEL_ENABLED": True,
            "ALERTS_ENABLED": True,
            "DATABASE_ECHO": False,
            "ASYNC_LOGGING": False,
            "STRUCTURED_LOGGING": True,
            "INCLUDE_TRACE_ID": True,
            "INCLUDE_USER_ID": True,
        }
    
    def _get_performance_defaults(self) -> Dict[str, Any]:
        """Настройки для максимальной производительности."""
        return {
            "DEBUG": False,
            "LOG_LEVEL": "WARNING",
            "LOG_FORMAT": "json",
            "CONSOLE_LOGGING": False,
            "FILE_LOGGING": True,
            "LOG_FILE_PATH": "/var/log/iskra/perf.log",
            "DOCS_ENABLED": False,
            "AUTO_RELOAD": False,
            "WORKERS": 8,
            "ASYNC_POOL_SIZE": 16,
            "ASYNC_QUEUE_SIZE": 5000,
            "IO_THREAD_POOL_SIZE": 32,
            "CPU_THREAD_POOL_SIZE": 16,
            "CONNECTION_POOL_SIZE": 50,
            "CONNECTION_POOL_MAX_OVERFLOW": 100,
            "LRU_CACHE_SIZE": 10000,
            "MEMORY_BATCH_SIZE": 200,
            "MEMORY_ASYNC": True,
            "MEMORY_COMPRESSION": True,
            "SEARCH_PARALLEL_THREADS": 16,
            "SEARCH_CACHE_ENABLED": True,
            "SEARCH_CACHE_SIZE": 10000,
            "SEARCH_CACHE_TTL": 7200,
            "METRICS_ENABLED": True,
            "OTEL_ENABLED": True,
            "ASYNC_LOGGING": True,
            "STRUCTURED_LOGGING": True,
            "INCLUDE_TRACE_ID": False,
            "INCLUDE_USER_ID": False,
        }
    
    def _get_minimal_defaults(self) -> Dict[str, Any]:
        """Минимальные настройки."""
        return {
            "DEBUG": False,
            "LOG_LEVEL": "WARNING",
            "LOG_FORMAT": "text",
            "CONSOLE_LOGGING": True,
            "FILE_LOGGING": False,
            "DOCS_ENABLED": False,
            "AUTO_RELOAD": False,
            "WORKERS": 1,
            "RATE_LIMIT_ENABLED": False,
            "SECURITY_HEADERS_ENABLED": False,
            "METRICS_ENABLED": False,
            "OTEL_ENABLED": False,
            "ALERTS_ENABLED": False,
            "DATABASE_ECHO": False,
            "ASYNC_LOGGING": False,
            "MEMORY_ASYNC": False,
            "MEMORY_COMPRESSION": False,
            "SEARCH_CACHE_ENABLED": False,
        }
    
    def get_version_1_compatibility_defaults(self) -> Dict[str, Any]:
        """Значения по умолчанию для совместимости с Version 1."""
        return {
            # Основные настройки Version 1
            "JWT_SECRET": "",  # Будет сгенерирован автоматически
            "JWT_ALGORITHM": "HS256",
            "JWT_EXPIRE_MINUTES": 60,  # Для совместимости
            "CORS_ORIGINS": "http://localhost:3000",
            "EVIDENCE_PATH": "memory/evidence.jsonl",
            "MAX_SEARCH_RESULTS": 10,
            "DEFAULT_SEARCH_K": 5,
            "LOG_LEVEL": "INFO",
            "OTEL_ENABLED": True,
            
            # Настройки совместимости
            "CORS_ALLOW_CREDENTIALS": False,  # Version 1 поведение
            "RATE_LIMIT_ENABLED": False,     # Отключено в V1
            "SECURITY_HEADERS_ENABLED": True,
            "MEMORY_ASYNC": False,           # Синхронная память
        }
    
    def get_version_2_enhancements(self) -> Dict[str, Any]:
        """Новые возможности Version 2."""
        return {
            # Улучшенные настройки памяти
            "MEMORY_ROOT": "memory",
            "MEMORY_BATCH_SIZE": 50,
            "MEMORY_FLUSH_INTERVAL": 5.0,
            "MEMORY_AUTO_FLUSH": True,
            "MEMORY_COMPRESSION": False,
            
            # Производительность
            "ASYNC_POOL_SIZE": 4,
            "CONNECTION_POOL_SIZE": 10,
            "LRU_CACHE_SIZE": 1000,
            
            # Мониторинг
            "METRICS_ENABLED": True,
            "HEALTH_CHECK_ENABLED": True,
            "OTEL_SERVICE_NAME": "iskra-api",
            
            # Безопасность
            "RATE_LIMIT_ENABLED": True,
            "RATE_LIMIT_REQUESTS": 100,
            
            # Улучшенный JWT
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": 30,
            "JWT_REFRESH_TOKEN_EXPIRE_DAYS": 7,
        }
    
    def get_security_recommendations(self) -> Dict[str, List[str]]:
        """Рекомендации по безопасности."""
        return {
            "required": [
                "JWT_SECRET должен быть длинным и случайным",
                "CORS_ORIGINS должен содержать только доверенные домены",
                "RATE_LIMIT_ENABLED должен быть включен в продакшене",
                "SECURITY_HEADERS_ENABLED должен быть включен",
                "LOG_LEVEL должен быть INFO или выше в продакшене"
            ],
            "recommended": [
                "Использовать HTTPS в продакшене",
                "Настроить логирование в безопасное место",
                "Включить мониторинг и алерты",
                "Использовать сжатие для больших данных",
                "Настроить автоматическую очистку логов"
            ],
            "optional": [
                "Включить детальное логирование для отладки",
                "Настроить интеграцию с системой алертов",
                "Использовать Redis для кэширования",
                "Настроить балансировку нагрузки",
                "Включить автоматическое масштабирование"
            ]
        }
    
    def generate_env_template(self, profile: Optional[DefaultProfile] = None) -> str:
        """Генерация .env шаблона для профиля."""
        if profile is None:
            profile = DefaultProfile.DEVELOPMENT
        
        defaults = self.get_defaults(profile)
        
        template = []
        template.append(f"# Iskra API Configuration Template - {profile.value}")
        template.append("# Generated automatically - adjust values for your environment")
        template.append("")
        
        # Категории настроек
        categories = {
            "Основные настройки": ["APP_NAME", "APP_VERSION", "DEBUG", "ENVIRONMENT_PROFILE"],
            "Сетевые настройки": ["HOST", "PORT"],
            "CORS настройки": ["CORS_ORIGINS", "CORS_ALLOW_CREDENTIALS", "CORS_ALLOW_METHODS"],
            "JWT настройки": ["JWT_SECRET", "JWT_ALGORITHM", "JWT_ACCESS_TOKEN_EXPIRE_MINUTES"],
            "Настройки памяти": ["MEMORY_ROOT", "MEMORY_BATCH_SIZE", "MEMORY_FLUSH_INTERVAL"],
            "Настройки поиска": ["DEFAULT_SEARCH_K", "MAX_SEARCH_RESULTS", "SEARCH_TIMEOUT"],
            "Производительность": ["ASYNC_POOL_SIZE", "CONNECTION_POOL_SIZE", "LRU_CACHE_SIZE"],
            "Логирование": ["LOG_LEVEL", "LOG_FORMAT", "FILE_LOGGING"],
            "Мониторинг": ["METRICS_ENABLED", "HEALTH_CHECK_ENABLED", "OTEL_ENABLED"],
            "Безопасность": ["RATE_LIMIT_ENABLED", "SECURITY_HEADERS_ENABLED", "RATE_LIMIT_REQUESTS"],
        }
        
        for category, keys in categories.items():
            template.append(f"# === {category.upper()} ===")
            for key in keys:
                if key in defaults:
                    value = defaults[key]
                    if isinstance(value, list):
                        if all(isinstance(v, str) for v in value):
                            value = ",".join(v)
                        else:
                            value = str(value)
                    elif isinstance(value, bool):
                        value = str(value).lower()
                    template.append(f"{key}={value}")
            template.append("")
        
        return "\n".join(template)
    
    def get_compatibility_matrix(self) -> Dict[str, Dict[str, str]]:
        """Матрица совместимости между версиями."""
        return {
            "version_1_to_unified": {
                "JWT_EXPIRE_MINUTES": "JWT_ACCESS_TOKEN_EXPIRE_MINUTES",
                "CORS_ORIGINS": "CORS_ALLOW_ORIGINS",
                "SEARCH_CACHE_SIZE": "LRU_CACHE_SIZE",
                "TELEMETRY_ENABLED": "OTEL_ENABLED",
            },
            "version_2_enhancements": {
                "MEMORY_ROOT": "memory - корневая директория памяти",
                "MEMORY_BATCH_SIZE": "размер батча для асинхронной памяти",
                "MEMORY_FLUSH_INTERVAL": "интервал сброса памяти в секундах",
                "ASYNC_POOL_SIZE": "размер пула асинхронных операций",
                "METRICS_ENABLED": "включение метрик",
                "HEALTH_CHECK_ENABLED": "включение проверок здоровья",
            },
            "deprecated": {
                "JWT_EXPIRE_MINUTES": "используйте JWT_ACCESS_TOKEN_EXPIRE_MINUTES",
                "CORS_ORIGINS": "используйте CORS_ALLOW_ORIGINS",
                "SEARCH_CACHE_SIZE": "используйте LRU_CACHE_SIZE",
                "TELEMETRY_ENABLED": "используйте OTEL_ENABLED",
            }
        }
    
    def validate_defaults(self, profile: DefaultProfile = DefaultProfile.DEVELOPMENT) -> Dict[str, Any]:
        """Валидация значений по умолчанию."""
        defaults = self.get_defaults(profile)
        
        validation_result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "statistics": {}
        }
        
        try:
            # Проверка обязательных полей
            required_fields = [
                "APP_NAME", "APP_VERSION", "JWT_ALGORITHM", "LOG_LEVEL",
                "MEMORY_ROOT", "EVIDENCE_PATH", "DEFAULT_SEARCH_K"
            ]
            
            for field in required_fields:
                if field not in defaults:
                    validation_result["errors"].append(f"Отсутствует обязательное поле: {field}")
                    validation_result["is_valid"] = False
            
            # Проверка типов данных
            type_checks = {
                "PORT": int,
                "MEMORY_BATCH_SIZE": int,
                "DEFAULT_SEARCH_K": int,
                "LOG_LEVEL": str,
                "JWT_ALGORITHM": str,
            }
            
            for field, expected_type in type_checks.items():
                if field in defaults and not isinstance(defaults[field], expected_type):
                    validation_result["errors"].append(
                        f"Неверный тип поля {field}: ожидается {expected_type.__name__}"
                    )
                    validation_result["is_valid"] = False
            
            # Статистика
            validation_result["statistics"] = {
                "total_defaults": len(defaults),
                "profile": profile.value,
                "development_features": sum(1 for k, v in defaults.items() if k.startswith("DEBUG") and v),
                "production_features": sum(1 for k, v in defaults.items() if "ENABLED" in k and v),
            }
            
        except Exception as e:
            validation_result["errors"].append(f"Ошибка валидации: {str(e)}")
            validation_result["is_valid"] = False
        
        return validation_result