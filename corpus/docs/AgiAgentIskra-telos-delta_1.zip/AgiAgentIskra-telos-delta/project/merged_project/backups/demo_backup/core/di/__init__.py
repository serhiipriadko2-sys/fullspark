"""
Dependency Injection система для проекта "Искра"

Обеспечивает постепенную миграцию от Version 1 к Version 2
с сохранением полной обратной совместимости.
"""

from .di_container import DIContainer
from .service_registry import ServiceRegistry
from .dependency_wiring import DependencyWiring

__all__ = [
    'DIContainer',
    'ServiceRegistry', 
    'DependencyWiring'
]

# Глобальный экземпляр контейнера для использования в приложении
container = DIContainer()
registry = ServiceRegistry(container)
wiring = DependencyWiring(container, registry)