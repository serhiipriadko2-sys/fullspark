#!/usr/bin/env python3
"""
Примеры использования синхронизированной системы конфигурации.

Демонстрирует различные сценарии использования конфигурации:
- Базовое использование
- Работа с профилями
- Валидация и миграция
- Интеграция с FastAPI
- Работа с переменными окружения
"""

import os
import sys
import json
import logging
from pathlib import Path

# Добавляем путь к родительскому каталогу для импорта
sys.path.append(str(Path(__file__).parent.parent))

from config import (
    # Основные классы
    UnifiedConfig,
    get_config,
    init_config,
    reload_config,
    create_config,
    
    # Enum типы
    EnvironmentProfile,
    CompatibilityMode,
    ValidationLevel,
    DefaultProfile,
    
    # Компоненты
    EnvironmentManager,
    VersionCompatibility,
    ConfigMigrator,
    ConfigValidator,
    DefaultSettings,
    
    # Утилиты
    check_compatibility,
    validate_config,
    export_env_template,
    get_version_info,
)


def example_01_basic_usage():
    """Пример 1: Базовое использование конфигурации."""
    print("\n" + "="*60)
    print("ПРИМЕР 1: БАЗОВОЕ ИСПОЛЬЗОВАНИЕ")
    print("="*60)
    
    # Создание конфигурации для разработки
    config = create_config(profile=EnvironmentProfile.DEVELOPMENT)
    
    print(f"✅ Конфигурация создана для профиля: {config.profile.value}")
    print(f"✅ Приложение: {config.api.host}:{config.api.port}")
    print(f"✅ JWT алгоритм: {config.security.jwt_algorithm}")
    print(f"✅ Память: {config.memory.memory_root}")
    print(f"✅ Поиск: {config.search.default_search_k} результатов")
    print(f"✅ Логирование: {config.logging.log_level}")
    
    # Проверка режимов
    if config.is_production_mode():
        print("🔒 Режим продакшена")
    elif config.is_development_mode():
        print("🔧 Режим разработки")
    
    return config


def example_02_profiles():
    """Пример 2: Работа с профилями."""
    print("\n" + "="*60)
    print("ПРИМЕР 2: ПРОФИЛИ КОНФИГУРАЦИИ")
    print("="*60)
    
    profiles = [
        EnvironmentProfile.DEVELOPMENT,
        EnvironmentProfile.PRODUCTION,
        EnvironmentProfile.TESTING,
        EnvironmentProfile.STAGING,
    ]
    
    for profile in profiles:
        config = create_config(profile=profile)
        
        print(f"\n📋 Профиль: {profile.value}")
        print(f"   Debug: {config.api.docs_enabled}")
        print(f"   Docs: {config.api.docs_enabled}")
        print(f"   Rate Limit: {config.security.rate_limit_enabled}")
        print(f"   Metrics: {config.monitoring.metrics_enabled}")
        print(f"   Log Level: {config.logging.log_level}")


def example_03_security_validation():
    """Пример 3: Валидация безопасности."""
    print("\n" + "="*60)
    print("ПРИМЕР 3: ВАЛИДАЦИЯ БЕЗОПАСНОСТИ")
    print("="*60)
    
    # Создание конфигурации
    config = create_config(profile=EnvironmentProfile.PRODUCTION)
    
    # Валидация с проверкой безопасности
    validator = ConfigValidator(level=ValidationLevel.SECURITY)
    result = validator.validate_all_settings(config)
    
    print(f"✅ Валидация пройдена: {result.is_valid}")
    print(f"📊 Статистика:")
    print(f"   Проверено полей: {result.statistics['validated_fields']}")
    print(f"   Ошибок: {len(result.errors)}")
    print(f"   Предупреждений: {len(result.warnings)}")
    
    if result.errors:
        print("\n❌ Ошибки:")
        for error in result.errors:
            print(f"   - {error}")
    
    if result.warnings:
        print("\n⚠️  Предупреждения:")
        for warning in result.warnings:
            print(f"   - {warning}")
    
    # Получение отчета
    report = validator.get_validation_report(result)
    print(f"\n📄 Отчет валидации сохранен")


def example_04_environment_variables():
    """Пример 4: Работа с переменными окружения."""
    print("\n" + "="*60)
    print("ПРИМЕР 4: ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ")
    print("="*60)
    
    # Установка тестовых переменных окружения
    os.environ["JWT_SECRET"] = "test-secret-key-123456789"
    os.environ["CORS_ORIGINS"] = "https://example.com,https://app.example.com"
    os.environ["LOG_LEVEL"] = "DEBUG"
    os.environ["MEMORY_BATCH_SIZE"] = "100"
    
    # Создание менеджера окружения
    env_manager = EnvironmentManager()
    
    # Загрузка переменных
    env_vars = env_manager.load_from_environment()
    print(f"✅ Загружено переменных: {len(env_vars)}")
    
    # Валидация окружения
    validation = env_manager.validate_environment()
    print(f"✅ Валидация окружения: {validation['is_valid']}")
    
    if validation['errors']:
        print("❌ Ошибки в переменных:")
        for error in validation['errors']:
            print(f"   - {error}")
    
    # Получение информации о переменной
    jwt_info = env_manager.get_variable_info("JWT_SECRET")
    print(f"\n📋 Информация о JWT_SECRET:")
    print(f"   Описание: {jwt_info.description}")
    print(f"   Тип: {jwt_info.type.value}")
    print(f"   Обязательная: {jwt_info.required}")
    
    # Список всех переменных
    all_vars = env_manager.list_variables()
    print(f"\n📊 Всего переменных: {len(all_vars)}")


def example_05_migration():
    """Пример 5: Миграция конфигурации."""
    print("\n" + "="*60)
    print("ПРИМЕР 5: МИГРАЦИЯ КОНФИГУРАЦИИ")
    print("="*60)
    
    # Создание старой конфигурации Version 1
    old_config = {
        "JWT_SECRET": "old-secret",
        "JWT_EXPIRE_MINUTES": 60,  # Устаревшее название
        "CORS_ORIGINS": "http://localhost:3000",
        "EVIDENCE_PATH": "memory/evidence.jsonl",
        "LOG_LEVEL": "INFO",
        "OTEL_ENABLED": True,
    }
    
    # Создание мигратора
    migrator = ConfigMigrator()
    
    # Определение версии
    current_version = migrator.detect_config_version(old_config)
    print(f"📋 Текущая версия: {current_version}")
    
    # Миграция
    migrated_config = migrator.migrate_config(old_config)
    
    print(f"✅ Миграция завершена")
    print(f"📊 Изменения:")
    
    # Сравнение конфигураций
    original_keys = set(old_config.keys())
    migrated_keys = set(migrated_config.keys())
    added_keys = migrated_keys - original_keys
    
    if added_keys:
        print(f"   Добавлено настроек: {len(added_keys)}")
        for key in list(added_keys)[:5]:  # Показать первые 5
            print(f"     + {key}")
    
    # Создание отчета
    report = migrator.create_migration_report(old_config, migrated_config)
    print(f"\n📄 Отчет о миграции создан")


def example_06_compatibility():
    """Пример 6: Совместимость версий."""
    print("\n" + "="*60)
    print("ПРИМЕР 6: СОВМЕСТИМОСТЬ ВЕРСИЙ")
    print("="*60)
    
    # Тестирование разных версий конфигурации
    test_configs = {
        "Version 1": {
            "JWT_SECRET": "secret",
            "CORS_ORIGINS": "http://localhost:3000",
            "EVIDENCE_PATH": "memory/evidence.jsonl",
            "LOG_LEVEL": "INFO"
        },
        "Version 2": {
            "JWT_SECRET": "secret",
            "JWT_ACCESS_TOKEN_EXPIRE_MINUTES": 30,
            "MEMORY_ROOT": "memory",
            "MEMORY_BATCH_SIZE": 50,
            "OTEL_SERVICE_NAME": "iskra-api"
        },
        "Hybrid": {
            "JWT_SECRET": "secret",
            "JWT_EXPIRE_MINUTES": 60,  # Version 1
            "MEMORY_ROOT": "memory",    # Version 2
            "CORS_ORIGINS": "http://localhost:3000"
        }
    }
    
    for config_name, config_data in test_configs.items():
        print(f"\n🔍 Тестирование: {config_name}")
        
        # Проверка совместимости
        report = check_compatibility(config_data)
        
        print(f"   Режим: {report['detected_mode']}")
        print(f"   Версия: {report['version']}")
        print(f"   Совместимо: {'✅' if report['is_fully_compatible'] else '❌'}")
        
        if report['deprecated_usage']:
            print(f"   Устаревшие настройки: {len(report['deprecated_usage'])}")
        
        if report['recommendations']:
            print(f"   Рекомендации: {len(report['recommendations'])}")


def example_07_export_import():
    """Пример 7: Экспорт и импорт конфигурации."""
    print("\n" + "="*60)
    print("ПРИМЕР 7: ЭКСПОРТ И ИМПОРТ")
    print("="*60)
    
    # Создание конфигурации
    config = create_config(profile=EnvironmentProfile.PRODUCTION)
    
    # Экспорт в .env файл
    env_file = ".env.example"
    config.export_to_env_file(env_file)
    print(f"✅ Экспорт в {env_file}")
    
    # Создание JSON файла конфигурации
    config_data = {
        "app_name": config.security.jwt_algorithm,  # Пример данных
        "profile": config.profile.value,
        "host": config.api.host,
        "port": config.api.port,
    }
    
    json_file = "config.example.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(config_data, f, indent=2, ensure_ascii=False)
    print(f"✅ JSON конфигурация сохранена в {json_file}")
    
    # Генерация шаблона .env
    export_env_template(".env.template")
    print(f"✅ Шаблон .env создан")
    
    # Получение версии системы
    version_info = get_version_info()
    print(f"\n📋 Версия системы: {version_info['version']}")
    print(f"📋 Поддерживаемые профили: {len(version_info['supported_profiles'])}")


def example_08_fastapi_integration():
    """Пример 8: Интеграция с FastAPI."""
    print("\n" + "="*60)
    print("ПРИМЕР 8: ИНТЕГРАЦИЯ С FASTAPI")
    print("="*60)
    
    try:
        from fastapi import FastAPI
        from fastapi.middleware.cors import CORSMiddleware
        
        # Получение конфигурации
        config = get_config()
        
        # Создание FastAPI приложения
        app = FastAPI(
            title=config.security.jwt_algorithm,  # Использование настроек
            version="1.0.0"
        )
        
        # Настройка CORS на основе конфигурации
        app.add_middleware(
            CORSMiddleware,
            allow_origins=config.security.cors_origins,
            allow_credentials=config.security.cors_allow_credentials,
            allow_methods=config.security.cors_allow_methods,
            allow_headers=config.security.cors_allow_headers,
        )
        
        print("✅ FastAPI приложение создано с конфигурацией")
        print(f"   CORS источники: {len(config.security.cors_origins)}")
        print(f"   Rate Limiting: {config.security.rate_limit_enabled}")
        print(f"   Логирование: {config.logging.log_level}")
        
    except ImportError:
        print("⚠️  FastAPI не установлен, пример пропущен")
        print("   Установите: pip install fastapi")


def example_09_custom_settings():
    """Пример 9: Пользовательские настройки."""
    print("\n" + "="*60)
    print("ПРИМЕР 9: ПОЛЬЗОВАТЕЛЬСКИЕ НАСТРОЙКИ")
    print("="*60)
    
    # Создание пользовательского валидатора
    def custom_validator(config, settings):
        errors = []
        warnings = []
        
        # Пример валидации: проверка порта
        port = settings.get("PORT")
        if port and (port < 1000 or port > 65535):
            errors.append(f"Порт {port} небезопасен для продакшена")
        
        # Пример предупреждения
        if settings.get("DEBUG") and config.is_production_mode():
            warnings.append("DEBUG включен в продакшене")
        
        return {"errors": errors, "warnings": warnings}
    
    # Создание конфигурации с пользовательскими настройками
    config = create_config(profile=EnvironmentProfile.PRODUCTION)
    
    # Добавление пользовательской настройки
    config.custom_api_key = "my-secret-key-123"
    config.custom_feature_enabled = True
    
    # Применение пользовательского валидатора
    validator = ConfigValidator()
    validator.add_custom_validator("custom_check", custom_validator)
    
    result = validator.validate_all_settings(config)
    
    print("✅ Пользовательские настройки добавлены")
    print(f"   API Key: {config.custom_api_key[:10]}...")
    print(f"   Feature: {config.custom_feature_enabled}")
    
    if result.warnings:
        print(f"⚠️  Предупреждения валидации: {len(result.warnings)}")


def example_10_monitoring():
    """Пример 10: Настройки мониторинга."""
    print("\n" + "="*60)
    print("ПРИМЕР 10: МОНИТОРИНГ И МЕТРИКИ")
    print("="*60)
    
    config = get_config()
    
    print("📊 Настройки мониторинга:")
    print(f"   Метрики: {config.monitoring.metrics_enabled}")
    print(f"   Health Checks: {config.monitoring.health_check_enabled}")
    print(f"   OpenTelemetry: {config.monitoring.otel_enabled}")
    print(f"   Сервис: {config.monitoring.otel_service_name}")
    print(f"   Порт метрик: {config.monitoring.metrics_port}")
    
    if config.monitoring.metrics_enabled:
        print(f"\n🔗 Endpoints мониторинга:")
        print(f"   Метрики: http://localhost:{config.monitoring.metrics_port}/metrics")
        print(f"   Health: http://localhost:{config.api.port}/health")
    
    print(f"\n📈 Настройки производительности:")
    print(f"   Async Pool: {config.performance.async_pool_size}")
    print(f"   Connection Pool: {config.performance.connection_pool_size}")
    print(f"   LRU Cache: {config.performance.lru_cache_enabled}")
    print(f"   Memory Pool: {config.performance.memory_pool_enabled}")


def main():
    """Главная функция для запуска примеров."""
    print("🚀 ЗАПУСК ПРИМЕРОВ СИНХРОНИЗИРОВАННОЙ КОНФИГУРАЦИИ")
    print("="*70)
    
    # Настройка логирования для демонстрации
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    examples = [
        ("Базовое использование", example_01_basic_usage),
        ("Профили конфигурации", example_02_profiles),
        ("Валидация безопасности", example_03_security_validation),
        ("Переменные окружения", example_04_environment_variables),
        ("Миграция конфигурации", example_05_migration),
        ("Совместимость версий", example_06_compatibility),
        ("Экспорт и импорт", example_07_export_import),
        ("Интеграция с FastAPI", example_08_fastapi_integration),
        ("Пользовательские настройки", example_09_custom_settings),
        ("Мониторинг и метрики", example_10_monitoring),
    ]
    
    # Запуск примеров
    for i, (name, func) in enumerate(examples, 1):
        try:
            func()
        except Exception as e:
            print(f"\n❌ Ошибка в примере {i} ({name}): {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*70)
    print("✅ ВСЕ ПРИМЕРЫ ЗАВЕРШЕНЫ")
    print("="*70)
    
    # Очистка временных файлов
    temp_files = [".env.example", ".env.template", "config.example.json"]
    for file in temp_files:
        if Path(file).exists():
            Path(file).unlink()
    
    print("🧹 Временные файлы удалены")


if __name__ == "__main__":
    main()