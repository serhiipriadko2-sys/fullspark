"""Основной модуль интегрированной системы памяти.

Обеспечивает единый интерфейс для работы с различными режимами памяти:
- Legacy Mode (Version 1): простая синхронная память
- Modern Mode (Version 2): продвинутая асинхронная память
- Hybrid Mode: дублирование в обе системы
- Migration Mode: постепенная миграция с синхронизацией
"""

import asyncio
import json
import time
import os
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Union
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor

from .legacy_memory import LegacyMemoryManager
from .modern_memory import ModernMemoryManager
from .migration_tools import MigrationManager, DataSynchronizer


class MemoryMode(Enum):
    """Режимы работы интегрированной системы памяти."""
    LEGACY = "legacy"          # Version 1 (простая синхронная)
    MODERN = "modern"          # Version 2 (продвинутая асинхронная) 
    HYBRID = "hybrid"          # Дублирование в обе системы
    MIGRATION = "migration"    # Постепенная миграция с синхронизацией


@dataclass
class MemoryEvent:
    """Стандартный класс события памяти для всех режимов."""
    t: float
    kind: str
    key: str
    value: dict
    meta: Optional[dict] = None
    
    def to_dict(self) -> dict:
        """Конвертация в словарь."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'MemoryEvent':
        """Создание из словаря."""
        return cls(**data)


@dataclass
class MemoryConfig:
    """Конфигурация интегрированной системы памяти."""
    mode: MemoryMode = MemoryMode.HYBRID
    root_path: str = "./memory"
    
    # Конфигурация Legacy памяти (Version 1)
    legacy_enabled: bool = True
    legacy_auto_flush: bool = True
    
    # Конфигурация Modern памяти (Version 2)
    modern_enabled: bool = True
    modern_batch_size: int = 50
    modern_flush_interval: float = 5.0
    modern_compress: bool = False
    max_workers: int = 4
    
    # Конфигурация миграции
    migration_auto_sync: bool = True
    migration_sync_interval: float = 60.0  # секунды
    migration_batch_size: int = 100
    enable_real_time_sync: bool = False
    
    # Мониторинг и статистика
    enable_stats: bool = True
    stats_update_interval: float = 30.0
    enable_performance_monitoring: bool = True
    
    def get_legacy_config(self) -> Dict[str, Any]:
        """Получить конфигурацию для Legacy памяти."""
        return {
            "root": self.root_path,
            "auto_flush": self.legacy_auto_flush
        }
    
    def get_modern_config(self) -> Dict[str, Any]:
        """Получить конфигурацию для Modern памяти."""
        return {
            "root": self.root_path,
            "batch_size": self.modern_batch_size,
            "flush_interval": self.modern_flush_interval,
            "compress": self.modern_compress,
            "max_workers": self.max_workers
        }


class IntegratedMemoryManager:
    """Интегрированный менеджер памяти с поддержкой всех режимов."""
    
    def __init__(self, config: MemoryConfig = None):
        """Инициализация интегрированной системы памяти."""
        self.config = config or MemoryConfig()
        self.mode = self.config.mode
        
        # Статистика и мониторинг
        self._stats = {
            "total_operations": 0,
            "legacy_operations": 0,
            "modern_operations": 0,
            "hybrid_operations": 0,
            "error_count": 0,
            "start_time": time.time(),
            "last_operation": None
        }
        self._stats_lock = threading.Lock()
        
        # Инициализация компонентов
        self._initialize_components()
        
        # Запуск фоновых задач
        if self.config.enable_stats:
            self._start_stats_monitor()
        
        if self.config.mode == MemoryMode.MIGRATION:
            self._start_migration_sync()
    
    def _initialize_components(self):
        """Инициализация компонентов системы."""
        try:
            # Legacy память (Version 1)
            if self.config.legacy_enabled:
                self.legacy_memory = LegacyMemoryManager(**self.config.get_legacy_config())
            else:
                self.legacy_memory = None
            
            # Modern память (Version 2)
            if self.config.modern_enabled:
                self.modern_memory = ModernMemoryManager(**self.config.get_modern_config())
            else:
                self.modern_memory = None
            
            # Миграция и синхронизация
            if self.config.mode in [MemoryMode.MIGRATION, MemoryMode.HYBRID]:
                self.migration_manager = MigrationManager(self)
                self.data_synchronizer = DataSynchronizer(self)
            else:
                self.migration_manager = None
                self.data_synchronizer = None
            
            # Валидация совместимости
            self._validate_configuration()
            
        except Exception as e:
            print(f"Ошибка инициализации компонентов памяти: {e}")
            raise
    
    def _validate_configuration(self):
        """Валидация конфигурации системы."""
        errors = []
        
        if self.mode == MemoryMode.LEGACY and not self.legacy_memory:
            errors.append("Legacy режим требует включенной Legacy памяти")
        
        if self.mode == MemoryMode.MODERN and not self.modern_memory:
            errors.append("Modern режим требует включенной Modern памяти")
        
        if self.mode in [MemoryMode.HYBRID, MemoryMode.MIGRATION]:
            if not self.legacy_memory:
                errors.append("Hybrid/Migration режимы требуют включенной Legacy памяти")
            if not self.modern_memory:
                errors.append("Hybrid/Migration режимы требуют включенной Modern памяти")
        
        if errors:
            raise ValueError(f"Ошибки конфигурации: {', '.join(errors)}")
    
    def put(self, kind: str, key: str, value: dict, meta: dict = None) -> Union[MemoryEvent, tuple]:
        """Сохранение данных в память (синхронный интерфейс)."""
        start_time = time.time()
        
        try:
            if self.mode == MemoryMode.LEGACY:
                result = self._put_legacy(kind, key, value, meta)
                self._update_stats('legacy')
                return result
                
            elif self.mode == MemoryMode.MODERN:
                result = self._put_modern_sync(kind, key, value, meta)
                self._update_stats('modern')
                return result
                
            elif self.mode == MemoryMode.HYBRID:
                legacy_result, modern_result = self._put_hybrid(kind, key, value, meta)
                self._update_stats('hybrid')
                return legacy_result, modern_result
                
            elif self.mode == MemoryMode.MIGRATION:
                result = self._put_migration(kind, key, value, meta)
                self._update_stats('hybrid')
                return result
                
        except Exception as e:
            self._update_error_stats()
            raise
    
    async def put_async(self, kind: str, key: str, value: dict, meta: dict = None) -> Union[MemoryEvent, tuple]:
        """Сохранение данных в память (асинхронный интерфейс)."""
        start_time = time.time()
        
        try:
            if self.mode == MemoryMode.LEGACY:
                # Legacy также можно вызвать асинхронно
                result = self._put_legacy(kind, key, value, meta)
                self._update_stats('legacy')
                return result
                
            elif self.mode == MemoryMode.MODERN:
                result = await self.modern_memory.put_async(kind, key, value, meta)
                self._update_stats('modern')
                return result
                
            elif self.mode == MemoryMode.HYBRID:
                legacy_result, modern_result = await self._put_hybrid_async(kind, key, value, meta)
                self._update_stats('hybrid')
                return legacy_result, modern_result
                
            elif self.mode == MemoryMode.MIGRATION:
                result = await self._put_migration_async(kind, key, value, meta)
                self._update_stats('hybrid')
                return result
                
        except Exception as e:
            self._update_error_stats()
            raise
    
    def _put_legacy(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение в Legacy память."""
        return self.legacy_memory.put(kind, key, value, meta)
    
    def _put_modern_sync(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение в Modern память (синхронный вызов)."""
        return self.modern_memory.put_sync(kind, key, value, meta)
    
    async def _put_modern_async(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение в Modern память (асинхронный вызов)."""
        return await self.modern_memory.put_async(kind, key, value, meta)
    
    async def _put_hybrid_async(self, kind: str, key: str, value: dict, meta: dict = None) -> tuple:
        """Сохранение в обе системы (Hybrid mode, асинхронный)."""
        if self.legacy_memory and self.modern_memory:
            # Параллельное сохранение в обе системы
            legacy_task = asyncio.create_task(
                asyncio.to_thread(self.legacy_memory.put, kind, key, value, meta)
            )
            modern_task = self.modern_memory.put_async(kind, key, value, meta)
            
            legacy_result, modern_result = await asyncio.gather(legacy_task, modern_task)
            return legacy_result, modern_result
        else:
            raise ValueError("Hybrid режим требует обеих систем памяти")
    
    def _put_hybrid(self, kind: str, key: str, value: dict, meta: dict = None) -> tuple:
        """Сохранение в обе системы (Hybrid mode, синхронный)."""
        if self.legacy_memory and self.modern_memory:
            legacy_result = self.legacy_memory.put(kind, key, value, meta)
            modern_result = self.modern_memory.put_sync(kind, key, value, meta)
            return legacy_result, modern_result
        else:
            raise ValueError("Hybrid режим требует обеих систем памяти")
    
    async def _put_migration_async(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение в Migration режиме (асинхронный)."""
        # Сохранение в Legacy (основная система)
        legacy_result = self.legacy_memory.put(kind, key, value, meta)
        
        # Асинхронная синхронизация с Modern
        if self.data_synchronizer and self.config.migration_auto_sync:
            await self.data_synchronizer.sync_event_async(legacy_result)
        
        return legacy_result
    
    def _put_migration(self, kind: str, key: str, value: dict, meta: dict = None) -> MemoryEvent:
        """Сохранение в Migration режиме (синхронный)."""
        # Сохранение в Legacy (основная система)
        legacy_result = self.legacy_memory.put(kind, key, value, meta)
        
        # Фоновая синхронизация с Modern
        if self.data_synchronizer and self.config.migration_auto_sync:
            asyncio.create_task(self.data_synchronizer.sync_event_async(legacy_result))
        
        return legacy_result
    
    def get(self, kind: str, key: str, since: Optional[float] = None) -> Union[List[MemoryEvent], Dict[str, List[MemoryEvent]]]:
        """Получение данных из памяти (синхронный интерфейс)."""
        try:
            if self.mode == MemoryMode.LEGACY:
                return self.legacy_memory.get(kind, key, since)
            elif self.mode == MemoryMode.MODERN:
                return self.modern_memory.get_sync(kind, key, since)
            elif self.mode == MemoryMode.HYBRID:
                return self._get_hybrid(kind, key, since)
            elif self.mode == MemoryMode.MIGRATION:
                return self.legacy_memory.get(kind, key, since)
        except Exception as e:
            self._update_error_stats()
            raise
    
    async def get_async(self, kind: str, key: str, since: Optional[float] = None) -> Union[List[MemoryEvent], Dict[str, List[MemoryEvent]]]:
        """Получение данных из памяти (асинхронный интерфейс)."""
        try:
            if self.mode == MemoryMode.LEGACY:
                return self.legacy_memory.get(kind, key, since)
            elif self.mode == MemoryMode.MODERN:
                return await self.modern_memory.get_async(kind, key, since)
            elif self.mode == MemoryMode.HYBRID:
                return await self._get_hybrid_async(kind, key, since)
            elif self.mode == MemoryMode.MIGRATION:
                return self.legacy_memory.get(kind, key, since)
        except Exception as e:
            self._update_error_stats()
            raise
    
    def _get_hybrid(self, kind: str, key: str, since: Optional[float] = None) -> Dict[str, List[MemoryEvent]]:
        """Получение данных из обеих систем (Hybrid mode)."""
        legacy_events = self.legacy_memory.get(kind, key, since)
        modern_events = self.modern_memory.get_sync(kind, key, since)
        
        return {
            "legacy": legacy_events,
            "modern": modern_events
        }
    
    async def _get_hybrid_async(self, kind: str, key: str, since: Optional[float] = None) -> Dict[str, List[MemoryEvent]]:
        """Получение данных из обеих систем (Hybrid mode, асинхронный)."""
        legacy_events = self.legacy_memory.get(kind, key, since)
        modern_events = await self.modern_memory.get_async(kind, key, since)
        
        return {
            "legacy": legacy_events,
            "modern": modern_events
        }
    
    def _update_stats(self, operation_type: str):
        """Обновление статистики операций."""
        with self._stats_lock:
            self._stats["total_operations"] += 1
            self._stats[f"{operation_type}_operations"] += 1
            self._stats["last_operation"] = time.time()
    
    def _update_error_stats(self):
        """Обновление статистики ошибок."""
        with self._stats_lock:
            self._stats["error_count"] += 1
    
    def _start_stats_monitor(self):
        """Запуск мониторинга статистики."""
        def monitor():
            while True:
                try:
                    time.sleep(self.config.stats_update_interval)
                    self._log_stats()
                except Exception as e:
                    print(f"Ошибка мониторинга статистики: {e}")
        
        stats_thread = threading.Thread(target=monitor, daemon=True)
        stats_thread.start()
    
    def _start_migration_sync(self):
        """Запуск периодической синхронизации в Migration режиме."""
        if not self.data_synchronizer or not self.config.migration_auto_sync:
            return
        
        async def migration_sync_loop():
            while True:
                try:
                    await asyncio.sleep(self.config.migration_sync_interval)
                    await self.data_synchronizer.sync_pending_events()
                except Exception as e:
                    print(f"Ошибка синхронизации миграции: {e}")
                    await asyncio.sleep(5)
        
        asyncio.create_task(migration_sync_loop())
    
    def _log_stats(self):
        """Логирование статистики системы."""
        uptime = time.time() - self._stats["start_time"]
        
        stats_message = (
            f"Статистика памяти [режим: {self.mode.value}]:\n"
            f"  Всего операций: {self._stats['total_operations']}\n"
            f"  Legacy операции: {self._stats['legacy_operations']}\n"
            f"  Modern операции: {self._stats['modern_operations']}\n"
            f"  Hybrid операции: {self._stats['hybrid_operations']}\n"
            f"  Ошибки: {self._stats['error_count']}\n"
            f"  Время работы: {uptime:.1f}с\n"
            f"  Последняя операция: {time.ctime(self._stats['last_operation']) if self._stats['last_operation'] else 'Нет'}"
        )
        
        print(stats_message)
    
    def get_stats(self) -> Dict[str, Any]:
        """Получение текущей статистики системы."""
        with self._stats_lock:
            stats = self._stats.copy()
        
        # Добавляем статистику компонентов
        component_stats = {}
        
        if self.legacy_memory:
            try:
                component_stats["legacy"] = self.legacy_memory.get_stats()
            except:
                component_stats["legacy"] = {"status": "error"}
        
        if self.modern_memory:
            try:
                component_stats["modern"] = self.modern_memory.get_stats()
            except:
                component_stats["modern"] = {"status": "error"}
        
        if self.data_synchronizer:
            try:
                component_stats["synchronizer"] = self.data_synchronizer.get_stats()
            except:
                component_stats["synchronizer"] = {"status": "error"}
        
        stats["components"] = component_stats
        stats["config"] = asdict(self.config)
        
        return stats
    
    async def flush_all(self):
        """Принудительная запись всех буферизованных данных."""
        if self.modern_memory:
            await self.modern_memory.flush_all()
        
        if self.data_synchronizer:
            await self.data_synchronizer.sync_pending_events()
    
    async def close(self):
        """Закрытие системы и освобождение ресурсов."""
        # Синхронизация всех данных
        await self.flush_all()
        
        # Закрытие компонентов
        if self.modern_memory:
            await self.modern_memory.close()
        
        if self.data_synchronizer:
            await self.data_synchronizer.close()
        
        print(f"Интегрированная система памяти закрыта (режим: {self.mode.value})")
    
    def __enter__(self):
        """Поддержка контекстного менеджера."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Выход из контекстного менеджера."""
        asyncio.create_task(self.close())


# Глобальный экземпляр интегрированной системы памяти
_global_integrated_memory = None
_global_config = None
_config_lock = threading.Lock()


def get_integrated_memory_manager(config: MemoryConfig = None) -> IntegratedMemoryManager:
    """Получение глобального экземпляра интегрированной системы памяти."""
    global _global_integrated_memory, _global_config
    
    with _config_lock:
        if _global_integrated_memory is None or _global_config != config:
            if config:
                _global_config = config
            elif _global_config is None:
                _global_config = MemoryConfig()
            
            _global_integrated_memory = IntegratedMemoryManager(_global_config)
    
    return _global_integrated_memory


def create_integrated_memory(mode: MemoryMode = MemoryMode.HYBRID, **kwargs) -> IntegratedMemoryManager:
    """Создание нового экземпляра интегрированной системы памяти."""
    config = MemoryConfig(mode=mode, **kwargs)
    return IntegratedMemoryManager(config)