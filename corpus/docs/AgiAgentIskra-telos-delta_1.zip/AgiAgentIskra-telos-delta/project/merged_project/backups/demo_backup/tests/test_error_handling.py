"""Тесты для интегрированной системы обработки ошибок.

Демонстрирует работу всех компонентов системы обработки ошибок.

Автор: Iskra Integration Team
Версия: 1.0
"""

import pytest
import asyncio
import json
from unittest.mock import Mock
from typing import Dict, Any

# Импорты системы обработки ошибок
from core.exceptions import (
    BaseIskraException, IskraException,
    AuthenticationException, AuthorizationException,
    ValidationException, NotFoundException,
    BusinessLogicException, DatabaseException,
    SearchException, VectorSearchException,
    ExternalServiceException, SystemException,
    ErrorLevel, ErrorType, ErrorScope,
    get_exception_info, create_exception_from_error
)

from core.handlers import (
    ErrorHandlerManager,
    HttpErrorHandler, AuthenticationHandler,
    ServiceErrorHandler, RepositoryErrorHandler
)

from core.logging import (
    CentralizedLogger, LogContext, LogFormat, 
    setup_logging, LoggerFactory
)

from core.middleware import RequestContext


class TestExceptionHierarchy:
    """Тестирование иерархии исключений."""
    
    def test_version1_compatibility_simple(self):
        """Тест простого исключения Version 1."""
        exc = IskraException("Простая ошибка")
        
        assert exc.message == "Простая ошибка"
        assert exc._version1_mode is True
        assert exc.status_code == 500
        
        # Преобразование в HTTP исключение (Version 1 стиль)
        http_exc = exc.to_http_exception()
        assert isinstance(http_exc.detail, str)
        assert http_exc.detail == "Простая ошибка"
    
    def test_version1_compatibility_with_details(self):
        """Тест исключения Version 1 с деталями."""
        details = {
            "status_code": 422,
            "field": "email",
            "level": "high"
        }
        exc = IskraException("Ошибка с деталями", details=details)
        
        assert exc.message == "Ошибка с деталями"
        assert exc._version1_mode is False
        assert exc.details == details
        assert exc.status_code == 422
        
        # Преобразование в HTTP исключение (Version 2 стиль)
        http_exc = exc.to_http_exception()
        assert isinstance(http_exc.detail, dict)
        assert "error" in http_exc.detail
        assert "error_code" in http_exc.detail
    
    def test_authentication_exception(self):
        """Тест ошибки аутентификации."""
        exc = AuthenticationException("Токен истек")
        
        assert exc.message == "Токен истек"
        assert exc.status_code == 401
        assert exc.error_type == ErrorType.AUTHENTICATION
        assert exc.level == ErrorLevel.HIGH
        
        http_exc = exc.to_http_exception()
        assert http_exc.status_code == 401
        assert http_exc.detail["error"] == "Токен истек"
    
    def test_validation_exception_with_field(self):
        """Тест ошибки валидации с полем."""
        exc = ValidationException("Неверный email", field="email")
        
        assert exc.message == "Неверный email"
        assert exc.details["field"] == "email"
        assert exc.status_code == 422
        
        http_exc = exc.to_http_exception()
        assert http_exc.status_code == 422
        assert http_exc.detail["details"]["field"] == "email"
    
    def test_business_logic_exception(self):
        """Тест ошибки бизнес-логики."""
        exc = BusinessLogicException(
            "Нельзя удалить администратора",
            error_code="BIZ_001"
        )
        
        assert exc.message == "Нельзя удалить администратора"
        assert exc.error_code == "BIZ_001"
        assert exc.error_type == ErrorType.BUSINESS_LOGIC
        assert exc.scope == ErrorScope.SERVICE
        
        http_exc = exc.to_http_exception()
        assert http_exc.status_code == 500
    
    def test_database_exception_with_cause(self):
        """Тест ошибки базы данных с причиной."""
        original_exc = ConnectionError("Connection failed")
        exc = DatabaseException("Ошибка БД", cause=original_exc)
        
        assert exc.message == "Ошибка БД"
        assert exc.cause == original_exc
        assert exc.error_type == ErrorType.DATABASE
        assert exc.scope == ErrorScope.REPOSITORY
    
    def test_base_iskra_exception_full_params(self):
        """Тест базового Iskra исключения со всеми параметрами."""
        exc = BaseIskraException(
            message="Продвинутая ошибка",
            error_code="ADV_001",
            details={"context": "important"},
            status_code=422,
            level=ErrorLevel.HIGH,
            error_type=ErrorType.BUSINESS_LOGIC,
            scope=ErrorScope.SERVICE
        )
        
        assert exc.message == "Продвинутая ошибка"
        assert exc.error_code == "ADV_001"
        assert exc.details["context"] == "important"
        assert exc.status_code == 422
        assert exc.level == ErrorLevel.HIGH
        assert exc.error_type == ErrorType.BUSINESS_LOGIC
        assert exc.scope == ErrorScope.SERVICE
    
    def test_to_dict_method(self):
        """Тест метода to_dict()."""
        exc = ValidationException("Тест", field="test")
        exc_dict = exc.to_dict()
        
        assert "error_code" in exc_dict
        assert "message" in exc_dict
        assert "details" in exc_dict
        assert "status_code" in exc_dict
        assert "level" in exc_dict
        assert "error_type" in exc_dict
        assert "scope" in exc_dict
    
    def test_get_exception_info(self):
        """Тест функции get_exception_info."""
        exc = ValidationException("Ошибка валидации", field="email")
        info = get_exception_info(exc)
        
        assert "error_code" in info
        assert info["message"] == "Ошибка валидации"
        assert info["type"] == "ValidationException"
    
    def test_create_exception_from_error(self):
        """Тест функции create_exception_from_error."""
        exc = create_exception_from_error(
            message="Тестовая ошибка",
            error_type=ErrorType.VALIDATION,
            status_code=422,
            details={"field": "test"}
        )
        
        assert isinstance(exc, BaseIskraException)
        assert exc.message == "Тестовая ошибка"
        assert exc.error_type == ErrorType.VALIDATION
        assert exc.status_code == 422
        assert exc.details["field"] == "test"


class TestErrorHandlers:
    """Тестирование обработчиков ошибок."""
    
    def test_error_handler_manager_creation(self):
        """Тест создания менеджера обработчиков."""
        logger = CentralizedLogger("test", format_type="text")
        manager = ErrorHandlerManager(logger)
        
        assert isinstance(manager._handlers, list)
        assert len(manager._handlers) > 0
    
    def test_authentication_handler(self):
        """Тест обработчика аутентификации."""
        from core.handlers import AuthenticationHandler
        
        logger = CentralizedLogger("test", format_type="text")
        handler = AuthenticationHandler(logger)
        
        exc = AuthenticationException("Токен истек")
        assert handler.can_handle(exc) is True
        
        # Создаем mock request
        from fastapi import Request
        request = Request({"type": "http", "method": "GET", "path": "/test"})
        
        # Обрабатываем исключение
        import asyncio
        response = asyncio.run(handler.handle(request, exc))
        
        assert response.status_code == 401
        assert "requires_auth" in response.json()
    
    def test_validation_handler(self):
        """Тест обработчика валидации."""
        from core.handlers import ValidationHandler
        
        logger = CentralizedLogger("test", format_type="text")
        handler = ValidationHandler(logger)
        
        exc = ValidationException("Неверный email", field="email")
        assert handler.can_handle(exc) is True
        
        from fastapi import Request
        request = Request({"type": "http", "method": "POST", "path": "/api/users"})
        
        response = asyncio.run(handler.handle(request, exc))
        
        assert response.status_code == 422
        assert response.json()["details"]["field"] == "email"


class TestLoggingSystem:
    """Тестирование системы логирования."""
    
    def test_centralized_logger_creation(self):
        """Тест создания централизованного логгера."""
        logger = CentralizedLogger(
            "test_logger",
            format_type="text",
            destinations=["console"]
        )
        
        assert logger.name == "test_logger"
        assert logger.format_type == LogFormat.TEXT
    
    def test_log_context(self):
        """Тест контекста логирования."""
        context = LogContext(
            request_id="req123",
            user_id="user456",
            endpoint="/api/test",
            method="GET"
        )
        
        assert context.request_id == "req123"
        assert context.user_id == "user456"
        assert context.endpoint == "/api/test"
        assert context.method == "GET"
    
    def test_logger_factory(self):
        """Тест фабрики логгеров."""
        # Настройка системы логирования
        logger = setup_logging(
            log_level="DEBUG",
            format_type="text",
            enable_async=False
        )
        
        # Получение именованного логгера
        named_logger = LoggerFactory.get_logger("test.component")
        assert named_logger is not None
        
        # Получение специализированных логгеров
        error_logger = LoggerFactory.get_error_logger()
        performance_logger = LoggerFactory.get_performance_logger()
        audit_logger = LoggerFactory.get_audit_logger()
        
        assert error_logger is not None
        assert performance_logger is not None
        assert audit_logger is not None
    
    def test_log_entry_to_dict(self):
        """Тест преобразования записи лога в словарь."""
        from core.logging import LogEntry
        
        entry = LogEntry(
            timestamp="2025-11-01T11:25:23Z",
            level="ERROR",
            logger="test_logger",
            message="Test error",
            module="test_module",
            function="test_function",
            line_number=123,
            context={"request_id": "req123"}
        )
        
        entry_dict = entry.to_dict()
        
        assert entry_dict["level"] == "ERROR"
        assert entry_dict["message"] == "Test error"
        assert entry_dict["context"]["request_id"] == "req123"
    
    def test_json_formatter(self):
        """Тест JSON форматера."""
        from core.logging import IskraJSONFormatter
        
        logger = CentralizedLogger("test", format_type="json")
        formatter = IskraJSONFormatter()
        
        # Создаем LogRecord
        import logging
        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=100,
            msg="Test message",
            args=(),
            exc_info=None
        )
        record.context = {"request_id": "req123"}
        
        formatted = formatter.format(record)
        parsed = json.loads(formatted)
        
        assert parsed["level"] == "ERROR"
        assert parsed["message"] == "Test message"
        assert parsed["context"]["request_id"] == "req123"


class TestMiddleware:
    """Тестирование middleware."""
    
    def test_request_context_creation(self):
        """Тест создания контекста запроса."""
        from fastapi import Request
        
        scope = {
            "type": "http",
            "method": "GET",
            "path": "/api/test",
            "headers": [
                (b"user-agent", b"test-client"),
                (b"x-request-id", b"req123")
            ]
        }
        
        request = Request(scope)
        context = RequestContext(request)
        
        assert context.request_id is not None
        assert context.method == "GET"
        assert context.endpoint == "/api/test"
        assert context.user_agent == "test-client"
        assert context.ip_address == "unknown"  # По умолчанию
    
    def test_middleware_stack_setup(self):
        """Тест настройки стека middleware."""
        from core.middleware import IskraMiddlewareStack
        
        # Создаем mock компоненты
        app = Mock()
        error_manager = Mock()
        logger = Mock()
        
        middleware_stack = IskraMiddlewareStack(
            app,
            error_manager,
            logger
        )
        
        assert middleware_stack.app == app
        assert middleware_stack.error_handler_manager == error_manager
        assert middleware_stack.logger == logger


class TestIntegration:
    """Интеграционные тесты системы."""
    
    def test_full_error_flow(self):
        """Тест полного потока обработки ошибки."""
        # 1. Создаем исключение
        exc = ValidationException("Неверный email", field="email")
        
        # 2. Получаем информацию об исключении
        info = get_exception_info(exc)
        
        assert info["message"] == "Неверный email"
        assert info["error_type"] == "validation"
        
        # 3. Преобразуем в HTTP исключение
        http_exc = exc.to_http_exception()
        
        assert http_exc.status_code == 422
        assert "error" in http_exc.detail
        
        # 4. Проверяем логирование (mock)
        logger = CentralizedLogger("integration_test", format_type="text")
        logger.log_exception(exc, level="ERROR")
        
        # Тест прошел успешно - исключение было обработано полностью
        assert True
    
    def test_version_compatibility_chain(self):
        """Тест цепочки совместимости Version 1 -> Version 2."""
        # Version 1 стиль
        v1_exc = IskraException("Простая ошибка")
        assert v1_exc._version1_mode is True
        
        # Version 2 стиль
        v2_exc = IskraException(
            "Ошибка с деталями",
            details={"status_code": 422}
        )
        assert v2_exc._version1_mode is False
        
        # Оба могут быть преобразованы в HTTP исключения
        v1_http = v1_exc.to_http_exception()
        v2_http = v2_exc.to_http_exception()
        
        assert v1_http.status_code == 500
        assert v2_http.status_code == 422
    
    def test_multi_level_error_handling(self):
        """Тест многоуровневой обработки ошибок."""
        # HTTP Level
        http_exc = AuthenticationException("Токен истек")
        
        # Service Level
        service_exc = BusinessLogicException("Ошибка бизнес-логики")
        
        # Repository Level
        repo_exc = DatabaseException("Ошибка БД")
        
        # Infrastructure Level
        infra_exc = ExternalServiceException(
            "Сервис недоступен",
            service_name="external_api"
        )
        
        # Проверяем, что все исключения имеют правильные scope
        assert http_exc.scope == ErrorScope.HTTP
        assert service_exc.scope == ErrorScope.SERVICE
        assert repo_exc.scope == ErrorScope.REPOSITORY
        assert infra_exc.scope == ErrorScope.INFRASTRUCTURE


if __name__ == "__main__":
    # Запуск тестов
    print("🧪 Запуск тестов интегрированной системы обработки ошибок")
    print("=" * 60)
    
    # Простые тесты без pytest
    test_hierarchy = TestExceptionHierarchy()
    test_handlers = TestErrorHandlers()
    test_logging = TestLoggingSystem()
    test_middleware = TestMiddleware()
    test_integration = TestIntegration()
    
    try:
        # Тестирование иерархии исключений
        print("\n📋 Тестирование иерархии исключений...")
        test_hierarchy.test_version1_compatibility_simple()
        test_hierarchy.test_version1_compatibility_with_details()
        test_hierarchy.test_authentication_exception()
        test_hierarchy.test_validation_exception_with_field()
        test_hierarchy.test_business_logic_exception()
        test_hierarchy.test_database_exception_with_cause()
        test_hierarchy.test_base_iskra_exception_full_params()
        test_hierarchy.test_to_dict_method()
        test_hierarchy.test_get_exception_info()
        test_hierarchy.test_create_exception_from_error()
        print("✅ Все тесты иерархии исключений пройдены")
        
        # Тестирование обработчиков
        print("\n🔧 Тестирование обработчиков ошибок...")
        test_handlers.test_error_handler_manager_creation()
        test_handlers.test_authentication_handler()
        test_handlers.test_validation_handler()
        print("✅ Все тесты обработчиков ошибок пройдены")
        
        # Тестирование системы логирования
        print("\n📝 Тестирование системы логирования...")
        test_logging.test_centralized_logger_creation()
        test_logging.test_log_context()
        test_logging.test_logger_factory()
        test_logging.test_log_entry_to_dict()
        test_logging.test_json_formatter()
        print("✅ Все тесты системы логирования пройдены")
        
        # Тестирование middleware
        print("\n🌐 Тестирование middleware...")
        test_middleware.test_request_context_creation()
        test_middleware.test_middleware_stack_setup()
        print("✅ Все тесты middleware пройдены")
        
        # Интеграционные тесты
        print("\n🔄 Интеграционные тесты...")
        test_integration.test_full_error_flow()
        test_integration.test_version_compatibility_chain()
        test_integration.test_multi_level_error_handling()
        print("✅ Все интеграционные тесты пройдены")
        
        print("\n🎉 Все тесты успешно завершены!")
        print("📊 Система обработки ошибок работает корректно")
        
    except Exception as e:
        print(f"\n❌ Ошибка в тестах: {e}")
        import traceback
        traceback.print_exc()