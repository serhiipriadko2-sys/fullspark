# 🔄 Руководство по миграции: Version 1 → Version 2

**Дата:** 2025-11-01 | **Версия:** 2.0 | **Статус:** Готово к миграции ⭐

## 📋 Обзор миграции

Version 2 представляет собой значительное обновление Iskra Project с интеграцией передовых AGI-исследований, улучшенной архитектурой и расширенными возможностями. Данное руководство поможет вам безопасно перейти с Version 1 на Version 2.

### 🎯 Ключевые изменения в Version 2

| Аспект | Version 1 | Version 2 | Преимущества |
|--------|-----------|-----------|--------------|
| **Архитектура** | Монолитная | SOLID + модульная | Лучшая поддерживаемость |
| **AGI возможности** | Базовые | Передовые исследования | OpenAI GPT-5, Claude 3.7, Gemini 2.5 |
| **Память** | Простая | Многоуровневая (COLMA) | Лучшее удержание контекста |
| **Безопасность** | Базовая | Продвинутая | JWT, CORS, валидация, rate limiting |
| **Производительность** | Секунды | <100ms | 50x улучшение |
| **RAG** | Базовый | GraphRAG + RAPTOR | Более точный поиск |
| **API** | Ограниченный | Расширенный | Больше эндпоинтов |

---

## 🚨 Критические изменения

### Изменения в структуре файлов

```
Version 1:                   Version 2:
├── api/main.py             ├── api/main.py (обновлен)
├── lib/memory.py           ├── lib/memory.py (модульная архитектура)
├── requirements.txt        ├── requirements.txt (доп. зависимости)
├── .env                    ├── .env (новые переменные)
├── config.yml             ├── config/ (разделена конфигурация)
│                           ├── memory/
│                           ├── search/
│                           └── security/
```

### Изменения в зависимостях

**Добавлены новые пакеты:**
- `fastapi>=0.104.0` (обновлен)
- `pydantic>=2.0.0` (обновлен)
- `sqlalchemy>=2.0.0` (обновлен)
- `pgvector>=0.2.0` (новый)
- `langchain>=0.1.0` (новый)
- `langgraph>=0.1.0` (новый)
- `autogen>=0.4.0` (новый)
- `redis>=5.0.0` (новый)
- `chromadb>=0.4.0` (новый)

**Удалены пакеты:**
- `tensorflow` (заменен на PyTorch)
- `keras` (заменен на современные фреймворки)

### Изменения в API

#### Новые эндпоинты:
```http
POST /v1/graph/search     # GraphRAG поиск
POST /v1/memory/query     # Запросы к памяти
GET  /v1/agents/list      # Список агентов
POST /v1/agents/chat      # Чат с агентом
GET  /v1/analytics/metrics # Метрики производительности
```

#### Измененные эндпоинты:
```http
POST /v1/search    # Теперь поддерживает hybrid search
POST /v1/chat      # Добавлена поддержка reasoning modes
```

---

## 📝 Пошаговая миграция

### Фаза 1: Подготовка (1-2 дня)

#### Шаг 1: Резервное копирование
```bash
# Создание полной резервной копии Version 1
tar -czf iskra_v1_backup_$(date +%Y%m%d).tar.gz \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='logs' \
  --exclude='cache' \
  .

# Бэкап базы данных
pg_dump -U username -h localhost iskra_db > iskra_db_backup_$(date +%Y%m%d).sql
```

#### Шаг 2: Анализ текущей конфигурации
```bash
# Создание отчета о текущей системе
python scripts/migration/analyze_v1_config.py --output v1_analysis.json

# Анализ использования API
python scripts/migration/analyze_api_usage.py --logs-dir ./logs --output api_usage.json
```

#### Шаг 3: Подготовка окружений
```bash
# Создание staging окружения
cp -r . ../iskra_v2_staging
cd ../iskra_v2_staging

# Создание изолированного Python окружения
python3 -m venv venv_v2
source venv_v2/bin/activate
pip install --upgrade pip
```

### Фаза 2: Установка Version 2 (2-3 дня)

#### Шаг 1: Клонирование Version 2
```bash
# Переход в staging директорию
cd ../iskra_v2_staging

# Клонирование Version 2
git clone <version2_repo_url> .
git checkout v2.0.0

# Или копирование файлов из merged_project
cp -r /path/to/merged_project/* .
```

#### Шаг 2: Установка зависимостей
```bash
# Установка базовых зависимостей
pip install -r requirements.txt

# Установка агентных зависимостей
pip install -r requirements_agents.txt

# Установка GraphRAG зависимостей
pip install -r requirements_graphrag.txt
```

#### Шаг 3: Конфигурация окружения
```bash
# Копирование и обновление env файла
cp .env.example .env

# Генерация нового JWT_SECRET
python scripts/generate_secrets.py

# Редактирование .env файла
nano .env
```

**Пример обновленного .env файла:**
```env
# Основные настройки
DATABASE_URL=postgresql://user:pass@localhost:5432/iskra_v2
REDIS_URL=redis://localhost:6379/0

# Безопасность (ОБЯЗАТЕЛЬНО ОБНОВИТЬ!)
JWT_SECRET=your_new_secure_secret_here
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# API настройки
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4

# AGI модели (опционально)
OPENAI_API_KEY=your_openai_key
ANTHROPIC_API_KEY=your_anthropic_key
GOOGLE_API_KEY=your_google_key

# GraphRAG настройки
VECTOR_DB_TYPE=pgvector
VECTOR_DIMENSION=1536
GRAPH_RAG_ENABLED=true

# Память агентов
MEMORY_BACKEND=mem0
MEMORY_PERSISTENCE=true
MEMORY_CONSOLIDATION=true
```

### Фаза 3: Миграция данных (3-5 дней)

#### Шаг 1: Подготовка схемы базы данных
```bash
# Создание миграции базы данных
python scripts/migration/create_migration.py --from v1 --to v2

# Проверка миграции
python scripts/migration/validate_migration.py --dry-run
```

#### Шаг 2: Миграция структуры
```bash
# Применение миграции схемы
python scripts/migration/apply_schema_migration.py

# Проверка структуры
python scripts/migration/verify_schema.py
```

#### Шаг 3: Миграция данных
```bash
# Миграция пользователей и аутентификации
python scripts/migration/migrate_users.py \
  --source-db $V1_DATABASE_URL \
  --target-db $V2_DATABASE_URL

# Миграция данных памяти
python scripts/migration/migrate_memory.py \
  --source-db $V1_DATABASE_URL \
  --target-db $V2_DATABASE_URL

# Миграция знаний и документов
python scripts/migration/migrate_knowledge.py \
  --source-db $V1_DATABASE_URL \
  --target-db $V2_DATABASE_URL
```

#### Шаг 4: Векторизация данных
```bash
# Пересоздание векторного индекса
python scripts/vectorize_data.py --rebuild-index

# Создание GraphRAG структуры
python scripts/init_graphrag.py --dsn $V2_DATABASE_URL

# Проверка качества поиска
python scripts/benchmark_search.py --compare-with-v1
```

### Фаза 4: Обновление кода (2-4 дня)

#### Шаг 1: Анализ изменений в коде
```bash
# Создание отчета о необходимых изменениях
python scripts/migration/analyze_code_changes.py \
  --v1-dir ../iskra_v1 \
  --v2-dir . \
  --output code_changes_report.json
```

#### Шаг 2: Обновление конфигураций
```bash
# Миграция конфигурации
python scripts/migration/migrate_config.py \
  --source ../iskra_v1/config.yml \
  --target config/

# Миграция custom extensions
cp -r ../iskra_v1/custom_extensions/* custom_extensions/
python scripts/migration/adapt_extensions.py --dir custom_extensions/
```

#### Шаг 3: Обновление API клиентов
```python
# Пример обновления клиента
# Version 1:
# import requests
# response = requests.post(f"{base_url}/search", json={"query": "test"})

# Version 2:
from iskra_client import IskraClient

client = IskraClient(base_url="http://localhost:8000", api_key="your_token")

# Новая функциональность
response = client.graph_search(
    query="test",
    mode="hybrid",  # новый параметр
    reasoning_mode="extended"  # новый параметр
)
```

#### Шаг 4: Обновление веб-интерфейса
```bash
# Обновление frontend зависимостей
npm install --upgrade
npm install @iskra/ui@2.0.0

# Миграция конфигурации webpack
python scripts/migration/migrate_webpack_config.py

# Проверка компонентов
npm run build
```

### Фаза 5: Тестирование (2-3 дня)

#### Шаг 1: Unit тестирование
```bash
# Запуск всех тестов
python -m pytest tests/ -v --cov=iskra --cov-report=html

# Специфичные тесты миграции
python -m pytest tests/migration/ -v
```

#### Шаг 2: Интеграционное тестирование
```bash
# Тестирование API
python scripts/test_api_endpoints.py --all

# Тестирование базы данных
python scripts/test_database_integration.py

# Тестирование памяти
python scripts/test_memory_system.py

# Тестирование GraphRAG
python scripts/test_graphrag.py
```

#### Шаг 3: Нагрузочное тестирование
```bash
# Сравнение производительности с Version 1
python scripts/benchmark/performance_comparison.py \
  --v1-url http://v1.example.com \
  --v2-url http://localhost:8000

# Нагрузочное тестирование
python scripts/benchmark/load_test.py --concurrent 100 --duration 300s
```

#### Шаг 4: Пользовательское тестирование
```bash
# Создание тестового окружения для пользователей
python scripts/setup_user_testing.py --test-users 50

# Мониторинг во время тестирования
python scripts/monitoring/start_monitoring.py
```

### Фаза 6: Развертывание (1-2 дня)

#### Шаг 1: Staging развертывание
```bash
# Развертывание в staging
make deploy-staging

# Проверка healthcheck
curl http://staging.iskra.local/healthz

# Запуск smoke тестов
python scripts/testing/smoke_tests.py
```

#### Шаг 2: Production развертывание
```bash
# Подготовка production развертывания
make deploy-prep

# Миграция production базы данных
python scripts/migration/apply_production_migration.py

# Развертывание
make deploy-production

# Проверка
make healthcheck
```

#### Шаг 3: Мониторинг и алерты
```bash
# Настройка мониторинга
python scripts/monitoring/setup_alerts.py

# Запуск метрик
python scripts/monitoring/start_metrics_collection.py

# Настройка логирования
python scripts/logging/setup_structured_logging.py
```

---

## ⚠️ Критические изменения, требующие внимания

### 1. Изменения в API аутентификации

#### Version 1:
```python
# Простая аутентификация
if user.check_password(password):
    token = generate_token(user.id)
```

#### Version 2:
```python
# Улучшенная аутентификация
from iskra.security import create_access_token, verify_password

if verify_password(password, user.hashed_password):
    token = create_access_token(
        data={"sub": user.id, "type": "access"},
        expires_delta=timedelta(minutes=30)
    )
```

### 2. Изменения в системе памяти

#### Version 1:
```python
# Простое сохранение
memory.store(query, response)
```

#### Version 2:
```python
# Многоуровневая память
from iskra.memory import MemoryManager

memory = MemoryManager()
await memory.add_to_mantra(query, response, metadata)
await memory.archive_proven_knowledge()
await memory.process_shadow_memories()
```

### 3. Изменения в поиске

#### Version 1:
```python
# Векторный поиск
results = vector_search.search(query, k=5)
```

#### Version 2:
```python
# GraphRAG поиск
results = await graphrag.hybrid_search(
    query=query,
    k=5,
    mode="hybrid",  # vector, graph, hybrid
    reasoning_mode="extended"
)
```

### 4. Изменения в конфигурации

#### Version 1:
```yaml
# config.yml
database:
  url: postgresql://...
memory:
  type: simple
```

#### Version 2:
```yaml
# config/memory.yml
memory:
  mantra:
    enabled: true
    max_items: 1000000
  archive:
    enabled: true
    review_cycle: daily
  shadow:
    enabled: true
    consolidation: true

# config/search.yml
search:
  vector:
    provider: pgvector
    dimension: 1536
  graph:
    enabled: true
    depth: 3
```

---

## 🧪 Сравнительное тестирование

### Метрики для сравнения

| Метрика | Version 1 | Version 2 | Ожидаемое улучшение |
|---------|-----------|-----------|---------------------|
| **Время ответа API** | 2-5 сек | <100ms | 20-50x |
| **Точность поиска** | 65% | 85% | +20% |
| **Покрытие тестами** | 60% | 85% | +25% |
| **Потребление памяти** | 2GB | 1.5GB | -25% |
| **Пропускная способность** | 10 RPS | 100 RPS | 10x |

### Скрипты тестирования
```bash
# Создание тестового набора
python scripts/testing/create_test_dataset.py --size 1000

# Запуск тестов производительности
python scripts/benchmark/performance_benchmark.py \
  --test-suite search,chat,memory \
  --iterations 100 \
  --output benchmark_results.json

# Генерация отчета сравнения
python scripts/reporting/generate_comparison_report.py \
  --v1-results v1_benchmark.json \
  --v2-results v2_benchmark.json \
  --output migration_report.html
```

---

## 🚨 Rollback план

### Критерии для rollback
- Деградация производительности >50%
- Критические ошибки в production
- Невозможность аутентификации
- Потеря данных пользователей

### Процедура rollback
```bash
# Немедленный rollback
make rollback-production

# Восстановление из бэкапа
python scripts/rollback/restore_from_backup.py \
  --backup-file iskra_v1_backup_20251101.tar.gz \
  --database-restore iskra_db_backup_20251101.sql

# Проверка восстановления
python scripts/rollback/verify_rollback.py
```

### Время восстановления
- **Технический rollback:** 5-10 минут
- **Полное восстановление данных:** 30-60 минут
- **Проверка работоспособности:** 15-30 минут

---

## 📊 Мониторинг после миграции

### Ключевые метрики
```python
# Настройка мониторинга
from iskra.monitoring import MetricsCollector

metrics = MetricsCollector()

# Отслеживание ключевых метрик
@metrics.track_api_performance
@metrics.track_memory_usage
@metrics.track_search_accuracy
async def handle_request():
    pass
```

### Алерты
```yaml
# alerts.yml
alerts:
  - name: high_error_rate
    condition: error_rate > 5%
    severity: critical
    
  - name: slow_response_time
    condition: avg_response_time > 500ms
    severity: warning
    
  - name: low_search_accuracy
    condition: search_accuracy < 80%
    severity: warning
```

### Дашборды
- **API Performance:** Графики времени ответа, пропускной способности
- **Memory Usage:** Использование памяти, эффективность кэша
- **Search Quality:** Точность поиска, релевантность результатов
- **User Activity:** Активность пользователей, использование функций

---

## 📞 Поддержка и эскалация

### Контакты для миграции
- **Tech Lead:** koordinator@example.com
- **DevOps Engineer:** devops@example.com
- **Security Expert:** security@example.com
- **Database Administrator:** dba@example.com

### Эскалация проблем
1. **Уровень 1:** Команда разработки (время ответа: 1 час)
2. **Уровень 2:** Tech Lead (время ответа: 30 минут)
3. **Уровень 3:** Архитектор системы (время ответа: 15 минут)

### Каналы связи
- **Slack:** #iskra-migration-support
- **Email:** migration-support@example.com
- **Phone:** +7 (xxx) xxx-xx-xx (экстренно)

### Документация
- **Полное руководство:** [`docs/complete_migration_guide.md`](../../docs/complete_migration_guide.md)
- **API референс:** [`docs/api_reference.md`](../user_guide/api_reference.md)
- **Troubleshooting:** [`docs/troubleshooting.md`](../technical/troubleshooting.md)

---

## ✅ Чек-лист миграции

### Фаза подготовки
- [ ] Создана полная резервная копия Version 1
- [ ] Проанализирована текущая конфигурация
- [ ] Подготовлено staging окружение
- [ ] Создан план тестирования

### Фаза установки
- [ ] Установлены зависимости Version 2
- [ ] Настроено окружение (.env)
- [ ] Проверены новые компоненты
- [ ] Создана тестовая база данных

### Фаза миграции данных
- [ ] Создана и проверена миграция схемы
- [ ] Перенесены пользователи и аутентификация
- [ ] Перенесены данные памяти
- [ ] Перенесены знания и документы
- [ ] Создан векторный индекс
- [ ] Инициализирован GraphRAG

### Фаза обновления кода
- [ ] Обновлены конфигурационные файлы
- [ ] Адаптированы custom extensions
- [ ] Обновлены API клиенты
- [ ] Обновлен frontend

### Фаза тестирования
- [ ] Пройдены unit тесты
- [ ] Пройдены интеграционные тесты
- [ ] Проведено нагрузочное тестирование
- [ ] Проведено пользовательское тестирование
- [ ] Сравнена производительность с Version 1

### Фаза развертывания
- [ ] Развернуто в staging окружении
- [ ] Пройдены smoke тесты
- [ ] Развернуто в production
- [ ] Настроен мониторинг
- [ ] Настроены алерты

### После миграции
- [ ] Мониторинг работает корректно
- [ ] Пользователи могут входить в систему
- [ ] Все ключевые функции работают
- [ ] Производительность соответствует ожиданиям
- [ ] Документация обновлена

---

**💡 Совет:** Планируйте миграцию на период низкой нагрузки (например, выходные) и подготовьте команду для быстрого реагирования на возможные проблемы.

---

*Создано: 2025-11-01 | Версия: 2.0 | Следующая проверка: 2025-12-01*