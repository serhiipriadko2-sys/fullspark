"""
Интегрированная архитектура проекта Искра v1.0

Объединяет функциональность Version 1 с архитектурными улучшениями Version 2.
Обеспечивает 100% backward compatibility при постепенной миграции к модульной архитектуре.

Паттерн: Legacy API + Modern Core
- Сохранены все работающие endpoint'ы Version 1
- Интегрированы улучшения Version 2
- Gradual migration от монолита к слоистой архитектуре
"""

import time
from contextlib import asynccontextmanager
from typing import Optional, Dict, Any
from fastapi import FastAPI, HTTPException, Depends, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder

# Импорты Version 1 - сохранение обратной совместимости
import os
import jwt
import secrets
import hashlib
import base64
from datetime import datetime, timedelta
from pydantic import BaseModel, Field, validator

# Импорты Version 2 - улучшенная архитектура
# Новая синхронизированная система конфигурации
try:
    from config import get_config, EnvironmentProfile
    CONFIG_AVAILABLE = True
except ImportError:
    CONFIG_AVAILABLE = False
    print("⚠️ Система конфигурации недоступна, используются настройки по умолчанию")
from core.config import Settings
from core.exceptions import IskraException
from api.legacy_bridge import LegacyAPIBridge
from api.version2_bridge import Version2APIBridge
from services.dependency_injection import get_container

# Инициализация конфигурации
if CONFIG_AVAILABLE:
    try:
        config = get_config()
        print("✅ Новая система конфигурации инициализирована")
    except Exception as e:
        print(f"⚠️ Ошибка инициализации конфигурации: {e}")
        CONFIG_AVAILABLE = False

if not CONFIG_AVAILABLE:
    # Fallback на старые настройки
    from core.config import Settings as OldSettings
    settings = OldSettings()
    config = None
    print("🔄 Используются настройки по умолчанию")

# Настройка безопасности с новой системой конфигурации
def get_jwt_secret() -> str:
    """Получение JWT секрета"""
    if CONFIG_AVAILABLE and config:
        return config.security.jwt_secret
    elif not CONFIG_AVAILABLE:
        # Fallback на старые настройки
        if hasattr(settings, 'JWT_SECRET') and len(settings.JWT_SECRET) >= 32:
            return settings.JWT_SECRET
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode('utf-8')

# Глобальный JWT секрет
JWT_SECRET = get_jwt_secret()

# CORS настройки с новой системой
def get_cors_origins() -> list[str]:
    """Получение CORS источников"""
    if CONFIG_AVAILABLE and config:
        return config.security.cors_origins
    elif not CONFIG_AVAILABLE:
        # Fallback на старые настройки
        if hasattr(settings, 'CORS_ORIGINS'):
            if isinstance(settings.CORS_ORIGINS, str):
                return [origin.strip() for origin in settings.CORS_ORIGINS.split(",") if origin.strip()]
            return settings.CORS_ORIGINS
    return ["http://localhost:3000", "http://localhost:8080"]

CORS_ORIGINS = get_cors_origins()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Управление жизненным циклом приложения"""
    # Инициализация DI контейнера
    container = get_container()
    
    # Логирование запуска с новой системой конфигурации
    if CONFIG_AVAILABLE and config:
        print(f"🚀 Запуск Iskra API v{config.api.port}")
        print(f"📍 Профиль: {config.profile.value}")
        print(f"🔐 JWT алгоритм: {config.security.jwt_algorithm}")
        print(f"🌐 CORS origins: {config.security.cors_origins}")
        print(f"📁 Memory root: {config.memory.memory_root}")
        print(f"⚡ Async pool: {config.performance.async_pool_size}")
    else:
        print(f"🚀 Запуск {settings.APP_NAME} v{settings.APP_VERSION}")
        print(f"📍 Режим отладки: {'включен' if settings.DEBUG else 'отключен'}")
        print(f"🔐 JWT алгоритм: {settings.JWT_ALGORITHM}")
        print(f"🌐 CORS origins: {CORS_ORIGINS}")
        print(f"📁 Memory путь: {settings.EVIDENCE_PATH}")
    
    # Инициализация legacy компонентов
    legacy_bridge = LegacyAPIBridge(container)
    await legacy_bridge.initialize()
    
    # Инициализация современных компонентов
    v2_bridge = Version2APIBridge(container)
    await v2_bridge.initialize()
    
    # Добавление в приложение для доступа в handlers
    app.state.legacy_bridge = legacy_bridge
    app.state.v2_bridge = v2_bridge
    app.state.container = container
    
    # Добавление конфигурации
    if CONFIG_AVAILABLE and config:
        app.state.config = config
    
    yield
    
    # Очистка при завершении
    print("🛑 Завершение работы приложения")
    await legacy_bridge.cleanup()
    await v2_bridge.cleanup()

# Создание FastAPI приложения
app = FastAPI(
    title=settings.APP_NAME,
    description="Искра - интеллектуальная система поиска и анализа документов (Интегрированная версия)",
    version="1.0.0",
    debug=settings.DEBUG,
    lifespan=lifespan
)

# Middleware CORS (Version 2)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

# Дополнительные middleware для безопасности
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    """Security headers middleware"""
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response

# ========== LEGACY API ENDPOINTS (Version 1 - 100% Compatibility) ==========

# Pydantic модели для обратной совместимости
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=100, description="Username")
    password: str = Field(..., min_length=8, max_length=255, description="Password")

class SearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=1000, description="Search query")
    k: int = Field(5, ge=1, le=50, description="Number of results to return")

class Chunk(BaseModel):
    doc_id: str
    score: float = Field(..., ge=0.0, le=1.0)
    content: str

class SearchResponse(BaseModel):
    query: str
    chunks: list[Chunk]
    latency_ms: float

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=5000, description="Chat message")
    topk: int = Field(4, ge=1, le=20, description="Number of top results")

class ChatResponse(BaseModel):
    reply: str
    citations: list[Chunk] = []
    cd_index: Optional[float] = None

# Совместимая система аутентификации
def require_auth(authorization: Optional[str] = Header(default=None)) -> str:
    """Аутентификация с обратной совместимостью"""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization header")
    
    token = authorization.split(" ", 1)[1]
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return data["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Token validation failed: {str(e)}")

# ========== LEGACY ENDPOINTS (Version 1 - Полностью совместимы) ==========

@app.get("/healthz")
async def healthz():
    """Health check endpoint"""
    return {"status": "ok", "time": time.time()}

@app.post("/auth/login", response_model=Token)
async def login(req: LoginRequest):
    """Аутентификация с поддержкой Version 1 API"""
    try:
        # Получаем legacy bridge из состояния приложения
        legacy_bridge = app.state.legacy_bridge
        token = await legacy_bridge.authenticate_user(req.username, req.password)
        return Token(access_token=token)
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Authentication failed: {str(e)}")

@app.post("/v1/search", response_model=SearchResponse)
async def search(req: SearchRequest, user: str = Depends(require_auth)):
    """Поиск с поддержкой Version 1 API"""
    try:
        legacy_bridge = app.state.legacy_bridge
        start = time.perf_counter()
        results = await legacy_bridge.search_evidence(req.query, req.k)
        elapsed_ms = (time.perf_counter() - start) * 1000
        
        return SearchResponse(
            query=req.query,
            chunks=[Chunk(doc_id=r.doc_id, score=r.score, content=r.content) for r in results],
            latency_ms=elapsed_ms
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

@app.post("/v1/chat", response_model=ChatResponse)
async def chat(req: ChatRequest, user: str = Depends(require_auth)):
    """Чат с поддержкой Version 1 API"""
    try:
        legacy_bridge = app.state.legacy_bridge
        response = await legacy_bridge.chat_with_evidence(req.message, req.topk)
        return ChatResponse(
            reply=response.reply,
            citations=[Chunk(doc_id=c.doc_id, score=c.score, content=c.content) for c in response.citations],
            cd_index=response.cd_index
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)}")

@app.get("/v1/version")
async def version():
    """Версия API с поддержкой Version 1"""
    try:
        legacy_bridge = app.state.legacy_bridge
        return await legacy_bridge.get_version_info()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load version info: {str(e)}")

@app.get("/v1/canon/index")
async def canon_index():
    """Канонический индекс с поддержкой Version 1"""
    try:
        legacy_bridge = app.state.legacy_bridge
        return await legacy_bridge.get_canon_index()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load canonical index: {str(e)}")

# ========== MODERN API ENDPOINTS (Version 2 - Новые возможности) ==========

@app.get("/api/v2/health", tags=["health"])
async def health_v2():
    """Улучшенный health check"""
    try:
        v2_bridge = app.state.v2_bridge
        return await v2_bridge.get_enhanced_health()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")

@app.get("/api/v2/version", tags=["version"])
async def version_v2():
    """Улучшенная информация о версии"""
    try:
        v2_bridge = app.state.v2_bridge
        return await v2_bridge.get_enhanced_version()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load version info: {str(e)}")

# ========== GLOBAL EXCEPTION HANDLERS ==========

@app.exception_handler(IskraException)
async def iskra_exception_handler(request: Request, exc: IskraException):
    """Обработчик исключений проекта Искра"""
    return exc.to_http_exception()

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Глобальный обработчик исключений"""
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "type": "internal_error",
            "exception_type": type(exc).__name__
        }
    )

# ========== ROOT ENDPOINT ==========

@app.get("/", tags=["root"])
async def root():
    """Корневой эндпоинт с информацией об интегрированной версии"""
    return {
        "message": f"Добро пожаловать в {settings.APP_NAME} (Интегрированная версия)",
        "version": "1.0.0",
        "compatibility": "Version 1 API: 100% | Version 2 API: Новые возможности",
        "docs": "/docs" if settings.DEBUG else "Документация отключена в продакшене",
        "health": "/healthz",
        "api_versions": {
            "v1_legacy": "Полная совместимость с Version 1",
            "v2_modern": "Новые возможности и улучшения",
            "bridge": "Плавная миграция между версиями"
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )