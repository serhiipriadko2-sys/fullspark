"""
Пакет синхронизированной конфигурации для интегрированной архитектуры Искра.

Объединяет настройки Version 1 и Version 2 с обеспечением совместимости,
гибкости и безопасности для всех компонентов системы.
"""

from .unified_config import (
    UnifiedConfig,
    get_config,
    init_config,
    reload_config,
    EnvironmentProfile,
    SecuritySettings,
    MemorySettings,
    SearchSettings,
    APISettings,
    PerformanceSettings,
    LoggingSettings,
    MonitoringSettings,
    DatabaseSettings,
)

from .environment import (
    EnvironmentManager,
    EnvVarType,
    EnvVarDefinition,
)

from .compatibility import (
    VersionCompatibility,
    CompatibilityMode,
    CompatibilityMapping,
)

from .migration import (
    ConfigMigrator,
    MigrationStatus,
    MigrationRule,
    MigrationResult,
)

from .validation import (
    ConfigValidator,
    ValidationLevel,
    ValidationRule,
    ValidationResult,
)

from .defaults import (
    DefaultSettings,
    DefaultProfile,
)


__version__ = "1.0.0"
__author__ = "Iskra Development Team"
__description__ = "Синхронизированная система конфигурации для интегрированной архитектуры Искра"


# Экспортируемые классы и функции
__all__ = [
    # Основные классы
    "UnifiedConfig",
    "get_config", 
    "init_config",
    "reload_config",
    
    # Enum типы
    "EnvironmentProfile",
    "CompatibilityMode", 
    "ValidationLevel",
    "DefaultProfile",
    "MigrationStatus",
    "EnvVarType",
    
    # Настройки по категориям
    "SecuritySettings",
    "MemorySettings", 
    "SearchSettings",
    "APISettings",
    "PerformanceSettings",
    "LoggingSettings",
    "MonitoringSettings",
    "DatabaseSettings",
    
    # Компоненты системы
    "EnvironmentManager",
    "VersionCompatibility",
    "ConfigMigrator",
    "ConfigValidator",
    "DefaultSettings",
    
    # Структуры данных
    "CompatibilityMapping",
    "MigrationRule", 
    "MigrationResult",
    "ValidationRule",
    "ValidationResult",
    "EnvVarDefinition",
]


# Функции быстрого доступа
def create_config(
    config_path: str = None,
    profile: EnvironmentProfile = EnvironmentProfile.DEVELOPMENT
) -> UnifiedConfig:
    """
    Быстрое создание конфигурации.
    
    Args:
        config_path: Путь к файлу конфигурации
        profile: Профиль окружения
        
    Returns:
        Объект UnifiedConfig
    """
    return UnifiedConfig(config_path=config_path, profile=profile)


def get_unified_config() -> UnifiedConfig:
    """Получение глобального экземпляра конфигурации."""
    return get_config()


def reload_configuration() -> UnifiedConfig:
    """Перезагрузка конфигурации."""
    return reload_config()


def export_env_template(output_path: str = ".env.template") -> None:
    """
    Экспорт шаблона переменных окружения.
    
    Args:
        output_path: Путь для сохранения шаблона
    """
    env_manager = EnvironmentManager()
    env_manager.generate_env_template(output_path)


def generate_migration_script(output_path: str = "config_migration.py") -> None:
    """
    Генерация скрипта миграции конфигурации.
    
    Args:
        output_path: Путь для сохранения скрипта
    """
    compatibility = VersionCompatibility()
    compatibility.create_migration_script(output_path)


# Информация о версии
def get_version_info() -> dict:
    """Получение информации о версии конфигурации."""
    return {
        "version": __version__,
        "author": __author__,
        "description": __description__,
        "supported_profiles": [profile.value for profile in EnvironmentProfile],
        "supported_compatibility_modes": [mode.value for mode in CompatibilityMode],
        "validation_levels": [level.value for level in ValidationLevel],
        "default_profiles": [profile.value for profile in DefaultProfile],
    }


# Проверка совместимости
def check_compatibility(config_data: dict) -> dict:
    """
    Быстрая проверка совместимости конфигурации.
    
    Args:
        config_data: Данные конфигурации
        
    Returns:
        Отчет о совместимости
    """
    compatibility = VersionCompatibility()
    return compatibility.generate_compatibility_report(config_data)


# Валидация конфигурации
def validate_config(config) -> dict:
    """
    Быстрая валидация конфигурации.
    
    Args:
        config: Объект конфигурации
        
    Returns:
        Результат валидации
    """
    validator = ConfigValidator()
    result = validator.validate_all_settings(config)
    
    return {
        "is_valid": result.is_valid,
        "error_count": len(result.errors),
        "warning_count": len(result.warnings),
        "errors": result.errors,
        "warnings": result.warnings,
        "statistics": result.statistics,
    }


# Примеры использования
EXAMPLES = {
    "basic_usage": '''
# Базовое использование
from merged_project.config import create_config, EnvironmentProfile

# Создание конфигурации для разработки
config = create_config(profile=EnvironmentProfile.DEVELOPMENT)

# Использование настроек
print(f"Host: {config.api.host}")
print(f"JWT Algorithm: {config.security.jwt_algorithm}")
''',
    
    "advanced_usage": '''
# Продвинутое использование
from merged_project.config import UnifiedConfig, EnvironmentManager, ConfigValidator

# Создание конфигурации с файлом
config = UnifiedConfig(config_path="config.json", profile=EnvironmentProfile.PRODUCTION)

# Валидация
validator = ConfigValidator()
result = validator.validate_all_settings(config)
if not result.is_valid:
    print("Ошибки валидации:", result.errors)

# Экспорт в .env файл
config.export_to_env_file(".env.production")
''',
    
    "migration": '''
# Миграция конфигурации
from merged_project.config import ConfigMigrator

# Создание мигратора
migrator = ConfigMigrator()

# Миграция данных конфигурации
with open("old_config.json") as f:
    old_config = json.load(f)

migrated_config = migrator.migrate_config(old_config)

# Сохранение отчета
report = migrator.create_migration_report(old_config, migrated_config)
print(report)
''',
    
    "environment": '''
# Работа с переменными окружения
from merged_project.config import EnvironmentManager

# Создание менеджера окружения
env_manager = EnvironmentManager()

# Загрузка из окружения
env_vars = env_manager.load_from_environment()

# Валидация окружения
validation = env_manager.validate_environment()
if validation["is_valid"]:
    print("Переменные окружения валидны")
else:
    print("Ошибки:", validation["errors"])

# Генерация шаблона .env
env_manager.generate_env_template(".env.template")
''',
}


def print_examples():
    """Вывод примеров использования."""
    print("=" * 70)
    print("ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ СИНХРОНИЗИРОВАННОЙ КОНФИГУРАЦИИ")
    print("=" * 70)
    
    for title, code in EXAMPLES.items():
        print(f"\n--- {title.upper().replace('_', ' ')} ---")
        print(code)
        print("-" * 50)


# Автоматическая инициализация при импорте
def _initialize_package():
    """Автоматическая инициализация пакета."""
    # Проверка совместимости Python
    import sys
    if sys.version_info < (3, 8):
        raise RuntimeError("Требуется Python 3.8 или выше")
    
    # Проверка зависимостей
    try:
        import pydantic
        import pydantic_settings
    except ImportError as e:
        raise ImportError(
            "Требуется установка pydantic и pydantic-settings: "
            "pip install pydantic pydantic-settings"
        )
    
    # Инициализация базовой конфигурации
    try:
        _ = get_config()
    except Exception as e:
        # В случае ошибки инициализации, просто логируем
        import logging
        logging.warning(f"Не удалось инициализировать конфигурацию: {e}")
    
    # Логирование успешной инициализации
    import logging
    logging.info(f"Синхронизированная конфигурация Искра v{__version__} инициализирована")


# Автоматическая инициализация
_initialize_package()