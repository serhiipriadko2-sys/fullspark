"""
Конфигурация зависимостей для DI системы

Определяет настройки для различных режимов совместимости
и автоматическое управление конфигурациями Version 1 и Version 2.
"""

import os
import logging
from typing import Any, Dict, List, Optional, Union
from enum import Enum
from dataclasses import dataclass, field
import yaml
import json
from pathlib import Path

from .di_container import ServiceLifetime, VersionCompatibility
from .service_registry import ServiceCategory

class EnvironmentMode(Enum):
    """Режимы окружения"""
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"

@dataclass
class SecurityConfig:
    """Конфигурация безопасности"""
    jwt_secret: str = "dev-secret"  # Will be overridden in production
    jwt_algorithm: str = "HS256"
    jwt_expiration_hours: int = 24
    cors_origins: List[str] = field(default_factory=lambda: ["*"])
    cors_methods: List[str] = field(default_factory=lambda: ["*"])
    cors_headers: List[str] = field(default_factory=lambda: ["*"])
    rate_limit_enabled: bool = False
    rate_limit_requests: int = 100
    rate_limit_window: int = 60
    enable_cors_validation: bool = False

@dataclass
class MemoryConfig:
    """Конфигурация системы памяти"""
    # Version 1 settings
    legacy_data_path: str = "./data/memory.jsonl"
    legacy_max_size: int = 10000
    
    # Version 2 settings
    modern_batch_size: int = 50
    modern_cache_size: int = 1000
    modern_compression: bool = True
    modern_async_enabled: bool = True
    
    # Hybrid settings
    hybrid_mode: bool = True
    auto_migration: bool = False
    fallback_to_legacy: bool = True

@dataclass
class SearchConfig:
    """Конфигурация системы поиска"""
    # Version 1 settings
    legacy_performance_mode: str = "linear"  # linear, optimized
    
    # Version 2 settings
    modern_cache_enabled: bool = True
    modern_cache_size: int = 1000
    modern_async_enabled: bool = True
    modern_performance_mode: str = "indexed"
    
    # Hybrid settings
    hybrid_auto_select: bool = True
    hybrid_threshold: int = 1000  # Switch to modern for >1000 items

@dataclass
class APIConfig:
    """Конфигурация API"""
    # Version 1 compatibility
    legacy_endpoints_preserved: bool = True
    legacy_response_format: bool = True
    
    # Version 2 enhancements
    modular_routing: bool = True
    enhanced_validation: bool = True
    versioning_support: bool = True
    
    # Performance
    async_handlers: bool = True
    request_batch_size: int = 100
    response_compression: bool = True

@dataclass
class DIConfig:
    """Главная конфигурация DI системы"""
    environment: EnvironmentMode = EnvironmentMode.DEVELOPMENT
    version_compatibility: VersionCompatibility = VersionCompatibility.HYBRID
    auto_discover: bool = True
    enable_metrics: bool = True
    enable_logging: bool = True
    service_scan_paths: List[str] = field(default_factory=lambda: ["lib", "optimized", "architecture"])
    
    # Компоненты конфигурации
    security: SecurityConfig = field(default_factory=SecurityConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    api: APIConfig = field(default_factory=APIConfig)
    
    # Переменные окружения
    env_overrides: Dict[str, str] = field(default_factory=dict)

class DependencyConfig:
    """
    Централизованная конфигурация зависимостей
    
    Управляет настройками DI системы для различных режимов
    и обеспечивает автоматическую конфигурацию для Version 1/2.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.logger = logging.getLogger(__name__)
        self.config: DIConfig = DIConfig()
        self.config_path = config_path
        
        # Загрузка конфигурации
        if config_path and Path(config_path).exists():
            self.load_from_file(config_path)
        else:
            self.load_from_environment()
        
        # Применение overrides для production
        self._apply_production_security()
        
        self.logger.info(f"Initialized DI config for {self.config.environment.value} mode")
    
    def load_from_file(self, config_path: str):
        """Загрузка конфигурации из файла"""
        
        config_file = Path(config_path)
        
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                if config_file.suffix.lower() == '.yaml' or config_file.suffix.lower() == '.yml':
                    data = yaml.safe_load(f)
                elif config_file.suffix.lower() == '.json':
                    data = json.load(f)
                else:
                    raise ValueError(f"Unsupported config format: {config_file.suffix}")
            
            self._apply_config_data(data)
            self.logger.info(f"Loaded config from {config_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to load config from {config_path}: {e}")
            self.load_from_environment()  # Fallback
    
    def load_from_environment(self):
        """Загрузка конфигурации из переменных окружения"""
        
        # Основные настройки
        env_mode = os.getenv('DI_ENVIRONMENT', 'development').lower()
        version_mode = os.getenv('DI_VERSION_COMPATIBILITY', 'hybrid').lower()
        
        try:
            self.config.environment = EnvironmentMode(env_mode)
        except ValueError:
            self.logger.warning(f"Invalid environment mode: {env_mode}, using development")
            self.config.environment = EnvironmentMode.DEVELOPMENT
        
        try:
            self.config.version_compatibility = VersionCompatibility(version_mode)
        except ValueError:
            self.logger.warning(f"Invalid version mode: {version_mode}, using hybrid")
            self.config.version_compatibility = VersionCompatibility.HYBRID
        
        # Security config
        self.config.security.jwt_secret = os.getenv('JWT_SECRET', self.config.security.jwt_secret)
        cors_origins = os.getenv('CORS_ORIGINS')
        if cors_origins:
            self.config.security.cors_origins = cors_origins.split(',')
        
        self.config.security.enable_cors_validation = os.getenv('ENABLE_CORS_VALIDATION', 'false').lower() == 'true'
        self.config.security.rate_limit_enabled = os.getenv('RATE_LIMIT_ENABLED', 'false').lower() == 'true'
        
        # Memory config
        self.config.memory.modern_batch_size = int(os.getenv('MEMORY_BATCH_SIZE', str(self.config.memory.modern_batch_size)))
        self.config.memory.modern_cache_size = int(os.getenv('MEMORY_CACHE_SIZE', str(self.config.memory.modern_cache_size)))
        self.config.memory.hybrid_mode = os.getenv('MEMORY_HYBRID_MODE', 'true').lower() == 'true'
        
        # Search config
        self.config.search.modern_cache_enabled = os.getenv('SEARCH_CACHE_ENABLED', 'true').lower() == 'true'
        self.config.search.hybrid_auto_select = os.getenv('SEARCH_HYBRID_AUTO', 'true').lower() == 'true'
        
        # API config
        self.config.api.async_handlers = os.getenv('API_ASYNC_HANDLERS', 'true').lower() == 'true'
        self.config.api.modular_routing = os.getenv('API_MODULAR_ROUTING', 'false').lower() == 'true'
        
        self.logger.info("Loaded config from environment variables")
    
    def _apply_config_data(self, data: Dict[str, Any]):
        """Применение данных конфигурации"""
        
        # Основные настройки
        if 'environment' in data:
            try:
                self.config.environment = EnvironmentMode(data['environment'].lower())
            except ValueError:
                self.logger.warning(f"Invalid environment in config: {data['environment']}")
        
        if 'version_compatibility' in data:
            try:
                self.config.version_compatibility = VersionCompatibility(data['version_compatibility'].lower())
            except ValueError:
                self.logger.warning(f"Invalid version compatibility in config: {data['version_compatibility']}")
        
        # Security config
        if 'security' in data:
            sec_data = data['security']
            self.config.security.jwt_secret = sec_data.get('jwt_secret', self.config.security.jwt_secret)
            self.config.security.jwt_algorithm = sec_data.get('jwt_algorithm', self.config.security.jwt_algorithm)
            self.config.security.cors_origins = sec_data.get('cors_origins', self.config.security.cors_origins)
            self.config.security.enable_cors_validation = sec_data.get('enable_cors_validation', self.config.security.enable_cors_validation)
        
        # Memory config
        if 'memory' in data:
            mem_data = data['memory']
            self.config.memory.modern_batch_size = mem_data.get('modern_batch_size', self.config.memory.modern_batch_size)
            self.config.memory.modern_cache_size = mem_data.get('modern_cache_size', self.config.memory.modern_cache_size)
            self.config.memory.hybrid_mode = mem_data.get('hybrid_mode', self.config.memory.hybrid_mode)
        
        # Search config
        if 'search' in data:
            search_data = data['search']
            self.config.search.modern_cache_enabled = search_data.get('modern_cache_enabled', self.config.search.modern_cache_enabled)
            self.config.search.hybrid_auto_select = search_data.get('hybrid_auto_select', self.config.search.hybrid_auto_select)
    
    def _apply_production_security(self):
        """Применение усиленных настроек безопасности для production"""
        
        if self.config.environment == EnvironmentMode.PRODUCTION:
            # Исправление критических уязвимостей Version 1
            if self.config.security.jwt_secret == "dev-secret":
                self.config.security.jwt_secret = os.getenv('PRODUCTION_JWT_SECRET', 'production-secret-change-me')
                self.logger.warning("JWT secret replaced with production value")
            
            if self.config.security.cors_origins == ["*"]:
                prod_origins = os.getenv('PRODUCTION_CORS_ORIGINS', 'https://yourdomain.com').split(',')
                self.config.security.cors_origins = prod_origins
                self.logger.warning("CORS origins restricted for production")
            
            # Включение дополнительных функций безопасности
            self.config.security.enable_cors_validation = True
            self.config.security.rate_limit_enabled = True
    
    def get_security_config(self) -> SecurityConfig:
        """Получение конфигурации безопасности"""
        return self.config.security
    
    def get_memory_config(self) -> MemoryConfig:
        """Получение конфигурации памяти"""
        return self.config.memory
    
    def get_search_config(self) -> SearchConfig:
        """Получение конфигурации поиска"""
        return self.config.search
    
    def get_api_config(self) -> APIConfig:
        """Получение конфигурации API"""
        return self.config.api
    
    def get_dicomponent_lifetime(self, component_name: str) -> ServiceLifetime:
        """Определение времени жизни компонента"""
        
        # Singleton для тяжелых компонентов
        if component_name in ['memory_manager', 'search_engine', 'auth_service']:
            return ServiceLifetime.SINGLETON
        
        # Scoped для контекстных сервисов
        if component_name in ['auth_service', 'rate_limiter']:
            return ServiceLifetime.SCOPED
        
        # Transient для легких сервисов
        return ServiceLifetime.TRANSIENT
    
    def get_component_config(self, component_name: str, category: ServiceCategory) -> Dict[str, Any]:
        """Получение конфигурации для конкретного компонента"""
        
        base_config = {
            'version_compatibility': self.config.version_compatibility,
            'environment': self.config.environment.value,
            'enable_metrics': self.config.enable_metrics
        }
        
        if category == ServiceCategory.MEMORY:
            base_config.update({
                'batch_size': self.config.memory.modern_batch_size,
                'cache_size': self.config.memory.modern_cache_size,
                'hybrid_mode': self.config.memory.hybrid_mode,
                'compression': self.config.memory.modern_compression,
                'async_enabled': self.config.memory.modern_async_enabled
            })
        elif category == ServiceCategory.SEARCH:
            base_config.update({
                'cache_enabled': self.config.search.modern_cache_enabled,
                'cache_size': self.config.search.modern_cache_size,
                'async_enabled': self.config.search.modern_async_enabled,
                'performance_mode': self.config.search.modern_performance_mode,
                'hybrid_auto_select': self.config.search.hybrid_auto_select
            })
        elif category == ServiceCategory.SECURITY:
            base_config.update({
                'jwt_secret': self.config.security.jwt_secret,
                'jwt_algorithm': self.config.security.jwt_algorithm,
                'cors_origins': self.config.security.cors_origins,
                'rate_limit_enabled': self.config.security.rate_limit_enabled,
                'enable_cors_validation': self.config.security.enable_cors_validation
            })
        elif category == ServiceCategory.API:
            base_config.update({
                'async_handlers': self.config.api.async_handlers,
                'modular_routing': self.config.api.modular_routing,
                'versioning_support': self.config.api.versioning_support,
                'response_compression': self.config.api.response_compression
            })
        
        return base_config
    
    def save_to_file(self, config_path: str):
        """Сохранение конфигурации в файл"""
        
        config_data = {
            'environment': self.config.environment.value,
            'version_compatibility': self.config.version_compatibility.value,
            'auto_discover': self.config.auto_discover,
            'enable_metrics': self.config.enable_metrics,
            'security': {
                'jwt_secret': '***',  # Не сохраняем реальный секрет
                'jwt_algorithm': self.config.security.jwt_algorithm,
                'cors_origins': self.config.security.cors_origins,
                'enable_cors_validation': self.config.security.enable_cors_validation,
                'rate_limit_enabled': self.config.security.rate_limit_enabled
            },
            'memory': {
                'modern_batch_size': self.config.memory.modern_batch_size,
                'modern_cache_size': self.config.memory.modern_cache_size,
                'hybrid_mode': self.config.memory.hybrid_mode,
                'modern_compression': self.config.memory.modern_compression
            },
            'search': {
                'modern_cache_enabled': self.config.search.modern_cache_enabled,
                'modern_cache_size': self.config.search.modern_cache_size,
                'hybrid_auto_select': self.config.search.hybrid_auto_select,
                'modern_performance_mode': self.config.search.modern_performance_mode
            },
            'api': {
                'async_handlers': self.config.api.async_handlers,
                'modular_routing': self.config.api.modular_routing,
                'enhanced_validation': self.config.api.enhanced_validation,
                'response_compression': self.config.api.response_compression
            }
        }
        
        config_file = Path(config_path)
        
        with open(config_file, 'w', encoding='utf-8') as f:
            if config_file.suffix.lower() in ['.yaml', '.yml']:
                yaml.safe_dump(config_data, f, default_flow_style=False, allow_unicode=True)
            elif config_file.suffix.lower() == '.json':
                json.dump(config_data, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"Saved config to {config_path}")
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Получение сводки конфигурации"""
        
        return {
            'environment': self.config.environment.value,
            'version_compatibility': self.config.version_compatibility.value,
            'security': {
                'jwt_secret_configured': bool(self.config.security.jwt_secret and self.config.security.jwt_secret != "dev-secret"),
                'cors_validation_enabled': self.config.security.enable_cors_validation,
                'rate_limiting_enabled': self.config.security.rate_limit_enabled
            },
            'memory': {
                'hybrid_mode': self.config.memory.hybrid_mode,
                'batch_size': self.config.memory.modern_batch_size,
                'cache_size': self.config.memory.modern_cache_size
            },
            'search': {
                'cache_enabled': self.config.search.modern_cache_enabled,
                'auto_select': self.config.search.hybrid_auto_select,
                'performance_mode': self.config.search.modern_performance_mode
            },
            'api': {
                'async_handlers': self.config.api.async_handlers,
                'modular_routing': self.config.api.modular_routing
            }
        }