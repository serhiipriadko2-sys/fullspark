"""
Интегрированная архитектура проекта Искра v1.0

Основной пакет, объединяющий функциональность Version 1 с архитектурными улучшениями Version 2.
"""

__version__ = "1.0.0"
__author__ = "Iskra Development Team"
__description__ = "Интегрированная архитектура проекта Искра - объединение Version 1 и Version 2"

# Экспорт основных компонентов
from .core.config import settings
from .core.exceptions import IskraException
from .services.dependency_injection import get_container, get_service_registry

__all__ = [
    "settings",
    "IskraException", 
    "get_container",
    "get_service_registry",
]