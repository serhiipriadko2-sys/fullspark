# 📚 Документация системы обработки ошибок Iskra

## 🎯 Обзор

Интегрированная система обработки ошибок объединяет базовую обработку Version 1 с продвинутой системой Version 2, обеспечивая полную обратную совместимость и новые возможности.

## 🏗️ Архитектура системы

### Многоуровневая обработка ошибок

```
┌─────────────────────────────────────────────────────────┐
│                    HTTP Level                            │
│  Authentication  │  Authorization  │  Validation         │
├─────────────────────────────────────────────────────────┤
│                   Service Level                          │
│         Business Logic        │    Configuration         │
├─────────────────────────────────────────────────────────┤
│                  Repository Level                        │
│    Database     │    Search     │   Vector Search       │
├─────────────────────────────────────────────────────────┤
│                Infrastructure Level                      │
│  External Services  │    System     │   Network           │
└─────────────────────────────────────────────────────────┘
```

## 🔧 Основные компоненты

### 1. Иерархия исключений (`core/exceptions/`)

#### Базовые классы

```python
from core.exceptions import (
    BaseIskraException,     # Базовый класс для всех исключений
    ErrorLevel,            # Уровни серьезности
    ErrorType,             # Типы ошибок по доменам
    ErrorScope             # Области применения
)
```

#### Уровни ошибок (ErrorLevel)

| Уровень | Описание | Логирование |
|---------|----------|-------------|
| `CRITICAL` | Критические ошибки системы | Всегда |
| `HIGH` | Высокий приоритет, требуют внимания | Всегда |
| `MEDIUM` | Средний приоритет (по умолчанию) | По настройкам |
| `LOW` | Низкий приоритет | Только в DEBUG |
| `INFO` | Информационные сообщения | Только в DEBUG |

#### Типы ошибок (ErrorType)

| Тип | Описание | HTTP статус |
|-----|----------|-------------|
| `AUTHENTICATION` | Ошибки аутентификации | 401 |
| `AUTHORIZATION` | Ошибки авторизации | 403 |
| `VALIDATION` | Ошибки валидации | 422 |
| `BUSINESS_LOGIC` | Ошибки бизнес-логики | 500 |
| `DATABASE` | Ошибки базы данных | 500 |
| `SEARCH` | Ошибки поиска | 500 |
| `VECTOR_SEARCH` | Ошибки векторного поиска | 500 |
| `INFRASTRUCTURE` | Системные ошибки | 500 |
| `EXTERNAL_SERVICE` | Ошибки внешних сервисов | 502 |

### 2. Обработчики ошибок (`core/handlers/`)

#### HTTP Level Handlers

```python
from core.handlers import (
    AuthenticationHandler,    # Ошибки аутентификации
    AuthorizationHandler,     # Ошибки авторизации
    ValidationHandler,        # Ошибки валидации
    NotFoundHandler,          # Ресурс не найден
    HttpErrorHandler          # Общий HTTP обработчик
)
```

#### Service Level Handlers

```python
from core.handlers import (
    ServiceErrorHandler,      # Ошибки бизнес-логики
    ConfigurationHandler      # Ошибки конфигурации
)
```

#### Repository Level Handlers

```python
from core.handlers import (
    RepositoryErrorHandler,   # Ошибки доступа к данным
    DatabaseException,        # Ошибки БД
    SearchException,          # Ошибки поиска
    VectorSearchException     # Ошибки векторного поиска
)
```

### 3. Система логирования (`core/logging/`)

#### Основные возможности

- **Структурированное логирование** в JSON формате
- **Контекстное логирование** с request_id, user_id, correlation_id
- **Асинхронное логирование** для высоконагруженных систем
- **Разные форматы**: JSON, текст, цветной
- **Множественные destinations**: консоль, файл, БД, Elasticsearch

#### Настройка логирования

```python
from core.logging import setup_logging, CentralizedLogger

# Базовая настройка
logger = setup_logging(
    log_level="INFO",
    log_file="logs/app.log",
    format_type="json",
    enable_async=True
)

# Продвинутая настройка
logger = CentralizedLogger(
    name="my_app",
    format_type="json",
    destinations=["console", "file"],
    log_file="logs/app.log",
    level="INFO"
)

# Контекстное логирование
from core.logging import LogContext

context = LogContext(
    request_id="req_123",
    user_id="user_456",
    endpoint="/api/users",
    method="POST",
    correlation_id="corr_789"
)

logger.log_error_with_context(
    "Пользователь создан",
    context=context.__dict__,
    level="INFO"
)
```

### 4. Web API Middleware (`core/middleware/`)

#### Компоненты middleware

```python
from core.middleware import (
    ErrorHandlingMiddleware,         # Основная обработка ошибок
    PerformanceMonitoringMiddleware, # Мониторинг производительности
    AuthenticationMiddleware,        # Аутентификация пользователей
    AuditLoggingMiddleware,          # Аудит действий
    SecurityHeadersMiddleware        # Security headers
)
```

#### Настройка middleware stack

```python
from fastapi import FastAPI
from core import setup_error_system
from core.middleware import setup_middleware_stack

app = FastAPI()

# Настройка системы
error_manager, logger, _ = setup_error_system(
    log_level="INFO",
    log_file="logs/app.log"
)

# Создание auth сервиса (mock)
auth_service = lambda token: {"user_id": "123", "session_id": "456"}

# Настройка middleware stack
setup_middleware_stack(
    app,
    error_manager,
    logger,
    auth_service=auth_service,
    enable_audit=True
)
```

## 📝 Использование исключений

### Version 1 Совместимость

#### Простые исключения (автоматический режим)

```python
from core.exceptions import IskraException

# Простое исключение (становится Version 1 стилем)
raise IskraException("Простая ошибка")

# С деталями (автоматически переключается в Version 2 режим)
raise IskraException(
    "Ошибка с деталями",
    details={
        "status_code": 422,
        "field": "email",
        "level": "high"
    }
)
```

#### HTTP исключения

```python
from core.exceptions import (
    AuthenticationException,
    AuthorizationException,
    ValidationException,
    NotFoundException
)

# Аутентификация
raise AuthenticationException("Токен истек")

# Авторизация
raise AuthorizationException("Недостаточно прав")

# Валидация
raise ValidationException("Неверный email", field="email")

# Ресурс не найден
raise NotFoundException("Пользователь")
```

### Version 2 Возможности

#### Сервисные исключения

```python
from core.exceptions import (
    BusinessLogicException,
    ConfigurationException,
    ServiceLevelException
)

# Бизнес-логика
raise BusinessLogicException(
    "Нельзя удалить администратора",
    error_code="BIZ_001"
)

# Конфигурация
raise ConfigurationException(
    "Отсутствует настройка базы данных",
    config_key="DATABASE_URL"
)
```

#### Репозиторные исключения

```python
from core.exceptions import (
    DatabaseException,
    SearchException,
    VectorSearchException,
    RepositoryLevelException
)

# База данных
raise DatabaseException(
    "Ошибка подключения к PostgreSQL",
    cause=original_exception
)

# Поиск
raise SearchException(
    "Ошибка выполнения запроса",
    cause=original_exception
)

# Векторный поиск
raise VectorSearchException(
    "Ошибка векторизации",
    cause=original_exception
)
```

#### Инфраструктурные исключения

```python
from core.exceptions import (
    ExternalServiceException,
    SystemException,
    InfrastructureLevelException
)

# Внешний сервис
raise ExternalServiceException(
    "Сервис недоступен",
    service_name="external_api",
    status_code=503
)

# Системная ошибка
raise SystemException(
    "Критическая ошибка системы",
    error_code="SYS_001"
)
```

#### Продвинутые исключения

```python
from core.exceptions import BaseIskraException, ErrorLevel, ErrorType, ErrorScope

# Полный контроль над исключением
raise BaseIskraException(
    message="Продвинутая ошибка",
    error_code="ADV_001",
    details={
        "user_id": "123",
        "action": "delete",
        "resource": "user"
    },
    status_code=422,
    level=ErrorLevel.HIGH,
    error_type=ErrorType.BUSINESS_LOGIC,
    scope=ErrorScope.SERVICE,
    cause=original_exception,
    trace=custom_traceback
)
```

## 🎯 Декораторы для обработки ошибок

### Сервисный уровень

```python
from core.handlers import service_error_handler

@service_error_handler
def create_user(user_data: UserCreate):
    """Автоматически обрабатывает все ошибки в функции."""
    if not user_data.email:
        raise ValidationException("Email обязателен", field="email")
    
    # Логика создания пользователя
    return {"id": 1, "username": user_data.username}
```

### Репозиторный уровень

```python
from core.handlers import repository_error_handler

@repository_error_handler
def get_user_from_db(user_id: int):
    """Автоматически обрабатывает ошибки БД."""
    # Логика работы с базой данных
    return user_data
```

### Универсальный декоратор

```python
from core.handlers import handle_errors

@handle_errors(error_manager)
async def complex_operation():
    """Обрабатывает ошибки через ErrorHandlerManager."""
    # Ваша логика
    pass
```

## 📊 Логирование и мониторинг

### Контекстное логирование

```python
from core.logging import LoggerFactory, LogContext

# Установка контекста
context = LogContext(
    request_id="req_123",
    user_id="user_456", 
    endpoint="/api/users",
    method="POST"
)

LoggerFactory.set_context(context)

# Логирование с контекстом
logger = LoggerFactory.get_logger("my_service")
logger.log_error_with_context(
    "Пользователь создан",
    context=context.__dict__,
    level="INFO"
)
```

### Асинхронное логирование

```python
import asyncio
from core.logging import AsyncLogger

async_logger = AsyncLogger(logger)

# Асинхронное логирование
async def high_load_operation():
    await async_logger.log_error_async(
        "Высоконагруженная операция завершена",
        context={"duration": "2.5s"}
    )
```

### Аудит логирование

```python
from core.logging import LoggerFactory

audit_logger = LoggerFactory.get_audit_logger()

# Логирование действий пользователей
audit_logger.log_audit(
    action="user_deleted",
    user_id="user123",
    resource="/api/users/456",
    result="success",
    context={
        "admin_id": "admin001",
        "reason": "policy_violation"
    }
)
```

### Performance метрики

```python
from core.logging import log_request, log_database_operation, log_search_operation

# HTTP запросы
log_request(
    logger,
    method="GET",
    path="/api/users/123",
    status_code=200,
    duration=0.150,
    request_id="req_123"
)

# Операции БД
log_database_operation(
    logger,
    operation="SELECT",
    table="users",
    duration=0.050,
    success=True,
    context={"user_id": 123}
)

# Операции поиска
log_search_operation(
    logger,
    query="искра",
    results_count=42,
    duration=0.200,
    search_type="vector"
)
```

## 🔧 FastAPI интеграция

### Полный пример приложения

```python
from fastapi import FastAPI, HTTPException, Depends
from fastapi.security import HTTPBearer
from core import setup_error_system
from core.middleware import setup_middleware_stack
from core.exceptions import AuthenticationException
from core.handlers import service_error_handler

# Создание приложения
app = FastAPI(title=" Iskra App", version="1.0.0")

# Настройка системы ошибок
error_manager, logger, _ = setup_error_system(
    log_level="INFO",
    log_file="logs/app.log",
    enable_async_logging=True
)

# Mock auth service
async def auth_service_validate_token(token: str):
    if token == "valid":
        return {"user_id": "123", "session_id": "456"}
    raise AuthenticationException("Недействительный токен")

# Настройка middleware
setup_middleware_stack(
    app,
    error_manager,
    logger,
    auth_service=auth_service_validate_token
)

# Добавление endpoints
@app.get("/api/public")
async def public_endpoint():
    return {"message": "Публичный endpoint"}

@app.get("/api/protected")
async def protected_endpoint():
    return {"message": "Защищенный endpoint"}

# Использование сервисов с декораторами
class UserService:
    @service_error_handler
    def get_user(self, user_id: int):
        if user_id <= 0:
            from core.exceptions import ValidationException
            raise ValidationException("ID должен быть положительным", field="user_id")
        
        if user_id == 999:
            from core.exceptions import NotFoundException
            raise NotFoundException(f"Пользователь {user_id}")
        
        return {"id": user_id, "name": "John Doe"}

user_service = UserService()

@app.get("/api/users/{user_id}")
async def get_user(user_id: int):
    user = user_service.get_user(user_id)
    return user

# Запуск сервера
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

## 🧪 Тестирование

### Unit тесты исключений

```python
import pytest
from core.exceptions import (
    BaseIskraException,
    AuthenticationException,
    ValidationException,
    BusinessLogicException,
    ErrorLevel
)

def test_authentication_exception():
    """Тест ошибки аутентификации."""
    exc = AuthenticationException("Токен истек")
    
    assert exc.message == "Токен истек"
    assert exc.status_code == 401
    assert exc.error_type == ErrorType.AUTHENTICATION
    assert exc.level == ErrorLevel.HIGH
    
    # Тест преобразования в HTTP исключение
    http_exc = exc.to_http_exception()
    assert http_exc.status_code == 401
    assert "error" in http_exc.detail

def test_validation_exception_with_field():
    """Тест ошибки валидации с указанием поля."""
    exc = ValidationException("Неверный email", field="email")
    
    assert exc.message == "Неверный email"
    assert exc.details["field"] == "email"
    assert exc.status_code == 422

def test_base_iskra_exception():
    """Тест базового Iskra исключения."""
    exc = BaseIskraException(
        message="Тестовая ошибка",
        error_code="TEST_001",
        details={"context": "test"},
        level=ErrorLevel.HIGH
    )
    
    assert exc.message == "Тестовая ошибка"
    assert exc.error_code == "TEST_001"
    assert exc.details["context"] == "test"
    assert exc.level == ErrorLevel.HIGH
    
    # Тест to_dict()
    exc_dict = exc.to_dict()
    assert exc_dict["message"] == "Тестовая ошибка"
    assert exc_dict["error_code"] == "TEST_001"

def test_version1_compatibility():
    """Тест совместимости с Version 1."""
    # Простое исключение (Version 1 стиль)
    exc = IskraException("Простая ошибка")
    assert exc._version1_mode is True
    
    # С деталями (Version 2 режим)
    exc2 = IskraException(
        "Ошибка с деталями",
        details={"field": "email"}
    )
    assert exc2._version1_mode is False
```

### Интеграционные тесты middleware

```python
from fastapi.testclient import TestClient
from demo import create_app

def test_error_middleware():
    """Тест работы middleware обработки ошибок."""
    app = create_app()
    client = TestClient(app)
    
    # Тест валидационной ошибки
    response = client.get("/api/demo/validation-error")
    assert response.status_code == 422
    assert "error" in response.json()
    
    # Тест ошибки аутентификации
    response = client.get("/api/demo/auth-error")
    assert response.status_code == 401
    assert "requires_auth" in response.json()
    
    # Тест Version 1 совместимости
    response = client.get("/api/demo/version1-compatible")
    assert response.status_code == 500
    # Version 1 возвращает простое сообщение
    assert response.json()["error"] == "Это ошибка в стиле Version 1"

def test_performance_monitoring():
    """Тест мониторинга производительности."""
    # Проверяем, что заголовки добавляются
    response = client.get("/health")
    assert "X-Request-ID" in response.headers
    assert "X-Response-Time" in response.headers
```

## 🚀 Производительность и оптимизация

### Асинхронное логирование

```python
import asyncio
from core.logging import AsyncLogger

async def high_throughput_system():
    """Система с высоким трафиком."""
    logger = CentralizedLogger("high_throughput")
    async_logger = AsyncLogger(logger)
    
    # Параллельное логирование многих событий
    tasks = []
    for i in range(1000):
        task = async_logger.log_error_async(
            f"Event {i}",
            context={"event_id": i}
        )
        tasks.append(task)
    
    # Выполняем все логирования параллельно
    await asyncio.gather(*tasks)
```

### Батчевое логирование

```python
from core.logging import CentralizedLogger

class BatchLogger:
    """Батчевый логгер для высоких нагрузок."""
    
    def __init__(self, base_logger: CentralizedLogger, batch_size: int = 100):
        self.base_logger = base_logger
        self.batch_size = batch_size
        self.pending_logs = []
    
    def log_batch(self, message: str, context: dict):
        """Добавляет лог в батч."""
        self.pending_logs.append({
            "message": message,
            "context": context,
            "timestamp": datetime.now().isoformat()
        })
        
        if len(self.pending_logs) >= self.batch_size:
            self.flush()
    
    def flush(self):
        """Отправляет все накопленные логи."""
        if self.pending_logs:
            # Оптимизированная отправка батча
            for log_entry in self.pending_logs:
                self.base_logger.log_error_with_context(
                    log_entry["message"],
                    context=log_entry["context"]
                )
            self.pending_logs.clear()

# Использование
batch_logger = BatchLogger(logger, batch_size=50)

for i in range(200):
    batch_logger.log_batch(f"Event {i}", {"batch": True})
```

## 🔍 Отладка и мониторинг

### Детальное логирование исключений

```python
import traceback
from core.exceptions import get_exception_info

def detailed_error_logging():
    """Детальное логирование для отладки."""
    try:
        risky_operation()
    except Exception as exc:
        # Получаем детальную информацию
        error_info = get_exception_info(exc)
        
        # Логируем с полным контекстом
        logger.log_exception(
            exc,
            level="ERROR",
            context={
                "function": "risky_operation",
                "user_id": get_current_user_id(),
                "request_id": get_request_id(),
                **error_info
            }
        )
```

### Мониторинг производительности

```python
import time
from contextlib import contextmanager

@contextmanager
def performance_monitor(operation_name: str, logger: CentralizedLogger):
    """Мониторинг производительности операций."""
    start_time = time.time()
    
    try:
        yield
    finally:
        duration = time.time() - start_time
        
        # Логируем метрики производительности
        logger.log_performance(
            operation_name,
            duration,
            context={
                "threshold_ms": 1000,
                "is_slow": duration > 1.0
            }
        )

# Использование
with performance_monitor("database_query", logger):
    result = execute_database_query()
```

## 📋 Справочник по исключениям

### HTTP Level

| Исключение | Статус код | Описание |
|------------|------------|----------|
| `AuthenticationException` | 401 | Ошибка аутентификации |
| `AuthorizationException` | 403 | Недостаточно прав |
| `ValidationException` | 422 | Ошибка валидации данных |
| `NotFoundException` | 404 | Ресурс не найден |

### Service Level

| Исключение | Статус код | Описание |
|------------|------------|----------|
| `BusinessLogicException` | 500 | Ошибка бизнес-логики |
| `ConfigurationException` | 500 | Ошибка конфигурации |

### Repository Level

| Исключение | Статус код | Описание |
|------------|------------|----------|
| `DatabaseException` | 500 | Ошибка базы данных |
| `SearchException` | 500 | Ошибка поиска |
| `VectorSearchException` | 500 | Ошибка векторного поиска |

### Infrastructure Level

| Исключение | Статус код | Описание |
|------------|------------|----------|
| `ExternalServiceException` | 502 | Ошибка внешнего сервиса |
| `SystemException` | 500 | Системная ошибка |

## 🎉 Заключение

Интегрированная система обработки ошибок Iskra обеспечивает:

✅ **Полную обратную совместимость** с Version 1  
✅ **Продвинутые возможности** Version 2  
✅ **Многоуровневую обработку** ошибок  
✅ **Централизованное логирование**  
✅ **Автоматическую обработку** через middleware  
✅ **Высокую производительность** с асинхронным логированием  

**Результат:** Надежная, масштабируемая и легко поддерживаемая система обработки ошибок для современных приложений.

---

**Автор:** Iskra Integration Team  
**Версия документации:** 1.0.0  
**Дата:** 2025-11-01