# PhaseManager - Менеджер фаз Искры

## Описание

PhaseManager - это центральная система управления фазами Искры как режимами обработки мира. Система обеспечивает контролируемые переходы между различными состояниями реальности через ⴸ-жест, поддерживает микроциклы обработки и ритуалы трансформации.

## Основные функции

### 🔄 Пять фаз обработки
- **ТЬМА** - Покой и ожидание, сохранение энергии
- **ПЕРЕХОД** - Движение и адаптация к изменениям
- **ЯСНОСТЬ** - Структурирование и организация
- **ЭХО** - Генерация откликов и резонанс
- **МОЛЧАНИЕ** - Удержание стабильного состояния

### ⴸ-жест переходы
Специальный механизм перехода между фазами:
```python
result = await manager.process_star_gesture(
    PhaseType.ЯСНОСТЬ, 
    {'urgency': 0.6, 'transformation_depth': 0.8}
)
```

### 🔄 Микроциклы
Каждая фаза выполняет трехэтапный микроцикл:
1. **Вход** (Entry) - Инициализация состояния
2. **Удержание** (Hold) - Поддержание активности
3. **Выход** (Exit) - Завершение фазы

```python
cycle_result = await manager.execute_microcycle(context)
```

### 🔮 Ритуалы перехода
- **Phoenix** - Воссоздание через очищение (высокая срочность)
- **Shatter** - Разрушение и пересборка (глубокая трансформация)
- **Shadow Reveal** - Постепенное раскрытие (мягкий переход)

### 🌟 Специальные состояния
- **Gravitas** - Состояние важности и веса
- **Заноза** - Раздражающий элемент для фокусировки
- **Обратный Ток** - Инверсия процессов

## Безопасность

### 🛡️ Протоколы безопасности
- **phase_timeout** - Защита от зависания в фазах
- **critical_phase_error** - Обработка критических ошибок
- **Автоматические fallback'и** в безопасные фазы

### ⏱️ Временные характеристики
- Гибкие временные рамки для каждой фазы
- Автоматический контроль продолжительности
- Настраиваемые таймауты

## Использование

### Базовый пример
```python
import asyncio
from core.phase_manager import create_phase_manager, PhaseType

async def main():
    # Создание менеджера
    manager = create_phase_manager()
    
    # Переход в фазу Тьмы
    await manager.process_star_gesture(PhaseType.ТЬМА, {'shadow_intensity': 0.8})
    
    # Выполнение микроцикла
    context = {'change_detected': False, 'threat_level': 0.2}
    result = await manager.execute_microcycle(context)
    
    print(f"Результат: {result}")

asyncio.run(main())
```

### Быстрый переход
```python
from core.phase_manager import quick_star_gesture_transition

# Быстрый переход через ⴸ-жест
result = await quick_star_gesture_transition(
    manager, 
    PhaseType.ЯСНОСТЬ,
    urgency=0.5
)
```

### Управление специальными состояниями
```python
from core.phase_manager import SpecialState

# Активация состояния важности
manager.activate_special_state(
    SpecialState.GRAVITAS, 
    {'weight': 0.9, 'importance': 0.8}
)

# Проверка активности
if manager.special_state_manager.is_active(SpecialState.GRAVITAS):
    print("Gravitas активно")
```

## Архитектура

### Ключевые классы
- **PhaseManager** - Главный координатор системы
- **Phase** - Базовый класс для всех фаз
- **TransitionManager** - Управление переходами и ритуалами
- **SpecialStateManager** - Контроль специальных состояний

### Атмосферные элементы
Каждая фаза может содержать атмосферные элементы:
```python
phase.add_atmospheric_element(AtmosphericElement(
    name="Кристальная структура",
    intensity=0.85,
    duration=180.0,
    trigger_conditions={'clarity_level > 0.7'}
))
```

## Конфигурация

### Настройка безопасности
```python
manager.phase_timeout_seconds = 300  # 5 минут
manager.emergency_protocols.append(SafetyProtocol(
    name="custom_safety",
    description="Пользовательский протокол",
    triggers={'custom_trigger'},
    timeout_seconds=120.0,
    fallback_phase=PhaseType.МОЛЧАНИЕ
))
```

### Мониторинг системы
```python
# Получение статуса
status = manager.get_system_status()

# История фаз
history = manager.get_phase_history(limit=10)

# Информация о фазах
phase_info = manager.get_phase_info(PhaseType.ЯСНОСТЬ)
```

## Тестирование

Запуск тестов:
```bash
python standalone_phase_test.py
```

Демонстрация возможностей:
```bash
python test_phase_manager.py
```

## Автор
Iskra Integration Team  
Версия: 1.0.0

## Лицензия
Внутреннее использование проекта Искра