"""Тесты для интегрированной API системы Искра.

Тестирует все версии API и их совместимость.
"""

import pytest
import json
from fastapi.testclient import TestClient
from fastapi import status
from unittest.mock import patch

# Импорт основного приложения
from api.unified_api import app

# Создание тестового клиента
client = TestClient(app)

class TestLegacyAPI:
    """Тесты для Version 1 API (Legacy)."""
    
    def test_healthz_legacy(self):
        """Тест проверки здоровья системы через Legacy API."""
        response = client.get("/healthz")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "time" in data
    
    def test_login_legacy(self):
        """Тест входа в систему через Legacy API."""
        login_data = {
            "username": "admin",
            "password": "admin123"
        }
        response = client.post("/auth/login", json=login_data)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "token_type" in data
    
    def test_search_legacy_with_auth(self):
        """Тест поиска через Legacy API с аутентификацией."""
        # Сначала получаем токен
        login_response = client.post("/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Выполняем поиск
        search_data = {
            "query": "API документация",
            "k": 5
        }
        response = client.post(
            "/v1/search", 
            json=search_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "query" in data
        assert "chunks" in data
        assert "latency_ms" in data
        assert len(data["chunks"]) <= search_data["k"]
    
    def test_chat_legacy_with_auth(self):
        """Тест чата через Legacy API с аутентификацией."""
        # Получаем токен
        login_response = client.post("/auth/login", json={
            "username": "admin", 
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Отправляем сообщение в чат
        chat_data = {
            "message": "Как использовать API?",
            "topk": 3
        }
        response = client.post(
            "/v1/chat",
            json=chat_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "reply" in data
        assert "citations" in data
        assert isinstance(data["citations"], list)
    
    def test_version_legacy(self):
        """Тест получения информации о версии Legacy API."""
        response = client.get("/v1/version")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
    
    def test_canon_index_legacy(self):
        """Тест получения канонического индекса Legacy API."""
        response = client.get("/v1/canon/index")
        assert response.status_code == 200
        data = response.json()
        assert "lines" in data
        assert isinstance(data["lines"], list)


class TestModernAPI:
    """Тесты для Version 2 API (Modern)."""
    
    def test_health_modern(self):
        """Тест проверки здоровья системы через Modern API."""
        response = client.get("/api/v2/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "time" in data
        assert "services" in data
    
    def test_login_modern(self):
        """Тест входа в систему через Modern API."""
        login_data = {
            "username": "admin",
            "password": "admin123"
        }
        response = client.post("/api/v2/auth/login", json=login_data)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "token_type" in data
        assert "expires_in" in data
    
    def test_logout_modern(self):
        """Тест выхода из системы через Modern API."""
        # Сначала входим
        login_response = client.post("/api/v2/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Выходим
        response = client.post(
            "/api/v2/auth/logout",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "timestamp" in data
    
    def test_search_modern_with_auth(self):
        """Тест поиска через Modern API с аутентификацией."""
        # Получаем токен
        login_response = client.post("/api/v2/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Выполняем поиск
        search_data = {
            "query": "API документация",
            "k": 5,
            "include_metadata": True
        }
        response = client.post(
            "/api/v2/search",
            json=search_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "query" in data
        assert "chunks" in data
        assert "latency_ms" in data
        assert "timestamp" in data
        assert "search_id" in data
    
    def test_document_chunks_modern(self):
        """Тест получения фрагментов документа через Modern API."""
        # Получаем токен
        login_response = client.post("/api/v2/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Получаем фрагменты документа
        response = client.get(
            "/api/v2/documents/doc_1/chunks",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "doc_id" in data
        assert "chunks" in data
        assert "total_chunks" in data
        assert "document_title" in data
    
    def test_statistics_modern(self):
        """Тест получения статистики через Modern API."""
        response = client.get("/api/v2/statistics")
        assert response.status_code == 200
        data = response.json()
        assert "total_searches" in data
        assert "unique_queries" in data
        assert "avg_latency_ms" in data
        assert "top_documents" in data
    
    def test_chat_modern_with_auth(self):
        """Тест чата через Modern API с аутентификацией."""
        # Получаем токен
        login_response = client.post("/api/v2/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Отправляем сообщение в чат
        chat_data = {
            "message": "Как использовать API?",
            "topk": 3,
            "conversation_id": "test_conversation_123"
        }
        response = client.post(
            "/api/v2/chat",
            json=chat_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "reply" in data
        assert "citations" in data
        assert "confidence" in data
        assert "response_time_ms" in data
    
    def test_system_status_modern(self):
        """Тест получения статуса системы через Modern API."""
        response = client.get("/api/v2/status")
        assert response.status_code == 200
        data = response.json()
        assert "overall_status" in data
        assert "uptime_seconds" in data
        assert "active_connections" in data


class TestHybridAPI:
    """Тесты для Version 3 API (Hybrid)."""
    
    def test_health_hybrid(self):
        """Тест проверки здоровья системы через Hybrid API."""
        response = client.get("/api/v3/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "services" in data
        # Проверяем наличие сервисов из всех версий
        services = data["services"]
        assert "legacy_api" in services
        assert "modern_api" in services
        assert "hybrid_api" in services
    
    def test_login_hybrid(self):
        """Тест входа в систему через Hybrid API."""
        login_data = {
            "username": "admin",
            "password": "admin123",
            "version_preference": "auto"
        }
        response = client.post("/api/v3/auth/login", json=login_data)
        assert response.status_code == 200
        data = response.json()
        assert "access_token" in data
        assert "token_type" in data
        assert "expires_in" in data
        assert data["expires_in"] == 3600  # Гибридный режим - 1 час
    
    def test_session_info_hybrid(self):
        """Тест получения информации о сессии через Hybrid API."""
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Получаем информацию о сессии
        response = client.get(
            "/api/v3/auth/session",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "user" in data
        assert "api_version" in data
        assert "mode" in data
        assert "active_endpoints" in data
        assert "permissions" in data
        assert data["mode"] == "hybrid"
    
    def test_search_hybrid_with_auth(self):
        """Тест поиска через Hybrid API с аутентификацией."""
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Выполняем гибридный поиск
        search_data = {
            "query": "API документация",
            "k": 5,
            "include_metadata": True
        }
        response = client.post(
            "/api/v3/search",
            json=search_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "query" in data
        assert "chunks" in data
        assert "latency_ms" in data
        assert "search_id" in data
        
        # Проверяем, что результаты содержат метаданные из всех версий
        for chunk in data["chunks"]:
            assert "metadata" in chunk
            assert "source_version" in chunk["metadata"]
    
    def test_advanced_search_options_hybrid(self):
        """Тест получения расширенных опций поиска через Hybrid API."""
        response = client.get("/api/v3/search/advanced")
        assert response.status_code == 200
        data = response.json()
        assert "search_modes" in data
        assert "ranking_factors" in data
        assert "filtering_options" in data
        
        # Проверяем доступные режимы поиска
        search_modes = data["search_modes"]
        mode_names = [mode["name"] for mode in search_modes]
        assert "hybrid" in mode_names
        assert "intelligent" in mode_names
    
    def test_document_chunks_hybrid(self):
        """Тест получения фрагментов документа через Hybrid API."""
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Получаем фрагменты документа
        response = client.get(
            "/api/v3/documents/doc_hybrid_1/chunks",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "doc_id" in data
        assert "chunks" in data
        assert "total_chunks" in data
        assert "document_title" in data
    
    def test_chat_hybrid_with_auth(self):
        """Тест чата через Hybrid API с аутентификацией."""
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Отправляем сообщение в гибридный чат
        chat_data = {
            "message": "Как использовать API?",
            "topk": 3,
            "conversation_id": "hybrid_test_123"
        }
        response = client.post(
            "/api/v3/chat",
            json=chat_data,
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "reply" in data
        assert "citations" in data
        assert "confidence" in data
        assert "response_time_ms" in data
        
        # Проверяем, что ответ содержит анализ по версиям
        assert "Анализ по версиям" in data["reply"] or "версиям" in data["reply"]
    
    def test_chat_context_hybrid(self):
        """Тест получения контекста диалога через Hybrid API."""
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        # Получаем контекст диалога
        response = client.get(
            "/api/v3/chat/context/test_conversation_123",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "conversation_id" in data
        assert "messages_count" in data
        assert "context_summary" in data
        assert "version_usage" in data
    
    def test_statistics_hybrid(self):
        """Тест получения статистики через Hybrid API."""
        response = client.get("/api/v3/statistics")
        assert response.status_code == 200
        data = response.json()
        assert "total_searches" in data
        assert "unique_queries" in data
        assert "avg_latency_ms" in data
        assert "search_distribution" in data
        
        # Проверяем, что статистика включает данные по версиям
        distribution = data["search_distribution"]
        assert "v1_legacy" in distribution
        assert "v2_modern" in distribution
        assert "v3_hybrid" in distribution
    
    def test_migration_guide_hybrid(self):
        """Тест получения руководства по миграции через Hybrid API."""
        response = client.get("/api/v3/migrate/1.0/3.0")
        assert response.status_code == 200
        data = response.json()
        assert "migration_path" in data
        assert "guide" in data
        assert "automated_migration" in data
        assert "recommended_steps" in data
        assert data["migration_path"] == "Version 1.0 → Version 3.0"
    
    def test_api_info_hybrid(self):
        """Тест получения информации о Hybrid API."""
        response = client.get("/api/v3/info")
        assert response.status_code == 200
        data = response.json()
        assert "metadata" in data
        assert "endpoints_summary" in data
        assert "deprecation_notices" in data
        
        # Проверяем метаданные
        metadata = data["metadata"]
        assert metadata["api_name"] == "Искра - Интегрированная API"
        assert "3.0" in metadata["supported_versions"]
        
        # Проверяем заметки об устаревании
        deprecation_notices = data["deprecation_notices"]
        assert len(deprecation_notices) > 0


class TestAPICompatibility:
    """Тесты совместимости между версиями API."""
    
    def test_root_endpoint(self):
        """Тест главного endpoint'а с информацией о системе."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
        assert "api_versions" in data
        assert "features" in data
        assert "links" in data
        
        # Проверяем наличие всех версий
        api_versions = data["api_versions"]
        assert "legacy" in api_versions
        assert "modern" in api_versions
        assert "hybrid" in api_versions
    
    def test_api_versions_endpoint(self):
        """Тест endpoint'а с информацией о версиях API."""
        response = client.get("/api/versions")
        assert response.status_code == 200
        data = response.json()
        assert "current_version" in data
        assert "supported_versions" in data
        assert "legacy_support" in data
        assert "modern_support" in data
        assert "hybrid_support" in data
    
    def test_compatibility_matrix(self):
        """Тест матрицы совместимости между версиями."""
        response = client.get("/api/compatibility")
        assert response.status_code == 200
        data = response.json()
        assert "compatibility_matrix" in data
        assert "migration_paths" in data
        
        # Проверяем совместимость между версиями
        matrix = data["compatibility_matrix"]
        assert "v1_to_v2" in matrix
        assert "v1_to_v3" in matrix
        assert "v2_to_v3" in matrix
    
    def test_error_404_handling(self):
        """Тест обработки 404 ошибок."""
        response = client.get("/nonexistent-endpoint")
        assert response.status_code == 404
        data = response.json()
        assert "error" in data
        assert "available_versions" in data
        assert "suggested_actions" in data
    
    def test_unauthorized_access(self):
        """Тест доступа без аутентификации."""
        # Тест для Legacy API
        response = client.post("/v1/search", json={
            "query": "test",
            "k": 5
        })
        assert response.status_code == 401
        
        # Тест для Modern API
        response = client.post("/api/v2/search", json={
            "query": "test", 
            "k": 5
        })
        assert response.status_code == 401
        
        # Тест для Hybrid API
        response = client.post("/api/v3/search", json={
            "query": "test",
            "k": 5
        })
        assert response.status_code == 401
    
    def test_invalid_credentials(self):
        """Тест с неверными учетными данными."""
        invalid_login_data = {
            "username": "invalid_user",
            "password": "wrong_password"
        }
        
        # Тест для всех версий
        versions = ["", "/api/v2", "/api/v3"]
        for version in versions:
            response = client.post(f"{version}/auth/login", json=invalid_login_data)
            assert response.status_code == 401
    
    def test_cors_headers(self):
        """Тест CORS заголовков."""
        response = client.options("/", headers={
            "Origin": "http://localhost:3000",
            "Access-Control-Request-Method": "GET"
        })
        assert response.status_code == 200
        headers = response.headers
        assert "access-control-allow-origin" in headers
        assert "access-control-allow-methods" in headers
    
    def test_api_version_headers(self):
        """Тест заголовков версии API."""
        response = client.get("/api/v3/health")
        assert response.status_code == 200
        headers = response.headers
        assert "x-api-supported-versions" in headers
        assert "x-api-deprecation-notice" in headers


class TestPerformance:
    """Тесты производительности API."""
    
    def test_response_time_health(self):
        """Тест времени ответа для health check."""
        import time
        
        start_time = time.time()
        response = client.get("/healthz")
        end_time = time.time()
        
        assert response.status_code == 200
        response_time = end_time - start_time
        assert response_time < 1.0  # Ответ должен прийти меньше чем за секунду
    
    def test_response_time_search(self):
        """Тест времени ответа для поиска."""
        import time
        
        # Получаем токен
        login_response = client.post("/api/v3/auth/login", json={
            "username": "admin",
            "password": "admin123"
        })
        token = login_response.json()["access_token"]
        
        start_time = time.time()
        response = client.post(
            "/api/v3/search",
            json={"query": "test", "k": 5},
            headers={"Authorization": f"Bearer {token}"}
        )
        end_time = time.time()
        
        assert response.status_code == 200
        response_time = end_time - start_time
        assert response_time < 2.0  # Поиск должен выполняться меньше чем за 2 секунды


if __name__ == "__main__":
    # Запуск тестов
    pytest.main([__file__, "-v"])
