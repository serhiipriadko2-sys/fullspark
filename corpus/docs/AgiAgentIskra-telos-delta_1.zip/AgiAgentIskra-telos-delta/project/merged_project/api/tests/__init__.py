"""Тесты для интегрированной API системы.

Содержит все тесты для проверки функциональности API.
"""

from .test_unified_api import (
    TestLegacyAPI,
    TestModernAPI,
    TestHybridAPI,
    TestAPICompatibility,
    TestPerformance
)

__all__ = [
    "TestLegacyAPI",
    "TestModernAPI",
    "TestHybridAPI",
    "TestAPICompatibility",
    "TestPerformance"
]