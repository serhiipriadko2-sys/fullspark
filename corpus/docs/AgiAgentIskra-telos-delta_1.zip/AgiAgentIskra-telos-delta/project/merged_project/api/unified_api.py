"""Унифицированная API система Искра.

Интегрирует все возможности Version 1, Version 2 и предоставляет гибридные решения.
"""

from fastapi import FastAPI, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
import logging
import time
from contextlib import asynccontextmanager

# Импорт endpoint'ов
from .endpoints import legacy_router, modern_router, hybrid_router

# Импорт middleware
from .middleware.unified_middleware import (
    SecurityHeadersMiddleware,
    APICompatibilityMiddleware,
    RequestLoggingMiddleware,
    CORSCompatibilityMiddleware,
    VersionHeaderMiddleware,
    RateLimitMiddleware,
    ErrorHandlingMiddleware,
    ResponseFormattingMiddleware
)

# Импорт моделей для документации
from .models.unified_models import APIInfo, APIMetadata

# Настройка логгера
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Управление жизненным циклом приложения."""
    # Startup
    logger.info("🚀 Искра Гибридная API система запускается...")
    logger.info("📊 Загружены компоненты:")
    logger.info("   - Version 1.0 (Legacy) endpoints")
    logger.info("   - Version 2.0 (Modern) endpoints") 
    logger.info("   - Version 3.0 (Hybrid) endpoints")
    logger.info("   - Middleware безопасности")
    logger.info("   - Система совместимости версий")
    
    # Инициализация ресурсов
    app.state.start_time = time.time()
    app.state.version = "3.0.0"
    app.state.api_type = "hybrid"
    
    yield
    
    # Shutdown
    logger.info("🛑 Искра API система завершает работу...")

# Создание основного приложения
app = FastAPI(
    title="Искра - Интегрированная API",
    description="""
    🚀 **Искра Гибридная API** - объединенная система, интегрирующая возможности всех версий
    
    ## 📋 Обзор системы
    
    Эта API система объединяет лучшие возможности из Version 1 (Legacy) и Version 2 (Modern),
    предоставляя унифицированный интерфейс с обратной совместимостью и новыми функциями.
    
    ## 🔗 Доступные API версии:
    
    ### Version 1.0 (Legacy) - `/`
    - **Совместимость:** 100% обратная совместимость с оригинальным API
    - **Endpoints:** 6 основных endpoints
    - **Особенности:** Проверенная функциональность
    
    ### Version 2.0 (Modern) - `/api/v2`
    - **Особенности:** Улучшенная функциональность и новые возможности  
    - **Endpoints:** 12 endpoints с расширенными функциями
    - **Нововведения:** Система статистики, расширенный поиск, улучшенная аутентификация
    
    ### Version 3.0 (Hybrid) - `/api/v3`
    - **Особенности:** Лучшее из всех версий в едином интерфейсе
    - **Endpoints:** 18 endpoints с гибридными возможностями
    - **Инновации:** Интеллектуальная агрегация, мультиверсионный поиск, контекстная осведомленность
    
    ## 🎯 Ключевые возможности
    
    ### Поиск и извлечение данных
    - Многоуровневый поиск по всем версиям документов
    - Интеллектуальная агрегация результатов из разных источников
    - Расширенные фильтры и метаданные
    - Статистика и аналитика поисковых запросов
    
    ### Система чата
    - Контекстная осведомленность и память диалога
    - Мультиверсионная база знаний
    - Аналитические ответы с цитированием источников
    - Поддержка различных форматов ответов
    
    ### Безопасность и аутентификация
    - JWT-аутентификация с поддержкой всех версий
    - Гибкая система авторизации
    - Политика CORS для веб-приложений
    - Ограничение частоты запросов
    
    ### Системная интеграция
    - Централизованное логирование и мониторинг
    - Обработка ошибок и восстановление
    - Версионирование API и миграция
    - Комплексное тестирование
    
    ## 🛠️ Архитектура
    
    - **Многоуровневая архитектура:** Разделение на слои для лучшей поддержки
    - **Модульный дизайн:** Независимые компоненты для каждой версии API
    - **Middleware система:** Централизованная обработка запросов
    - **Унифицированные модели:** Pydantic модели для всех версий
    - **Сервисный слой:** Бизнес-логика отделена от API endpoints
    
    ## 🚀 Быстрый старт
    
    1. **Аутентификация:**
       ```bash
       curl -X POST "http://localhost:8000/api/v3/auth/login" \\
            -H "Content-Type: application/json" \\
            -d '{"username": "admin", "password": "admin123"}'
       ```
    
    2. **Поиск:**
       ```bash
       curl -X POST "http://localhost:8000/api/v3/search" \\
            -H "Authorization: Bearer YOUR_TOKEN" \\
            -H "Content-Type: application/json" \\
            -d '{"query": "API documentation", "k": 5}'
       ```
    
    3. **Чат:**
       ```bash
       curl -X POST "http://localhost:8000/api/v3/chat" \\
            -H "Authorization: Bearer YOUR_TOKEN" \\
            -H "Content-Type: application/json" \\
            -d '{"message": "Как использовать API?", "topk": 3}'
       ```
    """,
    version="3.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# =============================================================================
# MIDDLEWARE CONFIGURATION
# =============================================================================

# Безопасность и CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:8080", 
        "http://127.0.0.1:3000",
        "http://127.0.0.1:8080"
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Requested-With", "X-API-Version"],
)

# Сжатие ответов
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Дополнительные middleware
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(CORSCompatibilityMiddleware)
app.add_middleware(VersionHeaderMiddleware)
app.add_middleware(RateLimitMiddleware, requests_per_minute=100)
app.add_middleware(ErrorHandlingMiddleware)
app.add_middleware(ResponseFormattingMiddleware)
app.add_middleware(APICompatibilityMiddleware)

# =============================================================================
# API ROUTERS REGISTRATION
# =============================================================================

# Legacy API (Version 1) - 100% совместимость
legacy_router = APIRouter(prefix="", tags=["legacy"])
legacy_router.include_router(legacy_router)

# Modern API (Version 2) - улучшенная функциональность  
modern_router = APIRouter(prefix="/api/v2", tags=["modern"])
modern_router.include_router(modern_router)

# Hybrid API (Version 3) - объединенная функциональность
hybrid_router = APIRouter(prefix="/api/v3", tags=["hybrid"])
hybrid_router.include_router(hybrid_router)

# Регистрация всех роутеров
app.include_router(legacy_router)
app.include_router(modern_router)  
app.include_router(hybrid_router)

# =============================================================================
# ROOT AND SYSTEM ENDPOINTS
# =============================================================================

@app.get("/")
async def root():
    """Главная страница API с информацией о системе."""
    uptime = time.time() - app.state.start_time if hasattr(app.state, 'start_time') else 0
    
    return {
        "name": "Искра Гибридная API",
        "version": "3.0.0",
        "status": "operational",
        "uptime_seconds": uptime,
        "description": "Интегрированная API система с поддержкой всех версий",
        "api_versions": {
            "legacy": {
                "path": "/",
                "version": "1.0.0", 
                "endpoints": 6,
                "status": "active"
            },
            "modern": {
                "path": "/api/v2",
                "version": "2.0.0",
                "endpoints": 12, 
                "status": "active"
            },
            "hybrid": {
                "path": "/api/v3", 
                "version": "3.0.0",
                "endpoints": 18,
                "status": "active"
            }
        },
        "features": [
            "Обратная совместимость с Version 1",
            "Улучшенная функциональность Version 2", 
            "Гибридные возможности Version 3",
            "Мультиверсионный поиск",
            "Контекстная система чата",
            "Комплексная статистика",
            "Расширенная безопасность"
        ],
        "links": {
            "docs": "/docs",
            "redoc": "/redoc", 
            "health": "/healthz",
            "api_info": "/api/v3/info"
        }
    }

@app.get("/healthz")
async def health_check():
    """Простая проверка здоровья системы."""
    uptime = time.time() - app.state.start_time if hasattr(app.state, 'start_time') else 0
    
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "uptime": uptime,
        "version": "3.0.0",
        "mode": "hybrid"
    }

@app.get("/ready")
async def readiness_check():
    """Проверка готовности системы к работе."""
    return {
        "status": "ready",
        "checks": {
            "api_gateway": "ok",
            "endpoints_loaded": "ok", 
            "middleware_active": "ok",
            "models_loaded": "ok"
        }
    }

# =============================================================================
# API INFORMATION ENDPOINTS  
# =============================================================================

@app.get("/api/info", response_model=APIInfo)
async def api_information():
    """Полная информация о API системе."""
    metadata = APIMetadata()
    
    endpoints_summary = {
        "legacy": "6 endpoints - полная совместимость с Version 1",
        "modern": "12 endpoints - улучшенная функциональность Version 2",
        "hybrid": "18 endpoints - объединенные возможности Version 3"
    }
    
    deprecation_notices = [
        "Version 1.0 будет объявлена устаревшей 31 декабря 2025",
        "Рекомендуется миграция на Version 3.0 для новых проектов",
        "Все версии будут поддерживаться минимум до Q2 2026"
    ]
    
    return APIInfo(
        metadata=metadata,
        endpoints_summary=endpoints_summary,
        deprecation_notices=deprecation_notices
    )

@app.get("/api/versions")
async def api_versions():
    """Информация о поддерживаемых версиях API."""
    return {
        "current_version": "3.0.0",
        "supported_versions": ["1.0", "2.0", "3.0"],
        "legacy_support": {
            "version": "1.0",
            "status": "fully_supported", 
            "endpoints": 6,
            "deprecation_date": "2025-12-31"
        },
        "modern_support": {
            "version": "2.0", 
            "status": "actively_developed",
            "endpoints": 12,
            "features": ["enhanced_search", "statistics", "advanced_auth"]
        },
        "hybrid_support": {
            "version": "3.0",
            "status": "latest",
            "endpoints": 18, 
            "features": ["intelligent_aggregation", "contextual_chat", "version_migration"]
        }
    }

@app.get("/api/compatibility")
async def compatibility_matrix():
    """Матрица совместимости между версиями."""
    return {
        "compatibility_matrix": {
            "v1_to_v2": {
                "auth": "compatible",
                "search": "enhanced", 
                "chat": "enhanced",
                "breaking_changes": []
            },
            "v1_to_v3": {
                "auth": "enhanced",
                "search": "hybrid",
                "chat": "intelligent",
                "breaking_changes": []
            },
            "v2_to_v3": {
                "auth": "seamless",
                "search": "intelligent", 
                "chat": "contextual",
                "breaking_changes": []
            }
        },
        "migration_paths": {
            "v1_to_v3": "recommended",
            "v2_to_v3": "optional",
            "v1_to_v2": "supported"
        }
    }

# =============================================================================
# DEVELOPMENT AND DEBUG ENDPOINTS
# =============================================================================

@app.get("/api/debug/config")
async def debug_config():
    """Информация о конфигурации (только для разработки)."""
    return {
        "app_config": {
            "title": app.title,
            "version": app.version,
            "docs_url": app.docs_url,
            "openapi_url": app.openapi_url
        },
        "middleware_active": [
            "SecurityHeadersMiddleware",
            "RequestLoggingMiddleware", 
            "CORSCompatibilityMiddleware",
            "VersionHeaderMiddleware",
            "RateLimitMiddleware",
            "ErrorHandlingMiddleware",
            "ResponseFormattingMiddleware"
        ],
        "routers_registered": [
            {"prefix": "", "tags": ["legacy"], "router": "legacy_router"},
            {"prefix": "/api/v2", "tags": ["modern"], "router": "modern_router"},
            {"prefix": "/api/v3", "tags": ["hybrid"], "router": "hybrid_router"}
        ]
    }

# =============================================================================
# GLOBAL EXCEPTION HANDLERS
# =============================================================================

@app.exception_handler(404)
async def not_found_handler(request, exc):
    """Обработчик 404 ошибок с информацией о доступных путях."""
    return {
        "error": "NOT_FOUND",
        "message": "Endpoint не найден",
        "available_versions": {
            "legacy": "/ (Version 1.0)",
            "modern": "/api/v2 (Version 2.0)", 
            "hybrid": "/api/v3 (Version 3.0)"
        },
        "suggested_actions": [
            "Проверьте правильность URL",
            "Используйте /docs для просмотра документации",
            "Попробуйте /api/info для получения информации о системе"
        ]
    }

@app.exception_handler(405)
async def method_not_allowed_handler(request, exc):
    """Обработчик ошибок неподдерживаемых методов."""
    return {
        "error": "METHOD_NOT_ALLOWED",
        "message": "Метод не поддерживается для данного endpoint",
        "supported_methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "request_method": request.method,
        "endpoint": str(request.url.path)
    }

# =============================================================================
# STARTUP AND SHUTDOWN EVENTS
# =============================================================================

@app.on_event("startup")
async def startup_event():
    """Событие запуска приложения."""
    logger.info("✅ Искра Гибридная API система успешно запущена")
    logger.info(f"📍 Base URL: http://localhost:8000")
    logger.info(f"📚 Documentation: http://localhost:8000/docs") 
    logger.info(f"🔍 API Info: http://localhost:8000/api/info")
    logger.info(f"❤️  Health Check: http://localhost:8000/healthz")

@app.on_event("shutdown") 
async def shutdown_event():
    """Событие завершения работы приложения."""
    logger.info("🛑 Искра API система завершает работу...")
    logger.info("💾 Сохранение состояния...")
    logger.info("👋 Завершение работы")
