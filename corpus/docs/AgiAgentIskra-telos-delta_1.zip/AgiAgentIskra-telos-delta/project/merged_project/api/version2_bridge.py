"""
Version 2 API Bridge для новых возможностей и улучшений.

Обеспечивает постепенное внедрение современных архитектурных паттернов
при сохранении полной совместимости с Version 1.
"""

import time
import asyncio
from typing import List, Dict, Any, Optional
from pathlib import Path
import json

# Импорты для улучшенных возможностей
from core.exceptions import IskraException
from core.config import settings
from services.dependency_injection import injectable


@injectable
class AsyncMemoryManager:
    """Улучшенный асинхронный менеджер памяти."""
    
    def __init__(self):
        self.root = settings.MEMORY_ROOT
        self.batch_size = settings.MEMORY_BATCH_SIZE
        self.flush_interval = settings.MEMORY_FLUSH_INTERVAL
        self.compression = settings.MEMORY_COMPRESSION
        self._buffer = []
        self._last_flush = time.time()
        self._lock = asyncio.Lock()
    
    async def put_event(self, kind: str, key: str, value: dict, meta: dict = None):
        """Асинхронное добавление события в память."""
        async with self._lock:
            event = {
                "t": time.time(),
                "kind": kind,
                "key": key,
                "value": value,
                "meta": meta or {}
            }
            self._buffer.append(event)
            
            # Автоматический flush при заполнении буфера
            if len(self._buffer) >= self.batch_size:
                await self._flush_buffer()
    
    async def _flush_buffer(self):
        """Сброс буфера в файл."""
        if not self._buffer:
            return
        
        try:
            # Создаем директорию если не существует
            Path(self.root).mkdir(parents=True, exist_ok=True)
            
            archive_path = Path(self.root) / "async_archive.jsonl"
            
            async with asyncio.Lock():  # Предотвращаем гонки
                with open(archive_path, "a", encoding="utf-8") as f:
                    for event in self._buffer:
                        json.dump(event, f, ensure_ascii=False)
                        f.write("\n")
            
            self._buffer.clear()
            self._last_flush = time.time()
            
        except Exception as e:
            raise IskraException(f"Async memory flush failed: {str(e)}")
    
    async def get_events(self, kind: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Получение событий из памяти."""
        try:
            archive_path = Path(self.root) / "async_archive.jsonl"
            if not archive_path.exists():
                return []
            
            events = []
            async with asyncio.Lock():
                with open(archive_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip():
                            try:
                                event = json.loads(line)
                                if kind is None or event.get("kind") == kind:
                                    events.append(event)
                            except json.JSONDecodeError:
                                continue
            
            return events[-limit:]  # Последние limit событий
            
        except Exception as e:
            raise IskraException(f"Get events failed: {str(e)}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Статистика асинхронной памяти."""
        return {
            "buffer_size": len(self._buffer),
            "batch_size": self.batch_size,
            "last_flush": self._last_flush,
            "compression_enabled": self.compression,
            "async_mode": True
        }


@injectable
class OptimizedVectorSearch:
    """Оптимизированный векторный поиск с кэшированием."""
    
    def __init__(self):
        self.evidence_path = settings.EVIDENCE_PATH
        self.cache_size = settings.LRU_CACHE_SIZE if settings.ENABLE_LRU_CACHE else 0
        self._cache = {} if settings.ENABLE_LRU_CACHE else None
        self._cache_order = []
        self._search_stats = {
            "total_searches": 0,
            "cache_hits": 0,
            "average_latency_ms": 0.0
        }
    
    async def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Асинхронный поиск с оптимизациями."""
        start_time = time.perf_counter()
        
        # Проверяем кэш
        cache_key = f"{query}:{k}"
        if self._cache is not None and cache_key in self._cache:
            self._search_stats["cache_hits"] += 1
            return self._cache[cache_key]
        
        try:
            results = await self._perform_search(query, k)
            
            # Кэшируем результат
            if self._cache is not None:
                self._cache_result(cache_key, results)
            
            # Обновляем статистику
            latency_ms = (time.perf_counter() - start_time) * 1000
            self._update_search_stats(latency_ms)
            
            return results
            
        except Exception as e:
            raise IskraException(f"Optimized search failed: {str(e)}")
    
    async def _perform_search(self, query: str, k: int) -> List[Dict[str, Any]]:
        """Выполнение поиска."""
        if not Path(self.evidence_path).exists():
            # Fallback для случая отсутствия данных
            return [
                {
                    "doc_id": f"optimized_demo_{i+1}",
                    "score": 0.95 - (i * 0.1),
                    "content": f"Optimized demo evidence {i+1} for query: {query}"
                }
                for i in range(min(k, 2))
            ]
        
        # Улучшенный поиск с дополнительной фильтрацией
        results = []
        query_words = set(query.lower().split())
        
        try:
            # Асинхронное чтение файла
            loop = asyncio.get_event_loop()
            
            def read_evidence():
                evidence_items = []
                with open(self.evidence_path, 'r', encoding='utf-8') as f:
                    for line in f:
                        if line.strip():
                            try:
                                evidence = json.loads(line)
                                evidence_items.append(evidence)
                            except json.JSONDecodeError:
                                continue
                return evidence_items
            
            evidence_items = await loop.run_in_executor(None, read_evidence)
            
            # Фильтрация и ранжирование
            for evidence in evidence_items:
                content = evidence.get('content', '').lower()
                content_words = set(content.split())
                
                # Улучшенный scoring
                match_score = len(query_words.intersection(content_words)) / max(len(query_words), 1)
                
                if match_score > 0:  # Есть совпадения
                    results.append({
                        "doc_id": evidence.get('doc_id', 'unknown'),
                        "score": match_score,
                        "content": evidence.get('content', ''),
                        "metadata": evidence.get('metadata', {})
                    })
            
            # Сортируем по score и возвращаем top-k
            results.sort(key=lambda x: x['score'], reverse=True)
            return results[:k]
            
        except Exception as e:
            raise IskraException(f"Search execution failed: {str(e)}")
    
    def _cache_result(self, cache_key: str, results: List[Dict[str, Any]]):
        """Кэширование результата поиска."""
        if len(self._cache) >= self.cache_size:
            # Удаляем самый старый элемент
            oldest_key = self._cache_order.pop(0)
            del self._cache[oldest_key]
        
        self._cache[cache_key] = results
        self._cache_order.append(cache_key)
    
    def _update_search_stats(self, latency_ms: float):
        """Обновление статистики поиска."""
        self._search_stats["total_searches"] += 1
        
        # Обновляем среднюю латентность
        total = self._search_stats["total_searches"]
        current_avg = self._search_stats["average_latency_ms"]
        self._search_stats["average_latency_ms"] = ((current_avg * (total - 1)) + latency_ms) / total
    
    def get_search_stats(self) -> Dict[str, Any]:
        """Получение статистики поиска."""
        return {
            **self._search_stats,
            "cache_enabled": self._cache is not None,
            "cache_size": len(self._cache),
            "cache_capacity": self.cache_size
        }


@injectable
class EnhancedChatService:
    """Улучшенный сервис чата."""
    
    def __init__(self, search_service: OptimizedVectorSearch, memory_service: AsyncMemoryManager):
        self.search_service = search_service
        self.memory_service = memory_service
        self.chat_stats = {
            "total_chats": 0,
            "average_response_time_ms": 0.0,
            "citations_used": 0
        }
    
    async def chat(self, message: str, topk: int = 4) -> Dict[str, Any]:
        """Улучшенный чат с памятью."""
        start_time = time.perf_counter()
        
        try:
            # Сохраняем запрос в память
            await self.memory_service.put_event(
                "chat_request", 
                f"req_{int(time.time())}", 
                {"message": message, "topk": topk}
            )
            
            # Получаем citations через оптимизированный поиск
            citations = await self.search_service.search(message, topk)
            
            # Генерируем улучшенный ответ
            response = await self._generate_enhanced_response(message, citations)
            
            # Сохраняем ответ в память
            await self.memory_service.put_event(
                "chat_response", 
                f"resp_{int(time.time())}", 
                {"response": response, "citations_count": len(citations)}
            )
            
            # Обновляем статистику
            latency_ms = (time.perf_counter() - start_time) * 1000
            self._update_chat_stats(latency_ms, len(citations))
            
            return {
                "reply": response,
                "citations": citations,
                "cd_index": None,
                "version": "2.0",
                "enhanced": True
            }
            
        except Exception as e:
            raise IskraException(f"Enhanced chat failed: {str(e)}")
    
    async def _generate_enhanced_response(self, message: str, citations: List[Dict[str, Any]]) -> str:
        """Генерация улучшенного ответа."""
        if not citations:
            return f"Не удалось найти релевантную информацию для запроса: {message}"
        
        # Формируем улучшенный ответ
        response_parts = [
            f"📊 Найдено {len(citations)} релевантных источников:",
            "",
            f"❓ Ваш запрос: {message}",
            ""
        ]
        
        # Добавляем краткие цитаты
        for i, citation in enumerate(citations[:2], 1):  # Показываем только top 2
            snippet = citation['content'][:150].replace('\n', ' ')
            response_parts.append(f"📄 Источник {i}: {snippet}...")
            response_parts.append("")
        
        response_parts.append("💡 Рекомендую ознакомиться с найденными материалами для получения более подробной информации.")
        
        return "\n".join(response_parts)
    
    def _update_chat_stats(self, latency_ms: float, citations_count: int):
        """Обновление статистики чата."""
        self.chat_stats["total_chats"] += 1
        
        # Обновляем среднее время ответа
        total = self.chat_stats["total_chats"]
        current_avg = self.chat_stats["average_response_time_ms"]
        self.chat_stats["average_response_time_ms"] = ((current_avg * (total - 1)) + latency_ms) / total
        
        # Обновляем статистику использования цитат
        self.chat_stats["citations_used"] += citations_count
    
    def get_chat_stats(self) -> Dict[str, Any]:
        """Получение статистики чата."""
        return {
            **self.chat_stats,
            "average_citations_per_chat": (
                self.chat_stats["citations_used"] / max(self.chat_stats["total_chats"], 1)
            )
        }


class Version2APIBridge:
    """Главный мост для Version 2 API."""
    
    def __init__(self, container):
        self.container = container
        
        # Инициализация современных сервисов
        # (будут созданы через DI при первом обращении)
    
    async def initialize(self):
        """Инициализация Version 2 компонентов."""
        try:
            print("✅ Version 2 API Bridge инициализирован")
        except Exception as e:
            raise IskraException(f"Version 2 bridge initialization failed: {str(e)}")
    
    async def cleanup(self):
        """Очистка ресурсов."""
        print("🧹 Version 2 API Bridge очищен")
    
    async def get_enhanced_health(self) -> Dict[str, Any]:
        """Улучшенный health check."""
        try:
            # Получаем статистику от сервисов
            search_service = self.container.get("OptimizedVectorSearch")
            memory_service = self.container.get("AsyncMemoryManager")
            
            return {
                "status": "ok",
                "version": "2.0",
                "enhanced": True,
                "services": {
                    "search": search_service.get_search_stats(),
                    "memory": memory_service.get_stats()
                },
                "timestamp": time.time()
            }
        except Exception as e:
            raise IskraException(f"Enhanced health check failed: {str(e)}")
    
    async def get_enhanced_version(self) -> Dict[str, Any]:
        """Улучшенная информация о версии."""
        try:
            # Получаем базовую информацию
            version_info = await self._get_base_version_info()
            
            # Добавляем Version 2 специфичную информацию
            version_info.update({
                "enhanced_features": [
                    "async_memory_management",
                    "optimized_vector_search", 
                    "enhanced_chat",
                    "performance_monitoring",
                    "caching_system"
                ],
                "architecture": "layered_with_di",
                "compatibility_mode": "hybrid_v1_v2"
            })
            
            return version_info
            
        except Exception as e:
            raise IskraException(f"Enhanced version info failed: {str(e)}")
    
    async def _get_base_version_info(self) -> Dict[str, Any]:
        """Базовая информация о версии."""
        try:
            manifest_path = Path(settings.MANIFEST_PATH)
            if manifest_path.exists():
                comp = json.loads(manifest_path.read_text(encoding="utf-8"))
                return {
                    "name": "Iskra Ω (Enhanced)",
                    "version": "2.0.0",
                    "components": comp.get("components", {}),
                    "cd_index": comp.get("cd_index")
                }
            else:
                return {
                    "name": "Iskra Ω (Enhanced)",
                    "version": "2.0.0", 
                    "components": {},
                    "cd_index": None
                }
        except Exception:
            return {
                "name": "Iskra Ω (Enhanced)",
                "version": "2.0.0",
                "components": {},
                "cd_index": None
            }