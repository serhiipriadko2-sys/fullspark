# 🚀 Интегрированная API система Искра

## 📋 Обзор

Интегрированная API система **Искра** объединяет возможности всех версий в единую, мощную и гибкую архитектуру. Система обеспечивает 100% обратную совместимость с Version 1, расширенную функциональность Version 2 и инновационные гибридные возможности Version 3.

## 🎯 Ключевые особенности

### ✨ Многоуровневая архитектура
- **Version 1.0 (Legacy)** - полная совместимость с оригинальным API
- **Version 2.0 (Modern)** - улучшенная функциональность и новые возможности  
- **Version 3.0 (Hybrid)** - объединение лучших возможностей всех версий

### 🔐 Безопасность и аутентификация
- JWT-аутентификация с поддержкой всех версий
- Гибкая система авторизации и управления сессиями
- Политика CORS для веб-приложений
- Middleware для ограничения частоты запросов

### 🔍 Интеллектуальный поиск
- Мультиверсионный поиск по всем источникам данных
- Интеллектуальная агрегация результатов
- Расширенные фильтры и метаданные
- Система статистики и аналитики

### 💬 Продвинутый чат
- Контекстная осведомленность и память диалога
- Мультиверсионная база знаний
- Аналитические ответы с цитированием источников
- Поддержка различных форматов ответов

## 🏗️ Архитектура системы

```
merged_project/api/
├── unified_api.py           # Основной API файл
├── endpoints/               # Endpoint'ы для разных версий
│   ├── legacy_endpoints.py  # Совместимость с Version 1
│   ├── modern_endpoints.py  # Новые возможности Version 2
│   └── hybrid_endpoints.py  # Объединенные возможности Version 3
├── models/                  # Унифицированные модели данных
│   ├── __init__.py
│   └── unified_models.py    # Объединенные Pydantic модели
├── middleware/              # Middleware для функциональности
│   ├── __init__.py
│   └── unified_middleware.py # Middleware для всех версий
└── tests/                   # Комплексные тесты
    ├── __init__.py
    └── test_unified_api.py  # Тесты для всех API версий
```

## 📚 API Версии и endpoints

### Version 1.0 (Legacy) - `/`

Полная совместимость с оригинальным API.

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/healthz` | GET | Проверка здоровья системы |
| `/auth/login` | POST | Вход в систему |
| `/v1/search` | POST | Поиск документов |
| `/v1/chat` | POST | Чат с системой |
| `/v1/version` | GET | Информация о версии |
| `/v1/canon/index` | GET | Канонический индекс |

### Version 2.0 (Modern) - `/api/v2`

Улучшенная функциональность с новыми возможностями.

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/api/v2/health` | GET | Проверка здоровья системы |
| `/api/v2/auth/login` | POST | Вход в систему (улучшенный) |
| `/api/v2/auth/logout` | POST | Выход из системы |
| `/api/v2/search` | POST | Поиск с расширенными фильтрами |
| `/api/v2/documents/{doc_id}/chunks` | GET | Фрагменты документа |
| `/api/v2/statistics` | GET | Статистика поиска |
| `/api/v2/chat` | POST | Чат с контекстной осведомленностью |
| `/api/v2/status` | GET | Статус системы |
| `/api/v2/version` | GET | Информация о версии |
| `/api/v2/canon/index` | GET | Канонический индекс |
| `/api/v2/info` | GET | Информация об API |
| `/api/v2/health/detailed` | GET | Детальная проверка здоровья |

### Version 3.0 (Hybrid) - `/api/v3`

Объединенные возможности с инновационными функциями.

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/api/v3/health` | GET | Комплексная проверка здоровья |
| `/api/v3/auth/login` | POST | Универсальный вход с поддержкой всех версий |
| `/api/v3/auth/logout` | POST | Универсальный выход |
| `/api/v3/auth/session` | GET | Информация о сессии |
| `/api/v3/search` | POST | Интеллектуальный мультиверсионный поиск |
| `/api/v3/search/advanced` | GET | Расширенные опции поиска |
| `/api/v3/documents/{doc_id}/chunks` | GET | Фрагменты документа из любой версии |
| `/api/v3/statistics` | GET | Объединенная статистика |
| `/api/v3/chat` | POST | Гибридный чат с анализом по версиям |
| `/api/v3/chat/context/{conversation_id}` | GET | Контекст диалога |
| `/api/v3/status` | GET | Общий статус системы |
| `/api/v3/version` | GET | Информация о гибридной версии |
| `/api/v3/canon/index` | GET | Полная документация |
| `/api/v3/info` | GET | Полная информация об API |
| `/api/v3/migrate/{from}/{to}` | GET | Руководство по миграции |

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
cd merged_project
pip install -r requirements.txt
```

### 2. Запуск API

```bash
python -m uvicorn api.unified_api:app --reload --host 0.0.0.0 --port 8000
```

### 3. Проверка работы

Откройте в браузере:
- **API документация:** http://localhost:8000/docs
- **Health check:** http://localhost:8000/healthz
- **Главная страница:** http://localhost:8000/

## 📖 Примеры использования

### Аутентификация

#### Legacy API (Version 1)
```bash
curl -X POST "http://localhost:8000/auth/login" \\
     -H "Content-Type: application/json" \\
     -d '{
       "username": "admin",
       "password": "admin123"
     }'
```

#### Modern API (Version 2)
```bash
curl -X POST "http://localhost:8000/api/v2/auth/login" \\
     -H "Content-Type: application/json" \\
     -d '{
       "username": "admin",
       "password": "admin123"
     }'
```

#### Hybrid API (Version 3)
```bash
curl -X POST "http://localhost:8000/api/v3/auth/login" \\
     -H "Content-Type: application/json" \\
     -d '{
       "username": "admin",
       "password": "admin123",
       "version_preference": "auto"
     }'
```

### Поиск

#### Legacy поиск
```bash
curl -X POST "http://localhost:8000/v1/search" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "API документация",
       "k": 5
     }'
```

#### Modern поиск с фильтрами
```bash
curl -X POST "http://localhost:8000/api/v2/search" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "API документация",
       "k": 10,
       "include_metadata": true
     }'
```

#### Hybrid интеллектуальный поиск
```bash
curl -X POST "http://localhost:8000/api/v3/search" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "query": "API документация",
       "k": 8,
       "include_metadata": true
     }'
```

### Чат

#### Legacy чат
```bash
curl -X POST "http://localhost:8000/v1/chat" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "message": "Как использовать API?",
       "topk": 3
     }'
```

#### Modern чат с контекстом
```bash
curl -X POST "http://localhost:8000/api/v2/chat" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "message": "Как использовать API?",
       "topk": 4,
       "conversation_id": "my_conversation_123"
     }'
```

#### Hybrid чат с анализом
```bash
curl -X POST "http://localhost:8000/api/v3/chat" \\
     -H "Authorization: Bearer YOUR_TOKEN" \\
     -H "Content-Type: application/json" \\
     -d '{
       "message": "Как использовать API?",
       "topk": 5,
       "conversation_id": "hybrid_chat_123",
       "enable_context": true,
       "prefer_version": "auto"
     }'
```

## 🧪 Тестирование

### Запуск всех тестов

```bash
cd merged_project
python -m pytest api/tests/test_unified_api.py -v
```

### Запуск тестов определенной версии

```bash
# Тесты Legacy API
python -m pytest api/tests/test_unified_api.py::TestLegacyAPI -v

# Тесты Modern API
python -m pytest api/tests/test_unified_api.py::TestModernAPI -v

# Тесты Hybrid API
python -m pytest api/tests/test_unified_api.py::TestHybridAPI -v

# Тесты совместимости
python -m pytest api/tests/test_unified_api.py::TestAPICompatibility -v
```

### Тесты производительности

```bash
python -m pytest api/tests/test_unified_api.py::TestPerformance -v
```

## 🔧 Конфигурация

### Переменные окружения

| Переменная | Описание | По умолчанию |
|------------|----------|--------------|
| `JWT_SECRET` | Секретный ключ для JWT | Автогенерируется |
| `CORS_ORIGINS` | Разрешенные CORS origins | `localhost:3000,localhost:8080` |
| `API_RATE_LIMIT` | Лимит запросов в минуту | `100` |
| `API_VERSION` | Версия API по умолчанию | `3.0` |

### Настройка middleware

Система включает следующие middleware:

- **SecurityHeadersMiddleware** - заголовки безопасности
- **RequestLoggingMiddleware** - логирование запросов
- **CORSCompatibilityMiddleware** - поддержка CORS
- **VersionHeaderMiddleware** - обработка версий API
- **RateLimitMiddleware** - ограничение частоты запросов
- **ErrorHandlingMiddleware** - централизованная обработка ошибок
- **ResponseFormattingMiddleware** - форматирование ответов

## 📊 Мониторинг и аналитика

### Endpoints для мониторинга

- `/healthz` - базовая проверка здоровья
- `/api/v2/health/detailed` - детальная проверка сервисов
- `/api/v3/health` - комплексная проверка гибридной системы
- `/api/v3/statistics` - статистика использования
- `/ready` - проверка готовности к работе

### Логирование

Система предоставляет подробное логирование:

```python
import logging

# Настройка уровня логирования
logging.basicConfig(level=logging.INFO)

# Структура логов
logger.info("API Request: GET /api/v3/search - Client: 192.168.1.100")
logger.info("Request processed: POST /api/v2/chat - Status: 200 - Time: 0.156s")
```

## 🔄 Миграция между версиями

### Автоматическая миграция

Система предоставляет автоматическое руководство по миграции:

```bash
curl "http://localhost:8000/api/v3/migrate/1.0/3.0"
```

### Ручная миграция

1. **Обновите base URL:**
   - Version 1: `http://localhost:8000/`
   - Version 2: `http://localhost:8000/api/v2/`
   - Version 3: `http://localhost:8000/api/v3/`

2. **Проверьте аутентификацию:**
   - Version 1: токены на 30 минут
   - Version 2: токены на 30 минут  
   - Version 3: токены на 60 минут

3. **Обновите обработку ответов:**
   - Version 3 добавляет метаданные к ответам

## 🛡️ Безопасность

### Аутентификация

- Поддержка JWT токенов для всех версий
- Валидация токенов с учетом времени истечения
- Защита от повторного использования токенов

### Авторизация

- Роли пользователей (admin, user)
- Контроль доступа к различным функциям
- Поддержка сессий с контекстом

### Защита от атак

- Защита от SQL injection через Pydantic валидацию
- Защита от XSS через заголовки безопасности
- Ограничение частоты запросов
- CORS политика для веб-приложений

## 📈 Производительность

### Оптимизации

- Сжатие ответов через GZip middleware
- Кэширование статических данных
- Асинхронная обработка запросов
- Оптимизированные запросы к базе данных

### Метрики

- Время ответа для health check: < 100ms
- Время поиска: < 500ms для стандартных запросов
- Время чата: < 1s для базовых ответов
- Пропускная способность: > 100 запросов/секунду

## 🚀 Развертывание

### Docker

```bash
# Сборка образа
docker build -t iskra-api .

# Запуск контейнера
docker run -p 8000:8000 iskra-api
```

### Docker Compose

```bash
# Запуск с зависимостями
docker-compose up -d
```

### Продакшн развертывание

```bash
# Использование Gunicorn
gunicorn api.unified_api:app \\
    --workers 4 \\
    --worker-class uvicorn.workers.UvicornWorker \\
    --bind 0.0.0.0:8000 \\
    --access-logfile - \\
    --error-logfile -
```

## 📝 Лицензия

Проект распространяется под лицензией MIT.

## 🤝 Поддержка

Для получения поддержки и сообщения об ошибках:

1. Проверьте документацию по адресу http://localhost:8000/docs
2. Изучите примеры использования в данном README
3. Запустите тесты для проверки функциональности
4. Проверьте логи системы для диагностики проблем

---

**Искра Гибридная API** - объединяем прошлое, настоящее и будущее в единой системе! 🚀✨
