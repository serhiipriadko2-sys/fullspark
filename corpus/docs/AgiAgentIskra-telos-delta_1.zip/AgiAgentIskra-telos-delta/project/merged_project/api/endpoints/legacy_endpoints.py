"""Legacy endpoints для совместимости с Version 1 API.

Обеспечивает 100% совместимость с оригинальным API Version 1.
"""

from fastapi import APIRouter, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from typing import Optional
import time
import jwt
import secrets
import hashlib
import base64
from datetime import datetime, timedelta
from pathlib import Path
import json

# Импорт моделей
from ..models.unified_models import (
    LoginRequest, Token, 
    SearchRequest, LegacySearchResponse, Chunk,
    ChatRequest, LegacyChatResponse,
    HealthResponse, VersionResponse, CanonIndexResponse
)

# Импорт middleware
from ..middleware.unified_middleware import APICompatibilityMiddleware

# Создаем роутер с префиксом для совместимости
legacy_router = APIRouter(prefix="", tags=["legacy"])

# Константы из Version 1
JWT_SECRET = "your-secret-key"  # В production должно быть из переменных окружения
MOCK_USERS = {
    "admin": {
        "password_hash": base64.b64encode(
            hashlib.pbkdf2_hmac('sha256', b'admin123', b'salt123', 100000)
        ).decode('utf-8'),
        "salt": "salt123"
    },
    "user": {
        "password_hash": base64.b64encode(
            hashlib.pbkdf2_hmac('sha256', b'user123', b'salt456', 100000)
        ).decode('utf-8'),
        "salt": "salt456"
    }
}

def create_token(subject: str, minutes: int = 60) -> str:
    """Создание JWT токена (совместимость с Version 1)."""
    payload = {
        "sub": subject, 
        "exp": datetime.utcnow() + timedelta(minutes=minutes), 
        "iat": datetime.utcnow(),
        "jti": secrets.token_hex(16)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def require_auth(authorization: Optional[str] = Header(default=None)) -> str:
    """Проверка аутентификации (совместимость с Version 1)."""
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid authorization header")
    
    token = authorization.split(" ", 1)[1]
    try:
        data = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return data["sub"]
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token has expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Token validation failed: {str(e)}")

def verify_password(password: str, password_hash: str, salt: str) -> bool:
    """Проверка пароля (совместимость с Version 1)."""
    try:
        computed_hash = base64.b64encode(
            hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
        ).decode('utf-8')
        return secrets.compare_digest(computed_hash, password_hash)
    except Exception:
        return False

# =============================================================================
# LEGACY ENDPOINTS (Version 1 API)
# =============================================================================

@legacy_router.get("/healthz")
async def legacy_healthz():
    """Проверка здоровья системы (Version 1 формат)."""
    return {"status": "ok", "time": time.time()}

@legacy_router.post("/auth/login", response_model=Token)
async def legacy_login(req: LoginRequest):
    """Вход в систему (Version 1 совместимость)."""
    
    # Get user from mock database
    user_data = MOCK_USERS.get(req.username)
    if not user_data:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    # Verify password
    password_valid = verify_password(
        req.password, 
        user_data["password_hash"], 
        user_data["salt"]
    )
    
    if not password_valid:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    
    # Create token with shorter expiration for security
    token = create_token(req.username, minutes=30)
    return Token(access_token=token)

@legacy_router.post("/v1/search", response_model=LegacySearchResponse)
async def legacy_search(req: SearchRequest, user: str = Depends(require_auth)):
    """Поиск релевантных фрагментов (Version 1 совместимость)."""
    start = time.perf_counter()
    
    # Имитация поиска (в реальной реализации здесь будет вызов сервиса)
    results = [
        Chunk(doc_id="demo_doc_1", score=0.95, content="Legacy demo evidence chunk"),
        Chunk(doc_id="demo_doc_2", score=0.87, content="Second legacy evidence chunk")
    ]
    
    elapsed_ms = (time.perf_counter() - start) * 1000
    return LegacySearchResponse(query=req.query, chunks=results, latency_ms=elapsed_ms)

@legacy_router.post("/v1/chat", response_model=LegacyChatResponse)
async def legacy_chat(req: ChatRequest, user: str = Depends(require_auth)):
    """Обработка сообщения чата (Version 1 совместимость)."""
    
    # Имитация генерации ответа (в реальной реализации здесь будет вызов сервиса)
    citations = [
        Chunk(doc_id="demo_doc_1", score=0.95, content="Legacy evidence chunk for chat")
    ]
    
    reply = f"На основе найденных {len(citations)} источников ваш запрос:\n{req.message}\n\nКраткий фрагмент: {citations[0].content[:200]} ..."
    
    return LegacyChatResponse(reply=reply, citations=citations)

@legacy_router.get("/v1/version")
async def legacy_version():
    """Получение информации о версии (Version 1 совместимость)."""
    try:
        manifest = Path("manifest/cd_index_baseline.json")
        comp = json.loads(manifest.read_text(encoding="utf-8")) if manifest.exists() else {}
        return {
            "name": "Iskra Ω",
            "version": "2025-10-29", 
            "components": comp.get("components", {}),
            "cd_index": comp.get("cd_index")
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load version info: {str(e)}")

@legacy_router.get("/v1/canon/index")
async def legacy_canon_index():
    """Получение канонического индекса (Version 1 совместимость)."""
    try:
        p = Path("docs/CANON/INDEX.md")
        return {"lines": p.read_text(encoding="utf-8").splitlines() if p.exists() else []}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load canonical index: {str(e)}")

# =============================================================================
# ДОПОЛНИТЕЛЬНЫЕ LEGACY ENDPOINTS
# =============================================================================

@legacy_router.get("/api/v1/health")
async def legacy_api_health():
    """Альтернативный endpoint для проверки здоровья."""
    return HealthResponse(status="ok", time=time.time())

@legacy_router.get("/api/v1/status")
async def legacy_api_status():
    """Альтернативный endpoint для статуса системы."""
    return {
        "status": "active",
        "version": "1.0",
        "legacy_mode": True,
        "timestamp": datetime.utcnow().isoformat()
    }

@legacy_router.get("/api/v1/info")
async def legacy_api_info():
    """Информация об API Version 1."""
    return {
        "api": "Iskra Legacy API",
        "version": "1.0",
        "mode": "compatibility",
        "endpoints": [
            "/healthz",
            "/auth/login", 
            "/v1/search",
            "/v1/chat",
            "/v1/version",
            "/v1/canon/index"
        ],
        "description": "Legacy compatibility endpoints for Version 1"
    }

# =============================================================================
# LEGACY ERROR HANDLERS
# =============================================================================

@legacy_router.exception_handler(Exception)
async def legacy_global_exception_handler(request: Request, exc: Exception):
    """Глобальный обработчик ошибок в формате Version 1."""
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": "internal_error"}
    )
