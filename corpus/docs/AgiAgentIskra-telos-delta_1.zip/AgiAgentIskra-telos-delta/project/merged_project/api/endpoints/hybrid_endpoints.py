"""Hybrid endpoints - объединенные возможности обеих версий.

Предоставляет лучшие возможности из Version 1 и Version 2 в едином API.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, List
import time
import json
from datetime import datetime
from pathlib import Path

# Импорт моделей
from ..models.unified_models import (
    LoginRequest, Token, TokenData,
    SearchRequest, SearchResponse, Chunk, DocumentChunksResponse, StatisticsResponse,
    ChatRequest, ChatResponse,
    HealthResponse, VersionResponse, CanonIndexResponse, SystemStatusResponse,
    APIInfo, APIMetadata
)

# Импорт middleware
from ..middleware.unified_middleware import APICompatibilityMiddleware

# Создаем роутер для гибридного API
hybrid_router = APIRouter(prefix="/api/v3", tags=["hybrid"])

# Схема авторизации
security = HTTPBearer()

# Объединенные данные из обеих версий
HYBRID_DATA = {
    "documents": {
        "doc_legacy_1": {
            "title": "Legacy Техническая документация",
            "content": "Оригинальная документация API Version 1",
            "version": "1.0",
            "chunks": [
                {"id": 1, "content": "Базовые endpoints API Version 1", "score": 0.95},
                {"id": 2, "content": "Совместимость с предыдущими версиями", "score": 0.88}
            ]
        },
        "doc_modern_1": {
            "title": "Modern API Руководство", 
            "content": "Улучшенная документация Version 2",
            "version": "2.0",
            "chunks": [
                {"id": 1, "content": "Расширенные возможности поиска", "score": 0.93},
                {"id": 2, "content": "Улучшенная система аутентификации", "score": 0.91}
            ]
        },
        "doc_hybrid_1": {
            "title": "Гибридная система Искра",
            "content": "Объединение лучших возможностей всех версий",
            "version": "3.0",
            "chunks": [
                {"id": 1, "content": "Обратная совместимость с Version 1", "score": 0.97},
                {"id": 2, "content": "Улучшенная функциональность Version 2", "score": 0.94},
                {"id": 3, "content": "Новые возможности Version 3", "score": 0.92}
            ]
        }
    },
    "statistics": {
        "total_searches": 2156,
        "unique_queries": 523,
        "avg_latency_ms": 142.3,
        "version_distribution": {
            "v1_legacy": 445,
            "v2_modern": 834,
            "v3_hybrid": 877
        },
        "top_documents": [
            {"doc_id": "doc_hybrid_1", "searches": 245, "version": "3.0"},
            {"doc_id": "doc_modern_1", "searches": 189, "version": "2.0"},
            {"doc_id": "doc_legacy_1", "searches": 156, "version": "1.0"}
        ]
    }
}

# =============================================================================
# ADVANCED AUTH ENDPOINTS (Объединенные возможности)
# =============================================================================

@hybrid_router.post("/auth/login", response_model=Token)
async def hybrid_login(
    req: LoginRequest,
    version_preference: str = Query(default="auto", description="Предпочитаемая версия API")
):
    """Универсальный вход в систему с поддержкой всех версий."""
    
    # Поддержка учетных данных из обеих версий
    valid_credentials = {
        "admin": {"password": "admin123", "role": "admin"},
        "user": {"password": "user123", "role": "user"},
        "legacy_admin": {"password": "admin123", "role": "admin", "legacy": True},
        "modern_user": {"password": "user123", "role": "user", "modern": True}
    }
    
    user_data = valid_credentials.get(req.username)
    if not user_data or user_data["password"] != req.password:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "INVALID_CREDENTIALS", 
                "message": "Неверные учетные данные",
                "supported_versions": ["1.0", "2.0", "3.0"]
            }
        )
    
    # Создание токена с версионной информацией
    token_payload = {
        "sub": req.username,
        "role": user_data["role"],
        "preferred_version": version_preference,
        "api_version": "3.0",
        "hybrid_mode": True
    }
    
    token = f"hybrid_token_{req.username}_{int(time.time())}"
    
    return Token(
        access_token=token,
        token_type="bearer",
        expires_in=3600  # 1 час для гибридного режима
    )

@hybrid_router.post("/auth/logout")
async def hybrid_logout(
    current_user: str = Depends(get_current_user),
    version: str = Query(default="3.0", description="Версия API")
):
    """Универсальный выход из системы."""
    return {
        "message": "Выход выполнен успешно",
        "user": current_user,
        "version": version,
        "mode": "hybrid",
        "timestamp": datetime.utcnow().isoformat(),
        "legacy_sessions_closed": True,
        "modern_sessions_closed": True
    }

@hybrid_router.get("/auth/session")
async def get_session_info(current_user: str = Depends(get_current_user)):
    """Получение информации о текущей сессии."""
    return {
        "user": current_user,
        "session_start": datetime.utcnow().isoformat(),
        "api_version": "3.0",
        "mode": "hybrid",
        "active_endpoints": [
            "/api/v3/auth/*",
            "/api/v3/search",
            "/api/v3/chat",
            "/api/v3/documents/*",
            "/api/v3/statistics",
            "/api/v3/system/*"
        ],
        "permissions": ["read", "search", "chat", "admin"],
        "legacy_compatibility": True,
        "modern_features": True
    }

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> str:
    """Получение текущего пользователя (универсальная версия)."""
    # Поддержка токенов из всех версий
    valid_tokens = [
        "legacy-admin-token",
        "modern-user-token", 
        "hybrid_token_admin",
        "hybrid_token_user"
    ]
    
    if credentials.credentials in valid_tokens:
        if "admin" in credentials.credentials:
            return "admin"
        else:
            return "user"
    else:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

# =============================================================================
# ADVANCED SEARCH ENDPOINTS (Лучшее из обеих версий)
# =============================================================================

@hybrid_router.post("/search", response_model=SearchResponse)
async def hybrid_search(
    req: SearchRequest,
    current_user: str = Depends(get_current_user),
    include_legacy: bool = Query(default=True, description="Включить результаты Version 1"),
    include_modern: bool = Query(default=True, description="Включить результаты Version 2"),
    version_filter: Optional[List[str]] = Query(default=None, description="Фильтр по версиям")
):
    """Универсальный поиск с поддержкой всех версий."""
    start_time = time.perf_counter()
    
    results = []
    
    # Поиск в данных всех версий
    for doc_id, doc_data in HYBRID_DATA["documents"].items():
        if version_filter and doc_data["version"] not in version_filter:
            continue
            
        for chunk in doc_data["chunks"]:
            # Улучшенный алгоритм поиска
            query_words = req.query.lower().split()
            content_lower = chunk["content"].lower()
            
            # Подсчет релевантности
            matches = sum(1 for word in query_words if word in content_lower)
            if matches > 0:
                # Дополнительные факторы релевантности
                base_score = chunk["score"]
                version_bonus = {"1.0": 0.02, "2.0": 0.03, "3.0": 0.05}.get(doc_data["version"], 0.01)
                relevance_bonus = matches * 0.1
                
                final_score = min(1.0, base_score + version_bonus + relevance_bonus)
                
                results.append(Chunk(
                    doc_id=doc_id,
                    score=final_score,
                    content=chunk["content"],
                    chunk_id=chunk.get("id"),
                    title=doc_data["title"],
                    metadata={
                        "source_version": doc_data["version"],
                        "relevance_score": final_score,
                        "word_matches": matches,
                        "hybrid_search": True
                    }
                ))
    
    # Сортировка по релевантности
    results.sort(key=lambda x: x.score, reverse=True)
    results = results[:req.k]
    
    latency_ms = (time.perf_counter() - start_time) * 1000
    
    return SearchResponse(
        query=req.query,
        chunks=results,
        latency_ms=latency_ms,
        total_results=len(results),
        search_id=f"hybrid_search_{int(time.time())}"
    )

@hybrid_router.get("/documents/{doc_id}/chunks", response_model=DocumentChunksResponse)
async def hybrid_document_chunks(
    doc_id: str,
    current_user: str = Depends(get_current_user),
    include_metadata: bool = Query(default=True, description="Включить метаданные")
):
    """Получение фрагментов документа из любой версии."""
    if doc_id not in HYBRID_DATA["documents"]:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "DOCUMENT_NOT_FOUND",
                "message": f"Документ {doc_id} не найден",
                "available_documents": list(HYBRID_DATA["documents"].keys())
            }
        )
    
    doc_data = HYBRID_DATA["documents"][doc_id]
    chunks = []
    
    for chunk_data in doc_data["chunks"]:
        chunk = Chunk(
            doc_id=doc_id,
            score=chunk_data["score"],
            content=chunk_data["content"],
            chunk_id=chunk_data["id"],
            title=doc_data["title"],
            metadata={
                "source_version": doc_data["version"],
                "document_type": "hybrid",
                "searchable": True
            } if include_metadata else {}
        )
        chunks.append(chunk)
    
    return DocumentChunksResponse(
        doc_id=doc_id,
        chunks=chunks,
        total_chunks=len(chunks),
        document_title=doc_data["title"]
    )

@hybrid_router.get("/statistics", response_model=StatisticsResponse)
async def hybrid_statistics():
    """Объединенная статистика из всех версий."""
    stats = HYBRID_DATA["statistics"]
    return StatisticsResponse(
        total_searches=stats["total_searches"],
        unique_queries=stats["unique_queries"],
        avg_latency_ms=stats["avg_latency_ms"],
        top_documents=stats["top_documents"],
        search_distribution=stats["version_distribution"]
    )

@hybrid_router.get("/search/advanced")
async def advanced_search_options():
    """Расширенные опции поиска."""
    return {
        "search_modes": [
            {"name": "legacy_only", "description": "Только Version 1 результаты"},
            {"name": "modern_only", "description": "Только Version 2 результаты"},
            {"name": "hybrid", "description": "Объединенные результаты всех версий"},
            {"name": "intelligent", "description": "Интеллектуальный выбор версии"}
        ],
        "ranking_factors": [
            "relevance_score",
            "version_preference",
            "document_quality",
            "user_feedback"
        ],
        "filtering_options": {
            "versions": ["1.0", "2.0", "3.0"],
            "document_types": ["legacy", "modern", "hybrid"],
            "quality_levels": ["basic", "enhanced", "premium"]
        }
    }

# =============================================================================
# ADVANCED CHAT ENDPOINTS (Объединенные возможности)
# =============================================================================

@hybrid_router.post("/chat", response_model=ChatResponse)
async def hybrid_chat(
    req: ChatRequest,
    current_user: str = Depends(get_current_user),
    enable_context: bool = Query(default=True, description="Включить контекст из предыдущих сообщений"),
    prefer_version: str = Query(default="auto", description="Предпочитаемая версия для ответов")
):
    """Универсальный чат с поддержкой всех версий."""
    start_time = time.perf_counter()
    
    # Поиск релевантных фрагментов из всех версий
    citations = []
    for doc_id, doc_data in HYBRID_DATA["documents"].items():
        for chunk in doc_data["chunks"]:
            if req.message.lower() in chunk["content"].lower():
                citations.append(Chunk(
                    doc_id=doc_id,
                    score=chunk["score"],
                    content=chunk["content"],
                    title=doc_data["title"],
                    metadata={"source_version": doc_data["version"]}
                ))
                if len(citations) >= req.topk:
                    break
        if len(citations) >= req.topk:
            break
    
    # Генерация интеллектуального ответа
    if citations:
        # Анализ источников
        version_counts = {}
        for citation in citations:
            version = citation.metadata.get("source_version", "unknown")
            version_counts[version] = version_counts.get(version, 0) + 1
        
        reply_lines = [
            "🤖 **Искра Гибридный ИИ**",
            f"\n📝 **Ваш запрос:** {req.message}",
            f"\n🔍 **Найдено источников:** {len(citations)}",
            "",
            "📊 **Анализ по версиям:**"
        ]
        
        for version, count in version_counts.items():
            reply_lines.append(f"- Version {version}: {count} источников")
        
        reply_lines.append(f"\n💡 **Рекомендации на основе анализа:**")
        
        # Добавляем лучшие цитаты
        for i, citation in enumerate(citations[:3], 1):
            snippet = citation.content[:200].replace('\n', ' ')
            version = citation.metadata.get("source_version", "?")
            reply_lines.append(f"{i}. [{version}] {snippet}...")
        
        # Добавляем заключение
        reply_lines.append(f"\n✅ **Заключение:** Система успешно обработала ваш запрос, используя данные из {len(set(c.metadata.get('source_version') for c in citations))} различных версий API.")
        
        reply = "\n".join(reply_lines)
        confidence = 0.9
    else:
        reply = f"🔍 **Анализ завершен**\n\nК сожалению, не удалось найти релевантную информацию для запроса: {req.message}\n\n💡 **Рекомендации:**\n- Попробуйте переформулировать запрос\n- Используйте более общие термины\n- Проверьте правильность написания"
        confidence = 0.3
    
    response_time_ms = (time.perf_counter() - start_time) * 1000
    
    return ChatResponse(
        reply=reply,
        citations=citations,
        confidence=confidence,
        conversation_id=req.conversation_id,
        response_time_ms=response_time_ms
    )

@hybrid_router.get("/chat/context/{conversation_id}")
async def get_chat_context(
    conversation_id: str,
    current_user: str = Depends(get_current_user)
):
    """Получение контекста диалога."""
    # Имитация контекста диалога
    context = {
        "conversation_id": conversation_id,
        "messages_count": 5,
        "last_activity": datetime.utcnow().isoformat(),
        "context_summary": {
            "main_topics": ["API", "поиск", "документация"],
            "preferred_version": "3.0",
            "user_satisfaction": 0.87
        },
        "version_usage": {
            "v1": 20,
            "v2": 35,
            "v3": 45
        }
    }
    
    return context

# =============================================================================
# SYSTEM ENDPOINTS (Лучшее из обеих версий)
# =============================================================================

@hybrid_router.get("/health", response_model=HealthResponse)
async def hybrid_health_check():
    """Комплексная проверка здоровья системы."""
    return HealthResponse(
        status="operational",
        time=time.time(),
        services={
            "legacy_api": {"status": "healthy", "version": "1.0", "endpoints": 6},
            "modern_api": {"status": "healthy", "version": "2.0", "endpoints": 12},
            "hybrid_api": {"status": "healthy", "version": "3.0", "endpoints": 18},
            "search_engine": {"status": "operational", "indexed_documents": len(HYBRID_DATA["documents"])},
            "chat_engine": {"status": "active", "context_awareness": True},
            "authentication": {"status": "secure", "multi_version_support": True}
        },
        version="3.0.0"
    )

@hybrid_router.get("/version", response_model=VersionResponse)
async def hybrid_version():
    """Информация о гибридной версии."""
    return VersionResponse(
        name="Искра Гибридная API",
        version="3.0.0",
        build_date="2025-10-29",
        components={
            "api_gateway": "3.0.0",
            "legacy_bridge": "1.0.0",
            "modern_bridge": "2.0.0", 
            "hybrid_engine": "3.0.0",
            "search_engine": "2.5.1",
            "chat_engine": "2.0.2"
        },
        api_versions=["1.0", "2.0", "3.0"],
        cd_index=0.95
    )

@hybrid_router.get("/status", response_model=SystemStatusResponse)
async def hybrid_system_status():
    """Общий статус гибридной системы."""
    return SystemStatusResponse(
        overall_status="excellent",
        uptime_seconds=172800,  # 48 часов
        active_connections=127,
        memory_usage_mb=1024.5,
        cpu_usage_percent=23.7,
        database_status="healthy",
        last_health_check=datetime.utcnow()
    )

@hybrid_router.get("/canon/index", response_model=CanonIndexResponse)
async def hybrid_canon_index():
    """Канонический индекс гибридной системы."""
    lines = [
        "# 🚀 Искра Гибридная API - Полная документация",
        "",
        "## 📋 Обзор системы",
        "Интегрированная API система, объединяющая возможности всех версий",
        "",
        "## 🔗 Доступные API версии:",
        "",
        "### Version 1.0 (Legacy)",
        "- **Путь:** `/`",
        "- **Совместимость:** 100% обратная совместимость",
        "- **Endpoints:** /healthz, /auth/login, /v1/search, /v1/chat, /v1/version, /v1/canon/index",
        "",
        "### Version 2.0 (Modern)", 
        "- **Путь:** `/api/v2`",
        "- **Особенности:** Улучшенная функциональность",
        "- **Endpoints:** /auth/*, /search, /documents/*, /chat, /statistics, /health, /status",
        "",
        "### Version 3.0 (Hybrid)",
        "- **Путь:** `/api/v3`",
        "- **Особенности:** Лучшее из всех версий",
        "- **Endpoints:** /auth/*, /search, /documents/*, /chat, /statistics, /system/*, /info",
        "",
        "## 🎯 Ключевые возможности",
        "",
        "### Поиск",
        "- Многоуровневый поиск по всем версиям",
        "- Интеллектуальная агрегация результатов",
        "- Расширенные фильтры и метаданные",
        "",
        "### Чат",
        "- Контекстная осведомленность",
        "- Мультиверсионная база знаний",
        "- Аналитические ответы",
        "",
        "### Безопасность",
        "- JWT аутентификация",
        "- Политика CORS",
        "- Ограничение частоты запросов",
        "",
        "## 🛠️ Архитектура",
        "- **Middleware:** Совместимость, логирование, безопасность",
        "- **Endpoints:** Модульная структура",
        "- **Models:** Унифицированные Pydantic модели",
        "- **Services:** Сервисный слой для бизнес-логики"
    ]
    
    return CanonIndexResponse(
        lines=lines,
        total_lines=len(lines),
        last_updated=datetime.utcnow()
    )

@hybrid_router.get("/info", response_model=APIInfo)
async def hybrid_api_info():
    """Полная информация о гибридном API."""
    metadata = APIMetadata()
    
    endpoints_summary = {
        "legacy": "6 endpoints - полная совместимость с Version 1",
        "modern": "12 endpoints - улучшенная функциональность Version 2", 
        "hybrid": "18 endpoints - объединенные возможности Version 3"
    }
    
    deprecation_notices = [
        "Version 1.0 будет объявлена устаревшей 31 декабря 2025",
        "Рекомендуется миграция на Version 3.0 для новых проектов"
    ]
    
    return APIInfo(
        metadata=metadata,
        endpoints_summary=endpoints_summary,
        deprecation_notices=deprecation_notices
    )

@hybrid_router.get("/migrate/{from_version}/{to_version}")
async def migration_guide(
    from_version: str,
    to_version: str,
    endpoint_type: str = Query(default="all", description="Тип endpoints для миграции")
):
    """Руководство по миграции между версиями."""
    migration_guides = {
        "1.0_to_2.0": {
            "auth": {"old": "/auth/login", "new": "/api/v2/auth/login", "changes": "Добавлен logout"},
            "search": {"old": "/v1/search", "new": "/api/v2/search", "changes": "Расширенная фильтрация"},
            "chat": {"old": "/v1/chat", "new": "/api/v2/chat", "changes": "Контекстная осведомленность"}
        },
        "1.0_to_3.0": {
            "auth": {"old": "/auth/login", "new": "/api/v3/auth/login", "changes": "Универсальная аутентификация"},
            "search": {"old": "/v1/search", "new": "/api/v3/search", "changes": "Мультиверсионный поиск"},
            "chat": {"old": "/v1/chat", "new": "/api/v3/chat", "changes": "Гибридный ИИ"}
        },
        "2.0_to_3.0": {
            "search": {"old": "/api/v2/search", "new": "/api/v3/search", "changes": "Интеллектуальная агрегация"},
            "chat": {"old": "/api/v2/chat", "new": "/api/v3/chat", "changes": "Продвинутая аналитика"},
            "system": {"old": "/api/v2/status", "new": "/api/v3/system/status", "changes": "Расширенный мониторинг"}
        }
    }
    
    guide_key = f"{from_version}_to_{to_version}"
    guide = migration_guides.get(guide_key, {})
    
    return {
        "migration_path": f"Version {from_version} → Version {to_version}",
        "guide": guide,
        "automated_migration": to_version == "3.0",
        "breaking_changes": [],
        "recommended_steps": [
            f"1. Обновите base URL с {from_version} на {to_version}",
            "2. Проверьте совместимость токенов аутентификации",
            "3. Обновите обработку ответов",
            "4. Протестируйте новые возможности"
        ]
    }
