"""Endpoint'ы для интегрированной API системы.

Экспортирует все роутеры для разных версий API.
"""

from .legacy_endpoints import legacy_router
from .modern_endpoints import modern_router
from .hybrid_endpoints import hybrid_router

__all__ = [
    "legacy_router",
    "modern_router", 
    "hybrid_router"
]