"""Middleware для интегрированной API системы.

Обеспечивает совместимость и дополнительную функциональность для всех версий API.
"""

import time
import logging
from typing import Callable, Dict, Any
from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import JSONResponse
import json
from datetime import datetime

# Настройка логгера
logger = logging.getLogger(__name__)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware для добавления заголовков безопасности."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        # Заголовки безопасности
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'"
        
        return response


class APICompatibilityMiddleware(BaseHTTPMiddleware):
    """Middleware для обеспечения совместимости между версиями API."""
    
    def __init__(self, app, version_mapping: Dict[str, str] = None):
        super().__init__(app)
        self.version_mapping = version_mapping or {
            "/v1/search": "/api/v2/search",
            "/v1/chat": "/api/v2/chat",
            "/v1/version": "/api/v2/version"
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Перенаправление устаревших путей на новые
        path = request.url.path
        
        # Логирование API вызовов
        logger.info(f"API Request: {request.method} {path} - Client: {request.client.host if request.client else 'unknown'}")
        
        # Обработка запроса
        response = await call_next(request)
        
        # Добавление заголовков совместимости
        response.headers["X-API-Version"] = self._get_api_version(path)
        response.headers["X-Response-Time"] = f"{time.time():.3f}"
        
        return response
    
    def _get_api_version(self, path: str) -> str:
        """Определение версии API по пути."""
        if path.startswith("/api/v3"):
            return "3.0"
        elif path.startswith("/api/v2"):
            return "2.0"
        elif path.startswith("/v1") or path == "/" or path.startswith("/auth"):
            return "1.0"
        return "unknown"


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Middleware для логирования запросов."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()
        
        # Извлекаем информацию о запросе
        client_ip = request.client.host if request.client else "unknown"
        method = request.method
        path = request.url.path
        query_params = str(request.query_params) if request.query_params else ""
        
        try:
            response = await call_next(request)
            
            # Вычисляем время обработки
            process_time = time.time() - start_time
            
            # Логируем запрос
            logger.info(
                f"Request processed: {method} {path} | "
                f"Client: {client_ip} | "
                f"Status: {response.status_code} | "
                f"Time: {process_time:.3f}s | "
                f"Query: {query_params}"
            )
            
            # Добавляем заголовок с временем обработки
            response.headers["X-Process-Time"] = str(process_time)
            
            return response
            
        except Exception as e:
            # Логируем ошибку
            process_time = time.time() - start_time
            logger.error(
                f"Request failed: {method} {path} | "
                f"Client: {client_ip} | "
                f"Error: {str(e)} | "
                f"Time: {process_time:.3f}s"
            )
            raise


class CORSCompatibilityMiddleware(BaseHTTPMiddleware):
    """Расширенный CORS middleware с поддержкой различных версий."""
    
    def __init__(self, app, allowed_origins: list = None):
        super().__init__(app)
        self.allowed_origins = allowed_origins or [
            "http://localhost:3000",
            "http://localhost:8080",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:8080"
        ]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Проверяем Origin для CORS
        origin = request.headers.get("origin")
        
        if origin and origin in self.allowed_origins:
            response = await call_next(request)
            
            # Добавляем CORS заголовки
            response.headers["Access-Control-Allow-Origin"] = origin
            response.headers["Access-Control-Allow-Credentials"] = "true"
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
            response.headers["Access-Control-Allow-Headers"] = "Authorization, Content-Type, X-Requested-With"
            
            return response
        
        # Если origin не разрешен, продолжаем без CORS заголовков
        return await call_next(request)


class VersionHeaderMiddleware(BaseHTTPMiddleware):
    """Middleware для обработки заголовков версии API."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Проверяем заголовок X-API-Version
        api_version = request.headers.get("X-API-Version")
        
        if api_version:
            # Сохраняем запрошенную версию в state
            request.state.api_version = api_version
        
        response = await call_next(request)
        
        # Добавляем информацию о поддерживаемых версиях
        response.headers["X-API-Supported-Versions"] = "1.0,2.0,3.0"
        response.headers["X-API-Deprecation-Notice"] = "Version 1.0 will be deprecated on 2025-12-31"
        
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Простой middleware для ограничения частоты запросов."""
    
    def __init__(self, app, requests_per_minute: int = 60):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.request_times = {}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        client_ip = request.client.host if request.client else "unknown"
        current_time = time.time()
        
        # Очищаем старые записи
        if client_ip in self.request_times:
            self.request_times[client_ip] = [
                t for t in self.request_times[client_ip] 
                if current_time - t < 60  # Последняя минута
            ]
        else:
            self.request_times[client_ip] = []
        
        # Проверяем лимит
        if len(self.request_times[client_ip]) >= self.requests_per_minute:
            return JSONResponse(
                status_code=429,
                content={
                    "error": "RATE_LIMIT_EXCEEDED",
                    "message": "Too many requests",
                    "retry_after": 60
                }
            )
        
        # Добавляем текущий запрос
        self.request_times[client_ip].append(current_time)
        
        return await call_next(request)


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware для централизованной обработки ошибок."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            response = await call_next(request)
            return response
            
        except Exception as e:
            # Логируем ошибку
            logger.error(
                f"Unhandled exception: {str(e)} | "
                f"Path: {request.url.path} | "
                f"Method: {request.method}"
            )
            
            # Определяем тип ошибки и возвращаем соответствующий ответ
            if hasattr(e, 'status_code'):
                status_code = e.status_code
            else:
                status_code = 500
            
            error_response = {
                "error": "INTERNAL_SERVER_ERROR",
                "message": "Произошла внутренняя ошибка сервера",
                "timestamp": datetime.utcnow().isoformat(),
                "path": str(request.url.path)
            }
            
            # В режиме разработки добавляем детали ошибки
            if request.url.path.startswith("/api/v") or request.url.path in ["/healthz"]:
                error_response["debug_message"] = str(e) if str(e) != "Internal Server Error" else "Unknown error"
            
            return JSONResponse(
                status_code=status_code,
                content=error_response
            )


class ResponseFormattingMiddleware(BaseHTTPMiddleware):
    """Middleware для форматирования ответов в зависимости от версии API."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        response = await call_next(request)
        
        # Проверяем, нужно ли изменить формат ответа
        accept_header = request.headers.get("accept", "")
        api_version = getattr(request.state, "api_version", "1.0")
        
        # Для версии 1.0 сохраняем исходный формат
        if api_version == "1.0":
            return response
        
        # Для новых версий добавляем метаданные
        if hasattr(response, "body"):
            try:
                content_type = response.headers.get("content-type", "")
                if "application/json" in content_type:
                    # Добавляем метаданные к JSON ответу
                    original_content = json.loads(response.body.decode())
                    
                    # Создаем обернутый ответ
                    wrapped_content = {
                        "success": response.status_code < 400,
                        "data": original_content,
                        "metadata": {
                            "api_version": api_version,
                            "timestamp": datetime.utcnow().isoformat(),
                            "request_id": getattr(request.state, "request_id", None)
                        }
                    }
                    
                    # Создаем новый ответ
                    return JSONResponse(
                        content=wrapped_content,
                        status_code=response.status_code,
                        headers=dict(response.headers)
                    )
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Если не удается распарсить JSON, возвращаем исходный ответ
                pass
        
        return response
