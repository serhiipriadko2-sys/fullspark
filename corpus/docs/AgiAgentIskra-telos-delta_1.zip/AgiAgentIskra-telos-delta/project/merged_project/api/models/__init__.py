"""Модели данных интегрированной API системы Искра.

Объединяет модели из обеих версий с поддержкой всех возможностей.
"""

from .unified_models import (
    # Authentication models
    LoginRequest, Token, TokenData,
    
    # Search models  
    SearchRequest, SearchResponse, Chunk, DocumentChunksResponse, StatisticsResponse,
    
    # Chat models
    ChatRequest, ChatResponse,
    
    # System models
    HealthResponse, VersionResponse, CanonIndexResponse, SystemStatusResponse,
    
    # Legacy compatibility models (Version 1)
    LegacySearchResponse, LegacyChatResponse,
    
    # Error models
    ErrorResponse, ValidationErrorResponse
)

__all__ = [
    # Authentication
    "LoginRequest", "Token", "TokenData",
    
    # Search
    "SearchRequest", "SearchResponse", "Chunk", "DocumentChunksResponse", "StatisticsResponse",
    
    # Chat
    "ChatRequest", "ChatResponse",
    
    # System
    "HealthResponse", "VersionResponse", "CanonIndexResponse", "SystemStatusResponse",
    
    # Legacy compatibility
    "LegacySearchResponse", "LegacyChatResponse",
    
    # Error handling
    "ErrorResponse", "ValidationErrorResponse"
]