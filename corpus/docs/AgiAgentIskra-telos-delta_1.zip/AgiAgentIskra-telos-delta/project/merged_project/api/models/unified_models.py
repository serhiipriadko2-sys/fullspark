"""Объединенные модели данных для интегрированной API системы.

Объединяет все модели из Version 1 и Version 2 с дополнительными возможностями.
"""

from datetime import datetime
from typing import List, Optional, Union, Any
from pydantic import BaseModel, Field, validator
import time

# =============================================================================
# AUTHENTICATION MODELS (объединенные из обеих версий)
# =============================================================================

class LoginRequest(BaseModel):
    """Запрос на вход в систему."""
    username: str = Field(..., description="Имя пользователя", min_length=1, max_length=100)
    password: str = Field(..., description="Пароль пользователя", min_length=8, max_length=255)
    
    @validator('username')
    def validate_username(cls, v):
        """Валидация имени пользователя."""
        v = v.strip()
        if any(char in v for char in ['<', '>', '&', '"', "'", '(', ')', ';']):
            raise ValueError('Username contains invalid characters')
        return v
    
    @validator('password')
    def validate_password(cls, v):
        """Валидация пароля."""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        return v

class Token(BaseModel):
    """Токен доступа (унифицированный формат)."""
    access_token: str = Field(..., description="Токен доступа")
    token_type: str = Field(default="bearer", description="Тип токена")
    expires_in: Optional[int] = Field(default=None, description="Время жизни токена в секундах")

class TokenData(BaseModel):
    """Данные пользователя из токена."""
    username: str = Field(..., description="Имя пользователя")
    exp: Optional[datetime] = Field(None, description="Время истечения токена")
    iat: Optional[datetime] = Field(None, description="Время создания токена")
    jti: Optional[str] = Field(None, description="Уникальный ID токена")

# =============================================================================
# SEARCH MODELS (объединенные и расширенные)
# =============================================================================

class SearchRequest(BaseModel):
    """Запрос на поиск (унифицированный)."""
    query: str = Field(..., description="Поисковый запрос", min_length=1, max_length=1000)
    k: int = Field(default=5, description="Количество результатов", ge=1, le=50)
    include_metadata: bool = Field(default=True, description="Включить метаданные")
    filter_documents: Optional[List[str]] = Field(default=None, description="Фильтр по документам")
    
    @validator('query')
    def validate_query(cls, v):
        """Валидация поискового запроса."""
        v = v.strip()
        if not v:
            raise ValueError('Query cannot be empty')
        return v

class Chunk(BaseModel):
    """Фрагмент документа (унифицированный)."""
    doc_id: str = Field(..., description="Идентификатор документа")
    score: float = Field(..., description="Оценка релевантности (0-1)", ge=0.0, le=1.0)
    content: str = Field(..., description="Содержимое фрагмента", min_length=1)
    chunk_id: Optional[int] = Field(None, description="Индекс фрагмента в документе")
    metadata: Optional[dict] = Field(default_factory=dict, description="Метаданные фрагмента")
    title: Optional[str] = Field(None, description="Заголовок документа")
    url: Optional[str] = Field(None, description="URL источника")

class SearchResponse(BaseModel):
    """Ответ на поисковый запрос (унифицированный)."""
    query: str = Field(..., description="Исходный поисковый запрос")
    chunks: List[Chunk] = Field(..., description="Найденные фрагменты")
    latency_ms: float = Field(..., description="Время выполнения в миллисекундах")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Время выполнения запроса")
    total_results: int = Field(..., description="Общее количество найденных результатов")
    search_id: Optional[str] = Field(None, description="Уникальный ID поиска")
    
    def __init__(self, **data):
        if 'timestamp' not in data:
            data['timestamp'] = datetime.utcnow()
        super().__init__(**data)

class DocumentChunksResponse(BaseModel):
    """Ответ с фрагментами документа."""
    doc_id: str = Field(..., description="Идентификатор документа")
    chunks: List[Chunk] = Field(..., description="Фрагменты документа")
    total_chunks: int = Field(..., description="Общее количество фрагментов")
    document_title: Optional[str] = Field(None, description="Заголовок документа")

class StatisticsResponse(BaseModel):
    """Ответ со статистикой поиска."""
    total_searches: int = Field(..., description="Общее количество поисков")
    unique_queries: int = Field(..., description="Количество уникальных запросов")
    avg_latency_ms: float = Field(..., description="Средняя задержка")
    top_documents: List[dict] = Field(default_factory=list, description="Топ документов")
    search_distribution: dict = Field(default_factory=dict, description="Распределение поисков")

# =============================================================================
# CHAT MODELS (объединенные и расширенные)
# =============================================================================

class ChatRequest(BaseModel):
    """Запрос чата (унифицированный)."""
    message: str = Field(..., description="Сообщение пользователя", min_length=1, max_length=5000)
    topk: int = Field(default=4, description="Количество контекстных фрагментов", ge=1, le=20)
    conversation_id: Optional[str] = Field(None, description="Идентификатор диалога")
    include_citations: bool = Field(default=True, description="Включить цитаты")
    response_format: Optional[str] = Field(default="text", description="Формат ответа (text/json)")
    
    @validator('message')
    def validate_message(cls, v):
        """Валидация сообщения чата."""
        v = v.strip()
        if not v:
            raise ValueError('Message cannot be empty')
        return v

class ChatResponse(BaseModel):
    """Ответ чата (унифицированный)."""
    reply: str = Field(..., description="Ответ пользователю")
    citations: List[Chunk] = Field(default_factory=list, description="Цитаты из документов")
    cd_index: Optional[float] = Field(None, description="Индекс конфиденциальности")
    confidence: Optional[float] = Field(None, description="Уровень уверенности ответа (0-1)")
    conversation_id: Optional[str] = Field(None, description="Идентификатор диалога")
    response_time_ms: Optional[float] = Field(None, description="Время ответа в миллисекундах")

# =============================================================================
# SYSTEM MODELS (объединенные из обеих версий)
# =============================================================================

class HealthResponse(BaseModel):
    """Ответ проверки здоровья системы."""
    status: str = Field(..., description="Статус системы")
    time: float = Field(..., description="Время проверки")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    services: Optional[dict] = Field(default_factory=dict, description="Статус сервисов")
    version: Optional[str] = Field(None, description="Версия системы")

class VersionResponse(BaseModel):
    """Ответ с информацией о версии."""
    name: str = Field(..., description="Название системы")
    version: str = Field(..., description="Версия")
    build_date: Optional[str] = Field(None, description="Дата сборки")
    components: dict = Field(default_factory=dict, description="Компоненты системы")
    cd_index: Optional[float] = Field(None, description="Индекс канонической документации")
    api_versions: List[str] = Field(default_factory=list, description="Доступные версии API")

class CanonIndexResponse(BaseModel):
    """Ответ с каноническим индексом."""
    lines: List[str] = Field(..., description="Строки индекса")
    total_lines: int = Field(..., description="Общее количество строк")
    last_updated: datetime = Field(default_factory=datetime.utcnow)

class SystemStatusResponse(BaseModel):
    """Общий статус системы."""
    overall_status: str = Field(..., description="Общий статус")
    uptime_seconds: float = Field(..., description="Время работы в секундах")
    active_connections: int = Field(default=0, description="Активные соединения")
    memory_usage_mb: Optional[float] = Field(None, description="Использование памяти в МБ")
    cpu_usage_percent: Optional[float] = Field(None, description="Использование CPU в процентах")
    database_status: str = Field(default="unknown", description="Статус базы данных")
    last_health_check: datetime = Field(default_factory=datetime.utcnow)

# =============================================================================
# LEGACY COMPATIBILITY MODELS (Version 1)
# =============================================================================

class LegacySearchResponse(BaseModel):
    """Ответ поиска в формате Version 1 (для обратной совместимости)."""
    query: str
    chunks: List[Chunk]
    latency_ms: float

class LegacyChatResponse(BaseModel):
    """Ответ чата в формате Version 1 (для обратной совместимости)."""
    reply: str
    citations: List[Chunk] = []
    cd_index: Optional[float] = None

# =============================================================================
# ERROR HANDLING MODELS
# =============================================================================

class ErrorResponse(BaseModel):
    """Базовая модель ошибки."""
    error: str = Field(..., description="Код ошибки")
    message: str = Field(..., description="Сообщение об ошибке")
    details: Optional[dict] = Field(default_factory=dict, description="Дополнительные детали")
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ValidationErrorResponse(BaseModel):
    """Ответ с ошибками валидации."""
    error: str = Field(default="VALIDATION_ERROR", description="Код ошибки валидации")
    message: str = Field(..., description="Сообщение об ошибке")
    validation_errors: List[dict] = Field(..., description="Детали ошибок валидации")
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# =============================================================================
# API METADATA AND UTILITIES
# =============================================================================

class APIMetadata(BaseModel):
    """Метаданные API."""
    api_name: str = Field(default="Искра - Интегрированная API")
    version: str = Field(default="3.0.0")
    description: str = Field(default="Объединенная API система с поддержкой всех версий")
    supported_versions: List[str] = Field(default=["1.0", "2.0", "3.0"])
    compatibility_mode: str = Field(default="hybrid", description="Режим совместимости")
    
class APIInfo(BaseModel):
    """Информация об API."""
    metadata: APIMetadata
    endpoints_summary: dict = Field(default_factory=dict)
    deprecation_notices: List[str] = Field(default_factory=list)
