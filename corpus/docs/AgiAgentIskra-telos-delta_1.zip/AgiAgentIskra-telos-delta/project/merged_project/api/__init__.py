"""Интегрированная API система Искра.

Объединяет возможности всех версий в единую систему.

Содержит:
- Legacy API (Version 1.0) - полная совместимость
- Modern API (Version 2.0) - улучшенная функциональность
- Hybrid API (Version 3.0) - объединенные возможности
- Унифицированные модели данных
- Middleware для безопасности и совместимости
"""

from .unified_api import app
from .endpoints import legacy_router, modern_router, hybrid_router
from .models.unified_models import *
from .middleware.unified_middleware import *

__all__ = [
    "app",
    "legacy_router",
    "modern_router", 
    "hybrid_router"
]