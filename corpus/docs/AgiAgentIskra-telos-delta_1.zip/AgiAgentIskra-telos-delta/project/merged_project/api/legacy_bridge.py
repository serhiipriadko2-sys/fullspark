"""
Legacy API Bridge для обеспечения 100% совместимости с Version 1.

Мост между новой архитектурой и существующими API endpoint'ами.
Гарантирует, что все работающие endpoint'ы Version 1 продолжают работать без изменений.
"""

import json
import time
from typing import List, Dict, Any, Optional
from pathlib import Path

# Импорты для backward compatibility
import os
import jwt
import hashlib
import base64
from datetime import datetime, timedelta
from dataclasses import asdict

# Импорты внутренних модулей
from core.exceptions import IskraException, handle_legacy_exception
from core.config import settings


class LegacyMemoryManager:
    """Backward compatible memory manager."""
    
    def __init__(self):
        self.root = settings.MEMORY_ROOT
        os.makedirs(self.root, exist_ok=True)
        self.archive = os.path.join(self.root, "main_archive.jsonl")
        self.shadow = os.path.join(self.root, "main_shadow.jsonl")
    
    def put(self, kind: str, key: str, value: dict, meta: dict = None):
        """Legacy put method для совместимости."""
        try:
            ev = {
                "t": time.time(),
                "kind": kind,
                "key": key,
                "value": value,
                "meta": meta or {}
            }
            path = self.archive if kind == "archive" else self.shadow
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps(ev, ensure_ascii=False) + "\n")
            return ev
        except Exception as e:
            raise IskraException(f"Memory put failed: {str(e)}", details={"error": str(e)})


class LegacyVectorSearch:
    """Backward compatible vector search."""
    
    def __init__(self):
        self.evidence_path = settings.EVIDENCE_PATH
    
    def search(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Legacy search method."""
        try:
            if not os.path.exists(self.evidence_path):
                # Fallback для случая, когда файл не существует
                return [
                    {
                        "doc_id": f"demo_doc_{i+1}",
                        "score": 0.95 - (i * 0.1),
                        "content": f"Demo evidence chunk {i+1} for query: {query}"
                    }
                    for i in range(min(k, 2))
                ]
            
            # Простейшая реализация поиска (O(n) как в Version 1)
            results = []
            with open(self.evidence_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            evidence = json.loads(line)
                            # Простой поиск по совпадению ключевых слов
                            query_words = set(query.lower().split())
                            content_words = set(evidence.get('content', '').lower().split())
                            
                            if query_words.intersection(content_words):
                                results.append({
                                    "doc_id": evidence.get('doc_id', 'unknown'),
                                    "score": 0.85,  # Постоянный score как в Version 1
                                    "content": evidence.get('content', '')
                                })
                        except json.JSONDecodeError:
                            continue
            
            # Возвращаем top-k результатов
            return results[:k]
            
        except Exception as e:
            raise IskraException(f"Search failed: {str(e)}", details={"error": str(e)})


class LegacyPasswordManager:
    """Backward compatible password manager."""
    
    @staticmethod
    def hash_password(password: str, salt: str = None) -> tuple[str, str]:
        """Hash password с salt."""
        if salt is None:
            salt = base64.b64encode(os.urandom(16)).decode('utf-8')
        
        password_hash = hashlib.pbkdf2_hmac(
            'sha256', 
            password.encode('utf-8'), 
            salt.encode('utf-8'), 
            100000
        )
        return base64.b64encode(password_hash).decode('utf-8'), salt
    
    @staticmethod
    def verify_password(password: str, password_hash: str, salt: str) -> bool:
        """Verify password."""
        try:
            computed_hash, _ = LegacyPasswordManager.hash_password(password, salt)
            return base64.b64encode(
                base64.b64decode(computed_hash)
            ) == base64.b64encode(
                base64.b64decode(password_hash)
            )
        except Exception:
            return False


class LegacyUserDatabase:
    """Legacy user database с backward compatibility."""
    
    def __init__(self):
        # Тестовые пользователи как в Version 1
        self.users = {
            "admin": {
                "password_hash": base64.b64encode(
                    hashlib.pbkdf2_hmac('sha256', b'admin123', b'salt123', 100000)
                ).decode('utf-8'),
                "salt": "salt123"
            },
            "user": {
                "password_hash": base64.b64encode(
                    hashlib.pbkdf2_hmac('sha256', b'user123', b'salt456', 100000)
                ).decode('utf-8'),
                "salt": "salt456"
            }
        }
    
    def get_user(self, username: str) -> Optional[Dict[str, str]]:
        """Get user by username."""
        return self.users.get(username)


class LegacyAPIBridge:
    """Главный мост для Legacy API (Version 1)."""
    
    def __init__(self, container):
        self.container = container
        
        # Инициализация legacy компонентов
        self.memory_manager = LegacyMemoryManager()
        self.vector_search = LegacyVectorSearch()
        self.user_db = LegacyUserDatabase()
        self.password_manager = LegacyPasswordManager()
    
    async def initialize(self):
        """Инициализация legacy компонентов."""
        try:
            # Проверяем доступность путей
            Path(settings.MEMORY_ROOT).mkdir(parents=True, exist_ok=True)
            Path(settings.EVIDENCE_PATH).parent.mkdir(parents=True, exist_ok=True)
            
            print("✅ Legacy API Bridge инициализирован")
        except Exception as e:
            raise IskraException(f"Legacy bridge initialization failed: {str(e)}")
    
    async def cleanup(self):
        """Очистка ресурсов."""
        print("🧹 Legacy API Bridge очищен")
    
    async def authenticate_user(self, username: str, password: str) -> str:
        """Аутентификация пользователя."""
        try:
            user_data = self.user_db.get_user(username)
            if not user_data:
                raise IskraException("Invalid username or password")
            
            # Verify password (используем legacy метод)
            if not self.password_manager.verify_password(
                password,
                user_data["password_hash"],
                user_data["salt"]
            ):
                raise IskraException("Invalid username or password")
            
            # Create token
            return self._create_jwt_token(username)
        
        except IskraException:
            raise
        except Exception as e:
            raise IskraException(f"Authentication error: {str(e)}")
    
    def _create_jwt_token(self, subject: str) -> str:
        """Create JWT token."""
        payload = {
            "sub": subject,
            "exp": datetime.utcnow() + timedelta(minutes=settings.JWT_EXPIRE_MINUTES),
            "iat": datetime.utcnow(),
            "jti": base64.b64encode(os.urandom(16)).decode('utf-8')
        }
        return jwt.encode(payload, settings.get_safe_jwt_secret(), algorithm=settings.JWT_ALGORITHM)
    
    async def search_evidence(self, query: str, k: int) -> List[Dict[str, Any]]:
        """Поиск доказательств."""
        try:
            return self.vector_search.search(query, k)
        except Exception as e:
            raise IskraException(f"Search evidence failed: {str(e)}")
    
    async def chat_with_evidence(self, message: str, topk: int) -> Dict[str, Any]:
        """Чат с использованием доказательств."""
        try:
            # Получаем citations
            citations = await self.search_evidence(message, topk)
            
            # Формируем ответ как в Version 1
            if citations:
                reply_lines = [
                    f"На основе найденных {len(citations)} источников ваш запрос:\n{message}\n",
                ]
                top_citation = citations[0]
                snippet = top_citation['content'][:200].replace('\n', ' ')
                reply_lines.append(f"Краткий фрагмент: {snippet} ...")
                reply = "\n".join(reply_lines)
            else:
                reply = f"Извините, не удалось найти релевантные данные для запроса:\n{message}"
            
            return {
                "reply": reply,
                "citations": citations,
                "cd_index": None  # Как в Version 1
            }
        
        except Exception as e:
            raise IskraException(f"Chat with evidence failed: {str(e)}")
    
    async def get_version_info(self) -> Dict[str, Any]:
        """Получение информации о версии."""
        try:
            manifest_path = Path(settings.MANIFEST_PATH)
            if manifest_path.exists():
                comp = json.loads(manifest_path.read_text(encoding="utf-8"))
                return {
                    "name": "Iskra Ω (Integrated)",
                    "version": "1.0.0",
                    "compatibility": "Version 1 + Version 2",
                    "components": comp.get("components", {}),
                    "cd_index": comp.get("cd_index")
                }
            else:
                return {
                    "name": "Iskra Ω (Integrated)",
                    "version": "1.0.0",
                    "compatibility": "Version 1 + Version 2",
                    "components": {},
                    "cd_index": None
                }
        except Exception as e:
            raise IskraException(f"Failed to load version info: {str(e)}")
    
    async def get_canon_index(self) -> Dict[str, List[str]]:
        """Получение канонического индекса."""
        try:
            canon_path = Path(settings.CANON_INDEX_PATH)
            if canon_path.exists():
                lines = canon_path.read_text(encoding="utf-8").splitlines()
                return {"lines": lines}
            else:
                return {"lines": []}
        except Exception as e:
            raise IskraException(f"Failed to load canonical index: {str(e)}")
    
    # Дополнительные методы для совместимости
    async def put_memory(self, kind: str, key: str, value: dict, meta: dict = None) -> Dict[str, Any]:
        """Legacy memory put."""
        return self.memory_manager.put(kind, key, value, meta)
    
    def get_memory_status(self) -> Dict[str, Any]:
        """Статус memory системы."""
        return {
            "memory_root": settings.MEMORY_ROOT,
            "archive_exists": os.path.exists(self.memory_manager.archive),
            "shadow_exists": os.path.exists(self.memory_manager.shadow),
            "legacy_mode": True
        }