# Синхронизированная система конфигурации

## Обзор системы

Синхронизированная система конфигурации для интегрированной архитектуры Искра - это комплексное решение, объединяющее настройки из Version 1 и Version 2 с обеспечением полной совместимости, безопасности и гибкости.

### Ключевые возможности

✅ **Унифицированная архитектура** - единая система настроек для всех компонентов  
✅ **Обратная совместимость** - поддержка Version 1 и Version 2  
✅ **Безопасность** - встроенные проверки и рекомендации  
✅ **Профили окружения** - настройки для dev, prod, test, staging  
✅ **Автоматическая миграция** - переход между версиями без потери данных  
✅ **Валидация** - комплексная проверка всех настроек  
✅ **Мониторинг** - встроенные метрики и проверки здоровья  

## Структура проекта

```
merged_project/config/
├── __init__.py                     # Инициализация пакета
├── unified_config.py               # Основная конфигурация
├── environment.py                  # Управление переменными окружения
├── compatibility.py                # Совместимость между версиями
├── migration.py                    # Миграция конфигурации
├── validation.py                   # Валидация настроек
├── defaults.py                     # Значения по умолчанию
├── README.md                       # Документация
└── examples/
    └── config_examples.py          # Примеры использования
```

## Быстрый старт

### 1. Базовое использование

```python
from merged_project.config import create_config, EnvironmentProfile

# Создание конфигурации для разработки
config = create_config(profile=EnvironmentProfile.DEVELOPMENT)

# Использование настроек
print(f"Host: {config.api.host}")
print(f"JWT Algorithm: {config.security.jwt_algorithm}")
print(f"Memory Root: {config.memory.memory_root}")
```

### 2. С конфигурационным файлом

```python
from merged_project.config import UnifiedConfig

config = UnifiedConfig(
    config_path="config.json",
    profile=EnvironmentProfile.PRODUCTION
)
```

### 3. Переменные окружения

```bash
# .env файл
JWT_SECRET=your-secret-key
CORS_ORIGINS=https://example.com
LOG_LEVEL=INFO
MEMORY_BATCH_SIZE=50
```

```python
from merged_project.config import EnvironmentManager

env_manager = EnvironmentManager()
env_vars = env_manager.load_from_environment()
```

## Категории настроек

### SecuritySettings
```python
config.security.jwt_secret                    # JWT секрет
config.security.jwt_algorithm                 # HS256, RS256, etc.
config.security.jwt_access_token_expire_minutes  # Время жизни токена
config.security.cors_origins                  # CORS источники
config.security.rate_limit_enabled            # Rate limiting
```

### MemorySettings  
```python
config.memory.memory_root                     # Корневая директория памяти
config.memory.evidence_path                   # Путь к evidence файлу
config.memory.memory_batch_size               # Размер батча
config.memory.memory_compression_enabled      # Сжатие
config.memory.memory_async_enabled            # Асинхронная память
```

### SearchSettings
```python
config.search.default_search_k                # Количество результатов
config.search.max_search_results              # Максимальное количество
config.search.search_cache_enabled            # Кэширование
config.search.similarity_threshold            # Порог схожести
```

### APISettings
```python
config.api.host                               # Хост сервера
config.api.port                               # Порт сервера
config.api.docs_enabled                       # Документация API
config.api.middleware_enabled                 # Middleware
```

### PerformanceSettings
```python
config.performance.async_pool_size            # Размер async пула
config.performance.connection_pool_size       # Размер пула соединений
config.performance.lru_cache_enabled          # LRU кэш
```

### LoggingSettings
```python
config.logging.log_level                      # Уровень логирования
config.logging.log_format                     # Формат (json, text, colored)
config.logging.file_logging                   # Логирование в файл
config.logging.structured_logging             # Структурированные логи
```

### MonitoringSettings
```python
config.monitoring.metrics_enabled             # Prometheus метрики
config.monitoring.health_check_enabled        # Health checks
config.monitoring.otel_enabled                # OpenTelemetry
```

## Профили конфигурации

### EnvironmentProfile
- **DEVELOPMENT** - Максимальные возможности, подробное логирование
- **PRODUCTION** - Оптимизированная производительность, безопасность
- **TESTING** - Изолированные настройки, быстрые тесты  
- **STAGING** - Промежуточная среда

### DefaultProfile
- **MINIMAL** - Минимальные настройки
- **SECURITY** - Максимальная безопасность
- **PERFORMANCE** - Максимальная производительность

## Миграция и совместимость

### Автоматическая миграция
```python
from merged_project.config import ConfigMigrator

migrator = ConfigMigrator()
migrated_config = migrator.migrate_config(old_config)
```

### Проверка совместимости
```python
from merged_project.config import check_compatibility

report = check_compatibility(config_data)
print(f"Режим: {report['detected_mode']}")
print(f"Совместимо: {report['is_fully_compatible']}")
```

### Генерация скрипта миграции
```python
from merged_project.config import generate_migration_script

generate_migration_script("migrate_config.py")
```

## Валидация

### Базовый уровень
```python
from merged_project.config import validate_config

result = validate_config(config)
if not result["is_valid"]:
    print("Ошибки:", result["errors"])
```

### Строгая валидация
```python
from merged_project.config import ConfigValidator, ValidationLevel

validator = ConfigValidator(level=ValidationLevel.STRICT)
result = validator.validate_all_settings(config)
```

### Проверка безопасности
```python
validator = ConfigValidator(level=ValidationLevel.SECURITY)
result = validator.validate_all_settings(config)

if not result.is_valid:
    print("Проблемы безопасности:", result.errors)
```

## Экспорт и импорт

### Экспорт в .env файл
```python
config.export_to_env_file(".env.production")
```

### Генерация шаблона .env
```python
from merged_project.config import export_env_template

export_env_template(".env.template")
```

### Получение версии системы
```python
from merged_project.config import get_version_info

version_info = get_version_info()
print(f"Версия: {version_info['version']}")
```

## Интеграция с FastAPI

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from merged_project.config import get_config

config = get_config()

app = FastAPI(title=config.security.jwt_algorithm)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.security.cors_origins,
    allow_credentials=config.security.cors_allow_credentials,
    allow_methods=config.security.cors_allow_methods,
    allow_headers=config.security.cors_allow_headers,
)
```

## Безопасность

### Рекомендации
- JWT_SECRET минимум 32 символа
- CORS_ORIGINS только доверенные домены
- Включать RATE_LIMIT_ENABLED в продакшене
- Использовать HTTPS
- Настроить логирование в безопасное место

### Автоматические проверки
```python
# Проверка слабых секретов
# Валидация CORS настроек
# Проверка небезопасных портов
# Анализ зависимостей настроек
```

## Мониторинг и метрики

### Встроенная поддержка
- Prometheus метрики: `/metrics`
- Health checks: `/health`
- OpenTelemetry tracing
- Performance метрики

### Настройки мониторинга
```python
config.monitoring.metrics_enabled            # Включение метрик
config.monitoring.health_check_enabled       # Health checks
config.monitoring.otel_enabled              # OpenTelemetry
config.monitoring.alert_webhook_url         # Webhook для алертов
```

## Примеры конфигурации

### Development (.env)
```bash
APP_NAME=Iskra API
DEBUG=true
LOG_LEVEL=DEBUG
DOCS_ENABLED=true
RATE_LIMIT_ENABLED=false
METRICS_ENABLED=true
```

### Production (.env)
```bash
APP_NAME=Iskra API
DEBUG=false
LOG_LEVEL=WARNING
DOCS_ENABLED=false
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=50
SECURITY_HEADERS_ENABLED=true
MEMORY_COMPRESSION=true
FILE_LOGGING=true
LOG_FILE_PATH=/var/log/iskra/app.log
```

### Config JSON
```json
{
  "profile": "production",
  "security": {
    "jwt_algorithm": "HS256",
    "cors_origins": ["https://example.com"],
    "rate_limit_enabled": true
  },
  "memory": {
    "memory_root": "memory",
    "memory_batch_size": 50,
    "memory_compression_enabled": true
  },
  "api": {
    "host": "0.0.0.0",
    "port": 8000,
    "docs_enabled": false
  }
}
```

## Запуск примеров

```bash
cd merged_project/config/examples
python config_examples.py
```

## API Reference

### Основные классы

#### UnifiedConfig
- `__init__(config_path, profile)` - Инициализация
- `is_production_mode()` - Проверка продакшена
- `is_development_mode()` - Проверка разработки
- `export_to_env_file(filepath)` - Экспорт в .env
- `get_config_summary()` - Сводка конфигурации

#### EnvironmentManager
- `load_from_environment()` - Загрузка переменных
- `validate_environment()` - Валидация окружения
- `generate_env_template(output_path)` - Генерация шаблона
- `get_variable_info(name)` - Информация о переменной

#### ConfigMigrator
- `detect_config_version(config_data)` - Определение версии
- `migrate_config(config_data, target_version)` - Миграция
- `create_migration_report(original, migrated)` - Отчет

#### ConfigValidator
- `validate_all_settings(config)` - Валидация
- `add_custom_validator(name, func)` - Пользовательские валидаторы
- `get_validation_report(result)` - Отчет валидации

## Расширение системы

### Добавление пользовательских настроек
```python
class CustomConfig(UnifiedConfig):
    def _create_custom_settings(self):
        self.custom = CustomSettings(
            custom_option=self.config_data.get("CUSTOM_OPTION", "default")
        )
```

### Пользовательские валидаторы
```python
def custom_validator(config, settings):
    errors = []
    # Логика валидации
    return {"errors": errors, "warnings": []}

validator.add_custom_validator("custom", custom_validator)
```

## Устранение неполадок

### Частые проблемы

1. **JWT_SECRET слишком короткий**
   ```python
   # Автоматически генерируется если < 32 символов
   config.security.jwt_secret  # Проверить длину
   ```

2. **CORS ошибки**
   ```python
   # Проверить источники
   config.security.cors_origins
   ```

3. **Проблемы с производительностью**
   ```python
   # Настроить пулы
   config.performance.async_pool_size
   config.performance.connection_pool_size
   ```

4. **Ошибки валидации**
   ```python
   # Получить детальный отчет
   validator = ConfigValidator()
   result = validator.validate_all_settings(config)
   print(result.errors)
   ```

## Миграция с существующих версий

### С Version 1
1. Автоматическая миграция базовых настроек
2. Обновление JWT_EXPIRE_MINUTES → JWT_ACCESS_TOKEN_EXPIRE_MINUTES
3. Добавление настроек Version 2

### С Version 2
1. Миграция расширенных настроек
2. Объединение с Version 1
3. Применение унифицированной архитектуры

### Проверка миграции
```python
from merged_project.config import ConfigMigrator

migrator = ConfigMigrator()
report = migrator.create_migration_report(old_config, new_config)
```

## Производительность

### Оптимизация для продакшена
- Увеличенные пулы соединений
- Включенное кэширование
- Сжатие памяти
- Оптимизированное логирование

### Мониторинг производительности
- Метрики производительности
- Health checks
- OpenTelemetry tracing
- Alerting

## Лицензия

Эта система конфигурации является частью проекта Iskra и распространяется под соответствующей лицензией.

---

**Синхронизированная система конфигурации v1.0.0**  
*Обеспечивает единообразную работу всех компонентов интегрированной архитектуры Искра*