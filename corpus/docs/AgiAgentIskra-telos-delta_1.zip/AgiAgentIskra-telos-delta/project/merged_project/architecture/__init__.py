"""
Архитектурный пакет для проверки соответствия принципам проектирования
"""

from .compliance_checker import ArchitectureComplianceChecker, Violation
from .migration_validator import MigrationValidator, MigrationReport, ArchitectureVersion
from .architecture_tests import ArchitectureTestSuite

__version__ = "1.0.0"
__author__ = "Architecture Compliance Team"

__all__ = [
    "ArchitectureComplianceChecker",
    "Violation", 
    "MigrationValidator",
    "MigrationReport",
    "ArchitectureVersion",
    "ArchitectureTestSuite"
]