# ⚠️ Отчет о нарушениях архитектурного соответствия

**Общее количество нарушений:** 1125

## 📊 Статистика по типам нарушений

- **SINGLE_RESPONSIBILITY:** 20 нарушений
- **DEPENDENCY_INVERSION:** 16 нарушений
- **HARDCODED_IMPORT:** 332 нарушений
- **PRINT_STATEMENT:** 733 нарушений
- **BARE_EXCEPT:** 4 нарушений
- **NO_ERROR_HANDLING:** 11 нарушений
- **HARDCODED_CONFIG:** 9 нарушений

## 🔍 Детальные нарушения

### SINGLE_RESPONSIBILITY

🔴 **demo.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **integrate_di_system.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **standalone_di_demo.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **api/version2_bridge.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **config/unified_config.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **examples/di_examples.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **memory/integrated_memory.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **memory/legacy_memory.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **memory/migration_tools.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **memory/modern_memory.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **search/integrated_search.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **services/dependency_injection.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **tests/test_error_handling.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **tests/test_integration.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **api/tests/test_unified_api.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **core/di/dependency_wiring.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **core/exceptions/exception_hierarchy.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **core/handlers/error_handlers.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **memory/tests/test_integration.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

🔴 **search/tests/test_compatibility.py** (строка 1)
   - Описание: Класс содержит слишком много методов
   - Предложение: Разделите класс на более мелкие классы

### DEPENDENCY_INVERSION

🔴 **integrate_di_system.py** (строка 48)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **api/legacy_bridge.py** (строка 163)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **api/legacy_bridge.py** (строка 164)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **api/legacy_bridge.py** (строка 165)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **api/legacy_bridge.py** (строка 166)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **config/unified_config.py** (строка 259)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **config/unified_config.py** (строка 260)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **config/unified_config.py** (строка 261)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **config/unified_config.py** (строка 262)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **config/unified_config.py** (строка 263)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **examples/di_examples.py** (строка 182)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **memory/migration_tools.py** (строка 82)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **memory/migration_tools.py** (строка 207)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **memory/migration_tools.py** (строка 237)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **memory/modern_memory.py** (строка 270)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

🔴 **core/di/dependency_wiring.py** (строка 86)
   - Описание: Прямое создание зависимости внутри класса
   - Предложение: Используйте dependency injection

### HARDCODED_IMPORT

🟡 **demo.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 25)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 26)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 27)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 155)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 283)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **demo.py** (строка 379)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **integrate_di_system.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **integrate_di_system.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **integrate_di_system.py** (строка 114)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **integrate_di_system.py** (строка 149)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 23)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 24)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 25)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 26)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 28)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 33)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 38)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 39)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 40)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 41)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 42)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 55)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **main.py** (строка 340)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 32)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 41)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 48)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 66)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 73)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 80)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **run.py** (строка 87)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **standalone_di_demo.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **standalone_di_demo.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **standalone_di_demo.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **standalone_di_demo.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **standalone_di_demo.py** (строка 419)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/legacy_bridge.py** (строка 23)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/unified_api.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/version2_bridge.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 211)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 223)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 240)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 258)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 301)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 302)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 314)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/__init__.py** (строка 318)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 339)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 340)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 479)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/compatibility.py** (строка 480)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/defaults.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/environment.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/environment.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/environment.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 282)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/migration.py** (строка 283)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/simple_test.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/simple_test.py** (строка 126)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/simple_test.py** (строка 132)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 23)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 24)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 25)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 26)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 39)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 62)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 96)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 124)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 149)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 177)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/test_config.py** (строка 202)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/unified_config.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/unified_config.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/unified_config.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/unified_config.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/unified_config.py** (строка 590)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/validation.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/validation.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/validation.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/validation.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/config.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/config.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/config.py** (строка 60)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/config.py** (строка 61)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/exceptions.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/exceptions.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **examples/di_examples.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **examples/di_examples.py** (строка 397)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 20)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 253)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 399)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/demo.py** (строка 428)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/integrated_memory.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/integrated_memory.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/integrated_memory.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/integrated_memory.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/legacy_memory.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/legacy_memory.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/legacy_memory.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 19)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/migration_tools.py** (строка 20)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 19)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 23)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/modern_memory.py** (строка 438)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **models/__init__.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 113)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 117)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 125)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 129)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 140)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/__init__.py** (строка 145)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/demo.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/demo.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/demo.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/demo.py** (строка 440)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/integrated_search.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/integrated_search.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/integrated_search.py** (строка 19)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/integrated_search.py** (строка 20)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/integrated_search.py** (строка 24)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 62)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 161)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/legacy_adapter.py** (строка 196)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 67)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/modern_adapter.py** (строка 258)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/performance_config.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/performance_config.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **services/dependency_injection.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **services/dependency_injection.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **services/dependency_injection.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 38)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 198)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 207)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 211)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 219)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 227)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 288)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 309)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 315)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 340)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 363)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_error_handling.py** (строка 513)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 159)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 168)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 177)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 254)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **tests/test_integration.py** (строка 265)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/hybrid_endpoints.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/hybrid_endpoints.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/hybrid_endpoints.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/hybrid_endpoints.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/legacy_endpoints.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/modern_endpoints.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/modern_endpoints.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/endpoints/modern_endpoints.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/middleware/unified_middleware.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/models/unified_models.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/models/unified_models.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 6)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 583)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **api/tests/test_unified_api.py** (строка 595)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/examples/config_examples.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/examples/config_examples.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/examples/config_examples.py** (строка 308)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/examples/config_examples.py** (строка 309)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **config/examples/config_examples.py** (строка 439)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/config_dependencies.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/config_dependencies.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/config_dependencies.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/dependency_wiring.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/di_container.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/di_container.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/di_container.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/di_container.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/di_container.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/service_registry.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/service_registry.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/service_registry.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/service_registry.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/di/service_registry.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/exceptions/exception_hierarchy.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/exceptions/exception_hierarchy.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/exceptions/exception_hierarchy.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 19)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 451)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/handlers/error_handlers.py** (строка 452)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/logging/logging_system.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 18)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 19)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **core/middleware/error_middleware.py** (строка 20)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/tests/test_integration.py** (строка 11)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/tests/test_integration.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/tests/test_integration.py** (строка 14)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/tests/test_integration.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **memory/tests/test_integration.py** (строка 16)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 20)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 66)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 67)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 86)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 95)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 96)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 116)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/simple_test.py** (строка 153)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 12)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 21)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 22)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_compatibility.py** (строка 23)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 7)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 8)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 9)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 10)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 13)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 15)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 17)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 237)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

🟡 **search/tests/test_performance.py** (строка 238)
   - Описание: Хардкод импорта вместо DI
   - Предложение: Используйте dependency injection

### PRINT_STATEMENT

🟢 **demo.py** (строка 301)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 302)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 308)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 309)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 313)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 317)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 320)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 323)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 326)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 327)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 330)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 331)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 334)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 335)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 353)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 356)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 357)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 367)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 369)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 370)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 371)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **demo.py** (строка 384)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 693)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 694)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 700)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 705)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 706)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 707)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 708)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 709)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 713)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 715)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 725)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 726)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 727)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 729)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **integrate_di_system.py** (строка 730)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 37)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 48)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 50)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 58)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 97)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 98)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 99)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 100)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 101)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 102)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 104)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 105)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 106)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 107)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 108)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **main.py** (строка 130)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 15)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 27)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 34)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 36)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 39)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 42)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 44)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 49)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 51)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 58)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 67)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 69)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 74)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 76)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 81)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 83)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 89)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 91)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 94)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 101)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 106)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 107)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 108)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 109)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 110)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 111)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 125)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 126)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 131)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 133)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 137)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 138)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 139)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 140)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 141)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 142)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 143)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 162)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **run.py** (строка 171)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 154)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 171)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 172)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 187)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 204)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 205)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 221)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 222)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 223)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 236)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 237)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 238)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 239)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 243)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 247)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 248)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 249)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 262)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 265)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 271)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 272)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 273)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 277)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 278)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 279)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 283)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 284)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 285)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 291)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 295)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 298)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 303)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 306)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 331)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 335)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 339)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 340)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 341)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 351)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 352)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 353)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 360)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 364)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 365)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 366)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 385)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 388)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 390)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 392)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 396)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 397)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 410)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 411)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 412)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 413)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 414)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 415)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **standalone_di_demo.py** (строка 418)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **api/legacy_bridge.py** (строка 175)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **api/legacy_bridge.py** (строка 181)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **api/version2_bridge.py** (строка 345)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **api/version2_bridge.py** (строка 351)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 217)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 218)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 232)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 253)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 269)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 271)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 281)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 282)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 283)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 286)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 287)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/__init__.py** (строка 288)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/compatibility.py** (строка 534)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/compatibility.py** (строка 538)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 15)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 25)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 36)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 40)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 46)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 71)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 73)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 77)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 83)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 99)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 108)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 112)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 118)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 127)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 129)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 133)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 135)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 139)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 145)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 167)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 173)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 177)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 183)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 205)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 213)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 219)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 233)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 240)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 246)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 247)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 269)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 272)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 273)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 274)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 275)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 276)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 277)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 280)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 281)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 282)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/simple_test.py** (строка 284)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 18)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 27)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 30)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 36)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 43)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 46)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 47)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 48)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 49)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 53)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 59)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 71)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 72)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 73)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 81)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 82)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 83)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 87)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 93)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 106)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 107)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 111)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 115)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 121)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 132)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 136)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 140)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 146)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 157)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 164)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 168)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 174)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 187)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 188)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 192)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 198)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 206)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 208)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 212)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 218)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 219)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 242)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 245)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 246)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 247)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 248)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 249)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 250)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 253)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/test_config.py** (строка 255)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 30)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 47)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 48)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 63)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 80)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 81)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 98)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 99)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 100)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 114)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 115)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 116)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 117)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 121)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 125)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 126)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 127)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 148)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 151)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 153)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 159)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 160)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 161)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 165)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 166)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 167)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 168)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 172)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 173)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 174)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 177)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 193)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 196)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 225)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 228)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 232)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 233)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 234)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 238)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 239)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 240)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 245)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 248)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 258)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 266)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 267)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 268)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 272)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 273)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 274)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 292)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 295)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 298)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 301)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 304)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 307)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 311)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 312)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 313)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 318)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 321)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 323)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 326)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 340)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 343)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 352)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 354)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 357)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 364)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 368)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 370)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 373)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 377)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 378)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 389)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 390)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 391)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 392)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 393)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **examples/di_examples.py** (строка 396)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 27)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 35)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 48)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 52)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 56)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 61)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 71)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 90)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 97)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 101)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 104)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 109)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 118)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 133)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 134)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 138)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 141)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 142)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 147)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 157)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 172)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 179)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 183)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 188)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 193)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 196)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 213)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 220)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 238)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 239)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 240)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 241)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 242)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 245)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 247)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 261)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 269)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 285)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 288)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 309)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 312)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 328)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 330)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 331)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 332)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 333)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 338)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 354)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 356)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 361)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 363)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 375)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 378)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 385)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 404)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 406)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 411)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 412)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 424)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/demo.py** (строка 427)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/integrated_memory.py** (строка 155)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/integrated_memory.py** (строка 363)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/integrated_memory.py** (строка 379)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/integrated_memory.py** (строка 399)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/integrated_memory.py** (строка 452)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 75)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 125)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 167)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 221)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 334)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 369)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 466)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 504)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 527)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 530)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 533)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/legacy_memory.py** (строка 539)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 152)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 174)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 254)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 257)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 268)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 272)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 307)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 357)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 480)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 484)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 501)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 554)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 556)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 565)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/migration_tools.py** (строка 635)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 106)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 131)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 297)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 310)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 354)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 426)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 463)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 489)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 518)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 645)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 694)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 724)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 742)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 745)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/modern_memory.py** (строка 748)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 86)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 87)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 88)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 106)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 108)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 112)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 113)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 114)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 117)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 118)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 120)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 127)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 128)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 129)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 143)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 144)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 147)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 151)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 152)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 155)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 157)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 164)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 165)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 166)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 180)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 181)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 187)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 196)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 197)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 198)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 199)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 200)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 204)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 206)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 213)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 214)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 215)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 228)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 229)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 232)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 237)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 238)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 239)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 242)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 247)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 248)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 249)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 254)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 258)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 260)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 262)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 269)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 270)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 271)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 281)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 295)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 298)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 299)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 300)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 304)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 305)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 306)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 307)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 309)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 312)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 314)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 316)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 318)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 325)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 326)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 327)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 335)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 336)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 345)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 350)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 351)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 352)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 353)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 356)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 359)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 361)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 365)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 366)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 367)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 370)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 382)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 383)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 384)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 385)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 390)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 394)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 395)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 396)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 399)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 410)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 412)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 416)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 420)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 421)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 422)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 433)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 434)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 435)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 436)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/demo.py** (строка 439)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 454)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 455)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 466)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 477)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 480)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 484)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 487)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 493)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 496)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 499)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 502)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 506)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 508)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 509)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **tests/test_error_handling.py** (строка 512)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 53)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 54)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 55)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 60)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 61)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 62)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 63)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 64)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 65)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 69)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 71)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 78)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 79)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 80)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 92)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 93)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 94)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 95)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 96)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 97)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 102)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 103)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 104)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 113)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 114)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 115)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 116)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 117)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 120)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 122)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 125)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 127)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 131)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 136)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 137)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 138)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 151)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 155)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 158)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 160)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 164)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 165)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 166)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 167)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 171)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 176)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 177)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 178)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 195)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 200)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 201)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 209)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 211)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 215)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 220)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 221)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 222)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 248)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 253)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 254)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 255)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 258)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 261)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 266)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 267)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 268)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 276)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 289)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 293)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 297)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 298)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 303)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 304)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 305)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 329)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 330)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 331)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 332)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 335)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 336)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 341)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 342)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 343)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 374)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 375)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 376)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 379)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 384)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 385)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 386)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 390)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 391)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 392)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 393)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 394)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 395)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 398)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 399)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 400)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 402)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 403)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 404)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 405)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 406)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 411)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 412)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 438)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 442)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 443)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 444)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **config/examples/config_examples.py** (строка 452)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **core/exceptions/exception_hierarchy.py** (строка 409)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 494)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 503)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 536)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 552)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 638)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 663)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 664)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 665)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 666)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 667)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 670)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 672)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 675)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **memory/tests/test_integration.py** (строка 677)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 16)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 23)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 25)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 33)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 35)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 42)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 44)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 53)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 55)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 58)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 63)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 79)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 81)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 85)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 92)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 109)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 111)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 115)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 122)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 123)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 142)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 143)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 144)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 145)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 147)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/simple_test.py** (строка 152)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 98)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 130)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 173)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 176)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 220)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 221)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 222)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 261)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 262)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 263)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 264)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 276)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 277)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 309)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

🟢 **search/tests/test_performance.py** (строка 325)
   - Описание: Использование print() вместо логирования
   - Предложение: Используйте систему логирования

### BARE_EXCEPT

🟡 **integrate_di_system.py** (строка 685)
   - Описание: Голый except без указания исключений
   - Предложение: Укажите конкретные исключения

🟡 **memory/integrated_memory.py** (строка 412)
   - Описание: Голый except без указания исключений
   - Предложение: Укажите конкретные исключения

🟡 **memory/integrated_memory.py** (строка 418)
   - Описание: Голый except без указания исключений
   - Предложение: Укажите конкретные исключения

🟡 **memory/integrated_memory.py** (строка 424)
   - Описание: Голый except без указания исключений
   - Предложение: Укажите конкретные исключения

### NO_ERROR_HANDLING

🟡 **api/unified_api.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **core/config.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **core/exceptions.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **models/__init__.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **tests/test_integration.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **api/endpoints/hybrid_endpoints.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **api/endpoints/modern_endpoints.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **api/models/unified_models.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **api/tests/test_unified_api.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **search/tests/test_compatibility.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

🟡 **search/tests/test_performance.py** (строка 1)
   - Описание: Методы не обрабатывают исключения
   - Предложение: Добавьте обработку ошибок

### HARDCODED_CONFIG

🟡 **config/compatibility.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/defaults.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/environment.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/migration.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/simple_test.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/test_config.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/unified_config.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/validation.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

🟡 **config/examples/config_examples.py** (строка 1)
   - Описание: Слишком много жестко закодированных значений в конфигурации
   - Предложение: Используйте переменные окружения

## 💡 Общие рекомендации

1. **Применяйте принципы SOLID** во всех компонентах
2. **Используйте dependency injection** для управления зависимостями
3. **Разделяйте слои** согласно архитектурным принципам
4. **Централизуйте обработку ошибок** через middleware
5. **Консистентно настройте конфигурацию** через unified_config

