"""
Архитектурный проверщик соответствия
Проверяет интегрированные компоненты на соответствие архитектурным принципам
"""

import os
import ast
import re
import importlib.util
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

@dataclass
class Violation:
    """Нарушение архитектурного принципа"""
    type: str
    file: str
    line: int
    description: str
    severity: str = "medium"
    suggestion: str = ""

class LayerType(Enum):
    """Типы архитектурных слоев"""
    API = "api"
    SERVICE = "services"
    REPOSITORY = "repositories"
    CORE = "core"
    CONFIG = "config"
    MEMORY = "memory"
    SEARCH = "search"

class ArchitectureComplianceChecker:
    """Основной класс для проверки архитектурного соответствия"""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.violations: List[Violation] = []
        self.layer_rules = self._initialize_layer_rules()
        self.solid_patterns = self._initialize_solid_patterns()
        
    def _initialize_layer_rules(self) -> Dict[LayerType, List[str]]:
        """Инициализация правил для слоев"""
        return {
            LayerType.API: [
                "from ..services import", "from services import", "from ..core import",
                "from core import", "from ..config import", "from config import"
            ],
            LayerType.SERVICE: [
                "from ..api import", "from api import", "from ..core import", 
                "from core import", "from ..config import", "from config import",
                "from .repository", "from ..repositories import"
            ],
            LayerType.REPOSITORY: [
                "from ..api import", "from api import", "from ..services import", 
                "from services import", "from ..core import", "from core import"
            ],
            LayerType.CORE: [
                "from ..api import", "from api import", "from ..services import",
                "from services import", "from ..repositories import", "from repositories import"
            ]
        }
    
    def _initialize_solid_patterns(self) -> Dict[str, List[str]]:
        """Паттерны для проверки SOLID принципов"""
        return {
            "single_responsibility": [
                r"class \w+.*\bhandler\b.*processor\b",
                r"class \w+.*\bmanager\b.*service\b"
            ],
            "open_closed": [
                r"if.*isinstance.*\(.*",
                r"if.*type.*==",
                r"elif.*==",
            ],
            "liskov_substitution": [
                r"super\(\).__init__\(\)",
                r"raise.*NotImplementedError"
            ],
            "interface_segregation": [
                r"class \w+.*\bInterface\b",
                r"def \w+.*raise NotImplementedError"
            ],
            "dependency_inversion": [
                r"import \w+",
                r"from \w+ import",
                r"self\.\w+\s*=\s*\w+"
            ]
        }
    
    def find_python_files(self) -> List[Path]:
        """Найти все Python файлы в проекте"""
        python_files = []
        for ext in ['*.py', '*.pyx']:
            python_files.extend(self.project_path.rglob(ext))
        return [f for f in python_files if not any(skip in str(f) for skip in 
                ['__pycache__', '.git', 'venv', 'node_modules', 'architecture'])]
    
    def analyze_file_for_solid_violations(self, file_path: Path) -> List[Violation]:
        """Анализ файла на нарушения SOLID принципов"""
        violations = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка наличия нескольких ответственностей
            if len(re.findall(r'def \w+.*:', content)) > 20:
                violations.append(Violation(
                    type="SINGLE_RESPONSIBILITY",
                    file=str(file_path),
                    line=1,
                    description="Класс содержит слишком много методов",
                    severity="high",
                    suggestion="Разделите класс на более мелкие классы"
                ))
            
            # Проверка на прямое создание зависимостей
            direct_imports = re.findall(r'from \w+ import \w+', content)
            class_definitions = re.findall(r'class \w+', content)
            
            for line_num, line in enumerate(content.splitlines(), 1):
                # Проверка создания экземпляров внутри классов
                if re.search(r'self\.\w+\s*=\s*\w+\(\)', line):
                    violations.append(Violation(
                        type="DEPENDENCY_INVERSION",
                        file=str(file_path),
                        line=line_num,
                        description="Прямое создание зависимости внутри класса",
                        severity="high",
                        suggestion="Используйте dependency injection"
                    ))
                
                # Проверка наследования для интерфейсов
                if re.search(r'class \w+.*:', line) and 'Interface' in line:
                    interface_methods = re.findall(r'def \w+.*self.*:', content)
                    if len(interface_methods) > 10:
                        violations.append(Violation(
                            type="INTERFACE_SEGREGATION",
                            file=str(file_path),
                            line=line_num,
                            description="Интерфейс содержит слишком много методов",
                            severity="medium",
                            suggestion="Разделите интерфейс на более специфичные"
                        ))
        
        except Exception as e:
            violations.append(Violation(
                type="FILE_READ_ERROR",
                file=str(file_path),
                line=1,
                description=f"Ошибка чтения файла: {str(e)}",
                severity="low"
            ))
        
        return violations
    
    def check_layer_separation(self) -> List[Violation]:
        """Проверка разделения слоев"""
        violations = []
        python_files = self.find_python_files()
        
        for file_path in python_files:
            layer = self._identify_layer(file_path)
            if layer not in self.layer_rules:
                continue
                
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                for line_num, line in enumerate(content.splitlines(), 1):
                    for forbidden_pattern in self.layer_rules[layer]:
                        if forbidden_pattern in line and "config" not in line.lower():
                            violations.append(Violation(
                                type="LAYER_VIOLATION",
                                file=str(file_path),
                                line=line_num,
                                description=f"Неправильная зависимость слоя {layer.value}",
                                severity="high",
                                suggestion="Переместите импорт в правильный слой или используйте DI"
                            ))
            except Exception as e:
                violations.append(Violation(
                    type="FILE_READ_ERROR",
                    file=str(file_path),
                    line=1,
                    description=f"Ошибка при проверке слоев: {str(e)}",
                    severity="low"
                ))
        
        return violations
    
    def check_dependency_injection(self) -> List[Violation]:
        """Проверка dependency injection"""
        violations = []
        python_files = self.find_python_files()
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Поиск конструкторов классов
                class_match = re.search(r'class (\w+).*:', content)
                if class_match:
                    class_name = class_match.group(1)
                    if class_name.endswith('Service') or class_name.endswith('Repository'):
                        # Проверка на прямое создание зависимостей в __init__
                        init_match = re.search(r'def __init__\(self.*?\):(.*?)(?=\n    def|\nclass|\Z)', 
                                             content, re.DOTALL)
                        if init_match:
                            init_body = init_match.group(1)
                            
                            # Проверка на прямое создание экземпляров
                            if re.search(r'=\s*\w+\(\)', init_body):
                                violations.append(Violation(
                                    type="DEPENDENCY_INJECTION",
                                    file=str(file_path),
                                    line=class_match.start(),
                                    description=f"Класс {class_name} создает зависимости напрямую",
                                    severity="high",
                                    suggestion="Используйте dependency injection в конструкторе"
                                ))
                
                # Проверка на hardcoded imports
                for line_num, line in enumerate(content.splitlines(), 1):
                    if re.search(r'import \w+', line) and 'from .' not in line:
                        # Исключаем стандартные библиотеки
                        std_libs = ['os', 'sys', 'json', 'datetime', 'typing', 'enum', 'dataclasses']
                        if not any(lib in line for lib in std_libs):
                            violations.append(Violation(
                                type="HARDCODED_IMPORT",
                                file=str(file_path),
                                line=line_num,
                                description="Хардкод импорта вместо DI",
                                severity="medium",
                                suggestion="Используйте dependency injection"
                            ))
            
            except Exception as e:
                violations.append(Violation(
                    type="FILE_READ_ERROR",
                    file=str(file_path),
                    line=1,
                    description=f"Ошибка при проверке DI: {str(e)}",
                    severity="low"
                ))
        
        return violations
    
    def check_error_handling(self) -> List[Violation]:
        """Проверка обработки ошибок"""
        violations = []
        python_files = self.find_python_files()
        
        for file_path in python_files:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Поиск обработчиков исключений
                for line_num, line in enumerate(content.splitlines(), 1):
                    # Проверка на bare except
                    if re.search(r'except\s*:', line):
                        violations.append(Violation(
                            type="BARE_EXCEPT",
                            file=str(file_path),
                            line=line_num,
                            description="Голый except без указания исключений",
                            severity="medium",
                            suggestion="Укажите конкретные исключения"
                        ))
                    
                    # Проверка на print() вместо логирования
                    if 'print(' in line and not line.strip().startswith('#'):
                        violations.append(Violation(
                            type="PRINT_STATEMENT",
                            file=str(file_path),
                            line=line_num,
                            description="Использование print() вместо логирования",
                            severity="low",
                            suggestion="Используйте систему логирования"
                        ))
                
                # Проверка на отсутствие try-except в методах
                methods = re.findall(r'def \w+.*?:', content)
                try_blocks = re.findall(r'try:', content)
                
                if len(methods) > 3 and len(try_blocks) == 0:
                    violations.append(Violation(
                        type="NO_ERROR_HANDLING",
                        file=str(file_path),
                        line=1,
                        description="Методы не обрабатывают исключения",
                        severity="medium",
                        suggestion="Добавьте обработку ошибок"
                    ))
            
            except Exception as e:
                violations.append(Violation(
                    type="FILE_READ_ERROR",
                    file=str(file_path),
                    line=1,
                    description=f"Ошибка при проверке обработки ошибок: {str(e)}",
                    severity="low"
                ))
        
        return violations
    
    def check_configuration_consistency(self) -> List[Violation]:
        """Проверка консистентности конфигурации"""
        violations = []
        config_dir = self.project_path / "config"
        
        if not config_dir.exists():
            violations.append(Violation(
                type="MISSING_CONFIG_DIR",
                file=str(config_dir),
                line=1,
                description="Отсутствует директория конфигурации",
                severity="high",
                suggestion="Создайте директорию config"
            ))
            return violations
        
        # Проверка наличия основных файлов конфигурации
        required_config_files = ['unified_config.py', 'defaults.py', 'validation.py']
        for config_file in required_config_files:
            config_path = config_dir / config_file
            if not config_path.exists():
                violations.append(Violation(
                    type="MISSING_CONFIG_FILE",
                    file=str(config_path),
                    line=1,
                    description=f"Отсутствует файл конфигурации: {config_file}",
                    severity="medium",
                    suggestion=f"Создайте файл {config_file}"
                ))
        
        # Проверка консистентности импортов в конфигурации
        for py_file in config_dir.rglob("*.py"):
            if py_file.name.startswith('__'):
                continue
                
            try:
                with open(py_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Проверка на жестко закодированные значения
                hardcoded_values = re.findall(r'=\s*["\'][^"\']*["\']', content)
                if len(hardcoded_values) > 10:
                    violations.append(Violation(
                        type="HARDCODED_CONFIG",
                        file=str(py_file),
                        line=1,
                        description="Слишком много жестко закодированных значений в конфигурации",
                        severity="medium",
                        suggestion="Используйте переменные окружения"
                    ))
            
            except Exception as e:
                violations.append(Violation(
                    type="FILE_READ_ERROR",
                    file=str(py_file),
                    line=1,
                    description=f"Ошибка чтения файла конфигурации: {str(e)}",
                    severity="low"
                ))
        
        return violations
    
    def _identify_layer(self, file_path: Path) -> Optional[LayerType]:
        """Определить слой по пути к файлу"""
        path_parts = file_path.parts
        
        if 'api' in path_parts:
            return LayerType.API
        elif 'services' in path_parts:
            return LayerType.SERVICE
        elif 'repositories' in path_parts:
            return LayerType.REPOSITORY
        elif 'core' in path_parts:
            return LayerType.CORE
        elif 'config' in path_parts:
            return LayerType.CONFIG
        elif 'memory' in path_parts:
            return LayerType.MEMORY
        elif 'search' in path_parts:
            return LayerType.SEARCH
        
        return None
    
    def run_full_check(self) -> List[Violation]:
        """Выполнить полную проверку архитектуры"""
        print("🔍 Запуск полной проверки архитектурного соответствия...")
        
        # Очистка предыдущих нарушений
        self.violations = []
        
        # SOLID принципы
        print("   ✅ Проверка SOLID принципов...")
        solid_violations = self.check_solid_principles()
        self.violations.extend(solid_violations)
        
        # Разделение слоев
        print("   ✅ Проверка разделения слоев...")
        layer_violations = self.check_layer_separation()
        self.violations.extend(layer_violations)
        
        # Dependency Injection
        print("   ✅ Проверка Dependency Injection...")
        di_violations = self.check_dependency_injection()
        self.violations.extend(di_violations)
        
        # Обработка ошибок
        print("   ✅ Проверка обработки ошибок...")
        error_violations = self.check_error_handling()
        self.violations.extend(error_violations)
        
        # Конфигурация
        print("   ✅ Проверка конфигурации...")
        config_violations = self.check_configuration_consistency()
        self.violations.extend(config_violations)
        
        print(f"✅ Проверка завершена. Найдено нарушений: {len(self.violations)}")
        return self.violations
    
    def check_solid_principles(self) -> List[Violation]:
        """Проверка SOLID принципов"""
        violations = []
        
        # Анализ каждого файла на нарушения SOLID
        for file_path in self.find_python_files():
            file_violations = self.analyze_file_for_solid_violations(file_path)
            violations.extend(file_violations)
        
        return violations
    
    def generate_compliance_report(self) -> str:
        """Генерация отчета о соответствии"""
        if not self.violations:
            return """
# ✅ Отчет о соответствии архитектуре

Все компоненты соответствуют архитектурным принципам!
"""
        
        # Группировка нарушений по типам
        violations_by_type = {}
        for violation in self.violations:
            if violation.type not in violations_by_type:
                violations_by_type[violation.type] = []
            violations_by_type[violation.type].append(violation)
        
        report = "# ⚠️ Отчет о нарушениях архитектурного соответствия\n\n"
        report += f"**Общее количество нарушений:** {len(self.violations)}\n\n"
        
        # Статистика по типам
        report += "## 📊 Статистика по типам нарушений\n\n"
        for violation_type, violations in violations_by_type.items():
            report += f"- **{violation_type}:** {len(violations)} нарушений\n"
        report += "\n"
        
        # Детальный список нарушений
        report += "## 🔍 Детальные нарушения\n\n"
        
        for violation_type, violations in violations_by_type.items():
            report += f"### {violation_type}\n\n"
            
            for violation in violations:
                severity_emoji = {
                    "high": "🔴",
                    "medium": "🟡", 
                    "low": "🟢"
                }.get(violation.severity, "⚪")
                
                report += f"{severity_emoji} **{violation.file}** (строка {violation.line})\n"
                report += f"   - Описание: {violation.description}\n"
                if violation.suggestion:
                    report += f"   - Предложение: {violation.suggestion}\n"
                report += "\n"
        
        # Рекомендации
        report += "## 💡 Общие рекомендации\n\n"
        report += "1. **Применяйте принципы SOLID** во всех компонентах\n"
        report += "2. **Используйте dependency injection** для управления зависимостями\n"
        report += "3. **Разделяйте слои** согласно архитектурным принципам\n"
        report += "4. **Централизуйте обработку ошибок** через middleware\n"
        report += "5. **Консистентно настройте конфигурацию** через unified_config\n\n"
        
        return report
    
    def save_report_to_file(self, filename: str = None):
        """Сохранение отчета в файл"""
        if filename is None:
            filename = f"architecture_compliance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
        
        report = self.generate_compliance_report()
        
        # Если мы в папке architecture, сохраняем в текущей папке
        if "architecture" in str(self.project_path):
            report_path = self.project_path / filename
        else:
            report_path = self.project_path / "architecture" / filename
        
        # Создаем директорию если не существует
        report_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"📄 Отчет сохранен в: {report_path}")
        return report_path

def main():
    """Основная функция для запуска проверки"""
    import sys
    from datetime import datetime
    
    project_path = sys.argv[1] if len(sys.argv) > 1 else "."
    
    checker = ArchitectureComplianceChecker(project_path)
    violations = checker.run_full_check()
    
    # Вывод краткой статистики
    print("\n" + "="*60)
    print("📋 КРАТКИЙ ОТЧЕТ")
    print("="*60)
    
    if not violations:
        print("✅ Все компоненты соответствуют архитектурным принципам!")
    else:
        print(f"⚠️  Найдено нарушений: {len(violations)}")
        
        # Группировка по типам
        violations_by_type = {}
        for violation in violations:
            violations_by_type[violation.type] = violations_by_type.get(violation.type, 0) + 1
        
        for violation_type, count in violations_by_type.items():
            print(f"   - {violation_type}: {count}")
    
    # Сохранение отчета
    checker.save_report_to_file()
    
    # Возврат кода ошибки для CI/CD
    return 1 if violations else 0

if __name__ == "__main__":
    exit(main())