#!/usr/bin/env python3
"""
Демонстрационный скрипт для архитектурных инструментов
Показывает примеры использования всех компонентов
"""

import sys
import os
from pathlib import Path

# Добавляем путь к проекту
sys.path.insert(0, str(Path(__file__).parent))

from compliance_checker import ArchitectureComplianceChecker
from migration_validator import MigrationValidator, ArchitectureVersion
from architecture_tests import run_architecture_tests

def demo_compliance_checker():
    """Демонстрация работы compliance checker"""
    print("=" * 60)
    print("🔍 ДЕМОНСТРАЦИЯ: Архитектурный проверщик соответствия")
    print("=" * 60)
    
    # Создание проверщика
    checker = ArchitectureComplianceChecker(".")
    
    print(f"📂 Проект: {Path('.').absolute()}")
    print(f"🔍 Найдено Python файлов: {len(checker.find_python_files())}")
    
    # Запуск проверки
    print("\n🚀 Запуск полной проверки архитектуры...")
    violations = checker.run_full_check()
    
    print(f"\n📊 РЕЗУЛЬТАТЫ:")
    print(f"   Всего нарушений: {len(violations)}")
    
    if violations:
        # Группировка по типам
        by_type = {}
        by_severity = {}
        
        for violation in violations:
            by_type[violation.type] = by_type.get(violation.type, 0) + 1
            by_severity[violation.severity] = by_severity.get(violation.severity, 0) + 1
        
        print("\n📈 По типам нарушений:")
        for vtype, count in by_type.items():
            print(f"   - {vtype}: {count}")
        
        print("\n🎯 По уровням серьезности:")
        for severity, count in by_severity.items():
            print(f"   - {severity}: {count}")
        
        # Показать первые несколько нарушений
        print(f"\n🔍 Первые {min(5, len(violations))} нарушений:")
        for i, violation in enumerate(violations[:5], 1):
            severity_emoji = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(violation.severity, "⚪")
            print(f"   {i}. {severity_emoji} {violation.file}:{violation.line}")
            print(f"      {violation.description}")
    else:
        print("✅ Отличная работа! Никаких нарушений не найдено!")
    
    # Генерация отчета
    print("\n📄 Генерация отчета...")
    report_path = checker.save_report_to_file()
    print(f"   Отчет сохранен: {report_path}")
    
    return len(violations)

def demo_migration_validator():
    """Демонстрация работы migration validator"""
    print("\n" + "=" * 60)
    print("🔄 ДЕМОНСТРАЦИЯ: Валидатор миграции архитектуры")
    print("=" * 60)
    
    # Создание валидатора
    validator = MigrationValidator(".")
    
    print(f"📂 Проект: {Path('.').absolute()}")
    
    # Валидация миграции
    print("\n🚀 Валидация миграции LEGACY → MODERN...")
    report = validator.validate_migration(
        ArchitectureVersion.LEGACY, 
        ArchitectureVersion.MODERN
    )
    
    print(f"\n📊 РЕЗУЛЬТАТЫ МИГРАЦИИ:")
    print(f"   Процент успеха: {report.success_rate:.1f}%")
    print(f"   Всего проверок: {report.total_checks}")
    print(f"   Пройдено: {report.passed_checks}")
    print(f"   Провалено: {report.failed_checks}")
    print(f"   Критических проблем: {report.critical_issues}")
    
    # Проверка консистентности файлов
    print("\n📁 Проверка консистентности файлов...")
    file_issues = validator.validate_file_consistency()
    print(f"   Найдено проблем с файлами: {len(file_issues)}")
    
    if file_issues:
        print("\n🔍 Примеры проблем:")
        for issue in file_issues[:3]:
            print(f"   - {issue['file']}: {issue['type']}")
    
    # Создание бэкапа
    print("\n💾 Создание резервной копии...")
    backup_path = validator.create_backup_before_migration("demo_backup")
    print(f"   Бэкап создан: {backup_path}")
    
    # Генерация отчета
    print("\n📄 Генерация отчета о миграции...")
    report_path = validator.save_report(report, "demo_migration_report.md")
    print(f"   Отчет сохранен: {report_path}")
    
    return report.critical_issues

def demo_architecture_tests():
    """Демонстрация работы архитектурных тестов"""
    print("\n" + "=" * 60)
    print("🧪 ДЕМОНСТРАЦИЯ: Архитектурные тесты")
    print("=" * 60)
    
    print("🚀 Запуск тестового набора архитектуры...")
    success = run_architecture_tests()
    
    if success:
        print("\n✅ Все тесты архитектуры пройдены успешно!")
    else:
        print("\n❌ Некоторые тесты архитектуры провалились")
    
    return success

def demo_integration():
    """Интеграционная демонстрация"""
    print("\n" + "=" * 60)
    print("🔗 ИНТЕГРАЦИОННАЯ ДЕМОНСТРАЦИЯ")
    print("=" * 60)
    
    # Последовательный запуск всех инструментов
    print("\n1️⃣  Шаг 1: Проверка архитектурного соответствия")
    violations_count = demo_compliance_checker()
    
    print("\n2️⃣  Шаг 2: Валидация миграции")
    critical_issues = demo_migration_validator()
    
    print("\n3️⃣  Шаг 3: Запуск архитектурных тестов")
    tests_success = demo_architecture_tests()
    
    # Итоговый отчет
    print("\n" + "=" * 60)
    print("📋 ИТОГОВЫЙ ОТЧЕТ")
    print("=" * 60)
    
    print(f"🔍 Нарушения архитектуры: {violations_count}")
    print(f"🔴 Критические проблемы миграции: {critical_issues}")
    print(f"🧪 Архитектурные тесты: {'✅ ПРОЙДЕНЫ' if tests_success else '❌ ПРОВАЛЕНЫ'}")
    
    overall_score = 100
    if violations_count > 0:
        overall_score -= min(50, violations_count * 2)
    if critical_issues > 0:
        overall_score -= min(40, critical_issues * 10)
    if not tests_success:
        overall_score -= 20
    
    overall_score = max(0, overall_score)
    
    print(f"\n🏆 ОБЩИЙ БАЛЛ КАЧЕСТВА АРХИТЕКТУРЫ: {overall_score}/100")
    
    if overall_score >= 90:
        print("🌟 ОТЛИЧНО! Архитектура соответствует высоким стандартам")
    elif overall_score >= 70:
        print("👍 ХОРОШО! Архитектура в основном соответствует стандартам")
    elif overall_score >= 50:
        print("⚠️  УДОВЛЕТВОРИТЕЛЬНО! Требуются улучшения")
    else:
        print("❌ КРИТИЧНО! Архитектура требует серьезного рефакторинга")
    
    print(f"\n📄 Детальные отчеты сохранены в папке architecture/")
    print(f"💾 Резервные копии находятся в папке backups/")
    
    return overall_score

def main():
    """Основная функция демонстрации"""
    print("🚀 ДЕМОНСТРАЦИЯ АРХИТЕКТУРНЫХ ИНСТРУМЕНТОВ")
    print("Инструменты для проверки соответствия архитектурным принципам")
    print("=" * 80)
    
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "checker":
            demo_compliance_checker()
        elif command == "validator":
            demo_migration_validator()
        elif command == "tests":
            demo_architecture_tests()
        elif command == "integration":
            demo_integration()
        else:
            print(f"❌ Неизвестная команда: {command}")
            print("Доступные команды: checker, validator, tests, integration")
            return 1
    else:
        # Запуск полной демонстрации
        score = demo_integration()
        return 0 if score >= 70 else 1
    
    return 0

if __name__ == "__main__":
    exit(main())