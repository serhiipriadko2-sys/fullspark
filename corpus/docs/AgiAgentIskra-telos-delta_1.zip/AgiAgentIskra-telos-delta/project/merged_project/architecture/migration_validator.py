"""
Валидатор миграции архитектуры
Проверяет корректность миграции от старой архитектуры к новой
"""

import os
import ast
import json
import re
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import datetime
import shutil

@dataclass
class MigrationCheck:
    """Проверка миграции"""
    name: str
    description: str
    passed: bool
    severity: str  # "critical", "major", "minor", "info"
    details: str = ""
    suggestion: str = ""

@dataclass
class MigrationReport:
    """Отчет о миграции"""
    timestamp: str
    source_version: str
    target_version: str
    total_checks: int
    passed_checks: int
    failed_checks: int
    critical_issues: int
    checks: List[MigrationCheck] = field(default_factory=list)
    
    @property
    def success_rate(self) -> float:
        if self.total_checks == 0:
            return 0.0
        return (self.passed_checks / self.total_checks) * 100
    
    @property
    def is_successful(self) -> bool:
        return self.critical_issues == 0

class ArchitectureVersion(Enum):
    """Версии архитектуры"""
    LEGACY = "1.0"
    HYBRID = "2.0"
    MODERN = "3.0"

class MigrationValidator:
    """Валидатор миграции архитектуры"""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.checks = []
        self.migration_rules = self._initialize_migration_rules()
        
    def _initialize_migration_rules(self) -> Dict[str, Dict]:
        """Инициализация правил миграции"""
        return {
            "di_implementation": {
                "description": "Dependency Injection система внедрена",
                "critical_files": [
                    "core/di/di_container.py",
                    "core/di/service_registry.py",
                    "core/di/dependency_wiring.py"
                ],
                "checks": [
                    self._check_di_container,
                    self._check_service_registry,
                    self._check_dependency_wiring
                ]
            },
            "layer_separation": {
                "description": "Слои архитектуры правильно разделены",
                "checks": [
                    self._check_api_layer,
                    self._check_service_layer,
                    self._check_repository_layer,
                    self._check_core_layer
                ]
            },
            "error_handling": {
                "description": "Централизованная обработка ошибок",
                "critical_files": [
                    "core/exceptions/exception_hierarchy.py",
                    "core/middleware/error_middleware.py",
                    "core/handlers/error_handlers.py"
                ],
                "checks": [
                    self._check_exception_hierarchy,
                    self._check_error_middleware,
                    self._check_error_handlers
                ]
            },
            "configuration_system": {
                "description": "Единая система конфигурации",
                "critical_files": [
                    "config/unified_config.py",
                    "config/defaults.py",
                    "config/validation.py",
                    "config/environment.py"
                ],
                "checks": [
                    self._check_unified_config,
                    self._check_config_validation,
                    self._check_environment_support
                ]
            },
            "api_integration": {
                "description": "Интеграция API слоев",
                "checks": [
                    self._check_api_integration,
                    self._check_endpoint_separation,
                    self._check_middleware_usage
                ]
            },
            "memory_system": {
                "description": "Интегрированная система памяти",
                "checks": [
                    self._check_memory_integration,
                    self._check_memory_legacy_compatibility
                ]
            },
            "search_system": {
                "description": "Интегрированная поисковая система",
                "checks": [
                    self._check_search_integration,
                    self._check_search_performance
                ]
            }
        }
    
    def validate_migration(self, from_version: ArchitectureVersion, 
                          to_version: ArchitectureVersion) -> MigrationReport:
        """Валидация миграции между версиями"""
        print(f"🔍 Валидация миграции {from_version.value} → {to_version.value}")
        
        # Создание отчета
        report = MigrationReport(
            timestamp=datetime.datetime.now().isoformat(),
            source_version=from_version.value,
            target_version=to_version.value,
            total_checks=0,
            passed_checks=0,
            failed_checks=0,
            critical_issues=0
        )
        
        # Выполнение проверок
        for rule_name, rule_config in self.migration_rules.items():
            print(f"   ✅ Проверка: {rule_config['description']}")
            
            check = MigrationCheck(
                name=rule_name,
                description=rule_config['description'],
                passed=True,  # Будет обновлено ниже
                severity="major"
            )
            
            try:
                # Проверка наличия критических файлов
                if 'critical_files' in rule_config:
                    missing_files = self._check_critical_files(rule_config['critical_files'])
                    if missing_files:
                        check.passed = False
                        check.details = f"Отсутствуют критические файлы: {missing_files}"
                        check.suggestion = "Создайте недостающие файлы"
                        report.critical_issues += 1
                
                # Выполнение дополнительных проверок
                rule_checks_passed = 0
                total_rule_checks = 0
                
                for check_func in rule_config['checks']:
                    total_rule_checks += 1
                    check_result = check_func()
                    if check_result:
                        rule_checks_passed += 1
                    else:
                        check.passed = False
                
                if rule_checks_passed < total_rule_checks:
                    check.details += f" Пройдено проверок: {rule_checks_passed}/{total_rule_checks}"
                
            except Exception as e:
                check.passed = False
                check.details = f"Ошибка при проверке: {str(e)}"
                check.suggestion = "Проверьте конфигурацию валидатора"
            
            # Обновление статистики
            report.total_checks += 1
            if check.passed:
                report.passed_checks += 1
            else:
                report.failed_checks += 1
                if check.severity == "critical":
                    report.critical_issues += 1
            
            report.checks.append(check)
        
        return report
    
    def _check_critical_files(self, files: List[str]) -> List[str]:
        """Проверка наличия критических файлов"""
        missing = []
        for file_path in files:
            full_path = self.project_path / file_path
            if not full_path.exists():
                missing.append(file_path)
        return missing
    
    def _check_di_container(self) -> bool:
        """Проверка DI контейнера"""
        di_file = self.project_path / "core" / "di" / "di_container.py"
        if not di_file.exists():
            return False
        
        try:
            with open(di_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка основных методов
            required_methods = ['register', 'get', 'resolve']
            return all(method in content for method in required_methods)
        except:
            return False
    
    def _check_service_registry(self) -> bool:
        """Проверка реестра сервисов"""
        registry_file = self.project_path / "core" / "di" / "service_registry.py"
        if not registry_file.exists():
            return False
        
        try:
            with open(registry_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка основных компонентов
            required_components = ['ServiceRegistry', 'register', 'get_service']
            return all(component in content for component in required_components)
        except:
            return False
    
    def _check_dependency_wiring(self) -> bool:
        """Проверка подключения зависимостей"""
        wiring_file = self.project_path / "core" / "di" / "dependency_wiring.py"
        if not wiring_file.exists():
            return False
        
        try:
            with open(wiring_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка настройки зависимостей
            return 'setup_dependencies' in content or 'configure_dependencies' in content
        except:
            return False
    
    def _check_api_layer(self) -> bool:
        """Проверка API слоя"""
        api_dir = self.project_path / "api"
        if not api_dir.exists():
            return False
        
        # Проверка структуры API
        required_dirs = ['endpoints', 'middleware', 'models']
        missing_dirs = [d for d in required_dirs if not (api_dir / d).exists()]
        if missing_dirs:
            return False
        
        # Проверка наличия файлов
        endpoints_dir = api_dir / "endpoints"
        has_endpoints = len(list(endpoints_dir.glob("*.py"))) > 0
        
        return has_endpoints
    
    def _check_service_layer(self) -> bool:
        """Проверка сервисного слоя"""
        services_dir = self.project_path / "services"
        if not services_dir.exists():
            return False
        
        # Проверка наличия сервисов
        service_files = list(services_dir.glob("*.py"))
        has_services = len(service_files) > 0
        
        # Проверка использования DI
        di_usage = False
        for service_file in service_files:
            try:
                with open(service_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                if 'Depends' in content or 'get_service' in content:
                    di_usage = True
                    break
            except:
                continue
        
        return has_services and di_usage
    
    def _check_repository_layer(self) -> bool:
        """Проверка repository слоя"""
        repo_dir = self.project_path / "repositories"
        if not repo_dir.exists():
            return False
        
        # Проверка наличия репозиториев
        repo_files = list(repo_dir.glob("*.py"))
        has_repositories = len(repo_files) > 0
        
        return has_repositories
    
    def _check_core_layer(self) -> bool:
        """Проверка core слоя"""
        core_dir = self.project_path / "core"
        if not core_dir.exists():
            return False
        
        # Проверка ключевых директорий
        required_dirs = ['di', 'exceptions', 'middleware', 'logging', 'handlers']
        missing_dirs = [d for d in required_dirs if not (core_dir / d).exists()]
        if missing_dirs:
            return False
        
        return True
    
    def _check_exception_hierarchy(self) -> bool:
        """Проверка иерархии исключений"""
        exceptions_file = self.project_path / "core" / "exceptions" / "exception_hierarchy.py"
        if not exceptions_file.exists():
            return False
        
        try:
            with open(exceptions_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Проверка базовых исключений
            base_exceptions = ['ApplicationException', 'ValidationException', 
                             'NotFoundException', 'AuthorizationException']
            return all(exc in content for exc in base_exceptions)
        except:
            return False
    
    def _check_error_middleware(self) -> bool:
        """Проверка middleware обработки ошибок"""
        middleware_file = self.project_path / "core" / "middleware" / "error_middleware.py"
        return middleware_file.exists()
    
    def _check_error_handlers(self) -> bool:
        """Проверка обработчиков ошибок"""
        handlers_dir = self.project_path / "core" / "handlers"
        return handlers_dir.exists() and len(list(handlers_dir.glob("*.py"))) > 0
    
    def _check_unified_config(self) -> bool:
        """Проверка единой конфигурации"""
        config_file = self.project_path / "config" / "unified_config.py"
        return config_file.exists()
    
    def _check_config_validation(self) -> bool:
        """Проверка валидации конфигурации"""
        validation_file = self.project_path / "config" / "validation.py"
        return validation_file.exists()
    
    def _check_environment_support(self) -> bool:
        """Проверка поддержки окружений"""
        environment_file = self.project_path / "config" / "environment.py"
        return environment_file.exists()
    
    def _check_api_integration(self) -> bool:
        """Проверка интеграции API"""
        api_file = self.project_path / "api" / "unified_api.py"
        return api_file.exists()
    
    def _check_endpoint_separation(self) -> bool:
        """Проверка разделения endpoints"""
        endpoints_dir = self.project_path / "api" / "endpoints"
        if not endpoints_dir.exists():
            return False
        
        endpoint_files = list(endpoints_dir.glob("*.py"))
        return len(endpoint_files) > 0
    
    def _check_middleware_usage(self) -> bool:
        """Проверка использования middleware"""
        middleware_dir = self.project_path / "api" / "middleware"
        return middleware_dir.exists() and len(list(middleware_dir.glob("*.py"))) > 0
    
    def _check_memory_integration(self) -> bool:
        """Проверка интеграции системы памяти"""
        memory_file = self.project_path / "memory" / "integrated_memory.py"
        return memory_file.exists()
    
    def _check_memory_legacy_compatibility(self) -> bool:
        """Проверка совместимости с legacy памятью"""
        legacy_file = self.project_path / "memory" / "legacy_memory.py"
        return legacy_file.exists()
    
    def _check_search_integration(self) -> bool:
        """Проверка интеграции поисковой системы"""
        search_file = self.project_path / "search" / "integrated_search.py"
        return search_file.exists()
    
    def _check_search_performance(self) -> bool:
        """Проверка производительности поиска"""
        perf_file = self.project_path / "search" / "performance_config.py"
        return perf_file.exists()
    
    def validate_file_consistency(self) -> List[Dict]:
        """Проверка консистентности файлов после миграции"""
        issues = []
        
        # Проверка импортов
        python_files = list(self.project_path.rglob("*.py"))
        
        for file_path in python_files:
            if "__pycache__" in str(file_path):
                continue
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Проверка на прямые импорты в сервисах
                if 'services' in str(file_path):
                    direct_imports = re.findall(r'from \w+ import \w+', content)
                    if direct_imports:
                        issues.append({
                            'file': str(file_path),
                            'type': 'direct_imports',
                            'details': f'Найдены прямые импорты: {direct_imports[:3]}',
                            'severity': 'major'
                        })
                
                # Проверка на создание экземпляров в __init__
                if 'def __init__' in content:
                    direct_instantiations = re.findall(r'self\.\w+\s*=\s*\w+\(\)', content)
                    if direct_instantiations:
                        issues.append({
                            'file': str(file_path),
                            'type': 'direct_instantiation',
                            'details': f'Прямое создание зависимостей: {len(direct_instantiations)}',
                            'severity': 'critical'
                        })
            
            except Exception as e:
                issues.append({
                    'file': str(file_path),
                    'type': 'read_error',
                    'details': f'Ошибка чтения файла: {str(e)}',
                    'severity': 'minor'
                })
        
        return issues
    
    def generate_migration_report(self, report: MigrationReport) -> str:
        """Генерация отчета о миграции"""
        md_content = f"""# 📋 Отчет о валидации миграции архитектуры

## 📊 Общая информация
- **Дата проверки:** {report.timestamp}
- **Миграция:** {report.source_version} → {report.target_version}
- **Успешность:** {'✅ УСПЕШНО' if report.is_successful else '❌ ПРОВАЛЕНО'}
- **Процент успеха:** {report.success_rate:.1f}%

## 📈 Статистика
- **Всего проверок:** {report.total_checks}
- **Пройдено:** {report.passed_checks}
- **Провалено:** {report.failed_checks}
- **Критических проблем:** {report.critical_issues}

## 🔍 Детальные результаты
"""
        
        # Группировка по статусу
        passed_checks = [c for c in report.checks if c.passed]
        failed_checks = [c for c in report.checks if not c.passed]
        
        md_content += f"### ✅ Пройденные проверки ({len(passed_checks)})\n\n"
        for check in passed_checks:
            md_content += f"- **{check.name}**: {check.description}\n"
        
        md_content += f"\n### ❌ Проваленные проверки ({len(failed_checks)})\n\n"
        for check in failed_checks:
            severity_emoji = {
                "critical": "🔴",
                "major": "🟠", 
                "minor": "🟡",
                "info": "🔵"
            }.get(check.severity, "⚪")
            
            md_content += f"{severity_emoji} **{check.name}**: {check.description}\n"
            md_content += f"   - Детали: {check.details}\n"
            if check.suggestion:
                md_content += f"   - Предложение: {check.suggestion}\n"
            md_content += "\n"
        
        # Рекомендации
        md_content += "## 💡 Рекомендации\n\n"
        
        if report.is_successful:
            md_content += "🎉 **Поздравляем! Миграция прошла успешно.**\n\n"
            md_content += "Рекомендации для дальнейшего развития:\n"
            md_content += "- Регулярно запускайте проверки соответствия архитектуре\n"
            md_content += "- Мониторьте соблюдение принципов SOLID\n"
            md_content += "- Обновляйте документацию при изменениях\n"
            md_content += "- Настройте автоматические проверки в CI/CD\n"
        else:
            md_content += "⚠️ **Миграция требует доработки.**\n\n"
            md_content += "Приоритетные действия:\n"
            
            critical_checks = [c for c in failed_checks if c.severity == "critical"]
            if critical_checks:
                md_content += "1. **Критические проблемы:**\n"
                for check in critical_checks:
                    md_content += f"   - {check.suggestion}\n"
            
            major_checks = [c for c in failed_checks if c.severity == "major"]
            if major_checks:
                md_content += "2. **Важные улучшения:**\n"
                for check in major_checks:
                    md_content += f"   - {check.suggestion}\n"
        
        return md_content
    
    def save_report(self, report: MigrationReport, filename: str = None):
        """Сохранение отчета в файл"""
        if filename is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"migration_validation_report_{timestamp}.md"
        
        report_content = self.generate_migration_report(report)
        report_path = self.project_path / "architecture" / filename
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        print(f"📄 Отчет сохранен: {report_path}")
        return report_path
    
    def create_backup_before_migration(self, backup_name: str = None) -> str:
        """Создание резервной копии перед миграцией"""
        if backup_name is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"migration_backup_{timestamp}"
        
        backup_path = self.project_path / "backups" / backup_name
        
        # Создание директории для бэкапов
        backup_path.parent.mkdir(exist_ok=True)
        
        # Исключаемые файлы и директории
        exclude_patterns = [
            '__pycache__',
            '.git',
            'venv',
            'env',
            '.env',
            'node_modules',
            '*.pyc',
            '*.pyo',
            'backups'
        ]
        
        def should_exclude(path: Path) -> bool:
            for pattern in exclude_patterns:
                if pattern in str(path) or str(path).endswith(pattern):
                    return True
            return False
        
        # Создание бэкапа
        shutil.copytree(
            self.project_path,
            backup_path,
            ignore=shutil.ignore_patterns(*exclude_patterns),
            dirs_exist_ok=True
        )
        
        # Создание метаданных бэкапа
        metadata = {
            "backup_name": backup_name,
            "timestamp": datetime.datetime.now().isoformat(),
            "source_path": str(self.project_path),
            "backup_path": str(backup_path),
            "architecture_version": ArchitectureVersion.LEGACY.value,
            "checksum": self._calculate_project_checksum()
        }
        
        metadata_file = backup_path / "backup_metadata.json"
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"💾 Резервная копия создана: {backup_path}")
        return str(backup_path)
    
    def _calculate_project_checksum(self) -> str:
        """Вычисление контрольной суммы проекта"""
        hash_md5 = hashlib.md5()
        
        python_files = list(self.project_path.rglob("*.py"))
        for file_path in sorted(python_files):
            try:
                with open(file_path, 'rb') as f:
                    content = f.read()
                    hash_md5.update(content)
            except:
                continue
        
        return hash_md5.hexdigest()
    
    def restore_from_backup(self, backup_path: str) -> bool:
        """Восстановление из резервной копии"""
        backup_dir = Path(backup_path)
        if not backup_dir.exists():
            print(f"❌ Резервная копия не найдена: {backup_path}")
            return False
        
        try:
            # Проверка метаданных
            metadata_file = backup_dir / "backup_metadata.json"
            if metadata_file.exists():
                with open(metadata_file, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                print(f"📋 Метаданные бэкапа: {metadata['timestamp']}")
            
            # Восстановление
            shutil.rmtree(self.project_path)
            shutil.copytree(backup_dir, self.project_path)
            
            # Удаление бэкапных метаданных из восстановленного проекта
            metadata_file.unlink(missing_ok=True)
            
            print(f"✅ Восстановление из резервной копии завершено: {backup_path}")
            return True
            
        except Exception as e:
            print(f"❌ Ошибка восстановления: {str(e)}")
            return False

def main():
    """Основная функция для запуска валидации"""
    import sys
    
    project_path = sys.argv[1] if len(sys.argv) > 1 else "."
    
    validator = MigrationValidator(project_path)
    
    print("🚀 Валидатор миграции архитектуры")
    print("=" * 50)
    
    # Создание резервной копии
    print("\n💾 Создание резервной копии...")
    backup_path = validator.create_backup_before_migration()
    
    # Валидация миграции
    print("\n🔍 Валидация миграции...")
    report = validator.validate_migration(
        ArchitectureVersion.LEGACY,
        ArchitectureVersion.MODERN
    )
    
    # Проверка консистентности файлов
    print("\n📁 Проверка консистентности файлов...")
    file_issues = validator.validate_file_consistency()
    
    if file_issues:
        print(f"⚠️  Найдено проблем с файлами: {len(file_issues)}")
        for issue in file_issues[:5]:  # Показываем только первые 5
            print(f"   - {issue['file']}: {issue['type']}")
    else:
        print("✅ Консистентность файлов в порядке")
    
    # Сохранение отчета
    print("\n📄 Сохранение отчета...")
    validator.save_report(report)
    
    # Вывод результатов
    print("\n" + "=" * 50)
    print("📋 РЕЗУЛЬТАТЫ ВАЛИДАЦИИ")
    print("=" * 50)
    print(f"Успешность: {report.success_rate:.1f}%")
    print(f"Пройдено проверок: {report.passed_checks}/{report.total_checks}")
    print(f"Критических проблем: {report.critical_issues}")
    
    if report.is_successful:
        print("\n🎉 Миграция валидна!")
        return 0
    else:
        print("\n⚠️  Миграция требует доработки")
        return 1

if __name__ == "__main__":
    exit(main())