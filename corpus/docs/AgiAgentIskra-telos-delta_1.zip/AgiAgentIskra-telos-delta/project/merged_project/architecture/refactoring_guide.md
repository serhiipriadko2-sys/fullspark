# 🔧 Руководство по улучшению архитектуры

## 📋 Оглавление
1. [Обзор принципов](#обзор-принципов)
2. [SOLID принципы](#solid-принципы)
3. [Слоистая архитектура](#слоистая-архитектура)
4. [Dependency Injection](#dependency-injection)
5. [Обработка ошибок](#обработка-ошибок)
6. [Система конфигурации](#система-конфигурации)
7. [Пошаговые рекомендации](#пошаговые-рекомендации)
8. [Лучшие практики](#лучшие-практики)

---

## 🎯 Обзор принципов

### Цель рефакторинга
Обеспечение соответствия всех компонентов интегрированной архитектуре через:
- ✅ Соблюдение SOLID принципов
- ✅ Правильное разделение слоев
- ✅ Применение dependency injection
- ✅ Централизованная обработка ошибок
- ✅ Консистентная система конфигурации

### Критерии успеха
- [ ] Все нарушения архитектуры устранены
- [ ] Код соответствует принципам SOLID
- [ ] Зависимости управляются через DI
- [ ] Ошибки обрабатываются централизованно
- [ ] Конфигурация единообразна

---

## 🏗️ SOLID ПРИНЦИПЫ

### 1. Single Responsibility Principle (SRP)

**Проблема:** Класс имеет более одной ответственности.

**Пример нарушения:**
```python
class UserService:
    def create_user(self, data):  # Бизнес-логика
        # создание пользователя
        pass
    
    def validate_email(self, email):  # Валидация
        if '@' not in email:
            raise ValueError("Invalid email")
    
    def save_to_database(self, user):  # Работа с данными
        # сохранение в БД
        pass
    
    def send_email(self, user):  # Коммуникации
        # отправка email
        pass
```

**Исправление:**
```python
# Отдельные классы для каждой ответственности

class UserValidator:
    def validate(self, email: str) -> bool:
        if '@' not in email:
            raise ValueError("Invalid email")
        return True

class UserRepository:
    def save(self, user: User) -> None:
        # сохранение в БД
        pass

class EmailService:
    def send_welcome_email(self, user: User) -> None:
        # отправка email
        pass

class UserService:
    def __init__(
        self,
        validator: UserValidator,
        repository: UserRepository,
        email_service: EmailService
    ):
        self.validator = validator
        self.repository = repository
        self.email_service = email_service
    
    def create_user(self, data: dict) -> User:
        # Валидация
        if not self.validator.validate(data['email']):
            raise ValidationError("Invalid user data")
        
        # Создание пользователя
        user = User(data)
        
        # Сохранение
        self.repository.save(user)
        
        # Уведомления
        self.email_service.send_welcome_email(user)
        
        return user
```

### 2. Open/Closed Principle (OCP)

**Проблема:** Код изменяется для добавления новой функциональности.

**Пример нарушения:**
```python
class PaymentProcessor:
    def process_payment(self, payment_type: str, amount: float):
        if payment_type == 'credit_card':
            # обработка кредитной карты
            return self._process_credit_card(amount)
        elif payment_type == 'paypal':
            # обработка PayPal
            return self._process_paypal(amount)
        elif payment_type == 'stripe':
            # обработка Stripe
            return self._process_stripe(amount)
        else:
            raise ValueError(f"Unsupported payment type: {payment_type}")
```

**Исправление:**
```python
from abc import ABC, abstractmethod

class PaymentProcessorInterface(ABC):
    @abstractmethod
    def process_payment(self, amount: float) -> bool:
        pass

class CreditCardProcessor(PaymentProcessorInterface):
    def process_payment(self, amount: float) -> bool:
        # обработка кредитной карты
        return True

class PayPalProcessor(PaymentProcessorInterface):
    def process_payment(self, amount: float) -> bool:
        # обработка PayPal
        return True

class StripeProcessor(PaymentProcessorInterface):
    def process_payment(self, amount: float) -> bool:
        # обработка Stripe
        return True

class PaymentService:
    def __init__(self, processors: List[PaymentProcessorInterface]):
        self.processors = processors
    
    def process_payment(self, amount: float) -> bool:
        # Автоматический выбор процессора
        for processor in self.processors:
            if processor.can_process(amount):
                return processor.process_payment(amount)
        
        raise ValueError("No suitable processor found")
```

### 3. Liskov Substitution Principle (LSP)

**Проблема:** Подкласс не может заменить родительский класс.

**Пример нарушения:**
```python
class Bird:
    def fly(self):
        return "Flying"

class Sparrow(Bird):
    def fly(self):
        return "Sparrow flying"

class Penguin(Bird):
    def fly(self):
        raise Exception("Penguins can't fly")  # Нарушение LSP!
```

**Исправление:**
```python
from abc import ABC, abstractmethod

class Bird(ABC):
    @abstractmethod
    def move(self) -> str:
        pass

class FlyingBird(Bird):
    @abstractmethod
    def fly(self) -> str:
        pass

class NonFlyingBird(Bird):
    @abstractmethod
    def swim(self) -> str:
        pass

class Sparrow(FlyingBird):
    def fly(self) -> str:
        return "Sparrow flying"
    
    def move(self) -> str:
        return self.fly()

class Penguin(NonFlyingBird):
    def swim(self) -> str:
        return "Penguin swimming"
    
    def move(self) -> str:
        return self.swim()
```

### 4. Interface Segregation Principle (ISP)

**Проблема:** Классы вынуждены реализовывать ненужные методы.

**Пример нарушения:**
```python
class IMachine(ABC):
    @abstractmethod
    def print(self, document):
        pass
    
    @abstractmethod
    def scan(self, document):
        pass
    
    @abstractmethod
    def staple(self, document):
        pass
    
    @abstractmethod
    def fax(self, document):
        pass

class SimplePrinter(IMachine):
    def print(self, document):
        return "Printing"
    
    def scan(self, document):  # Не нужна, но обязательна
        raise NotImplementedError()
    
    def staple(self, document):
        raise NotImplementedError()
    
    def fax(self, document):
        raise NotImplementedError()
```

**Исправление:**
```python
from abc import ABC, abstractmethod
from typing import List

class PrinterInterface(ABC):
    @abstractmethod
    def print(self, document) -> str:
        pass

class ScannerInterface(ABC):
    @abstractmethod
    def scan(self, document) -> str:
        pass

class StaplerInterface(ABC):
    @abstractmethod
    def staple(self, document) -> str:
        pass

class FaxInterface(ABC):
    @abstractmethod
    def fax(self, document) -> str:
        pass

class SimplePrinter(PrinterInterface):
    def print(self, document) -> str:
        return "Printing"

class MultiFunctionPrinter(
    PrinterInterface, 
    ScannerInterface, 
    StaplerInterface,
    FaxInterface
):
    def print(self, document) -> str:
        return "Printing"
    
    def scan(self, document) -> str:
        return "Scanning"
    
    def staple(self, document) -> str:
        return "Stapling"
    
    def fax(self, document) -> str:
        return "Faxing"
```

### 5. Dependency Inversion Principle (DIP)

**Проблема:** Высокоуровневые модули зависят от низкоуровневых.

**Пример нарушения:**
```python
class MySQLDatabase:
    def save(self, data):
        # сохранение в MySQL
        pass

class UserService:
    def __init__(self):
        self.db = MySQLDatabase()  # Прямая зависимость
    
    def create_user(self, user_data):
        self.db.save(user_data)
```

**Исправление:**
```python
from abc import ABC, abstractmethod

class DatabaseInterface(ABC):
    @abstractmethod
    def save(self, data):
        pass

class MySQLDatabase(DatabaseInterface):
    def save(self, data):
        # сохранение в MySQL
        pass

class PostgreSQLDatabase(DatabaseInterface):
    def save(self, data):
        # сохранение в PostgreSQL
        pass

class UserService:
    def __init__(self, database: DatabaseInterface):
        self.db = database  # Зависимость через интерфейс
    
    def create_user(self, user_data):
        self.db.save(user_data)

# Использование
mysql_db = MySQLDatabase()
user_service = UserService(mysql_db)
```

---

## 🏛️ СЛОИСТАЯ АРХИТЕКТУРА

### Правильное разделение слоев

#### API Layer (`api/`)
```python
from fastapi import FastAPI, Depends
from ..services.user_service import UserService
from ..di.dependency_resolver import get_user_service

app = FastAPI()

@app.post("/users/", response_model=UserResponse)
def create_user(
    user_data: UserCreate,
    user_service: UserService = Depends(get_user_service)
):
    """Создание пользователя через API"""
    user = user_service.create_user(user_data.dict())
    return UserResponse.from_user(user)
```

**Правила для API Layer:**
- ✅ Только HTTP обработка
- ✅ Валидация входных данных
- ✅ Преобразование форматов данных
- ❌ НЕТ бизнес-логики
- ❌ НЕТ прямых обращений к БД
- ❌ НЕТ вычислений

#### Service Layer (`services/`)
```python
class UserService:
    def __init__(
        self,
        user_repository: UserRepository,
        email_service: EmailService,
        validator: UserValidator
    ):
        self.user_repository = user_repository
        self.email_service = email_service
        self.validator = validator
    
    def create_user(self, user_data: dict) -> User:
        # Валидация
        if not self.validator.validate(user_data):
            raise ValidationError("Invalid user data")
        
        # Бизнес-логика
        user = User(user_data)
        
        # Сохранение
        saved_user = self.user_repository.save(user)
        
        # Уведомления
        self.email_service.send_welcome_email(saved_user)
        
        return saved_user
```

**Правила для Service Layer:**
- ✅ Только бизнес-логика
- ✅ Валидация доменных правил
- ✅ Координация между слоями
- ❌ НЕТ HTTP обработки
- ❌ НЕТ прямых обращений к БД (через репозиторий)

#### Repository Layer (`repositories/`)
```python
class UserRepository:
    def __init__(self, database: DatabaseInterface):
        self.db = database
    
    def save(self, user: User) -> User:
        """Сохранение пользователя в БД"""
        query = "INSERT INTO users (name, email) VALUES (?, ?)"
        self.db.execute(query, user.name, user.email)
        return user
    
    def find_by_id(self, user_id: int) -> Optional[User]:
        """Поиск пользователя по ID"""
        query = "SELECT * FROM users WHERE id = ?"
        result = self.db.fetch_one(query, user_id)
        return User.from_db_result(result) if result else None
```

**Правила для Repository Layer:**
- ✅ Только работа с данными
- ✅ CRUD операции
- ✅ Преобразование данных
- ❌ НЕТ бизнес-логики
- ❌ НЕТ HTTP обработки

#### Core Layer (`core/`)
```python
# Конфигурация
class Settings:
    DATABASE_URL: str = "sqlite:///app.db"
    EMAIL_HOST: str = "localhost"
    EMAIL_PORT: int = 587

# Исключения
class DomainException(Exception):
    """Базовое исключение домена"""

class ValidationError(DomainException):
    """Ошибка валидации"""

class NotFoundError(DomainException):
    """Ресурс не найден"""
```

**Правила для Core Layer:**
- ✅ Конфигурация и настройки
- ✅ Базовые исключения
- ✅ Утилиты и helpers
- ❌ НЕТ специфичной бизнес-логики
- ❌ НЕТ зависимостей от внешних слоев

---

## 💉 DEPENDENCY INJECTION

### Правильная настройка DI

#### 1. Регистрация зависимостей (`di/service_registry.py`)
```python
class ServiceRegistry:
    def __init__(self):
        self._services = {}
        self._singletons = {}
    
    def register(self, interface, implementation, singleton=True):
        """Регистрация сервиса"""
        self._services[interface] = {
            'implementation': implementation,
            'singleton': singleton
        }
    
    def get(self, interface):
        """Получение сервиса"""
        if interface not in self._services:
            raise ValueError(f"Service {interface} not registered")
        
        service_config = self._services[interface]
        implementation = service_config['implementation']
        
        if service_config['singleton']:
            if interface not in self._singletons:
                self._singletons[interface] = implementation()
            return self._singletons[interface]
        
        return implementation()
```

#### 2. Настройка контейнера (`di/di_container.py`)
```python
class DIContainer:
    def __init__(self):
        self.registry = ServiceRegistry()
        self._setup_services()
    
    def _setup_services(self):
        """Настройка всех сервисов"""
        # База данных
        self.registry.register(
            DatabaseInterface,
            Database,
            singleton=True
        )
        
        # Репозитории
        self.registry.register(
            UserRepository,
            UserRepositoryImpl,
            singleton=True
        )
        
        # Сервисы
        self.registry.register(
            UserService,
            UserService,
            singleton=False  # Новый экземпляр для каждого запроса
        )
    
    def get(self, interface):
        """Получение сервиса"""
        return self.registry.get(interface)
```

#### 3. Использование в FastAPI (`di/dependency_resolver.py`)
```python
from fastapi import Depends

container = DIContainer()

def get_user_repository() -> UserRepository:
    return container.get(UserRepository)

def get_email_service() -> EmailService:
    return container.get(EmailService)

def get_user_service(
    user_repo: UserRepository = Depends(get_user_repository),
    email_service: EmailService = Depends(get_email_service)
) -> UserService:
    return UserService(user_repo, email_service)
```

---

## 🚨 ОБРАБОТКА ОШИБОК

### Централизованная обработка исключений

#### 1. Иерархия исключений (`core/exceptions.py`)
```python
class ApplicationException(Exception):
    """Базовое исключение приложения"""
    
    def __init__(self, message: str, details: dict = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)

class ValidationException(ApplicationException):
    """Ошибка валидации данных"""
    pass

class NotFoundException(ApplicationException):
    """Ресурс не найден"""
    pass

class AuthorizationException(ApplicationException):
    """Ошибка авторизации"""
    pass

class BusinessLogicException(ApplicationException):
    """Ошибка бизнес-логики"""
    pass
```

#### 2. Middleware для обработки ошибок (`core/middleware/error_middleware.py`)
```python
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse

async def error_handler(request: Request, exc: Exception):
    """Глобальный обработчик ошибок"""
    
    if isinstance(exc, ValidationException):
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "code": "VALIDATION_ERROR",
                    "message": exc.message,
                    "details": exc.details
                }
            }
        )
    
    elif isinstance(exc, NotFoundException):
        return JSONResponse(
            status_code=404,
            content={
                "error": {
                    "code": "NOT_FOUND",
                    "message": exc.message
                }
            }
        )
    
    elif isinstance(exc, AuthorizationException):
        return JSONResponse(
            status_code=401,
            content={
                "error": {
                    "code": "UNAUTHORIZED",
                    "message": exc.message
                }
            }
        )
    
    else:
        # Необработанная ошибка
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": "INTERNAL_SERVER_ERROR",
                    "message": "Внутренняя ошибка сервера"
                }
            }
        )
```

#### 3. Использование в сервисах
```python
class UserService:
    def get_user_by_id(self, user_id: int) -> User:
        user = self.user_repository.find_by_id(user_id)
        
        if not user:
            raise NotFoundException(f"Пользователь с ID {user_id} не найден")
        
        return user
    
    def create_user(self, user_data: dict) -> User:
        # Валидация
        if not self._validate_user_data(user_data):
            raise ValidationException("Некорректные данные пользователя")
        
        # Проверка уникальности email
        if self.user_repository.find_by_email(user_data['email']):
            raise ValidationException("Пользователь с таким email уже существует")
        
        # Создание пользователя
        user = User(user_data)
        return self.user_repository.save(user)
```

---

## ⚙️ СИСТЕМА КОНФИГУРАЦИИ

### Единая система настроек

#### 1. Базовые настройки (`config/defaults.py`)
```python
from pydantic import BaseSettings

class Settings(BaseSettings):
    # База данных
    DATABASE_URL: str = "sqlite:///app.db"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # Email
    EMAIL_HOST: str = "localhost"
    EMAIL_PORT: int = 587
    EMAIL_USERNAME: str = ""
    EMAIL_PASSWORD: str = ""
    EMAIL_USE_TLS: bool = True
    
    # API
    API_VERSION: str = "v1"
    API_TITLE: str = "My Application"
    API_DESCRIPTION: str = "API для управления приложением"
    
    # Безопасность
    SECRET_KEY: str = "your-secret-key"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    ALGORITHM: str = "HS256"
    
    # Логирование
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Глобальный экземпляр настроек
settings = Settings()
```

#### 2. Валидация настроек (`config/validation.py`)
```python
from typing import List
from .defaults import Settings

class SettingsValidator:
    """Валидатор настроек приложения"""
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.errors = []
    
    def validate(self) -> bool:
        """Валидация всех настроек"""
        self.errors = []
        
        self._validate_database()
        self._validate_email()
        self._validate_security()
        
        return len(self.errors) == 0
    
    def _validate_database(self):
        """Валидация настроек БД"""
        if not self.settings.DATABASE_URL:
            self.errors.append("DATABASE_URL обязателен")
        
        if not self.settings.DATABASE_URL.startswith(('sqlite://', 'postgresql://', 'mysql://')):
            self.errors.append("DATABASE_URL должен начинаться с sqlite://, postgresql:// или mysql://")
    
    def _validate_email(self):
        """Валидация email настроек"""
        if not self.settings.EMAIL_HOST:
            self.errors.append("EMAIL_HOST обязателен")
        
        if not (1 <= self.settings.EMAIL_PORT <= 65535):
            self.errors.append("EMAIL_PORT должен быть в диапазоне 1-65535")
    
    def _validate_security(self):
        """Валидация настроек безопасности"""
        if len(self.settings.SECRET_KEY) < 32:
            self.errors.append("SECRET_KEY должен содержать минимум 32 символа")
    
    def get_errors(self) -> List[str]:
        """Получение списка ошибок"""
        return self.errors

# Функция для проверки настроек при запуске
def validate_settings() -> bool:
    """Валидация настроек при запуске приложения"""
    validator = SettingsValidator(settings)
    
    if not validator.validate():
        print("❌ Ошибки в настройках:")
        for error in validator.get_errors():
            print(f"   - {error}")
        return False
    
    print("✅ Настройки валидны")
    return True
```

#### 3. Поддержка профилей
```python
# config/environment.py
import os
from typing import Dict, Any
from .defaults import Settings

class EnvironmentConfig:
    """Конфигурация для разных окружений"""
    
    PROFILES = {
        'development': {
            'LOG_LEVEL': 'DEBUG',
            'DATABASE_URL': 'sqlite:///dev.db',
            'SECRET_KEY': 'dev-secret-key-not-for-production'
        },
        'testing': {
            'LOG_LEVEL': 'WARNING',
            'DATABASE_URL': 'sqlite:///:memory:'
        },
        'staging': {
            'LOG_LEVEL': 'INFO',
            'DATABASE_URL': os.getenv('STAGING_DATABASE_URL'),
            'SECRET_KEY': os.getenv('STAGING_SECRET_KEY')
        },
        'production': {
            'LOG_LEVEL': 'WARNING',
            'DATABASE_URL': os.getenv('PRODUCTION_DATABASE_URL'),
            'SECRET_KEY': os.getenv('PRODUCTION_SECRET_KEY'),
            'EMAIL_USE_TLS': True
        }
    }
    
    @classmethod
    def apply_profile(cls, settings: Settings, profile: str) -> Settings:
        """Применение профиля к настройкам"""
        if profile not in cls.PROFILES:
            raise ValueError(f"Неизвестный профиль: {profile}")
        
        profile_config = cls.PROFILES[profile]
        for key, value in profile_config.items():
            if hasattr(settings, key):
                setattr(settings, key, value)
        
        return settings

def get_settings_for_environment(env: str = None) -> Settings:
    """Получение настроек для окружения"""
    env = env or os.getenv('ENVIRONMENT', 'development')
    
    settings = Settings()
    EnvironmentConfig.apply_profile(settings, env)
    
    return settings
```

---

## 🚀 ПОШАГОВЫЕ РЕКОМЕНДАЦИИ

### Этап 1: Анализ текущего состояния
1. **Запустите автоматическую проверку:**
   ```bash
   python architecture/compliance_checker.py merged_project/
   ```

2. **Проанализируйте отчет о нарушениях**
3. **Приоритизируйте проблемы по важности**

### Этап 2: Исправление критических нарушений

#### Критические (🔴) - требуют немедленного исправления:
1. **Нарушения разделения слоев**
   - Проверьте импорты между слоями
   - Переместите бизнес-логику в service layer
   - Уберите прямые обращения к БД из API

2. **Отсутствие dependency injection**
   - Внедрите DI контейнер
   - Уберите прямое создание зависимостей
   - Настройте автоматическое подключение сервисов

#### Важные (🟡) - исправляются в рамках рефакторинга:
1. **Нарушения SOLID принципов**
   - Разделите классы по ответственностям
   - Выделите интерфейсы
   - Примените паттерны проектирования

2. **Неправильная обработка ошибок**
   - Создайте иерархию исключений
   - Настройте централизованную обработку
   - Уберите голые except блоки

### Этап 3: Улучшение архитектуры

#### Высокий приоритет:
1. **Создайте интерфейсы для всех сервисов**
2. **Настройте автоматическую регистрацию зависимостей**
3. **Реализуйте паттерны Repository и Service**

#### Средний приоритет:
1. **Добавьте документацию к API**
2. **Создайте тесты для архитектурных проверок**
3. **Настройте мониторинг соответствия**

### Этап 4: Валидация и тестирование
1. **Запустите тесты архитектуры:**
   ```bash
   python architecture/architecture_tests.py
   ```

2. **Проверьте соответствие с помощью валидатора:**
   ```bash
   python architecture/migration_validator.py
   ```

3. **Выполните интеграционные тесты**

---

## 💎 ЛУЧШИЕ ПРАКТИКИ

### Общие принципы

#### 1. Структура проекта
```
merged_project/
├── api/                 # HTTP слой
│   ├── endpoints/       # API endpoints
│   ├── middleware/      # Middleware компоненты
│   ├── models/          # DTO и модели
│   └── tests/           # Тесты API
├── services/            # Бизнес-логика
│   ├── user_service.py
│   ├── email_service.py
│   └── ...
├── repositories/        # Работа с данными
│   ├── user_repository.py
│   ├── base_repository.py
│   └── ...
├── core/                # Ядро приложения
│   ├── exceptions.py    # Исключения
│   ├── config.py        # Конфигурация
│   ├── logging.py       # Логирование
│   └── di/              # Dependency Injection
├── config/              # Настройки
│   ├── defaults.py      # Базовые настройки
│   ├── validation.py    # Валидация
│   ├── development.py   # Настройки dev
│   └── production.py    # Настройки prod
├── memory/              # Система памяти
├── search/              # Поисковая система
└── architecture/        # Архитектурные компоненты
```

#### 2. Именование
- **Классы:** PascalCase (`UserService`, `EmailSender`)
- **Функции/методы:** snake_case (`create_user`, `send_email`)
- **Константы:** UPPER_SNAKE_CASE (`MAX_RETRIES`, `DEFAULT_TIMEOUT`)
- **Переменные:** snake_case (`user_repository`, `error_message`)

#### 3. Документация
```python
class UserService:
    """
    Сервис для управления пользователями.
    
    Отвечает за:
    - Создание и обновление пользователей
    - Валидацию пользовательских данных
    - Отправку уведомлений
    
    Примеры:
        >>> user_service = UserService(user_repo, email_service)
        >>> user = user_service.create_user({'name': 'John', 'email': 'john@example.com'})
    """
    
    def create_user(self, user_data: dict) -> User:
        """
        Создает нового пользователя.
        
        Args:
            user_data: Данные пользователя
            
        Returns:
            User: Созданный пользователь
            
        Raises:
            ValidationError: Если данные некорректны
            
        Примеры:
            >>> user_service.create_user({'name': 'John', 'email': 'john@example.com'})
        """
        pass
```

#### 4. Обработка ошибок
```python
from typing import Optional

def create_user_safely(user_data: dict) -> tuple[Optional[User], Optional[str]]:
    """
    Безопасное создание пользователя.
    
    Returns:
        tuple: (user, error_message)
    """
    try:
        user = user_service.create_user(user_data)
        return user, None
    except ValidationError as e:
        return None, f"Ошибка валидации: {e.message}"
    except Exception as e:
        return None, f"Неожиданная ошибка: {str(e)}"
```

#### 5. Тестирование
```python
import pytest
from unittest.mock import Mock

class TestUserService:
    def test_create_user_success(self):
        # Arrange
        user_repo = Mock()
        email_service = Mock()
        service = UserService(user_repo, email_service)
        
        user_data = {'name': 'John', 'email': 'john@example.com'}
        
        # Act
        user = service.create_user(user_data)
        
        # Assert
        assert user is not None
        user_repo.save.assert_called_once()
        email_service.send_welcome_email.assert_called_once()
    
    def test_create_user_validation_error(self):
        # Arrange
        service = UserService(Mock(), Mock())
        invalid_data = {'name': '', 'email': 'invalid-email'}
        
        # Act & Assert
        with pytest.raises(ValidationError):
            service.create_user(invalid_data)
```

---

## 🔄 АВТОМАТИЗАЦИЯ И МОНИТОРИНГ

### CI/CD интеграция

#### 1. GitHub Actions workflow
```yaml
# .github/workflows/architecture-compliance.yml
name: Architecture Compliance

on: [push, pull_request]

jobs:
  architecture-check:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.9'
    
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
    
    - name: Run architecture compliance check
      run: |
        python architecture/compliance_checker.py .
    
    - name: Run architecture tests
      run: |
        python architecture/architecture_tests.py
    
    - name: Run migration validator
      run: |
        python architecture/migration_validator.py
```

#### 2. Pre-commit hooks
```yaml
# .pre-commit-config.yaml
repos:
-   repo: local
    hooks:
    -   id: architecture-check
        name: Architecture Compliance Check
        entry: python architecture/compliance_checker.py
        language: system
        pass_filenames: false
        always_run: true
```

#### 3. Мониторинг в разработке
```python
# tools/architecture_monitor.py
import subprocess
import time
import os

class ArchitectureMonitor:
    """Мониторинг архитектурного соответствия в реальном времени"""
    
    def __init__(self):
        self.project_path = "."
    
    def watch_and_check(self):
        """Отслеживание изменений и автоматическая проверка"""
        print("🔍 Запуск мониторинга архитектуры...")
        
        while True:
            # Проверка на изменения
            result = subprocess.run(
                ['git', 'diff', '--name-only'],
                capture_output=True,
                text=True,
                cwd=self.project_path
            )
            
            changed_files = result.stdout.strip().split('\n')
            python_files = [f for f in changed_files if f.endswith('.py')]
            
            if python_files:
                print(f"\n📝 Обнаружены изменения в: {python_files}")
                
                # Запуск проверки архитектуры
                result = subprocess.run(
                    ['python', 'architecture/compliance_checker.py', self.project_path],
                    capture_output=True,
                    text=True
                )
                
                if result.returncode != 0:
                    print("❌ Найдены нарушения архитектуры!")
                    print(result.stdout)
                else:
                    print("✅ Архитектурное соответствие в порядке")
            
            time.sleep(5)  # Проверка каждые 5 секунд

if __name__ == "__main__":
    monitor = ArchitectureMonitor()
    monitor.watch_and_check()
```

---

## 📈 МЕТРИКИ И KPI

### Отслеживание качества архитектуры

#### 1. Ключевые метрики
- **Количество нарушений архитектуры** (должно стремиться к 0)
- **Процент покрытия тестами архитектуры** (минимум 90%)
- **Время выполнения автоматических проверок** (меньше 30 секунд)
- **Количество проблем с регрессией** после изменений

#### 2. Регулярные отчеты
```python
# architecture/metrics_reporter.py
class ArchitectureMetricsReporter:
    """Генератор отчетов по архитектурным метрикам"""
    
    def __init__(self, checker: ArchitectureComplianceChecker):
        self.checker = checker
    
    def generate_weekly_report(self):
        """Еженедельный отчет о состоянии архитектуры"""
        violations = self.checker.run_full_check()
        
        report = {
            'total_violations': len(violations),
            'violations_by_type': {},
            'violations_by_severity': {},
            'trend': self._calculate_trend(),
            'recommendations': self._generate_recommendations(violations)
        }
        
        # Группировка по типам
        for violation in violations:
            report['violations_by_type'][violation.type] = \
                report['violations_by_type'].get(violation.type, 0) + 1
            
            report['violations_by_severity'][violation.severity] = \
                report['violations_by_severity'].get(violation.severity, 0) + 1
        
        return report
```

---

## 🎯 ЗАКЛЮЧЕНИЕ

Соблюдение архитектурных принципов - это непрерывный процесс, который требует постоянного внимания и автоматизации. Используя предоставленные инструменты и рекомендации, вы сможете:

1. **Автоматически выявлять** нарушения архитектуры
2. **Систематически исправлять** проблемы
3. **Предотвращать регрессию** через CI/CD интеграцию
4. **Поддерживать качество** кода на высоком уровне

### Следующие шаги:
1. Запустите автоматическую проверку
2. Проанализируйте найденные нарушения
3. Создайте план рефакторинга
4. Внедрите мониторинг в разработку
5. Настройте регулярные отчеты

Помните: **качественная архитектура - это инвестиция в будущее проекта!**

---

*Для дополнительной помощи обращайтесь к документации или создавайте issue в репозитории проекта.*