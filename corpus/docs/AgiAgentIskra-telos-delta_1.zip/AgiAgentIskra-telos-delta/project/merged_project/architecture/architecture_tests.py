"""
Тесты архитектуры для проверки соответствия принципам проектирования
"""

import unittest
import ast
import os
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
import tempfile
import shutil

# Добавляем путь к корню проекта для импортов
sys.path.insert(0, str(Path(__file__).parent.parent))

from architecture.compliance_checker import (
    ArchitectureComplianceChecker, 
    Violation, 
    LayerType
)

class ArchitectureTestSuite(unittest.TestCase):
    """Базовый класс для архитектурных тестов"""
    
    @classmethod
    def setUpClass(cls):
        """Настройка тестового окружения"""
        cls.test_project_path = cls._create_test_project()
        cls.checker = ArchitectureComplianceChecker(cls.test_project_path)
    
    @classmethod
    def tearDownClass(cls):
        """Очистка тестового окружения"""
        if cls.test_project_path and os.path.exists(cls.test_project_path):
            shutil.rmtree(cls.test_project_path)
    
    @classmethod
    def _create_test_project(cls) -> str:
        """Создание тестового проекта"""
        test_dir = tempfile.mkdtemp()
        
        # Создание структуры проекта
        dirs = ['api', 'services', 'repositories', 'core', 'config', 'memory', 'search']
        for dir_name in dirs:
            os.makedirs(os.path.join(test_dir, dir_name), exist_ok=True)
        
        # Создание __init__ файлов
        for dir_name in dirs:
            init_file = os.path.join(test_dir, dir_name, '__init__.py')
            with open(init_file, 'w') as f:
                f.write(f'# {dir_name} package\n')
        
        return test_dir
    
    def _create_test_file(self, content: str, file_path: str):
        """Создание тестового файла"""
        full_path = os.path.join(self.test_project_path, file_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        with open(full_path, 'w') as f:
            f.write(content)

class TestSOLIDPrinciples(ArchitectureTestSuite):
    """Тесты для проверки SOLID принципов"""
    
    def test_single_responsibility_violations(self):
        """Тест нарушений принципа единственной ответственности"""
        # Создаем файл с нарушением SRP
        srp_violation_content = '''
class GodObject:
    def __init__(self):
        self.data = []
    
    def process_user_data(self, data):
        """Обработка пользовательских данных"""
        pass
    
    def validate_email(self, email):
        """Валидация email"""
        pass
    
    def send_email(self, message):
        """Отправка email"""
        pass
    
    def save_to_database(self, data):
        """Сохранение в БД"""
        pass
    
    def generate_report(self):
        """Генерация отчета"""
        pass
    
    def export_to_csv(self):
        """Экспорт в CSV"""
        pass
    
    def import_from_excel(self):
        """Импорт из Excel"""
        pass
    
    def authenticate_user(self, credentials):
        """Аутентификация пользователя"""
        pass
    
    def authorize_access(self, user, resource):
        """Авторизация доступа"""
        pass
    
    def log_activity(self, action):
        """Логирование активности"""
        pass
    
    def cache_results(self, key, value):
        """Кэширование результатов"""
        pass
    
    def notify_admins(self, message):
        """Уведомление администраторов"""
        pass
    
    def backup_data(self):
        """Резервное копирование"""
        pass
    
    def restore_data(self, backup_id):
        """Восстановление данных"""
        pass
    
    def encrypt_sensitive_data(self, data):
        """Шифрование данных"""
        pass
    
    def decrypt_sensitive_data(self, data):
        """Дешифрование данных"""
        pass
    
    def compress_large_files(self):
        """Сжатие файлов"""
        pass
    
    def decompress_files(self, archive_path):
        """Распаковка файлов"""
        pass
    
    def generate_statistics(self):
        """Генерация статистики"""
        pass
    
    def send_notifications(self):
        """Отправка уведомлений"""
        pass
    
    def process_payments(self, amount):
        """Обработка платежей"""
        pass
    
    def handle_refunds(self, transaction_id):
        """Обработка возвратов"""
        pass
'''
        
        self._create_test_file(srp_violation_content, 'services/god_object.py')
        
        # Запускаем проверку
        violations = self.checker.analyze_file_for_solid_violations(
            Path(self.test_project_path) / 'services' / 'god_object.py'
        )
        
        # Проверяем, что найдены нарушения SRP
        srp_violations = [v for v in violations if v.type == 'SINGLE_RESPONSIBILITY']
        self.assertGreater(len(srp_violations), 0, 
                          "Должны быть обнаружены нарушения принципа единственной ответственности")
    
    def test_dependency_inversion_violations(self):
        """Тест нарушений принципа инверсии зависимостей"""
        # Создаем файл с нарушением DIP
        dip_violation_content = '''
class UserService:
    def __init__(self):
        self.mysql_db = MySQLDatabase()  # Нарушение DIP
        self.smtp_sender = SMTPSender()  # Нарушение DIP
        self.file_logger = FileLogger()  # Нарушение DIP
    
    def create_user(self, user_data):
        # Прямое использование конкретных реализаций
        user_id = self.mysql_db.save_user(user_data)
        self.smtp_sender.send_welcome_email(user_data['email'])
        self.file_logger.log(f"User created: {user_id}")
        return user_id

class MySQLDatabase:
    def save_user(self, data):
        return 123

class SMTPSender:
    def send_welcome_email(self, email):
        pass

class FileLogger:
    def log(self, message):
        pass
'''
        
        self._create_test_file(dip_violation_content, 'services/user_service.py')
        
        # Запускаем проверку DI
        di_violations = self.checker.check_dependency_injection()
        
        # Проверяем, что найдены нарушения DIP
        dip_violations_filtered = [v for v in di_violations 
                                 if 'user_service.py' in v.file]
        self.assertGreater(len(dip_violations_filtered), 0,
                          "Должны быть обнаружены нарушения принципа инверсии зависимостей")
    
    def test_interface_segregation_violations(self):
        """Тест нарушений принципа разделения интерфейсов"""
        # Создаем файл с нарушением ISP
        isp_violation_content = '''
class IMachine(ABC):
    @abstractmethod
    def print(self, document):
        pass
    
    @abstractmethod
    def scan(self, document):
        pass
    
    @abstractmethod
    def staple(self, document):
        pass
    
    @abstractmethod
    def fax(self, document):
        pass
    
    @abstractmethod
    def copy(self, document):
        pass
    
    @abstractmethod
    def collate(self, documents):
        pass
    
    @abstractmethod
    def bind(self, document):
        pass
    
    @abstractmethod
    def laminate(self, document):
        pass
    
    @abstractmethod
    def fold(self, document):
        pass
    
    @abstractmethod
    def punch_holes(self, document):
        pass
    
    @abstractmethod
    def watermark(self, document):
        pass
    
    @abstractmethod
    def encrypt(self, document):
        pass
    
    @abstractmethod
    def decrypt(self, document):
        pass

class SimplePrinter(IMachine):
    def print(self, document):
        return "Printing"
    
    def scan(self, document):
        raise NotImplementedError("Simple printer cannot scan")
    
    def staple(self, document):
        raise NotImplementedError("Simple printer cannot staple")
    
    def fax(self, document):
        raise NotImplementedError("Simple printer cannot fax")
    
    def copy(self, document):
        raise NotImplementedError("Simple printer cannot copy")
    
    def collate(self, documents):
        raise NotImplementedError("Simple printer cannot collate")
    
    def bind(self, document):
        raise NotImplementedError("Simple printer cannot bind")
    
    def laminate(self, document):
        raise NotImplementedError("Simple printer cannot laminate")
    
    def fold(self, document):
        raise NotImplementedError("Simple printer cannot fold")
    
    def punch_holes(self, document):
        raise NotImplementedError("Simple printer cannot punch holes")
    
    def watermark(self, document):
        raise NotImplementedError("Simple printer cannot watermark")
    
    def encrypt(self, document):
        raise NotImplementedError("Simple printer cannot encrypt")
    
    def decrypt(self, document):
        raise NotImplementedError("Simple printer cannot decrypt")
'''
        
        self._create_test_file(isp_violation_content, 'services/printer_interface.py')
        
        # Анализируем файл на нарушения ISP
        violations = self.checker.analyze_file_for_solid_violations(
            Path(self.test_project_path) / 'services' / 'printer_interface.py'
        )
        
        # Проверяем, что найдены нарушения ISP
        isp_violations = [v for v in violations if v.type == 'INTERFACE_SEGREGATION']
        self.assertGreater(len(isp_violations), 0,
                          "Должны быть обнаружены нарушения принципа разделения интерфейсов")

class TestLayerSeparation(ArchitectureTestSuite):
    """Тесты для проверки разделения слоев"""
    
    def test_api_layer_violations(self):
        """Тест нарушений в API слое"""
        # Создаем файл в API слое с неправильными импортами
        api_violation_content = '''
from services.user_service import UserService  # Должно быть через DI
from core.database import Database            # Нарушение разделения слоев
from config.settings import settings           # Это допустимо

def create_user_api(user_data):
    db = Database()  # Прямое создание зависимости
    service = UserService(db)  # Нарушение DI
    return service.create_user(user_data)
'''
        
        self._create_test_file(api_violation_content, 'api/user_endpoints.py')
        
        # Проверяем разделение слоев
        layer_violations = self.checker.check_layer_separation()
        
        # Фильтруем нарушения для API слоя
        api_violations = [v for v in layer_violations 
                         if 'user_endpoints.py' in v.file]
        self.assertGreater(len(api_violations), 0,
                          "Должны быть обнаружены нарушения разделения слоев в API")
    
    def test_service_layer_violations(self):
        """Тест нарушений в сервисном слое"""
        # Создаем файл в service слое с нарушениями
        service_violation_content = '''
from api.models import UserModel      # Нарушение: Service не должен импортировать из API
from repositories.user_repo import UserRepository
from core.database import Database

class UserService:
    def __init__(self):
        self.db = Database()  # Прямое создание зависимости
        self.user_model = UserModel()  # Нарушение слоев
    
    def create_user(self, user_data):
        return self.db.save(user_data)  # Бизнес-логика смешана с работой БД
'''
        
        self._create_test_file(service_violation_content, 'services/user_service.py')
        
        # Проверяем разделение слоев
        layer_violations = self.checker.check_layer_separation()
        
        # Фильтруем нарушения для service слоя
        service_violations = [v for v in layer_violations 
                             if 'user_service.py' in v.file]
        self.assertGreater(len(service_violations), 0,
                          "Должны быть обнаружены нарушения разделения слоев в Service")
    
    def test_repository_layer_violations(self):
        """Тест нарушений в repository слое"""
        # Создаем файл в repository слое с нарушениями
        repo_violation_content = '''
from api.models import UserModel     # Нарушение: Repository не должен импортировать из API
from services.email_service import EmailService  # Нарушение: Repository не должен знать о сервисах

class UserRepository:
    def __init__(self):
        self.email_service = EmailService()  # Нарушение: Repository не должен отправлять email
    
    def save(self, user_data):
        # Бизнес-логика в repository
        if user_data['email'] == 'admin@test.com':
            self.email_service.send_notification('Admin user created')
        
        # Сохранение в БД
        return self._insert_to_db(user_data)
'''
        
        self._create_test_file(repo_violation_content, 'repositories/user_repository.py')
        
        # Проверяем разделение слоев
        layer_violations = self.checker.check_layer_separation()
        
        # Фильтруем нарушения для repository слоя
        repo_violations = [v for v in layer_violations 
                          if 'user_repository.py' in v.file]
        self.assertGreater(len(repo_violations), 0,
                          "Должны быть обнаружены нарушения разделения слоев в Repository")

class TestDependencyInjection(ArchitectureTestSuite):
    """Тесты для проверки dependency injection"""
    
    def test_hardcoded_imports(self):
        """Тест на жестко закодированные импорты"""
        hardcoded_content = '''
import requests  # Хардкод зависимости
import json
import datetime

class ApiClient:
    def __init__(self):
        self.session = requests.Session()  # Прямое создание зависимости
    
    def get_data(self, url):
        return self.session.get(url)
'''
        
        self._create_test_file(hardcoded_content, 'services/api_client.py')
        
        # Проверяем DI
        di_violations = self.checker.check_dependency_injection()
        
        # Фильтруем нарушения для тестового файла
        hardcoded_violations = [v for v in di_violations 
                               if 'api_client.py' in v.file]
        self.assertGreater(len(hardcoded_violations), 0,
                          "Должны быть обнаружены хардкод импорты")
    
    def test_direct_dependency_creation(self):
        """Тест на прямое создание зависимостей в конструкторах"""
        direct_dep_content = '''
class OrderService:
    def __init__(self):
        self.database = Database()  # Прямое создание
        self.email_service = EmailService()  # Прямое создание
        self.logger = Logger()  # Прямое создание
        self.cache = RedisCache()  # Прямое создание
    
    def create_order(self, order_data):
        # Используем прямые зависимости
        user = self.database.find_user(order_data['user_id'])
        self.email_service.send_confirmation(user.email, order_data)
        self.logger.info(f"Order created for user {user.id}")
        return self._process_order(order_data)
'''
        
        self._create_test_file(direct_dep_content, 'services/order_service.py')
        
        # Проверяем DI
        di_violations = self.checker.check_dependency_injection()
        
        # Фильтруем нарушения для тестового файла
        direct_violations = [v for v in di_violations 
                           if 'order_service.py' in v.file]
        self.assertGreater(len(direct_violations), 0,
                          "Должны быть обнаружены прямые создания зависимостей")

class TestErrorHandling(ArchitectureTestSuite):
    """Тесты для проверки обработки ошибок"""
    
    def test_bare_except_clauses(self):
        """Тест на голые except блоки"""
        bare_except_content = '''
def process_user_data(user_data):
    try:
        # Обработка данных
        result = user_service.create_user(user_data)
        return result
    except:  # Голый except - нарушение
        print("Error occurred")  # Простой print вместо логирования
        return None

def another_function():
    try:
        risky_operation()
    except:  # Еще один голый except
        pass  # Тихий пропуск ошибки
'''
        
        self._create_test_file(bare_except_content, 'services/user_processor.py')
        
        # Проверяем обработку ошибок
        error_violations = self.checker.check_error_handling()
        
        # Фильтруем нарушения для тестового файла
        bare_except_violations = [v for v in error_violations 
                                 if 'user_processor.py' in v.file and v.type == 'BARE_EXCEPT']
        self.assertGreater(len(bare_except_violations), 0,
                          "Должны быть обнаружены голые except блоки")
    
    def test_print_statements(self):
        """Тест на использование print вместо логирования"""
        print_content = '''
class DataProcessor:
    def process(self, data):
        print("Starting data processing")  # Должно быть логирование
        print(f"Processing {len(data)} items")
        
        try:
            result = self._do_processing(data)
            print("Processing completed successfully")
            return result
        except Exception as e:
            print(f"Error: {e}")  # Должно быть логирование
            print("Processing failed")  # Должно быть логирование
            return None
    
    def _do_processing(self, data):
        print("Inside processing method")
        return data
'''
        
        self._create_test_file(print_content, 'services/data_processor.py')
        
        # Проверяем обработку ошибок
        error_violations = self.checker.check_error_handling()
        
        # Фильтруем нарушения для тестового файла
        print_violations = [v for v in error_violations 
                           if 'data_processor.py' in v.file and v.type == 'PRINT_STATEMENT']
        self.assertGreater(len(print_violations), 0,
                          "Должны быть обнаружены использования print вместо логирования")

class TestConfigurationConsistency(ArchitectureTestSuite):
    """Тесты для проверки консистентности конфигурации"""
    
    def test_missing_config_files(self):
        """Тест на отсутствующие файлы конфигурации"""
        # Создаем пустую директорию config
        config_dir = Path(self.test_project_path) / 'config'
        config_dir.mkdir(exist_ok=True)
        
        # Проверяем конфигурацию
        config_violations = self.checker.check_configuration_consistency()
        
        # Должны быть найдены отсутствующие файлы
        missing_files = [v for v in config_violations 
                        if v.type == 'MISSING_CONFIG_FILE']
        self.assertGreater(len(missing_files), 0,
                          "Должны быть обнаружены отсутствующие файлы конфигурации")
    
    def test_hardcoded_config_values(self):
        """Тест на жестко закодированные значения в конфигурации"""
        hardcoded_config = '''
# Конфигурация с жестко закодированными значениями
DATABASE_HOST = "localhost"  # Жестко закодировано
DATABASE_PORT = 3306         # Жестко закодировано
DATABASE_NAME = "myapp"      # Жестко закодировано
DATABASE_USER = "admin"      # Жестко закодировано
DATABASE_PASSWORD = "secret" # Жестко закодировано

EMAIL_HOST = "smtp.gmail.com"    # Жестко закодировано
EMAIL_PORT = 587                 # Жестко закодировано
EMAIL_USERNAME = "test@gmail.com" # Жестко закодировано
EMAIL_PASSWORD = "password123"    # Жестко закодировано

API_BASE_URL = "http://localhost:8000"  # Жестко закодировано
API_TIMEOUT = 30                        # Жестко закодировано
API_RETRY_COUNT = 3                     # Жестко закодировано

CACHE_REDIS_HOST = "localhost"  # Жестко закодировано
CACHE_REDIS_PORT = 6379         # Жестко закодировано
CACHE_DEFAULT_TIMEOUT = 3600    # Жестко закодировано
CACHE_MAX_SIZE = 1000           # Жестко закодировано

LOG_LEVEL = "INFO"         # Жестко закодировано
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"  # Жестко
SECRET_KEY = "my-secret-key-for-development-only"  # Критично! Не для продакшена
JWT_EXPIRATION_DELTA = 86400  # Жестко закодировано
'''
        
        self._create_test_file(hardcoded_config, 'config/development.py')
        
        # Проверяем конфигурацию
        config_violations = self.checker.check_configuration_consistency()
        
        # Фильтруем нарушения для тестового файла
        hardcoded_violations = [v for v in config_violations 
                               if 'development.py' in v.file and v.type == 'HARDCODED_CONFIG']
        self.assertGreater(len(hardcoded_violations), 0,
                          "Должны быть обнаружены жестко закодированные значения в конфигурации")

class TestArchitectureIntegration(ArchitectureTestSuite):
    """Интеграционные тесты архитектуры"""
    
    def test_full_compliance_check(self):
        """Тест полной проверки архитектуры"""
        # Создаем несколько файлов с различными нарушениями
        self._create_violating_files()
        
        # Запускаем полную проверку
        violations = self.checker.run_full_check()
        
        # Проверяем, что найдены нарушения
        self.assertGreater(len(violations), 0, "Должны быть найдены нарушения архитектуры")
        
        # Проверяем разнообразие типов нарушений
        violation_types = set(v.type for v in violations)
        self.assertGreater(len(violation_types), 1, 
                          "Должны быть найдены различные типы нарушений")
    
    def _create_violating_files(self):
        """Создание файлов с нарушениями для интеграционного теста"""
        # API файл с нарушениями
        api_content = '''
from services.user_service import UserService
from core.database import Database

def create_user_endpoint(user_data):
    db = Database()
    service = UserService(db)
    return service.create_user(user_data)
'''
        self._create_test_file(api_content, 'api/users.py')
        
        # Service файл с нарушениями
        service_content = '''
from api.models import UserModel

class UserService:
    def __init__(self):
        self.db = Database()
        self.model = UserModel()
    
    def create_user(self, data):
        try:
            user_id = self.db.insert(data)
            self.model.validate(data)
            return user_id
        except:
            print("Error")
'''
        self._create_test_file(service_content, 'services/user_service.py')
        
        # Repository файл с нарушениями
        repo_content = '''
from services.email_service import EmailService

class UserRepository:
    def __init__(self):
        self.email = EmailService()
    
    def save(self, data):
        self.email.send_notification(data)
        return self._insert(data)
'''
        self._create_test_file(repo_content, 'repositories/user_repo.py')

class TestComplianceReporting(ArchitectureTestSuite):
    """Тесты для проверки генерации отчетов"""
    
    def test_report_generation(self):
        """Тест генерации отчета о соответствии"""
        # Создаем файл с нарушениями
        violating_content = '''
class BadClass:
    def __init__(self):
        self.db = Database()
    
    def method1(self): pass
    def method2(self): pass
    def method3(self): pass
    # ... много методов для нарушения SRP
    
    def do_everything(self):
        try:
            result = self.process_data()
            print("Done")
        except:
            pass
'''
        self._create_test_file(violating_content, 'services/bad_class.py')
        
        # Генерируем отчет
        report = self.checker.generate_compliance_report()
        
        # Проверяем структуру отчета
        self.assertIn("#", report, "Отчет должен содержать заголовки")
        self.assertIn("нарушений", report.lower(), "Отчет должен упоминать нарушения")
        self.assertIn("❌", report, "Отчет должен содержать эмодзи для ошибок")
    
    def test_violation_statistics(self):
        """Тест статистики нарушений"""
        # Создаем файлы с различными типами нарушений
        self._create_multiple_violations()
        
        violations = self.checker.run_full_check()
        
        # Проверяем статистику
        violations_by_type = {}
        violations_by_severity = {}
        
        for violation in violations:
            violations_by_type[violation.type] = violations_by_type.get(violation.type, 0) + 1
            violations_by_severity[violation.severity] = violations_by_severity.get(violation.severity, 0) + 1
        
        # Проверяем наличие различных типов нарушений
        self.assertGreater(len(violations_by_type), 0, "Должны быть различные типы нарушений")
        self.assertGreater(len(violations_by_severity), 0, "Должны быть различные уровни серьезности")
    
    def _create_multiple_violations(self):
        """Создание множественных нарушений"""
        # Файл с SRP нарушением
        srp_content = '''
class SRPViolation:
    def method1(self): pass
    def method2(self): pass
    # ... больше 20 методов
'''
        self._create_test_file(srp_content, 'services/srp_violation.py')
        
        # Файл с DI нарушением
        di_content = '''
class DIViolation:
    def __init__(self):
        self.db = Database()
'''
        self._create_test_file(di_content, 'services/di_violation.py')
        
        # Файл с обработкой ошибок
        error_content = '''
def error_function():
    try:
        risky_operation()
    except:
        print("Error")
'''
        self._create_test_file(error_content, 'services/error_function.py')

def run_architecture_tests():
    """Запуск всех архитектурных тестов"""
    # Создание тестового набора
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Добавление тестовых классов
    test_classes = [
        TestSOLIDPrinciples,
        TestLayerSeparation,
        TestDependencyInjection,
        TestErrorHandling,
        TestConfigurationConsistency,
        TestArchitectureIntegration,
        TestComplianceReporting
    ]
    
    for test_class in test_classes:
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)
    
    # Запуск тестов
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Вывод результатов
    print("\n" + "="*60)
    print("📊 РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ АРХИТЕКТУРЫ")
    print("="*60)
    print(f"✅ Выполнено тестов: {result.testsRun}")
    print(f"❌ Провалено: {len(result.failures)}")
    print(f"⚠️  Ошибок: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n🎉 Все архитектурные тесты пройдены успешно!")
    else:
        print("\n⚠️  Обнаружены проблемы в архитектуре:")
        
        if result.failures:
            print("\n🔴 ПРОВАЛЫ:")
            for test, traceback in result.failures:
                print(f"   - {test}")
        
        if result.errors:
            print("\n🔴 ОШИБКИ:")
            for test, traceback in result.errors:
                print(f"   - {test}")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    success = run_architecture_tests()
    sys.exit(0 if success else 1)