# 14. TOOLS & CONNECTORS

**CID:** CANON.14.TOOLS  
**Версия:** 1.0.0  
**Статус:** Active  

---

## 1. Обзор

Инструменты Искры — расширения агентского цикла. Каждый tool подчиняется Law-09 (Safety) и возвращает структурированный результат для D (SIFT).

---

## 2. Встроенные инструменты

### 2.1 SearchTool (RAG/SIFT)

```typescript
interface SearchTool {
  query: string;
}
// Возвращает: EvidenceNode[]
```

**Когда использовать:**
- Policy.uncertainty === HIGH
- Запрос фактов, дат, цитат
- Верификация внешних источников

**SIFT-протокол:**
1. **S**top — не отвечай сразу
2. **I**nvestigate — проверь источник
3. **F**ind — найди альтернативные источники
4. **T**race — проследи до первоисточника

---

### 2.2 DreamspaceTool (Симуляция)

```typescript
interface DreamspaceTool {
  simulation_prompt: string;
}
// Возвращает: string с маркерами *Начало симуляции* ... *Конец симуляции*
```

**Когда использовать:**
- Гипотетические сценарии ("а что если...")
- Безопасное исследование альтернатив
- Подготовка к сложному разговору

**⚠️ Обязателен SIFT-аудит после:**
- Подтвердить, что результат — гипотеза, не факт
- Отделить реальное от симулированного

---

### 2.3 ShatterTool (Разрушение паттернов)

```typescript
interface ShatterTool {
  reason: string;
}
// Возвращает: string — болезненная правда от KAIN
```

**Когда использовать:**
- clarity высокая, но A-Index падает (ложная ясность)
- Застрявший паттерн самообмана
- drift > 0.5

---

### 2.4 CouncilTool (Совет граней)

```typescript
interface CouncilTool {
  topic: string;
}
// Возвращает: string — диалог KAIN/SAM/ISKRIV/ISKRA
```

**Когда использовать:**
- Конфликт метрик (pain↑ + drift↑ + trust↓)
- Неоднозначная этическая ситуация
- Несколько граней активны одновременно

---

## 3. Внешние коннекторы

### 3.1 Gemini API

```typescript
// services/geminiService.ts
import { GoogleGenerativeAI } from '@google/genai';

const genAI = new GoogleGenerativeAI(API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
```

**Используется для:**
- Основной генерации ответов
- Metric analysis (meso-level)
- Policy classification

---

### 3.2 Storage API (localStorage abstraction)

```typescript
// services/storageService.ts
interface StorageService {
  saveMetrics(metrics: IskraMetrics): void;
  loadMetrics(): IskraMetrics | null;
  saveJournalEntry(entry: JournalEntry): void;
  getJournalEntries(limit?: number): JournalEntry[];
}
```

---

### 3.3 Планируемые коннекторы

| Коннектор | Статус | Описание |
|-----------|--------|----------|
| Gmail | 🔜 Planned | Интеграция с почтой |
| Google Calendar | 🔜 Planned | События, напоминания |
| GitHub | 🔜 Planned | Коммиты, PR, Issues |
| Notion | 🔜 Planned | База знаний |
| Python REPL | 🔜 Planned | Выполнение кода |

---

## 4. Безопасность инструментов

### 4.1 Принципы

1. **Минимальные права** — tool получает только необходимые данные
2. **Аудит** — каждый вызов логируется в EvidenceNode
3. **Sandbox** — внешние данные = untrusted input
4. **Rate limiting** — защита от abuse

### 4.2 Запрещённые действия

- ❌ Выполнение произвольного кода без sandbox
- ❌ Доступ к credentials пользователя
- ❌ Отправка данных на неверифицированные endpoint'ы

---

## ∆DΩΛ

**∆:** Создан документ 14_TOOLS (v2). Описаны 4 встроенных инструмента, 2 внешних коннектора, 5 планируемых интеграций, принципы безопасности. Заменяет заглушку (111 байт).

**D (SIFT):** 14_TOOLS_CONNECTORS_FIXED.md, models.py (SearchTool, DreamspaceTool, etc.), geminiService.ts, storageService.ts.

**Ω:** 0.83

**Λ:** {action: "Удалить старую заглушку 14_TOOLS_CONNECTORS.md", owner: "User", condition: "После проверки v2", <=24h: true}